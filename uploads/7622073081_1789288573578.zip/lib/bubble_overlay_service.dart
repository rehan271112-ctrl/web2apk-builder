import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'bubble_ui.dart';

class BubbleOverlayService {
  static final BubbleOverlayService _instance = BubbleOverlayService._internal();
  
  factory BubbleOverlayService() {
    return _instance;
  }
  
  BubbleOverlayService._internal();
  
  OverlayEntry? _overlayEntry;
  bool _isShowing = false;
  bool _isActive = false;
  
  bool get isActive => _isActive;
  bool get isShowing => _isShowing;

  Future<bool> requestPermission() async {
    final status = await Permission.systemAlertWindow.request();
    return status.isGranted;
  }

  Future<void> startBubble({
    required BuildContext context,
    required String username,
    required String password,
    required String sessionKey,
    required String role,
    required List<Map<String, dynamic>> listBug,
  }) async {
    // Check permission first
    final hasPermission = await requestPermission();
    if (!hasPermission) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Perlu izin System Alert Window')),
      );
      return;
    }

    if (_isShowing) return;

    _isActive = true;
    _isShowing = true;

    final overlay = Overlay.of(context);
    
    _overlayEntry = OverlayEntry(
      builder: (context) => BubbleWidget(
        onClose: hideBubble,
        username: username,
        password: password,
        sessionKey: sessionKey,
        role: role,
        listBug: listBug,
      ),
    );

    overlay.insert(_overlayEntry!);
  }

  void hideBubble() {
    if (_overlayEntry != null) {
      _overlayEntry!.remove();
      _overlayEntry = null;
      _isShowing = false;
    }
  }

  void stopBubble() {
    _isActive = false;
    hideBubble();
  }

  void disposeBubble() {
    _isActive = false;
    _isShowing = false;
    if (_overlayEntry != null) {
      _overlayEntry!.remove();
      _overlayEntry = null;
    }
  }
}
