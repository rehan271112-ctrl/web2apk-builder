import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';

class BubbleWidget extends StatefulWidget {
  final VoidCallback onClose;
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final List<Map<String, dynamic>> listBug;

  const BubbleWidget({
    Key? key,
    required this.onClose,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.listBug,
  }) : super(key: key);

  @override
  State<BubbleWidget> createState() => _BubbleWidgetState();
}

class _BubbleWidgetState extends State<BubbleWidget> with SingleTickerProviderStateMixin {
  late Offset _offset;
  late Size _screenSize;
  bool _isExpanded = false;
  bool _isHiddenAtEdge = false;
  late AnimationController _expandController;
  
  String _selectedBugId = "";
  String _selectedBugMode = "number";
  String _senderType = "private";
  String _targetNumber = "";
  String _responseMessage = "";
  bool _isSending = false;
  bool _isLoadingSenders = false;
  
  int _globalSenderCount = 0;
  int _privateSenderCount = 0;

  @override
  void initState() {
    super.initState();
    _expandController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    
    // Set first bug as default
    if (widget.listBug.isNotEmpty) {
      _selectedBugId = widget.listBug[0]['bug_id'] ?? "";
    }
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _screenSize = MediaQuery.of(context).size;
      _offset = Offset(
        _screenSize.width - 80,
        _screenSize.height / 2 - 40,
      );
      _fetchActiveSenders();
    });
  }

  @override
  void dispose() {
    _expandController.dispose();
    super.dispose();
  }

  // Fetch MySender status (Global & Private senders)
  Future<void> _fetchActiveSenders() async {
    setState(() => _isLoadingSenders = true);

    try {
      final res = await http.get(
        Uri.parse("$apiBaseUrl/mySender?key=${widget.sessionKey}"),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        if (data["valid"] == true) {
          final globalConnections = data["globalConnections"] as List<dynamic>? ?? [];
          final privateConnections = data["privateConnections"] as List<dynamic>? ?? [];
          
          setState(() {
            _globalSenderCount = globalConnections.length;
            _privateSenderCount = privateConnections.length;
          });
        } else {
          setState(() {
            _globalSenderCount = 0;
            _privateSenderCount = 0;
          });
        }
      }
    } catch (e) {
      setState(() {
        _globalSenderCount = 0;
        _privateSenderCount = 0;
      });
    } finally {
      setState(() => _isLoadingSenders = false);
    }
  }

  void _toggleExpand() {
    setState(() {
      _isExpanded = !_isExpanded;
      if (_isExpanded) {
        _expandController.forward();
      } else {
        _expandController.reverse();
      }
    });
  }

  void _onBubbleDrag(DragUpdateDetails details) {
    setState(() {
      _offset = Offset(
        _offset.dx + details.delta.dx,
        _offset.dy + details.delta.dy,
      );
      
      _isHiddenAtEdge = _offset.dx > _screenSize.width - 40;
    });
  }

  void _onDragEnd(DragEndDetails details) {
    if (_offset.dx > _screenSize.width - 100) {
      setState(() {
        _offset = Offset(_screenSize.width - 35, _offset.dy);
        _isHiddenAtEdge = true;
      });
    } else if (_offset.dx < 50) {
      setState(() {
        _offset = Offset(-35 + 20, _offset.dy);
        _isHiddenAtEdge = true;
      });
    }
  }

  Future<void> _sendBug() async {
    final rawInput = _targetNumber.trim();
    final key = widget.sessionKey;

    if (rawInput.isEmpty || _selectedBugId.isEmpty) {
      setState(() {
        _responseMessage = "❌ Nomor atau Bug tidak boleh kosong!";
      });
      return;
    }

    // Validate Global Sender access
    if (_senderType == 'global') {
      final role = widget.role.toLowerCase();
      final canAccessGlobal = role == 'owner' || role == 'admin' || role == 'dev' || role == 'ghost' || role == 'vip';
      
      if (!canAccessGlobal) {
        setState(() {
          _responseMessage = "❌ Global Sender hanya untuk Owner, Admin, Dev & VIP!";
        });
        return;
      }
      
      if (_globalSenderCount == 0) {
        setState(() {
          _responseMessage = "❌ Tidak ada Global Sender aktif (Status: 0)";
        });
        return;
      }
    } else {
      if (_privateSenderCount == 0) {
        setState(() {
          _responseMessage = "❌ Tidak ada Private Sender aktif (Status: 0)";
        });
        return;
      }
    }

    setState(() {
      _isSending = true;
      _responseMessage = "⏳ Mengirim...";
    });

    try {
      late Uri url;
      
      // Determine endpoint based on bug mode
      if (_selectedBugMode == "group") {
        url = Uri.parse(
          "$apiBaseUrl/sendGroupBug?key=$key&link=$rawInput&bug=$_selectedBugId&senderType=$_senderType"
        );
      } else {
        url = Uri.parse(
          "$apiBaseUrl/sendBug?key=$key&target=$rawInput&bug=$_selectedBugId&senderType=$_senderType"
        );
      }

      final response = await http.get(url).timeout(const Duration(seconds: 30));

      if (!mounted) return;

      final data = jsonDecode(response.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Tunggu sebentar sebelum coba lagi");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Session expired. Login ulang!");
      } else if (data["sended"] == false) {
        final message = data["message"] ?? "⚠️ Gagal mengirim bug";
        setState(() => _responseMessage = message);
      } else {
        setState(() => _responseMessage = "✅ Bug berhasil dikirim!");
        _targetNumber = "";
      }
    } catch (e) {
      setState(() => _responseMessage = "❌ Error: $e");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_screenSize == null) {
      return const SizedBox.shrink();
    }

    return Stack(
      children: [
        // Bubble mungil
        Positioned(
          left: _offset.dx,
          top: _offset.dy,
          child: GestureDetector(
            onPanUpdate: _onBubbleDrag,
            onPanEnd: _onDragEnd,
            onTap: _toggleExpand,
            child: Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: const Color(0xFFE91E8C),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFE91E8C).withOpacity(0.5),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Material(
                color: Colors.transparent,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Icon(
                      Icons.bug_report_rounded,
                      color: Colors.white,
                      size: 35,
                    ),
                    if (_isSending)
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            Colors.white.withOpacity(0.7),
                          ),
                          strokeWidth: 2,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),

        // Panel expanded
        if (_isExpanded)
          Positioned(
            left: 20,
            right: 20,
            top: _offset.dy - 350,
            child: _buildExpandedPanel(),
          ),
      ],
    );
  }

  Widget _buildExpandedPanel() {
    return Material(
      color: Colors.transparent,
      child: ScaleTransition(
        scale: Tween<double>(begin: 0.8, end: 1.0).animate(_expandController),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: const Color(0xFF141414),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: const Color(0xFFE91E8C).withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFE91E8C).withOpacity(0.2),
                blurRadius: 20,
                spreadRadius: 3,
              ),
            ],
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "KIRIM BUG",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFFE91E8C),
                        letterSpacing: 2,
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        _toggleExpand();
                        widget.onClose();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.white30,
                            width: 1.5,
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.close,
                          color: Colors.white70,
                          size: 18,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Target input
                TextField(
                  onChanged: (val) => setState(() => _targetNumber = val),
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: "Nomor target (62xxx / https://...)",
                    hintStyle: TextStyle(color: Colors.white38),
                    prefixIcon: const Icon(Icons.phone, color: Color(0xFFE91E8C), size: 18),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: Color(0xFFE91E8C)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(
                        color: const Color(0xFFE91E8C).withOpacity(0.3),
                      ),
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  ),
                ),
                const SizedBox(height: 12),

                // Bug Mode Selector
                const Text(
                  "MODE",
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Colors.white70,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _buildModeButton("NOMOR", "number"),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _buildModeButton("GRUP", "group"),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Bug List
                const Text(
                  "PILIH BUG",
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Colors.white70,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 100,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: widget.listBug.length,
                    itemBuilder: (context, index) {
                      final bug = widget.listBug[index];
                      final bugId = bug['bug_id'] ?? "";
                      final bugName = bug['bug_name'] ?? bug['name'] ?? "Unknown";
                      final isSelected = _selectedBugId == bugId;

                      return GestureDetector(
                        onTap: () => setState(() => _selectedBugId = bugId),
                        child: Container(
                          width: 130,
                          margin: const EdgeInsets.only(right: 8),
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? const Color(0xFFE91E8C).withOpacity(0.2)
                                : Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFFE91E8C)
                                  : Colors.white.withOpacity(0.1),
                              width: isSelected ? 2 : 1,
                            ),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.bug_report_rounded,
                                color: isSelected ? const Color(0xFFE91E8C) : Colors.white70,
                                size: 24,
                              ),
                              const SizedBox(height: 4),
                              Text(
                                bugName,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 9,
                                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                                  color: isSelected ? const Color(0xFFE91E8C) : Colors.white70,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 12),

                // Sender Selector
                const Text(
                  "SENDER",
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Colors.white70,
                    letterSpacing: 1.5,
                  ),
                ),
                const SizedBox(height: 8),
                if (_isLoadingSenders)
                  Center(
                    child: SizedBox(
                      height: 40,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          const Color(0xFFE91E8C).withOpacity(0.7),
                        ),
                      ),
                    ),
                  )
                else
                  Row(
                    children: [
                      Expanded(
                        child: _buildSenderButton(
                          "PRIBADI",
                          "private",
                          _privateSenderCount,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _buildSenderButton(
                          "GLOBAL",
                          "global",
                          _globalSenderCount,
                        ),
                      ),
                    ],
                  ),
                const SizedBox(height: 14),

                // Response message
                if (_responseMessage.isNotEmpty)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE91E8C).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: const Color(0xFFE91E8C).withOpacity(0.3),
                      ),
                    ),
                    child: Text(
                      _responseMessage,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Colors.white70,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                const SizedBox(height: 12),

                // Send button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _isSending ? null : _sendBug,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE91E8C),
                      disabledBackgroundColor: Colors.grey,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      _isSending ? "MENGIRIM..." : "KIRIM BUG SEKARANG",
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModeButton(String label, String value) {
    bool isSelected = _selectedBugMode == value;
    return GestureDetector(
      onTap: () => setState(() => _selectedBugMode = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFFE91E8C).withOpacity(0.2)
              : Colors.white.withOpacity(0.03),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected
                ? const Color(0xFFE91E8C)
                : Colors.white.withOpacity(0.1),
            width: 1.5,
          ),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: isSelected ? const Color(0xFFE91E8C) : Colors.white70,
            letterSpacing: 0.5,
          ),
        ),
      ),
    );
  }

  Widget _buildSenderButton(String label, String value, int count) {
    bool isSelected = _senderType == value;
    bool hasStatus = (value == 'global' && _globalSenderCount > 0) ||
        (value == 'private' && _privateSenderCount > 0);

    return GestureDetector(
      onTap: () => setState(() => _senderType = value),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF25D366).withOpacity(0.2)
              : Colors.white.withOpacity(0.03),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected
                ? const Color(0xFF25D366)
                : Colors.white.withOpacity(0.1),
            width: 1.5,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                color: isSelected ? const Color(0xFF25D366) : Colors.white70,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              hasStatus ? '✓ $count' : '✗ 0',
              style: TextStyle(
                fontSize: 8,
                color: hasStatus ? Colors.green : Colors.red,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
