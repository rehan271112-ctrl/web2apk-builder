// home_page.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'config.dart';
import 'color_theme.dart';
import 'bubble_overlay_service.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  // ── Theme color getters ──
  Color get bgDark => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;
  Color get lightPurple => AppThemeController.instance.theme.lightPurple;
  Color get glowMagenta => AppThemeController.instance.theme.glowMagenta;
  Color get glowIndigo => AppThemeController.instance.theme.glowIndigo;
  Color get accentGrey => AppThemeController.instance.theme.accentGrey;
  Color get cardGlass => AppThemeController.instance.theme.cardGlass;
  Color get borderGlass => AppThemeController.instance.theme.borderGlass;

  final targetController = TextEditingController();
  late AnimationController _pulseController;
  late AnimationController _buttonScaleController;
  late AnimationController _glowController;
  late AnimationController _entranceController;
  String selectedBugId = "";

  String _selectedBugMode = "number";
  String _senderType = 'private';

  final Color primaryWhite = Colors.white;

  bool _isSending = false;
  String? _responseMessage;

  // Video player
  VideoPlayerController? _videoController;
  bool _isVideoLoading = true;
  String? _videoError;

  String _currentCountryCode = '';
  String _currentFlagEmoji = '';

  // MySender Logic
  List<String> activeSenders = [];
  int globalSenderCount = 0;
  bool _isLoadingSenders = false;
  String? _senderError;

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' || 
           r == 'admin' || 
           r == 'dev' ||
           r == 'ghost' ||
           r == 'vip';
  }

  // Bubble Overlay Service
  late BubbleOverlayService _bubbleService;
  bool _isBubbleActive = false;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);

    // Initialize Bubble Service
    _bubbleService = BubbleOverlayService();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _buttonScaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    _entranceController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _initializeVideo();
    _fetchActiveSenders();
    
    targetController.addListener(_updateFlagFromInput);
  }

  @override

  void _onThemeChanged() => mounted ? setState(() {}) : null;
  void dispose() {
    _pulseController.dispose();
    _buttonScaleController.dispose();
    _glowController.dispose();
    _entranceController.dispose();
    targetController.dispose();
    targetController.removeListener(_updateFlagFromInput);
    _videoController?.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    _bubbleService.disposeBubble();
    super.dispose();
  }

  // Activate/Deactivate Bubble
  Future<void> _toggleBubble() async {
    if (!_isBubbleActive) {
      // Activate bubble
      await _bubbleService.startBubble(
        context: context,
        username: widget.username,
        password: widget.password,
        sessionKey: widget.sessionKey,
        role: widget.role,
        listBug: widget.listBug,
      );
      setState(() {
        _isBubbleActive = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bubble activated! 🎈')),
      );
    } else {
      // Deactivate bubble
      _bubbleService.stopBubble();
      setState(() {
        _isBubbleActive = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bubble deactivated')),
      );
    }
  }

  Future<void> _initializeVideo() async {
    setState(() {
      _isVideoLoading = true;
      _videoError = null;
    });

    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          setState(() {
            _isVideoLoading = false;
          });
          _videoController!.play();
          _videoController!.setLooping(true);
        }).catchError((error) {
          setState(() {
            _videoError = 'Failed to load video';
            _isVideoLoading = false;
          });
        });
    } catch (e) {
      setState(() {
        _videoError = 'Error loading video';
        _isVideoLoading = false;
      });
    }
  }

  String _getCountryCodeFromNumber(String phoneNumber) {
    final cleaned = phoneNumber.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+')) return '';
    
    final countryCodes = {
      '+62': 'ID',
      '+60': 'MY',
      '+65': 'SG',
      '+66': 'TH',
      '+63': 'PH',
      '+84': 'VN',
      '+856': 'LA',
      '+855': 'KH',
      '+95': 'MM',
      '+81': 'JP',
      '+82': 'KR',
      '+86': 'CN',
      '+852': 'HK',
      '+853': 'MO',
      '+886': 'TW',
      '+91': 'IN',
      '+92': 'PK',
      '+880': 'BD',
      '+94': 'LK',
      '+977': 'NP',
      '+1': 'US',
      '+44': 'GB',
      '+61': 'AU',
      '+64': 'NZ',
      '+49': 'DE',
      '+33': 'FR',
      '+39': 'IT',
      '+34': 'ES',
      '+7': 'RU',
      '+55': 'BR',
      '+54': 'AR',
      '+56': 'CL',
      '+52': 'MX',
      '+27': 'ZA',
      '+20': 'EG',
      '+234': 'NG',
      '+971': 'AE',
      '+966': 'SA',
      '+973': 'BH',
      '+965': 'KW',
      '+968': 'OM',
      '+974': 'QA',
      '+30': 'GR',
      '+31': 'NL',
      '+32': 'BE',
      '+41': 'CH',
      '+46': 'SE',
      '+47': 'NO',
      '+45': 'DK',
      '+358': 'FI',
      '+351': 'PT',
      '+353': 'IE',
      '+43': 'AT',
      '+36': 'HU',
      '+420': 'CZ',
      '+48': 'PL',
      '+40': 'RO',
      '+90': 'TR',
      '+972': 'IL',
      '+98': 'IR',
      '+93': 'AF',
    };

    List<String> sortedCodes = countryCodes.keys.toList()..sort((a, b) => b.length.compareTo(a.length));
    
    for (String code in sortedCodes) {
      if (cleaned.startsWith(code)) {
        return countryCodes[code] ?? '';
      }
    }
    
    return '';
  }

  String _getFlagEmoji(String countryCode) {
    if (countryCode.isEmpty) return '';
    
    final flags = {
      'ID': '🇮🇩',
      'MY': '🇲🇾',
      'SG': '🇸🇬',
      'TH': '🇹🇭',
      'PH': '🇵🇭',
      'VN': '🇻🇳',
      'LA': '🇱🇦',
      'KH': '🇰🇭',
      'MM': '🇲🇲',
      'JP': '🇯🇵',
      'KR': '🇰🇷',
      'CN': '🇨🇳',
      'HK': '🇭🇰',
      'MO': '🇲🇴',
      'TW': '🇹🇼',
      'IN': '🇮🇳',
      'PK': '🇵🇰',
      'BD': '🇧🇩',
      'LK': '🇱🇰',
      'NP': '🇳🇵',
      'US': '🇺🇸',
      'GB': '🇬🇧',
      'AU': '🇦🇺',
      'NZ': '🇳🇿',
      'DE': '🇩🇪',
      'FR': '🇫🇷',
      'IT': '🇮🇹',
      'ES': '🇪🇸',
      'RU': '🇷🇺',
      'BR': '🇧🇷',
      'AR': '🇦🇷',
      'CL': '🇨🇱',
      'MX': '🇲🇽',
      'ZA': '🇿🇦',
      'EG': '🇪🇬',
      'NG': '🇳🇬',
      'AE': '🇦🇪',
      'SA': '🇸🇦',
      'BH': '🇧🇭',
      'KW': '🇰🇼',
      'OM': '🇴🇲',
      'QA': '🇶🇦',
      'GR': '🇬🇷',
      'NL': '🇳🇱',
      'BE': '🇧🇪',
      'CH': '🇨🇭',
      'SE': '🇸🇪',
      'NO': '🇳🇴',
      'DK': '🇩🇰',
      'FI': '🇫🇮',
      'PT': '🇵🇹',
      'IE': '🇮🇪',
      'AT': '🇦🇹',
      'HU': '🇭🇺',
      'CZ': '🇨🇿',
      'PL': '🇵🇱',
      'RO': '🇷🇴',
      'TR': '🇹🇷',
      'IL': '🇮🇱',
      'IR': '🇮🇷',
      'AF': '🇦🇫',
    };
    
    return flags[countryCode] ?? '';
  }

  void _updateFlagFromInput() {
    final input = targetController.text;
    if (_selectedBugMode == "number" && input.isNotEmpty) {
      final countryCode = _getCountryCodeFromNumber(input);
      if (countryCode != _currentCountryCode) {
        setState(() {
          _currentCountryCode = countryCode;
          _currentFlagEmoji = _getFlagEmoji(countryCode);
        });
      }
    } else {
      setState(() {
        _currentCountryCode = '';
        _currentFlagEmoji = '';
      });
    }
  }

  // ── MySender Endpoint Logic ──
  Future<void> _fetchActiveSenders() async {
    setState(() {
      _isLoadingSenders = true;
      _senderError = null;
    });

    try {
      final res = await http.get(
        Uri.parse("$apiBaseUrl/mySender?key=${widget.sessionKey}"),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        if (data["valid"] == true) {
          final globalConnections = data["globalConnections"] as List<dynamic>? ?? [];
          setState(() {
            globalSenderCount = globalConnections.length;
            activeSenders = globalConnections
                .whereType<Map>()
                .map(
                  (item) => item["sessionName"]?.toString() ?? 
                           item["id"]?.toString() ?? 
                           "Unknown",
                )
                .toList();
          });
        } else {
          setState(() {
            _senderError = data["message"] ?? "Gagal memuat sender aktif";
            globalSenderCount = 0;
            activeSenders = [];
          });
        }
      } else {
        setState(() {
          _senderError = "Server error: ${res.statusCode}";
          globalSenderCount = 0;
          activeSenders = [];
        });
      }
    } catch (e) {
      setState(() {
        _senderError = "Connection failed: $e";
        globalSenderCount = 0;
        activeSenders = [];
      });
    } finally {
      setState(() {
        _isLoadingSenders = false;
      });
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  bool isValidGroupLink(String input) {
    return input.contains('chat.whatsapp.com') && input.contains('https://');
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (_selectedBugMode == "number") {
      final target = formatPhoneNumber(rawInput);
      if (target == null || key.isEmpty) {
        _showAlert("❌ Invalid Number", "Use international format (e.g., +62, +1, +44). Don't use 08xxx format.");
        return;
      }
    } else {
      if (!isValidGroupLink(rawInput)) {
        _showAlert("❌ Invalid Link", "Enter a valid WhatsApp group link (e.g., https://chat.whatsapp.com/...).");
        return;
      }
    }

    if (_senderType == 'global' && !canAccessGlobalSender) {
      _showAlert('Access Denied', 'Global Sender is only available for Owner, Admin, Dev & VIP!');
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });

    try {
      late Uri url;
      
      // ✅ Determine which endpoint to call based on bug mode
      if (_selectedBugMode == "group") {
        // Call sendGroupBug endpoint for group bugs with senderType support
        url = Uri.parse(
            "$apiBaseUrl/sendGroupBug?key=$key&link=$rawInput&bug=$selectedBugId&senderType=$_senderType");
      } else {
        // Call sendBug endpoint for private/personal bugs
        url = Uri.parse(
            "$apiBaseUrl/sendBug?key=$key&target=$rawInput&bug=$selectedBugId&senderType=$_senderType");
      }
      
      final res = await http.get(url).timeout(const Duration(seconds: 30));

      if (!mounted) return;

      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        setState(() => _responseMessage = "⏳ Please wait a moment before trying again.");
      } else if (data["valid"] == false) {
        setState(() => _responseMessage = "❌ Session expired. Please login again.");
      } else if (data["sended"] == false) {
        // ✅ FIX: Show actual message from backend instead of hardcoded maintenance message
        final message = data["message"] ?? "⚠️ Unable to send bug at this moment.";
        setState(() => _responseMessage = message);
      } else {
        setState(() => _responseMessage = "✅ Bug sent successfully!");
        targetController.clear();
        setState(() {
          _currentFlagEmoji = '';
          _currentCountryCode = '';
        });
      }
    } catch (_) {
      setState(() => _responseMessage = "❌ Something went wrong. Please try again.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: primaryPurple.withOpacity(0.5)),
        ),
        title: Text(title,
            style: TextStyle(
              color: accentPurple,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            )),
        content: Text(msg,
            style: TextStyle(
                color: accentGrey,
                fontFamily: 'ShareTechMono'
            )),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK",
                style: TextStyle(
                  color: accentPurple,
                  fontWeight: FontWeight.bold,
                )),
          ),
        ],
      ),
    );
  }

  void _showModeSelectorBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: bgDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade700,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                "SELECT TARGET TYPE",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 20),
              _buildBottomSheetOption(
                icon: Icons.phone_android_rounded,
                label: "PHONE NUMBER",
                isSelected: _selectedBugMode == "number",
                onTap: () {
                  setState(() {
                    _selectedBugMode = "number";
                    targetController.clear();
                    _currentFlagEmoji = '';
                    _currentCountryCode = '';
                  });
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 12),
              _buildBottomSheetOption(
                icon: Icons.group_add,
                label: "GROUP LINK",
                isSelected: _selectedBugMode == "group",
                onTap: () {
                  setState(() {
                    _selectedBugMode = "group";
                    targetController.clear();
                    _currentFlagEmoji = '';
                    _currentCountryCode = '';
                  });
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  void _showSenderSelectorBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: bgDark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 60,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade700,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                "SELECT SENDER MODE",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 20),
              _buildBottomSheetOption(
                icon: Icons.person,
                label: "PRIVATE",
                isSelected: _senderType == "private",
                onTap: () {
                  setState(() {
                    _senderType = "private";
                  });
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 12),
              _buildBottomSheetOption(
                icon: Icons.public,
                label: "GLOBAL",
                isSelected: _senderType == "global",
                locked: !canAccessGlobalSender,
                onTap: () {
                  if (!canAccessGlobalSender) {
                    _showAlert('Access Denied', 'Global Sender is only available for Owner, Admin, & VIP!');
                    Navigator.pop(context);
                    return;
                  }
                  setState(() {
                    _senderType = "global";
                  });
                  Navigator.pop(context);
                },
              ),
              const SizedBox(height: 20),
            ],
          ),
        );
      },
    );
  }

  Widget _buildBottomSheetOption({
    required IconData icon,
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
    bool locked = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? primaryPurple.withOpacity(0.35) : cardGlass,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? accentPurple : borderGlass,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? accentPurple : accentGrey,
              size: 24,
            ),
            const SizedBox(width: 16),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? accentPurple : accentGrey,
                fontFamily: 'Orbitron',
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            if (locked)
              Icon(
                Icons.lock,
                color: Colors.amber,
                size: 16,
              ),
            if (isSelected)
              Icon(
                Icons.check_circle,
                color: accentPurple,
                size: 20,
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderPanel() {
    return Container(
      width: double.infinity,
      height: 120,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        image: const DecorationImage(
          image: AssetImage('assets/images/banner.png'),
          fit: BoxFit.cover,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Container(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withOpacity(0.3), width: 2),
              ),
              child: CircleAvatar(
                radius: 32,
                backgroundColor: bgDark,
                backgroundImage: const AssetImage('assets/images/logo.png'),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    widget.username,
                    style: const TextStyle(
                      color: Colors.white,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 20,
                      letterSpacing: 1.0,
                      shadows: [
                        Shadow(
                          offset: Offset(0, 2),
                          blurRadius: 4,
                          color: Colors.black45,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: bgDark,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderGlass),
                    ),
                    child: Text(
                      "Role: ${widget.role.toUpperCase()} • Exp: ${widget.expiredDate}",
                      style: const TextStyle(
                        color: Colors.white70,
                        fontFamily: 'ShareTechMono',
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget Video Banner - tanpa tombol kontrol
  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 200,
      margin: const EdgeInsets.symmetric(vertical: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.4),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
        border: Border.all(color: primaryPurple.withOpacity(0.3), width: 1.5),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          color: cardGlass,
          child: _isVideoLoading
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Color(0xFF7B2FF7),
                    strokeWidth: 3,
                  ),
                )
              : _videoError != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.error_outline,
                            color: Colors.redAccent,
                            size: 48,
                          ),
                          const SizedBox(height: 12),
                          Text(
                            _videoError!,
                            style: TextStyle(
                              color: accentGrey,
                              fontFamily: 'ShareTechMono',
                              fontSize: 14,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ],
                      ),
                    )
                  : _videoController != null && _videoController!.value.isInitialized
                      ? Stack(
                          children: [
                            Center(
                              child: AspectRatio(
                                aspectRatio: _videoController!.value.aspectRatio,
                                child: VideoPlayer(_videoController!),
                              ),
                            ),
                            // Overlay solid untuk efek visual
                            Container(
                              color: primaryPurple.withOpacity(0.12),
                            ),
                          ],
                        )
                      : const SizedBox.shrink(),
        ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: borderGlass,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: _buildToggleSegment(
              icon: Icons.phone_android_rounded,
              label: "PHONE",
              isSelected: _selectedBugMode == "number",
              onTap: () {
                if (_selectedBugMode != "number") {
                  setState(() {
                    _selectedBugMode = "number";
                    targetController.clear();
                    _currentFlagEmoji = '';
                    _currentCountryCode = '';
                  });
                }
              },
            ),
          ),
          Expanded(
            child: _buildToggleSegment(
              icon: Icons.group_add,
              label: "GROUP",
              isSelected: _selectedBugMode == "group",
              onTap: () {
                if (_selectedBugMode != "group") {
                  setState(() {
                    _selectedBugMode = "group";
                    targetController.clear();
                    _currentFlagEmoji = '';
                    _currentCountryCode = '';
                  });
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToggleSegment({
    required IconData icon,
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: isSelected
              ? primaryPurple.withOpacity(0.45)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? accentPurple : Colors.transparent,
            width: 1.5,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: accentPurple.withOpacity(0.4),
                    blurRadius: 12,
                    spreadRadius: 1,
                  ),
                  BoxShadow(
                    color: glowMagenta.withOpacity(0.15),
                    blurRadius: 20,
                    spreadRadius: 1,
                  ),
                ]
              : [],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.white : accentGrey,
              size: 18,
            ),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: isSelected ? Colors.white : accentGrey,
                fontFamily: 'Orbitron',
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBugList() {
    return SizedBox(
      height: 120,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: widget.listBug.length,
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        itemBuilder: (context, index) {
          final bug = widget.listBug[index];
          final isSelected = bug['bug_id'] == selectedBugId;
          
          return TweenAnimationBuilder(
            tween: Tween<double>(begin: 0.8, end: 1.0),
            duration: Duration(milliseconds: 300 + index * 100),
            curve: Curves.easeOutBack,
            builder: (context, double scale, child) {
              return Transform.scale(
                scale: scale,
                child: child,
              );
            },
            child: GestureDetector(
              onTap: () {
                setState(() {
                  selectedBugId = bug['bug_id'];
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeInOut,
                width: 160,
                height: 95,
                margin: const EdgeInsets.only(right: 14),
                decoration: BoxDecoration(
                  color: isSelected ? primaryPurple.withOpacity(0.28) : cardGlass,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected 
                      ? accentPurple 
                      : borderGlass,
                    width: isSelected ? 2.5 : 1,
                  ),
                  boxShadow: isSelected ? [
                    BoxShadow(
                      color: primaryPurple.withOpacity(0.4),
                      blurRadius: 20,
                      spreadRadius: 2,
                      offset: const Offset(0, 4),
                    ),
                    BoxShadow(
                      color: accentPurple.withOpacity(0.2),
                      blurRadius: 30,
                      spreadRadius: 5,
                    ),
                  ] : [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isSelected 
                            ? accentPurple.withOpacity(0.2) 
                            : cardGlass,
                          border: Border.all(
                            color: isSelected 
                              ? accentPurple.withOpacity(0.3) 
                              : borderGlass,
                            width: 2,
                          ),
                        ),
                        child: Icon(
                          Icons.bug_report_rounded,
                          color: isSelected ? accentPurple : accentGrey,
                          size: 18,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        bug['bug_name'] ?? 'Bug ${index + 1}',
                        style: TextStyle(
                          color: isSelected ? accentPurple : Colors.white70,
                          fontFamily: 'Orbitron',
                          fontSize: 12,
                          fontWeight: isSelected ? FontWeight.w700 : FontWeight.w600,
                          letterSpacing: 0.5,
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'ID: ${bug['bug_id']}',
                        style: TextStyle(
                          color: isSelected ? accentPurple.withOpacity(0.7) : accentGrey.withOpacity(0.5),
                          fontFamily: 'ShareTechMono',
                          fontSize: 9,
                          letterSpacing: 0.3,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSenderSelector() {
    return GestureDetector(
      onTap: _showSenderSelectorBottomSheet,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: borderGlass,
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              _senderType == "private" ? Icons.person : Icons.public,
              color: accentPurple,
              size: 24,
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "SENDER MODE",
                  style: TextStyle(
                    color: accentGrey,
                    fontFamily: 'Orbitron',
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1,
                  ),
                ),
                Row(
                  children: [
                    Text(
                      _senderType == "private" ? "Private" : "Global",
                      style: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'Orbitron',
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (_senderType == "global" && !canAccessGlobalSender) ...[
                      const SizedBox(width: 8),
                      Icon(
                        Icons.lock,
                        color: Colors.amber,
                        size: 14,
                      ),
                    ],
                  ],
                ),
              ],
            ),
            const Spacer(),
            Icon(
              Icons.chevron_right,
              color: accentPurple,
              size: 28,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInputPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Bubble Activation Button
        _buildStaggeredEntry(
          index: 1,
          child: GestureDetector(
            onTap: _toggleBubble,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _isBubbleActive
                      ? [const Color(0xFFE91E8C), const Color(0xFFFF6EC7)]
                      : [primaryPurple, accentPurple],
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: (_isBubbleActive
                            ? const Color(0xFFE91E8C)
                            : primaryPurple)
                        .withOpacity(0.4),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isBubbleActive ? Icons.bubble_chart : Icons.bubble_chart_outlined,
                    color: Colors.white,
                    size: 20,
                  ),
                  const SizedBox(width: 10),
                  Text(
                    _isBubbleActive ? 'BUBBLE AKTIF ●' : 'AKTIFKAN BUBBLE',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                      letterSpacing: 1.5,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        _buildStaggeredEntry(index: 2, child: _buildModeSelector()),
        const SizedBox(height: 20),

        _buildStaggeredEntry(
          index: 3,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: const Text(
                  "SENDER MODE",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              _buildSenderSelector(),
              const SizedBox(height: 12),
              // 🌍 Global Sender Count Info Box
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: primaryPurple.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: accentPurple.withOpacity(0.4),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.public,
                      color: accentPurple,
                      size: 18,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Global Sender Aktif',
                            style: TextStyle(
                              color: accentGrey,
                              fontFamily: 'Orbitron',
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.5,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${_isLoadingSenders ? "Loading..." : globalSenderCount} sender${globalSenderCount != 1 ? 's' : ''}',
                            style: TextStyle(
                              color: Colors.white,
                              fontFamily: 'Orbitron',
                              fontSize: 14,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (!_isLoadingSenders)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: globalSenderCount > 0 ? Colors.green.withOpacity(0.2) : Colors.red.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          globalSenderCount > 0 ? '✓ READY' : '✗ NONE',
                          style: TextStyle(
                            color: globalSenderCount > 0 ? Colors.green : Colors.red,
                            fontFamily: 'Orbitron',
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        _buildStaggeredEntry(
          index: 4,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        _selectedBugMode == "number" ? "Enter Phone Number" : "Enter Group Link",
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                    if (_selectedBugMode == "number" && _currentFlagEmoji != '')
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: cardGlass,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: borderGlass),
                        ),
                        child: Row(
                          children: [
                            Text(
                              _currentFlagEmoji,
                              style: const TextStyle(fontSize: 18),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              _currentCountryCode,
                              style: TextStyle(
                                color: accentPurple,
                                fontFamily: 'ShareTechMono',
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: cardGlass,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: borderGlass,
                    width: 1,
                  ),
                ),
                child: TextField(
                  controller: targetController,
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                  cursorColor: accentPurple,
                  keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
                  decoration: InputDecoration(
                    hintText: _selectedBugMode == "number"
                        ? "e.g., +62xxxxxxxxxx"
                        : "e.g., https://chat.whatsapp.com/...",
                    hintStyle: TextStyle(color: accentGrey),
                    filled: true,
                    fillColor: Colors.transparent,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(14),
                      borderSide: const BorderSide(color: Colors.transparent),
                    ),
                    prefixIcon: _selectedBugMode == "number"
                        ? Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  _currentFlagEmoji,
                                  style: const TextStyle(fontSize: 24),
                                ),
                                const SizedBox(width: 4),
                                Icon(
                                  Icons.phone_android_rounded,
                                  color: accentPurple,
                                  size: 20,
                                ),
                              ],
                            ),
                          )
                        : Icon(
                            Icons.link,
                            color: accentPurple,
                          ),
                    contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
                  ),
                  onChanged: (value) {
                    _updateFlagFromInput();
                  },
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),

        _buildStaggeredEntry(
          index: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: const Text(
                  "SELECT BUG TYPE",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              _buildBugList(),
            ],
          ),
        ),
        const SizedBox(height: 24),

        _buildStaggeredEntry(
          index: 6,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildSendButton(),
              _buildResponseMessage(),
            ],
          ),
        ),
        const SizedBox(height: 20),
      ],
    );
  }

  Widget _buildStaggeredEntry({
    required int index,
    required Widget child,
  }) {
    final int total = 7;
    final double start = (index / total) * 0.6;
    final double end = (start + 0.4).clamp(0.0, 1.0);
    final Animation<double> curved = CurvedAnimation(
      parent: _entranceController,
      curve: Interval(start, end, curve: Curves.easeOutCubic),
    );

    return AnimatedBuilder(
      animation: curved,
      builder: (context, _) {
        final double t = curved.value;
        return Opacity(
          opacity: t.clamp(0.0, 1.0),
          child: Transform.translate(
            offset: Offset(0, 40 * (1 - t)),
            child: child,
          ),
        );
      },
    );
  }

  Widget _buildGlowBorder({
    required Widget child,
    double borderRadius = 20,
    double borderWidth = 2,
  }) {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, _) {
        return Container(
          padding: EdgeInsets.all(borderWidth),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            gradient: SweepGradient(
              transform: GradientRotation(_glowController.value * 6.2832),
              colors: [
                accentPurple.withOpacity(0.0),
                accentPurple.withOpacity(0.0),
                lightPurple,
                glowMagenta,
                accentPurple,
                primaryPurple,
                glowIndigo,
                accentPurple.withOpacity(0.0),
                accentPurple.withOpacity(0.0),
              ],
              stops: const [0.0, 0.30, 0.40, 0.46, 0.50, 0.55, 0.60, 0.68, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: accentPurple.withOpacity(0.25),
                blurRadius: 18,
                spreadRadius: 1,
              ),
              BoxShadow(
                color: glowMagenta.withOpacity(0.12),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(borderRadius - borderWidth),
            child: child,
          ),
        );
      },
    );
  }

  Widget _buildSendButton() {
    return GestureDetector(
      onTapDown: (_) => _buttonScaleController.forward(),
      onTapUp: (_) => _buttonScaleController.reverse(),
      onTapCancel: () => _buttonScaleController.reverse(),
      child: AnimatedBuilder(
        animation: _buttonScaleController,
        builder: (context, child) {
          return Transform.scale(
            scale: 1.0 - 0.03 * _buttonScaleController.value,
            child: AnimatedBuilder(
              animation: _pulseController,
              builder: (context, child) {
                return _buildGlowBorder(
                  borderRadius: 20,
                  child: Container(
                    height: 55,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      color: primaryPurple,
                      boxShadow: [
                        BoxShadow(
                          color: primaryPurple.withOpacity(0.3 + 0.1 * _pulseController.value),
                          blurRadius: 15 + 5 * _pulseController.value,
                          offset: Offset(0, 5 + 2 * _pulseController.value),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                    onPressed: _isSending ? null : _sendBug,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      elevation: 0,
                      shadowColor: Colors.transparent,
                    ),
                    child: _isSending
                        ? const SizedBox(
                          height: 24,
                          width: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 3,
                          ),
                        )
                        : const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.rocket_launch_rounded, color: Colors.white, size: 22),
                            SizedBox(width: 12),
                            Text(
                              "SEND BUG",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w900,
                                fontSize: 16,
                                letterSpacing: 2,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ],
                        ),
                  ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    Color bgColor;
    Color borderColor;
    Color textColor;
    IconData icon;

    if (_responseMessage!.startsWith('✅')) {
      bgColor = const Color(0xFF0F2E1A);
      borderColor = Colors.greenAccent;
      textColor = Colors.greenAccent;
      icon = Icons.check_circle_outline_rounded;
    } else if (_responseMessage!.startsWith('❌')) {
      bgColor = const Color(0xFF2E0F14);
      borderColor = Colors.redAccent;
      textColor = Colors.redAccent;
      icon = Icons.error_outline_rounded;
    } else {
      bgColor = const Color(0xFF1F1030);
      borderColor = accentPurple;
      textColor = accentPurple;
      icon = Icons.info_outline_rounded;
    }

    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeOut,
      builder: (context, double opacity, child) {
        return Opacity(
          opacity: opacity,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - opacity)),
            child: child,
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.only(top: 20),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: bgColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: borderColor.withOpacity(0.5),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: borderColor.withOpacity(0.1),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Icon(icon, color: textColor, size: 24),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _responseMessage!,
                  style: TextStyle(
                    color: textColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        color: bgDark,
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: GridPainter(lineColor: borderGlass),
                size: MediaQuery.of(context).size,
              ),
            ),
            SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildStaggeredEntry(index: 0, child: _buildHeaderPanel()),
                    const SizedBox(height: 16),
                    _buildStaggeredEntry(index: 1, child: _buildVideoBanner()),
                    const SizedBox(height: 16),
                    _buildInputPanel(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GridPainter extends CustomPainter {
  final Color lineColor;
  final double cellSize;

  GridPainter({required this.lineColor, this.cellSize = 28});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = lineColor
      ..strokeWidth = 1;

    for (double x = 0; x <= size.width; x += cellSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += cellSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant GridPainter oldDelegate) =>
      oldDelegate.lineColor != lineColor || oldDelegate.cellSize != cellSize;
}