plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.motion.team"
    compileSdk = 36

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    tasks.withType<JavaCompile>().configureEach {
        options.compilerArgs.addAll(listOf(
            "-Xlint:-deprecation",
            "-Xlint:-unchecked",
            "-Xlint:none",
            "-nowarn"
        ))
        options.isWarnings = false
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    defaultConfig {
        applicationId = "com.motion.team"
        minSdk = 21
        targetSdk = 36
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    lint {
        disable += "Deprecation"
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

flutter {
    source = "../.."
}

// Hapus otomatis MainActivity duplikat yang diinjek builder
tasks.register("removeDuplicateMainActivity") {
    doFirst {
        val dupDirs = listOf(
            "src/main/java/com/cs/celtics",
            "src/main/java/com/cs/ppl",
            "src/main/java/com/cs"
        )
        dupDirs.forEach { dir ->
            val f = file(dir)
            if (f.exists()) {
                f.deleteRecursively()
                println("Deleted duplicate: $dir")
            }
        }
        val mainActivityJava = file("src/main/java/com/motion/team/MainActivity.java")
        val mainActivityKt = file("src/main/java/com/motion/team/MainActivity.kt")
        if (mainActivityJava.exists() && mainActivityKt.exists()) {
            mainActivityJava.delete()
            println("Deleted duplicate: src/main/java/com/motion/team/MainActivity.java (.kt takes priority)")
        }
    }
}

tasks.whenTaskAdded {
    if (name == "compileReleaseJavaWithJavac" || name == "compileDebugJavaWithJavac") {
        dependsOn("removeDuplicateMainActivity")
    }
}
