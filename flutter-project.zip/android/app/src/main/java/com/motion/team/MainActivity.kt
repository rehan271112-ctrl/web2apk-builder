package com.motion.team

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
