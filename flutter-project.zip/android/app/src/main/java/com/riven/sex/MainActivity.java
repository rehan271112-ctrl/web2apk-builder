package com.riven.sex;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;

public class MainActivity extends FlutterActivity {

    // Channel khusus untuk "pilih file dari SEMUA app" (bukan cuma cloud/Drive).
    // Dipakai sebagai pengganti file_picker khusus untuk upload ZIP build APK,
    // karena file_picker (dan sistem Android di sebagian ROM/MIUI) mengarahkan
    // ACTION_GET_CONTENT + CATEGORY_OPENABLE ke DocumentsUI, yang di beberapa
    // device cuma menampilkan akun cloud (Drive/TeraBox) dan menyembunyikan
    // file manager lokal (Pengelola File, Manajer MT, File Manager+, dst).
    private static final String CHANNEL = "com.riven.sex/anyfile_picker";
    private static final int REQ_PICK_ANY_FILE = 9421;
    private MethodChannel.Result pendingResult;

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
            .setMethodCallHandler((call, result) -> {
                if (call.method.equals("pickAnyFile")) {
                    if (pendingResult != null) {
                        result.error("BUSY", "Picker sedang terbuka", null);
                        return;
                    }
                    pendingResult = result;
                    try {
                        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                        intent.setType("*/*");
                        intent.addCategory(Intent.CATEGORY_DEFAULT);
                        // SENGAJA tidak addCategory(Intent.CATEGORY_OPENABLE):
                        // itu yang bikin Android mengalihkan ke DocumentsUI
                        // (list "Buka dari" yang cuma nampilin provider cloud).
                        // Tanpa OPENABLE, dipakai app-chooser biasa yang
                        // menampilkan SEMUA app pemegang ACTION_GET_CONTENT,
                        // termasuk file manager lokal.
                        Intent chooser = Intent.createChooser(intent, "Pilih file ZIP dari...");
                        startActivityForResult(chooser, REQ_PICK_ANY_FILE);
                    } catch (Exception e) {
                        MethodChannel.Result r = pendingResult;
                        pendingResult = null;
                        if (r != null) r.error("PICK_FAILED", e.getMessage(), null);
                    }
                } else {
                    result.notImplemented();
                }
            });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_ANY_FILE) return;

        MethodChannel.Result result = pendingResult;
        pendingResult = null;
        if (result == null) return;

        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) {
            // User membatalkan pemilihan
            result.success(null);
            return;
        }

        Uri uri = data.getData();
        try {
            String displayName = queryDisplayName(uri);
            String safeName = displayName != null ? sanitize(displayName) : "file.zip";
            File outFile = new File(getCacheDir(), "picked_" + System.currentTimeMillis() + "_" + safeName);

            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(outFile)) {
                if (in == null) throw new Exception("Tidak bisa membuka file yang dipilih");
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                }
            }

            HashMap<String, Object> map = new HashMap<>();
            map.put("path", outFile.getAbsolutePath());
            map.put("name", displayName != null ? displayName : outFile.getName());
            result.success(map);
        } catch (Exception e) {
            result.error("COPY_FAILED", e.getMessage(), null);
        }
    }

    private String queryDisplayName(Uri uri) {
        String name = null;
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = cursor.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (name == null) {
            name = uri.getLastPathSegment();
        }
        return name;
    }

    private String sanitize(String name) {
        return name.replaceAll("[^a-zA-Z0-9._-]", "_");
    }
}
