package com.rizz.rzyn;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
