# Template Integrasi ProfileImageWidget di Dashboard

## Langkah 1: Tambah Import

Di bagian atas `dashboard_page.dart`, tambahkan:

```dart
import 'profile_image_widget.dart';
```

## Langkah 2: Cari dan Ganti Avatar Display

### Option A: Simple Profile Image Widget

Jika ada kode seperti ini di dashboard header/top area:

```dart
// SEBELUM - Mencari bagian yang menampilkan profil
GestureDetector(
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfilePage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
          ratId: ratId,
        ),
      ),
    );
  },
  child: Container(
    height: 100,
    width: 100,
    decoration: BoxDecoration(
      image: DecorationImage(
        image: AssetImage('assets/images/xp.png'),
      ),
    ),
  ),
)
```

Ganti dengan:

```dart
// SESUDAH - Menggunakan ProfileImageWidget
GestureDetector(
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfilePage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
          ratId: ratId,
        ),
      ),
    );
  },
  child: ProfileImageWidget(
    size: 100,
    assetFallback: 'assets/images/xp.png',
    borderColor: Colors.white.withOpacity(0.2),
    borderWidth: 1.5,
  ),
)
```

### Option B: Profile Avatar Widget (Recommended)

Untuk tampilan yang lebih menarik dengan role indicator:

```dart
// SESUDAH - Menggunakan ProfileAvatarWidget
GestureDetector(
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProfilePage(
          username: username,
          password: password,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
          ratId: ratId,
        ),
      ),
    );
  },
  child: ProfileAvatarWidget(
    size: 100,
    username: username,
    role: role,
  ),
)
```

## Langkah 3: Cek Control Panel

Di `control_panel.dart`, cari bagian yang menampilkan avatar/profil dan lakukan langkah yang sama.

Lokasi kemungkinan di:
- Header/top bar
- Profile card
- User info section

## Langkah 4: Test

### Test di Device/Emulator:

1. Buka app dan navigasi ke Profile Page
2. Klik avatar untuk membuka dialog ganti foto
3. Pilih dari galeri atau ambil foto dari kamera
4. Verifikasi foto muncul di profile page
5. Kembali ke dashboard dan verifikasi foto juga muncul di sana
6. Restart app dan verifikasi foto masih ada (persistence)
7. Buka control panel dan verifikasi foto juga muncul di sana

## Common Issues dan Solutions

### 1. Image tidak tampil di widget

**Problem:**
```
Image of type 'NetworkImage' cannot be drawn to a Canvas because it has not been instantiated
```

**Solution:**
```dart
// Gunakan FutureBuilder untuk proper image loading
ProfileImageWidget(
  size: 100,
  assetFallback: 'assets/images/logo.png',
)
```

### 2. Widget tidak update setelah pick image

**Problem:** Foto di profile berubah tapi di dashboard tidak.

**Solution:** 
Gunakan `FutureBuilder` atau buat callback ke parent untuk notify perubahan:

```dart
// Di dashboard, reload image setelah kembali dari profile
Navigator.push(...).then((_) {
  setState(() {}); // Rebuild dashboard untuk load gambar terbaru
});
```

### 3. Storage permission error

**Problem:** "Access denied" saat pick image dari galeri

**Solution:**
Pastikan permissions sudah di setup di:
- `android/app/src/main/AndroidManifest.xml` - add permissions
- iOS: `ios/Runner/Info.plist` - add camera/gallery descriptions

Permissions yang diperlukan:
```xml
<!-- Android: AndroidManifest.xml -->
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.CAMERA" />
```

## Advanced Customization

### Membuat Custom Image Loader

Jika ingin loading indicator yang custom:

```dart
class CustomProfileImageWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder<File?>(
      future: ProfileImageUtils.getProfileImageFile(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.grey[800],
            ),
            child: const Center(
              child: SizedBox(
                width: 40,
                height: 40,
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation(Color(0xFF00D9FF)),
                ),
              ),
            ),
          );
        }
        
        // ... rest of implementation
      },
    );
  }
}
```

### Blur Effect pada Background

```dart
ProfileImageWidget(
  size: 100,
  backgroundColor: Colors.black.withOpacity(0.5),
)
```

## Versi Lengkap untuk Dashboard Profile Button

```dart
// Di dashboard, ganti profile button dengan:
Widget _buildProfileButton() {
  return GestureDetector(
    onTap: () {
      Navigator.push(
        context,
        _createRoute(
          ProfilePage(
            username: username,
            password: password,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
            ratId: widget.ratId,
          ),
        ),
      ).then((_) {
        // Refresh dashboard setelah kembali dari profile
        setState(() {});
      });
    },
    child: Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: ProfileAvatarWidget(
        size: 80,
        username: username,
        role: role,
      ),
    ),
  );
}
```

## File Checklist

Pastikan file-file ini sudah ada di lib folder:
- ✅ `profile_utils.dart` - Utility functions
- ✅ `profile_image_widget.dart` - Widget components
- ✅ `profile_page.dart` - Updated profile page (sudah dilakukan)
- ✅ `dashboard_page.dart` - Need to update with ProfileImageWidget
- ✅ `control_panel.dart` - Need to update with ProfileImageWidget

## Quick Reference

### ProfileImageWidget API
```dart
ProfileImageWidget(
  size: 80,                          // default: 80
  assetFallback: 'assets/images/logo.png',  // fallback if no custom image
  backgroundColor: Color(0xFF1A1A1A),       // default: #1A1A1A
  borderColor: Colors.white,                // default: #6B6B75
  borderWidth: 2,                           // default: 2
  shape: BoxShape.circle,                   // default: circle
  onTap: () => print('Tapped'),             // optional callback
)
```

### ProfileAvatarWidget API
```dart
ProfileAvatarWidget(
  size: 100,                    // default: 100
  username: 'username',         // required
  role: 'owner',                // required - for role color
  onTap: () => print('Tapped'), // optional callback (auto shows edit button)
)
```
