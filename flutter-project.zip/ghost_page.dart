// ghost_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'config.dart';
import 'color_theme.dart';

enum GhostSection { none, deleteAccount, createAccount, listUser }

class GhostPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const GhostPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<GhostPage> createState() => _GhostPageState();
}

class _GhostPageState extends State<GhostPage> with SingleTickerProviderStateMixin {
  // ── Theme color getters ──
  Color get bgDark => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;
  Color get lightPurple => AppThemeController.instance.theme.lightPurple;
  Color get cardGlass => AppThemeController.instance.theme.cardGlass;
  Color get borderGlass => AppThemeController.instance.theme.borderGlass;

  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  // All available roles - Ghost can create all of them
  final List<String> allRoles = ['member', 'reseller', 'vip', 'owner', 'helper', 'admin', 'pt', 'founder', 'tk', 'dev', 'ghost'];
  
  final List<String> roleOptions = ['member', 'reseller', 'vip', 'owner', 'helper', 'admin', 'pt', 'founder', 'tk', 'dev', 'ghost'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  String newUserRole = 'member';
  bool isLoading = false;

  GhostSection _activeSection = GhostSection.none;
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;

  int totalUsers = 0;
  Map<String, int> roleStats = {};

  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    sessionKey = widget.sessionKey;
    _animController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeInOut);
    _scaleAnim = Tween<double>(begin: 0.96, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeOutCubic),
    );
    _animController.forward();
    _fetchTotalStats();
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;
  
  void dispose() {
    _animController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _selectSection(GhostSection section) {
    setState(() {
      _activeSection = section;
    });
    _animController.forward(from: 0);
    if (section == GhostSection.listUser) {
      _fetchUsers();
    }
  }

  void _goBack() {
    setState(() {
      _activeSection = GhostSection.none;
    });
    _animController.forward(from: 0);
  }

  Future<void> _fetchTotalStats() async {
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        fullUserList = data['users'] ?? [];
        
        // Count users per role
        Map<String, int> stats = {};
        for (String role in allRoles) {
          stats[role] = fullUserList.where((u) => u['role'] == role).length;
        }
        
        setState(() {
          totalUsers = fullUserList.length;
          roleStats = stats;
        });
      }
    } catch (e) {
      print("Error fetching stats: $e");
    }
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchTotalStats();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$apiBaseUrl/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() => newUserRole = 'member');
        _fetchTotalStats();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$apiBaseUrl/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentPurple.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: accentPurple),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: primaryWhite)),
          ],
        ),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: accentPurple)),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectorPage() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            Text(
              "ADMIN DASHBOARD",
              style: TextStyle(
                color: primaryWhite,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'ShareTechMono',
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 28),

            // Create & Delete User Cards
            Row(
              children: [
                Expanded(child: _buildActionCard(
                  label: "Create User",
                  icon: FontAwesomeIcons.userPlus,
                  onTap: () => _selectSection(GhostSection.createAccount),
                )),
                const SizedBox(width: 16),
                Expanded(child: _buildActionCard(
                  label: "Delete User",
                  icon: FontAwesomeIcons.userMinus,
                  onTap: () => _selectSection(GhostSection.deleteAccount),
                )),
              ],
            ),
            const SizedBox(height: 28),

            // Total Users Section
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "TOTAL USERS",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  "All Registered Accounts",
                  style: TextStyle(
                    color: textGrey.withOpacity(0.5),
                    fontSize: 11,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Colors.blue.withOpacity(0.15),
                        Colors.cyan.withOpacity(0.1),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.blue.withOpacity(0.3)),
                  ),
                  child: Text(
                    "$totalUsers USERS",
                    style: TextStyle(
                      color: Colors.blue.shade300,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 32),

            // Total Users Per Role Section
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(FontAwesomeIcons.users, color: accentPurple, size: 18),
                    const SizedBox(width: 10),
                    Text(
                      "TOTAL USERS PER ROLE",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    _buildRoleBadge("MEMBER", roleStats['member'] ?? 0, Colors.blue),
                    _buildRoleBadge("RESELLER", roleStats['reseller'] ?? 0, Colors.green),
                    _buildRoleBadge("VIP", roleStats['vip'] ?? 0, Colors.yellow),
                    _buildRoleBadge("OWNER", roleStats['owner'] ?? 0, Colors.deepPurple),
                    _buildRoleBadge("HELPER", roleStats['helper'] ?? 0, Colors.cyan),
                    _buildRoleBadge("ADMIN", roleStats['admin'] ?? 0, Colors.red),
                    _buildRoleBadge("PT", roleStats['pt'] ?? 0, Colors.indigo),
                    _buildRoleBadge("FOUNDER", roleStats['founder'] ?? 0, Colors.purple),
                    _buildRoleBadge("TK", roleStats['tk'] ?? 0, Colors.pink),
                    _buildRoleBadge("DEV", roleStats['dev'] ?? 0, Colors.orange),
                    _buildRoleBadge("GHOST", roleStats['ghost'] ?? 0, Colors.grey),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionCard({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: borderGlass),
          boxShadow: [
            BoxShadow(
              color: primaryPurple.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: label == "Create User"
                    ? Colors.blue.withOpacity(0.15)
                    : Colors.red.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(
                  color: label == "Create User"
                      ? Colors.blue.withOpacity(0.4)
                      : Colors.red.withOpacity(0.4),
                ),
              ),
              child: Icon(
                icon,
                color: label == "Create User" ? Colors.blue : Colors.red,
                size: 24,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              label,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: primaryWhite,
                fontSize: 14,
                fontWeight: FontWeight.w600,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoleBadge(String label, int count, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4), width: 1.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: TextStyle(
              color: primaryWhite,
              fontSize: 12,
              fontWeight: FontWeight.bold,
              fontFamily: 'ShareTechMono',
            ),
          ),
          const SizedBox(width: 8),
          Text(
            count.toString(),
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeleteSection() {
    return Column(
      children: [
        AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: primaryWhite),
            onPressed: _goBack,
          ),
          title: Text(
            "DELETE USER",
            style: TextStyle(
              color: primaryWhite,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.red.withOpacity(0.2)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.warning_outlined, color: Colors.red, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          "Penghapusan user bersifat PERMANEN. Pastikan Anda yakin sebelum melanjutkan.",
                          style: TextStyle(color: textGrey, fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: deleteController,
                  decoration: InputDecoration(
                    labelText: "Username",
                    labelStyle: TextStyle(color: textGrey),
                    filled: true,
                    fillColor: primaryPurple.withOpacity(0.08),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple.withOpacity(0.3)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple.withOpacity(0.2)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple),
                    ),
                  ),
                  style: TextStyle(color: primaryWhite),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: isLoading ? null : _deleteUser,
                    child: isLoading
                        ? SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(primaryWhite),
                            ),
                          )
                        : Text(
                            "HAPUS USER",
                            style: TextStyle(
                              color: primaryWhite,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'ShareTechMono',
                              fontSize: 14,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildCreateSection() {
    return Column(
      children: [
        AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: primaryWhite),
            onPressed: _goBack,
          ),
          title: Text(
            "CREATE ACCOUNT",
            style: TextStyle(
              color: primaryWhite,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              children: [
                TextField(
                  controller: createUsernameController,
                  decoration: InputDecoration(
                    labelText: "Username",
                    labelStyle: TextStyle(color: textGrey),
                    filled: true,
                    fillColor: primaryPurple.withOpacity(0.08),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple.withOpacity(0.3)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple.withOpacity(0.2)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple),
                    ),
                  ),
                  style: TextStyle(color: primaryWhite),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: createPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: "Password",
                    labelStyle: TextStyle(color: textGrey),
                    filled: true,
                    fillColor: primaryPurple.withOpacity(0.08),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple.withOpacity(0.3)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple.withOpacity(0.2)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple),
                    ),
                  ),
                  style: TextStyle(color: primaryWhite),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: createDayController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: "Durasi (Hari)",
                    labelStyle: TextStyle(color: textGrey),
                    filled: true,
                    fillColor: primaryPurple.withOpacity(0.08),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple.withOpacity(0.3)),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple.withOpacity(0.2)),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide(color: accentPurple),
                    ),
                  ),
                  style: TextStyle(color: primaryWhite),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: primaryPurple.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: accentPurple.withOpacity(0.2)),
                  ),
                  child: DropdownButton<String>(
                    value: newUserRole,
                    isExpanded: true,
                    underline: const SizedBox(),
                    dropdownColor: bgDark,
                    style: TextStyle(color: primaryWhite),
                    items: roleOptions.map((role) {
                      return DropdownMenuItem(
                        value: role,
                        child: Text(
                          role.toUpperCase(),
                          style: TextStyle(
                            color: primaryWhite,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() => newUserRole = value!);
                    },
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: isLoading ? null : _createAccount,
                    child: isLoading
                        ? SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor: AlwaysStoppedAnimation(primaryWhite),
                            ),
                          )
                        : Text(
                            "BUAT AKUN",
                            style: TextStyle(
                              color: primaryWhite,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'ShareTechMono',
                              fontSize: 14,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildListUserSection() {
    return Column(
      children: [
        AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: primaryWhite),
            onPressed: _goBack,
          ),
          title: Text(
            "LIST USER",
            style: TextStyle(
              color: primaryWhite,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: accentPurple.withOpacity(0.2)),
            ),
            child: DropdownButton<String>(
              value: selectedRole,
              isExpanded: true,
              underline: const SizedBox(),
              dropdownColor: bgDark,
              style: TextStyle(color: primaryWhite),
              items: allRoles.map((role) {
                return DropdownMenuItem(
                  value: role,
                  child: Text(
                    role.toUpperCase(),
                    style: TextStyle(
                      color: primaryWhite,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                );
              }).toList(),
              onChanged: (value) {
                setState(() => selectedRole = value!);
                _filterAndPaginate();
              },
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            children: [
              _buildStatChip(
                label: "Total",
                value: "${filteredList.length}",
                icon: Icons.people_alt_outlined,
              ),
              const SizedBox(width: 10),
              _buildStatChip(
                label: "Halaman",
                value: "$currentPage / ${totalPages == 0 ? 1 : totalPages}",
                icon: Icons.menu_book_outlined,
              ),
            ],
          ),
        ),
        Expanded(
          child: isLoading
              ? Center(child: CircularProgressIndicator(color: accentPurple))
              : filteredList.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.person_off_outlined, color: textGrey, size: 52),
                          const SizedBox(height: 12),
                          Text("Tidak ada user ditemukan", style: TextStyle(color: textGrey)),
                        ],
                      ),
                    )
                  : ListView(
                      padding: const EdgeInsets.only(bottom: 20),
                      children: [
                        ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                        if (totalPages > 1)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            child: _buildPagination(),
                          ),
                      ],
                    ),
        ),
      ],
    );
  }

  Widget _buildStatChip({required String label, required String value, required IconData icon}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: primaryPurple.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accentPurple.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Icon(icon, color: accentPurple, size: 16),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: textGrey, fontSize: 10)),
                Text(value, style: TextStyle(color: primaryWhite, fontSize: 13, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: accentPurple.withOpacity(0.3)),
            ),
            child: Icon(Icons.person, color: accentPurple),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(
                    color: primaryWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()}  •  EXP: ${user['expiredDate']}",
                  style: TextStyle(color: textGrey.withOpacity(0.6), fontSize: 11),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.redAccent.withOpacity(0.08),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.redAccent.withOpacity(0.25)),
            ),
            child: IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: bgDark,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(color: accentPurple.withOpacity(0.3)),
                    ),
                    title: Text("Konfirmasi", style: TextStyle(color: primaryWhite)),
                    content: Text("Hapus user '${user['username']}'?", style: TextStyle(color: textGrey)),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: Text("Batal", style: TextStyle(color: accentPurple)),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text("Hapus", style: TextStyle(color: Colors.redAccent)),
                      ),
                    ],
                  ),
                );
                if (confirm == true) {
                  deleteController.text = user['username'];
                  await _deleteUser();
                  _fetchUsers();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isActive = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isActive ? accentPurple : const Color(0xFF0D0D0D),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isActive ? accentPurple : borderGlass,
              ),
              boxShadow: isActive
                  ? [BoxShadow(color: accentPurple.withOpacity(0.3), blurRadius: 8)]
                  : [],
            ),
            child: Center(
              child: Text(
                "$page",
                style: TextStyle(
                  color: isActive ? Colors.white : textGrey,
                  fontSize: 13,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, primaryPurple.withOpacity(0.06), bgDark],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: _activeSection == GhostSection.none
                ? _buildSelectorPage()
                : _activeSection == GhostSection.deleteAccount
                    ? _buildDeleteSection()
                    : _activeSection == GhostSection.createAccount
                        ? _buildCreateSection()
                        : _buildListUserSection(),
          ),
        ),
      ),
    );
  }
}
