// ignore_for_file: non_constant_identifier_names
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

// ═══════════════════════════════════════════════════════════════
// COLOR THEME SYSTEM — Voltara
// 6 Tema: Purple (default), Dark, Pink, Blue, Red, Jade
// ═══════════════════════════════════════════════════════════════

enum AppThemeType { purple, dark, pink, blue, red, jade }

class AppTheme {
  final AppThemeType type;
  final String name;
  final Color bgDark;
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color glowIndigo;
  final Color cardGlass;
  final Color borderGlass;
  final Color cardSolid;
  final Color cardSolidSelected;
  final Color borderSolid;
  final Color accentGrey;
  final Color themePreviewColor; // warna kotak preview di UI
  final List<Color> drawerGradient;
  final List<Color> sweepGradientColors;
  
  // Warna untuk landing page yang berubah sesuai tema
  final Color landingBgTop;
  final Color landingBgMid;
  final Color landingAccent1;
  final Color landingAccent2;
  final Color landingAccent3;

  const AppTheme({
    required this.type,
    required this.name,
    required this.bgDark,
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.glowIndigo,
    required this.cardGlass,
    required this.borderGlass,
    required this.cardSolid,
    required this.cardSolidSelected,
    required this.borderSolid,
    required this.accentGrey,
    required this.themePreviewColor,
    required this.drawerGradient,
    required this.sweepGradientColors,
    required this.landingBgTop,
    required this.landingBgMid,
    required this.landingAccent1,
    required this.landingAccent2,
    required this.landingAccent3,
  });
}

// ─── TEMA UNGU (default) ───────────────────────────────────────
const AppTheme _purple = AppTheme(
  type: AppThemeType.purple,
  name: 'Purple',
  bgDark: Color(0xFF0C0518),
  primaryPurple: Color(0xFF9B5DE5),
  accentPurple: Color(0xFFC77DFF),
  lightPurple: Color(0xFFF3E8FF),
  glowMagenta: Color(0xFFE0AAFF),
  glowIndigo: Color(0xFF7B2CBF),
  cardGlass: Color(0x179B5DE5),
  borderGlass: Color(0x289B5DE5),
  cardSolid: Color(0xFF1C1030),
  cardSolidSelected: Color(0xFF3A1F63),
  borderSolid: Color(0xFF4E3380),
  accentGrey: Color(0xFFB0A0C8),
  themePreviewColor: Color(0xFF9B5DE5),
  drawerGradient: [Color(0xFF1A0E36), Color(0xFF150826), Color(0xFF0A0418)],
  sweepGradientColors: [
    Color(0x00C77DFF), Color(0xFFC77DFF), Color(0xFFF3E8FF),
    Color(0xFFE0AAFF), Color(0x00C77DFF),
  ],
  landingBgTop: Color(0xFF200D3C),
  landingBgMid: Color(0xFF2D1B47),
  landingAccent1: Color(0xFF9B5DE5),
  landingAccent2: Color(0xFFC77DFF),
  landingAccent3: Color(0xFFE0AAFF),
);

// ─── TEMA DARK (abu-abu putih premium) ────────────────────────
const AppTheme _dark = AppTheme(
  type: AppThemeType.dark,
  name: 'Dark',
  bgDark: Color(0xFF0F0F12),
  primaryPurple: Color(0xFF9E9E9E),
  accentPurple: Color(0xFFD4D4D4),
  lightPurple: Color(0xFFF0EFED),
  glowMagenta: Color(0xFFBDBDBD),
  glowIndigo: Color(0xFF616161),
  cardGlass: Color(0x149E9E9E),
  borderGlass: Color(0x229E9E9E),
  cardSolid: Color(0xFF1C1C1F),
  cardSolidSelected: Color(0xFF2E2E33),
  borderSolid: Color(0xFF424248),
  accentGrey: Color(0xFFAAAAAA),
  themePreviewColor: Color(0xFF6E6E73),
  drawerGradient: [Color(0xFF1C1C1F), Color(0xFF141417), Color(0xFF0A0A0D)],
  sweepGradientColors: [
    Color(0x00D4D4D4), Color(0xFFD4D4D4), Color(0xFFF0EFED),
    Color(0xFFBDBDBD), Color(0x00D4D4D4),
  ],
  landingBgTop: Color(0xFF1A1A1D),
  landingBgMid: Color(0xFF242428),
  landingAccent1: Color(0xFF9E9E9E),
  landingAccent2: Color(0xFFD4D4D4),
  landingAccent3: Color(0xFFBDBDBD),
);

// ─── TEMA PINK (pink premium) ─────────────────────────────────
const AppTheme _pink = AppTheme(
  type: AppThemeType.pink,
  name: 'Pink',
  bgDark: Color(0xFF12030D),
  primaryPurple: Color(0xFFE91E8C),
  accentPurple: Color(0xFFFF6EC7),
  lightPurple: Color(0xFFFFD6F0),
  glowMagenta: Color(0xFFFF4DB8),
  glowIndigo: Color(0xFFAD1457),
  cardGlass: Color(0x17E91E8C),
  borderGlass: Color(0x28E91E8C),
  cardSolid: Color(0xFF2A0A1E),
  cardSolidSelected: Color(0xFF4A0E32),
  borderSolid: Color(0xFF7A1A4A),
  accentGrey: Color(0xFFD4A0BC),
  themePreviewColor: Color(0xFFE91E8C),
  drawerGradient: [Color(0xFF2A0820), Color(0xFF1C0516), Color(0xFF0E020C)],
  sweepGradientColors: [
    Color(0x00FF6EC7), Color(0xFFFF6EC7), Color(0xFFFFD6F0),
    Color(0xFFFF4DB8), Color(0x00FF6EC7),
  ],
  landingBgTop: Color(0xFF2D0D20),
  landingBgMid: Color(0xFF3D1A2E),
  landingAccent1: Color(0xFFE91E8C),
  landingAccent2: Color(0xFFFF6EC7),
  landingAccent3: Color(0xFFFF4DB8),
);

// ─── TEMA BLUE (biru elegan) ──────────────────────────────────
const AppTheme _blue = AppTheme(
  type: AppThemeType.blue,
  name: 'Blue',
  bgDark: Color(0xFF020C1B),
  primaryPurple: Color(0xFF1565C0),
  accentPurple: Color(0xFF42A5F5),
  lightPurple: Color(0xFFBBDEFB),
  glowMagenta: Color(0xFF64B5F6),
  glowIndigo: Color(0xFF0D47A1),
  cardGlass: Color(0x171565C0),
  borderGlass: Color(0x281565C0),
  cardSolid: Color(0xFF061830),
  cardSolidSelected: Color(0xFF0D2E52),
  borderSolid: Color(0xFF1A4A7A),
  accentGrey: Color(0xFFA0BECE),
  themePreviewColor: Color(0xFF1E88E5),
  drawerGradient: [Color(0xFF061830), Color(0xFF040F22), Color(0xFF020810)],
  sweepGradientColors: [
    Color(0x0042A5F5), Color(0xFF42A5F5), Color(0xFFBBDEFB),
    Color(0xFF64B5F6), Color(0x0042A5F5),
  ],
  landingBgTop: Color(0xFF0D1F38),
  landingBgMid: Color(0xFF1A2E52),
  landingAccent1: Color(0xFF1565C0),
  landingAccent2: Color(0xFF42A5F5),
  landingAccent3: Color(0xFF64B5F6),
);

// ─── TEMA RED (merah elegan) ──────────────────────────────────
const AppTheme _red = AppTheme(
  type: AppThemeType.red,
  name: 'Red',
  bgDark: Color(0xFF120205),
  primaryPurple: Color(0xFFC62828),
  accentPurple: Color(0xFFEF5350),
  lightPurple: Color(0xFFFFCDD2),
  glowMagenta: Color(0xFFFF8A80),
  glowIndigo: Color(0xFFB71C1C),
  cardGlass: Color(0x17C62828),
  borderGlass: Color(0x28C62828),
  cardSolid: Color(0xFF250508),
  cardSolidSelected: Color(0xFF450A10),
  borderSolid: Color(0xFF7A1520),
  accentGrey: Color(0xFFCEA0A4),
  themePreviewColor: Color(0xFFE53935),
  drawerGradient: [Color(0xFF280508), Color(0xFF1A0305), Color(0xFF0E0203)],
  sweepGradientColors: [
    Color(0x00EF5350), Color(0xFFEF5350), Color(0xFFFFCDD2),
    Color(0xFFFF8A80), Color(0x00EF5350),
  ],
  landingBgTop: Color(0xFF2D0A0D),
  landingBgMid: Color(0xFF3D1517),
  landingAccent1: Color(0xFFC62828),
  landingAccent2: Color(0xFFEF5350),
  landingAccent3: Color(0xFFFF8A80),
);

// ─── TEMA JADE (hijau premium elegan) ─────────────────────────
const AppTheme _jade = AppTheme(
  type: AppThemeType.jade,
  name: 'Jade',
  bgDark: Color(0xFF021210),
  primaryPurple: Color(0xFF00796B),
  accentPurple: Color(0xFF26A69A),
  lightPurple: Color(0xFFB2DFDB),
  glowMagenta: Color(0xFF4DB6AC),
  glowIndigo: Color(0xFF004D40),
  cardGlass: Color(0x1700796B),
  borderGlass: Color(0x2800796B),
  cardSolid: Color(0xFF051E1A),
  cardSolidSelected: Color(0xFF0A3530),
  borderSolid: Color(0xFF155A50),
  accentGrey: Color(0xFF9ABEBB),
  themePreviewColor: Color(0xFF00897B),
  drawerGradient: [Color(0xFF061E1A), Color(0xFF041410), Color(0xFF020C0A)],
  sweepGradientColors: [
    Color(0x0026A69A), Color(0xFF26A69A), Color(0xFFB2DFDB),
    Color(0xFF4DB6AC), Color(0x0026A69A),
  ],
  landingBgTop: Color(0xFF0D2D24),
  landingBgMid: Color(0xFF1A3D32),
  landingAccent1: Color(0xFF00796B),
  landingAccent2: Color(0xFF26A69A),
  landingAccent3: Color(0xFF4DB6AC),
);

// ─── MAP SEMUA TEMA ───────────────────────────────────────────
const Map<AppThemeType, AppTheme> _themes = {
  AppThemeType.purple: _purple,
  AppThemeType.dark: _dark,
  AppThemeType.pink: _pink,
  AppThemeType.blue: _blue,
  AppThemeType.red: _red,
  AppThemeType.jade: _jade,
};

// ═══════════════════════════════════════════════════════════════
// THEME CONTROLLER — Singleton ChangeNotifier
// ═══════════════════════════════════════════════════════════════

class AppThemeController extends ChangeNotifier {
  AppThemeController._();
  static final AppThemeController instance = AppThemeController._();

  static const String _prefsKey = 'app_theme_type';

  AppThemeType _current = AppThemeType.blue;
  bool _isLoaded = false;

  AppTheme get theme => _themes[_current]!;
  AppThemeType get currentType => _current;
  bool get isLoaded => _isLoaded;

  /// Panggil sekali saat app start (sebelum runApp) untuk memuat
  /// tema terakhir yang disimpan user dari penyimpanan lokal.
  /// Selama disk penyimpanan app belum dihapus (uninstall), tema
  /// akan tetap sama walau app ditutup / HP di-restart.
  Future<void> loadTheme() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedName = prefs.getString(_prefsKey);
      if (savedName != null) {
        final match = AppThemeType.values.where(
          (t) => t.name == savedName,
        );
        if (match.isNotEmpty) {
          _current = match.first;
        }
      }
    } catch (_) {
      // Jika gagal load (mis. storage error), tetap pakai default purple.
    } finally {
      _isLoaded = true;
      notifyListeners();
    }
  }

  /// Ganti tema. Selalu disimpan ke local storage (SharedPreferences) supaya
  /// app tetap kebuka cepat dengan tema terakhir walau lagi offline.
  ///
  /// Kalau [username] & [sessionKey] diisi, tema JUGA dikirim & disimpan ke
  /// akun di server (database.json). Dengan begini tema jadi milik AKUN,
  /// bukan milik device — jadi tetap sama walau: app ditutup, cache/data
  /// dihapus, app di-uninstall lalu install ulang, atau login pakai akun
  /// yang sama di HP lain.
  Future<void> setTheme(
    AppThemeType type, {
    String? username,
    String? sessionKey,
  }) async {
    if (_current == type) return;
    _current = type;
    notifyListeners();

    // Langkah 1: Simpan ke local storage (cache device, biar buka app instan)
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsKey, type.name);
    } catch (_) {
      // Kalau gagal simpan, tema tetap berubah untuk sesi ini saja.
    }

    // Langkah 2: Simpan ke server → database.json (sumber kebenaran per akun)
    if (username != null && sessionKey != null) {
      try {
        await http.post(
          Uri.parse('$apiBaseUrl/setTheme'),
          body: {
            'username': username,
            'key': sessionKey,
            'theme': type.name,
          },
        );
      } catch (_) {
        // Offline / server down → tema tetap berubah secara lokal.
        // Nanti otomatis ke-sync lagi begitu user ganti tema saat online,
        // atau saat login ulang tema akan mengikuti data server.
      }
    }
  }

  /// Dipanggil sekali setelah login berhasil (baik auto-login lewat
  /// /myInfo maupun login manual lewat /validate) untuk menyamakan tema
  /// device dengan tema yang tersimpan di AKUN (field "theme" di
  /// database.json). Ini yang bikin tema ikut akun: login di HP lain /
  /// abis uninstall-install ulang, tema otomatis kembali ke pilihan
  /// terakhir si akun.
  Future<void> applyServerTheme(String? themeName) async {
    if (themeName == null) return;
    final match = AppThemeType.values.where((t) => t.name == themeName);
    if (match.isEmpty) return;

    final type = match.first;
    if (_current == type) return;
    _current = type;
    notifyListeners();

    // Update cache lokal juga, supaya kalau buka app tanpa internet,
    // tema yang tampil tetap tema akun ini (bukan default purple).
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefsKey, type.name);
    } catch (_) {}
  }

  /// Shortcut getters — semua kode existing pakai nama ini
  Color get bgDark => theme.bgDark;
  Color get primaryPurple => theme.primaryPurple;
  Color get accentPurple => theme.accentPurple;
  Color get lightPurple => theme.lightPurple;
  Color get glowMagenta => theme.glowMagenta;
  Color get glowIndigo => theme.glowIndigo;
  Color get cardGlass => theme.cardGlass;
  Color get borderGlass => theme.borderGlass;
  Color get cardSolid => theme.cardSolid;
  Color get cardSolidSelected => theme.cardSolidSelected;
  Color get borderSolid => theme.borderSolid;
  Color get accentGrey => theme.accentGrey;
  
  // Getter untuk landing page colors
  Color get landingBgTop => theme.landingBgTop;
  Color get landingBgMid => theme.landingBgMid;
  Color get landingAccent1 => theme.landingAccent1;
  Color get landingAccent2 => theme.landingAccent2;
  Color get landingAccent3 => theme.landingAccent3;
}

// ═══════════════════════════════════════════════════════════════
// COLOR THEME PICKER WIDGET — dipakai di drawer dashboard_page
// ═══════════════════════════════════════════════════════════════

class ColorThemePicker extends StatefulWidget {
  final String username;
  final String sessionKey;
  const ColorThemePicker({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ColorThemePicker> createState() => _ColorThemePickerState();
}

class _ColorThemePickerState extends State<ColorThemePicker> {
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppThemeController.instance,
      builder: (context, _) {
        final ctrl = AppThemeController.instance;
        final t = ctrl.theme;

        // Urutan tema sesuai permintaan: Ungu di atas Dark
        final List<AppThemeType> order = [
          AppThemeType.purple,
          AppThemeType.dark,
          AppThemeType.pink,
          AppThemeType.blue,
          AppThemeType.red,
          AppThemeType.jade,
        ];

        return Container(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: t.cardSolid,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: t.borderGlass, width: 1),
            boxShadow: [
              BoxShadow(
                color: t.primaryPurple.withOpacity(0.18),
                blurRadius: 16,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header: icon + title + username
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [t.primaryPurple, t.accentPurple],
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.palette_rounded,
                        color: Colors.white, size: 16),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Color Theme',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.5,
                        ),
                      ),
                      Text(
                        widget.username,
                        style: TextStyle(
                          color: t.accentPurple,
                          fontSize: 10,
                          fontFamily: 'ShareTechMono',
                          letterSpacing: 0.3,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 14),
              // Grid tema 3 kolom
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.05,
                children: order.map((type) {
                  final th = _themes[type]!;
                  final isSelected = ctrl.currentType == type;
                  return _ThemeBox(
                    theme: th,
                    isSelected: isSelected,
                    onTap: () => ctrl.setTheme(
                      type,
                      username: widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  );
                }).toList(),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ThemeBox extends StatelessWidget {
  final AppTheme theme;
  final bool isSelected;
  final VoidCallback onTap;

  const _ThemeBox({
    required this.theme,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeInOut,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              theme.themePreviewColor,
              theme.glowIndigo,
            ],
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? Colors.white : Colors.white.withOpacity(0.18),
            width: isSelected ? 2.2 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: theme.themePreviewColor.withOpacity(0.55),
                    blurRadius: 14,
                    spreadRadius: 1,
                  )
                ]
              : [],
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            // Background shimmer
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  gradient: RadialGradient(
                    colors: [
                      Colors.white.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    center: Alignment.topLeft,
                    radius: 1.2,
                  ),
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (isSelected)
                  const Icon(Icons.check_circle_rounded,
                      color: Colors.white, size: 20)
                else
                  Icon(
                    _iconForTheme(theme.type),
                    color: Colors.white.withOpacity(0.85),
                    size: 18,
                  ),
                const SizedBox(height: 5),
                Text(
                  theme.name,
                  style: TextStyle(
                    color: isSelected
                        ? Colors.white
                        : Colors.white.withOpacity(0.88),
                    fontSize: 10,
                    fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  IconData _iconForTheme(AppThemeType type) {
    switch (type) {
      case AppThemeType.purple:
        return Icons.auto_awesome_rounded;
      case AppThemeType.dark:
        return Icons.dark_mode_rounded;
      case AppThemeType.pink:
        return Icons.favorite_rounded;
      case AppThemeType.blue:
        return Icons.water_drop_rounded;
      case AppThemeType.red:
        return Icons.local_fire_department_rounded;
      case AppThemeType.jade:
        return Icons.eco_rounded;
    }
  }
}
