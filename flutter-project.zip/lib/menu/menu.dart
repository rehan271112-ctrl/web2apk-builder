import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ==================== IMPORTS BUG PAGES ====================
import '../bug/home_page.dart';
import '../bug/custom_bug.dart';
import '../bug/bug_group.dart';

// ==================== IMPORT UNBAN PAGE ====================
import '../spam/unban_page.dart';

// ==================== IMPORT RUN HTML PAGE ====================
import '../spam/run_html.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFE8E4DF);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
  static const Color orange = Color(0xFFF59E0B);
  static const Color teal = Color(0xFF14B8A6);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class MenuPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;

  const MenuPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
  });

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  late PageController _pageController;
  int _currentPage = 0;

  final List<Map<String, dynamic>> _menuItems = [
    {
      'title': 'Bug',
      'icon': FontAwesomeIcons.whatsapp,
      'color': NeoBrutalismColors.green,
      'desc': 'WhatsApp Bug Attack',
      'route': 'bug',
    },
    {
      'title': 'Custom Bug',
      'icon': FontAwesomeIcons.squareWhatsapp,
      'color': NeoBrutalismColors.purple,
      'desc': 'Custom Payload Attack',
      'route': 'custom',
    },
    {
      'title': 'Group Bug',
      'icon': FontAwesomeIcons.users,
      'color': NeoBrutalismColors.blue,
      'desc': 'Group Join & Attack',
      'route': 'group',
    },
    {
      'title': 'Unban WA',
      'icon': FontAwesomeIcons.unlock,
      'color': NeoBrutalismColors.pink,
      'desc': 'Unban WhatsApp Number',
      'route': 'unban',
    },
    {
      'title': 'Run HTML',
      'icon': FontAwesomeIcons.code,
      'color': NeoBrutalismColors.orange,
      'desc': 'HTML Code Runner & Preview',
      'route': 'runhtml',
    },
  ];

  @override
  void initState() {
    super.initState();
    _pageController = PageController(viewportFraction: 0.82);
  }

  void _navigateToPage(String route) {
    switch (route) {
      case 'bug':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => AttackPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              listBug: widget.listBug,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
      case 'custom':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => CustomAttackPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              listPayload: widget.listPayload,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
      case 'group':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => GroupBugPage(
              username: widget.username,
              password: widget.password,
              sessionKey: widget.sessionKey,
              role: widget.role,
              expiredDate: widget.expiredDate,
            ),
          ),
        );
        break;
      case 'unban':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => UnbanPage(
              username: widget.username,
              sessionKey: widget.sessionKey,
            ),
          ),
        );
        break;
      case 'runhtml':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const RunHtmlPage(),
          ),
        );
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          // Background dengan grid
          Container(
            color: NeoBrutalismColors.grey,
            child: CustomPaint(
              painter: GridPainter(),
              size: Size.infinite,
            ),
          ),
          
          SafeArea(
            child: Column(
              children: [
                // ===== HEADER CARD DENGAN GAMBAR =====
                Container(
                  margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                  width: double.infinity,
                  height: 200,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: NeoBrutalismColors.black.withOpacity(0.15),
                        offset: const Offset(6, 6),
                        blurRadius: 0,
                      ),
                    ],
                    image: const DecorationImage(
                      image: AssetImage('assets/images/menu.jpg'),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      gradient: LinearGradient(
                        colors: [
                          NeoBrutalismColors.black.withOpacity(0.6),
                          Colors.transparent,
                        ],
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                      ),
                    ),
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(2),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: NeoBrutalismColors.white, width: 2),
                              ),
                              child: ClipOval(
                                child: Image.asset(
                                  'assets/images/profil.jpg',
                                  width: 36,
                                  height: 36,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    width: 36,
                                    height: 36,
                                    color: NeoBrutalismColors.purple,
                                    child: const Icon(Icons.person, color: NeoBrutalismColors.white, size: 18),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              widget.username,
                              style: const TextStyle(
                                color: NeoBrutalismColors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Inter',
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: NeoBrutalismColors.yellow,
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                              ),
                              child: Text(
                                widget.role.toUpperCase(),
                                style: const TextStyle(
                                  color: NeoBrutalismColors.black,
                                  fontSize: 8,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Inter',
                                ),
                              ),
                            ),
                            const Spacer(),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: NeoBrutalismColors.black.withOpacity(0.5),
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(color: NeoBrutalismColors.white, width: 1),
                              ),
                              child: Text(
                                "EXP: ${widget.expiredDate.split(' ').first}",
                                style: const TextStyle(
                                  color: NeoBrutalismColors.white,
                                  fontSize: 8,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Inter',
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: NeoBrutalismColors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                ),
                                child: const Icon(
                                  Icons.close,
                                  color: NeoBrutalismColors.black,
                                  size: 16,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                          decoration: BoxDecoration(
                            color: NeoBrutalismColors.pink,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                          ),
                          child: const Text(
                            'Menu Bug & Others',
                            style: TextStyle(
                              color: NeoBrutalismColors.white,
                              fontSize: 14,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // ===== PAGEVIEW CARDS =====
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: (index) {
                      setState(() {
                        _currentPage = index;
                      });
                    },
                    itemCount: _menuItems.length,
                    itemBuilder: (context, index) {
                      final item = _menuItems[index];
                      final isActive = _currentPage == index;
                      
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                        child: GestureDetector(
                          onTap: () => _navigateToPage(item['route']),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.white,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: isActive 
                                    ? item['color'] 
                                    : NeoBrutalismColors.borderColor,
                                width: isActive ? 4 : 3,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoBrutalismColors.black.withOpacity(
                                    isActive ? 0.25 : 0.15
                                  ),
                                  offset: isActive 
                                      ? const Offset(12, 12) 
                                      : const Offset(6, 6),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                // Icon besar
                                Container(
                                  padding: const EdgeInsets.all(28),
                                  decoration: BoxDecoration(
                                    color: item['color'].withOpacity(0.15),
                                    borderRadius: BorderRadius.circular(24),
                                    border: Border.all(
                                      color: item['color'].withOpacity(0.3),
                                      width: 3,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: NeoBrutalismColors.black.withOpacity(0.05),
                                        offset: const Offset(4, 4),
                                        blurRadius: 0,
                                      ),
                                    ],
                                  ),
                                  child: Icon(
                                    item['icon'],
                                    color: item['color'],
                                    size: 72,
                                  ),
                                ),
                                
                                const SizedBox(height: 20),
                                
                                // Title
                                Text(
                                  item['title'],
                                  style: TextStyle(
                                    color: NeoBrutalismColors.black,
                                    fontSize: 24,
                                    fontWeight: FontWeight.w900,
                                    fontFamily: 'Inter',
                                    letterSpacing: 1,
                                  ),
                                ),
                                
                                const SizedBox(height: 6),
                                
                                // Description
                                Text(
                                  item['desc'],
                                  style: TextStyle(
                                    color: NeoBrutalismColors.darkGrey,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                                
                                const SizedBox(height: 16),
                                
                                // Tap to open indicator
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: item['color'].withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: item['color'].withOpacity(0.2),
                                      width: 2,
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        "Tap to open",
                                        style: TextStyle(
                                          color: item['color'],
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                          fontFamily: 'Inter',
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Icon(
                                        Icons.arrow_forward,
                                        color: item['color'],
                                        size: 14,
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                
                // ===== INDICATOR DOTS =====
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      _menuItems.length,
                      (index) => AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        margin: const EdgeInsets.symmetric(horizontal: 5),
                        height: 8,
                        width: _currentPage == index ? 30 : 8,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: _currentPage == index
                              ? NeoBrutalismColors.borderColor
                              : NeoBrutalismColors.borderColor.withOpacity(0.3),
                          border: Border.all(
                            color: NeoBrutalismColors.borderColor,
                            width: 1,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                
                // ===== COPYRIGHT =====
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Column(
                    children: [
                      Container(
                        width: 40,
                        height: 2,
                        color: NeoBrutalismColors.borderColor,
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        "flutter by @Rizzisreal01",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: NeoBrutalismColors.darkGrey,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}