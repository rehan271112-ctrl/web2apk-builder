import 'package:flutter/material.dart';
import 'dart:ui';
import 'dart:async';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'login_page.dart';
import 'color_theme.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with SingleTickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _glowController;
  late Animation<double> _glowAnimation;
  
  // Animasi untuk karakter
  late AnimationController _floatController;
  late Animation<double> _floatAnimation;
  late AnimationController _swayController;
  late Animation<double> _swayAnimation;

  // Animasi masuk (fade & slide)
  late AnimationController _entryController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // ═══════════════════════════════════════════════════════════════
  // FIXED COLORS untuk TELEGRAM dan TIKTOK (tidak berubah dengan tema)
  // ═══════════════════════════════════════════════════════════════
  static const Color telegramBlue = Color(0xFF0088cc);
  static const Color tikTokBlue = Color(0xFF0A66C2);
  
  // Warna dari HomePage (tidak dipakai di landing)
  static const Color blackCard = Color(0xFF141414);
  static const Color blackSoft = Color(0xFF1A1A1A);
  static const Color greyMid = Color(0xFF9E9E9E);
  static const Color blueAccent = Color(0xFF2196F3);
  static const Color greenAccent = Color(0xFF34C759);
  static const Color whitePure = Color(0xFFFFFFFF);
  static const Color blackPure = Color(0xFF000000);
  static const Color greyDark = Color(0xFF3A3A3A);

  @override
  void initState() {
    super.initState();
    
    // Video
    _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(0.6);
        _videoController.play();
      });

    // Glow animation
    _glowController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);

    _glowAnimation = Tween<double>(begin: 0.3, end: 0.7).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
    
    // Karakter animasi
    _floatController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);
    
    _floatAnimation = Tween<double>(begin: -10, end: 10).animate(
      CurvedAnimation(parent: _floatController, curve: Curves.easeInOut),
    );
    
    _swayController = AnimationController(
      duration: const Duration(milliseconds: 4000),
      vsync: this,
    )..repeat();
    
    _swayAnimation = Tween<double>(begin: -8, end: 8).animate(
      CurvedAnimation(parent: _swayController, curve: Curves.easeInOutSine),
    );

    // Entry animation
    _entryController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..forward();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _entryController, curve: Curves.easeOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _entryController, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() {
    _videoController.dispose();
    _glowController.dispose();
    _floatController.dispose();
    _swayController.dispose();
    _entryController.dispose();
    super.dispose();
  }

  void _navigateToLogin() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
    );
  }

  void _openWhatsApp() {
    String phone = "6285764505122";
    String message = "Bang beli ZeroCrash";
    String url = "https://wa.me/$phone?text=${Uri.encodeComponent(message)}";
    _launchUrl(url);
  }

  void _openTelegram() {
    _launchUrl("https://t.me/VinzzCeooo");
  }

  void _openSaluran() {
    _launchUrl("https://whatsapp.com/channel/0029VbDha8WF6smyZqv8Cq1w");
  }

  void _openTikTok() {
    _launchUrl("https://tiktok.com/@maklongemis");
  }

  void _openBugChannel() {
    _launchUrl("https://whatsapp.com/channel/0029VbDha8WF6smyZqv8Cq1w");
  }

  Future<void> _launchUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppThemeController.instance,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: Colors.black,
          body: Stack(
            children: [
              // BACKGROUND seperti di foto (Nocturne style dengan aksen biru)
              _buildBackground(),
              
              // Efek grid halus
              CustomPaint(
                painter: RiyLixGridPainter(),
                size: Size.infinite,
              ),

              SafeArea(
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          _buildHeaderWithLogo(),
                          const SizedBox(height: 16),
                          _buildVideoPlayer(),
                          const SizedBox(height: 16),
                          _buildCharacter(),
                          const SizedBox(height: 12),
                          _buildInfoCard(),
                          const SizedBox(height: 16),
                          _buildLoginButton(),
                          const SizedBox(height: 8),
                          _buildBugSpesial(),
                          const SizedBox(height: 24),
                          _buildContactTitle(),
                          const SizedBox(height: 14),
                          _buildContactButtons(),
                          const SizedBox(height: 20),
                          _buildCopyright(),
                          const SizedBox(height: 12),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // BACKGROUND seperti di foto - Nocturne style dengan aksen sesuai tema
  Widget _buildBackground() {
    final ctrl = AppThemeController.instance;
    final landingAccent = ctrl.landingAccent1;
    final landingBgTop = ctrl.landingBgTop;
    final landingBgMid = ctrl.landingBgMid;
    
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            landingBgTop, // warna top sesuai tema
            landingBgMid, // warna mid sesuai tema
            const Color(0xFF0A0A0F), // hitam pekat di bawah (tetap sama)
          ],
          stops: const [0.0, 0.4, 1.0],
        ),
      ),
      child: Stack(
        children: [
          // Efek glow sesuai tema di bagian atas
          Positioned(
            top: -80,
            left: -50,
            right: -50,
            child: Container(
              height: 250,
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -0.3),
                  radius: 0.6,
                  colors: [
                    landingAccent.withOpacity(0.25),
                    landingAccent.withOpacity(0.08),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          // Efek glow kedua di tengah sesuai tema
          Positioned(
            top: 150,
            left: -100,
            right: -100,
            child: Container(
              height: 200,
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, 0),
                  radius: 0.5,
                  colors: [
                    landingAccent.withOpacity(0.08),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // HEADER: WELCOME + LOGO
  Widget _buildHeaderWithLogo() {
    final ctrl = AppThemeController.instance;
    final accentColor = ctrl.landingAccent1;
    
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [accentColor.withOpacity(0.2), Colors.transparent],
                ),
                borderRadius: BorderRadius.circular(30),
              ),
              child: const Text(
                "WELCOME",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 3,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
        // Logo bulat
        ClipOval(
          child: Container(
            width: 65,
            height: 65,
            decoration: BoxDecoration(
              border: Border.all(
                color: accentColor.withOpacity(0.4),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(0.3),
                  blurRadius: 15,
                ),
              ],
            ),
            child: Image.asset(
              'assets/images/logo.jpg',
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  color: blackSoft,
                  child: Icon(
                    Icons.image_rounded,
                    color: accentColor,
                    size: 30,
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildVideoPlayer() {
    final ctrl = AppThemeController.instance;
    final accentColor = ctrl.landingAccent1;
    
    return Container(
      width: double.infinity,
      height: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: accentColor.withOpacity(0.15),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
        border: Border.all(
          color: accentColor.withOpacity(0.15),
          width: 0.5,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: _videoController.value.isInitialized
            ? FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              )
            : Container(
                color: blackSoft,
                child: const Center(
                  child: CircularProgressIndicator(
                    color: Color(0xFF0A66C2),
                    strokeWidth: 2.5,
                  ),
                ),
              ),
      ),
    );
  }

  // KARAKTER di bawah video
  Widget _buildCharacter() {
    final ctrl = AppThemeController.instance;
    final accentColor = ctrl.landingAccent1;
    
    return AnimatedBuilder(
      animation: Listenable.merge([_floatAnimation, _swayAnimation]),
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(_swayAnimation.value, _floatAnimation.value),
          child: Center(
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withOpacity(0.12),
                    Colors.transparent,
                  ],
                ),
              ),
              child: Image.asset(
                'assets/images/mybe.png',
                width: 100,
                height: 100,
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: accentColor.withOpacity(0.2),
                      border: Border.all(color: accentColor, width: 1.5),
                    ),
                    child: const Icon(Icons.person_rounded, color: Colors.white, size: 40),
                  );
                },
              ),
            ),
          ),
        );
      },
    );
  }

  // INFO CARD di atas ENTER TO LOGIN
  Widget _buildInfoCard() {
    final ctrl = AppThemeController.instance;
    final accentColor = ctrl.landingAccent1;
    
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.05),
            Colors.white.withOpacity(0.02),
          ],
        ),
        border: Border.all(
          color: accentColor.withOpacity(0.2),
          width: 0.8,
        ),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.info_outline_rounded, color: accentColor, size: 18),
              const SizedBox(width: 8),
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [accentColor, ctrl.landingAccent2],
                ).createShader(bounds),
                child: const Text(
                  "INFO ZERO CRASH",
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Text(
            "APK ZERO CRASH AKAN SELALU MEMBERIKAN UPDATE BAGUS DAN BUG WORK. SUPPORT KAMI LEWAT SALURAN WA & TELE DENGAN RESPON CEPAT 24/7.",
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.white70,
              letterSpacing: 0.5,
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  // ENTER TO LOGIN -> navigasi ke LoginPage
  Widget _buildLoginButton() {
    final ctrl = AppThemeController.instance;
    final accentColor = ctrl.landingAccent1;
    final accentColor2 = ctrl.landingAccent2;
    final accentColor3 = ctrl.landingAccent3;
    
    return AnimatedBuilder(
      animation: _glowAnimation,
      builder: (context, child) {
        return GestureDetector(
          onTap: _navigateToLogin,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 18),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [accentColor, accentColor2, accentColor3],
              ),
              borderRadius: BorderRadius.circular(30),
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(_glowAnimation.value * 0.6),
                  blurRadius: 25,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  "ENTER TO LOGIN",
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2.5,
                    color: Colors.white,
                  ),
                ),
                SizedBox(width: 10),
                Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 22),
              ],
            ),
          ),
        );
      },
    );
  }

  // APK BUG FREE CLIK -> buka saluran
  Widget _buildBugSpesial() {
    final ctrl = AppThemeController.instance;
    final accentColor = ctrl.landingAccent1;
    
    return GestureDetector(
      onTap: _openBugChannel,
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                accentColor.withOpacity(0.15),
                accentColor.withOpacity(0.05),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: accentColor.withOpacity(0.2),
              width: 0.5,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.verified_rounded,
                color: accentColor,
                size: 16,
              ),
              const SizedBox(width: 8),
              const Text(
                "APK BUG FREE CLIK",
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5,
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // CONTACT TITLE di tengah
  Widget _buildContactTitle() {
    final ctrl = AppThemeController.instance;
    final accentColor = ctrl.landingAccent1;
    
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        decoration: BoxDecoration(
          color: accentColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
            color: accentColor.withOpacity(0.15),
            width: 0.5,
          ),
        ),
        child: const Text(
          "HUBUNGI KAMI LEWAT",
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            letterSpacing: 2,
            color: Colors.white70,
          ),
        ),
      ),
    );
  }

  // CONTACT BUTTONS dengan icon dan desain modern
  Widget _buildContactButtons() {
    final ctrl = AppThemeController.instance;
    final themeAccent = ctrl.landingAccent1;
    
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildGlassButton(
                icon: Icons.telegram,
                label: "TELEGRAM",
                onTap: _openTelegram,
                // TELEGRAM tetap warna fixed (tidak berubah tema)
                iconColor: telegramBlue,
                bgColor: telegramBlue.withOpacity(0.1),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildGlassButton(
                icon: Icons.people_alt_rounded,
                label: "SALURAN",
                onTap: _openSaluran,
                // SALURAN gunakan warna hijau tetap
                iconColor: const Color(0xFF25D366),
                bgColor: const Color(0xFF25D366).withOpacity(0.1),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildGlassButton(
                icon: Icons.chat_rounded,
                label: "NO WA",
                onTap: _openWhatsApp,
                // NO WA gunakan warna hijau tetap
                iconColor: const Color(0xFF25D366),
                bgColor: const Color(0xFF25D366).withOpacity(0.1),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildGlassButton(
                icon: Icons.music_note_rounded,
                label: "TIKTOK",
                onTap: _openTikTok,
                // TIKTOK tetap warna fixed (tidak berubah tema)
                iconColor: tikTokBlue,
                bgColor: tikTokBlue.withOpacity(0.1),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildGlassButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required Color iconColor,
    required Color bgColor,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: bgColor,
          border: Border.all(
            color: iconColor.withOpacity(0.3),
            width: 1.2,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: iconColor.withOpacity(0.08),
              blurRadius: 10,
              spreadRadius: 1,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: iconColor, size: 22),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.8,
                color: iconColor,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCopyright() {
    final ctrl = AppThemeController.instance;
    final accentColor = ctrl.landingAccent1;
    
    return Column(
      children: [
        Container(
          width: 50,
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.transparent, accentColor, Colors.transparent],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          "© 2026 ZERO CRASH PROJECT • ALL RIGHTS RESERVED",
          style: TextStyle(
            fontSize: 9,
            letterSpacing: 1.5,
            color: accentColor.withOpacity(0.4),
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

// GRID PAINTER dari HomePage (RiyLix V5 style)
class RiyLixGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0x1AFFFFFF)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}