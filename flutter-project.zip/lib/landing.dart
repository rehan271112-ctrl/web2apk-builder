import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart';
import 'login_page.dart';
import 'utils/update_checker.dart';
import 'buy_account.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> with SingleTickerProviderStateMixin {
  // --- WARNA (Hitam, Abu-abu, Abu-abu terang) ---
  final Color bgBlack = Colors.black;
  final Color greyDark = Colors.grey[800]!;
  final Color greyLight = Colors.grey[500]!;
  final Color greyMedium = Colors.grey[600]!;
  
  final Color glassBorder = Colors.white.withOpacity(0.15);
  final Color cardBg = Colors.white.withOpacity(0.08);

  int _currentPage = 0;
  late AnimationController _indicatorAnimController;
  late Animation<double> _indicatorAnimation;
  final PageController _pageController = PageController();

  @override
  void initState() {
    super.initState();
    
    // Pindahkan inisialisasi controller ke sini
    _indicatorAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);

    _indicatorAnimation = Tween<double>(begin: 6.0, end: 18.0).animate(
      CurvedAnimation(parent: _indicatorAnimController, curve: Curves.easeInOut),
    );
    
    // Pindahkan check update ke sini
    WidgetsBinding.instance.addPostFrameCallback((_) {
      checkForUpdate(context);
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    _indicatorAnimController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          PageView(
            scrollDirection: Axis.vertical,
            controller: _pageController,
            onPageChanged: (int page) {
              setState(() => _currentPage = page);
            },
            children: [
              // PAGE 1: WELCOME
              const Center(
                child: Text(
                  ".WELCOME HERE",
                  style: TextStyle(
                    color: Colors.white, 
                    fontSize: 32, 
                    fontWeight: FontWeight.bold, 
                    fontFamily: 'Orbitron', 
                    letterSpacing: 2
                  ),
                ),
              ),

              // PAGE 2: INFORMATION
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      "Explanation About Apps Xeternalz",
                      style: TextStyle(
                        color: Colors.white, 
                        fontSize: 28, 
                        fontWeight: FontWeight.bold, 
                        fontFamily: 'Orbitron'
                      )
                    ),
                    SizedBox(height: 20),
                    Text(
                      "XETERNALZ CRASHER V18, adalah aplikasi Bug WhatsApp canggih yang dibangun oleh Tim Xeternalz Crasher dan didukung penuh oleh seluruh member setia komunitas Xeternalz Apps.",
                      style: TextStyle(color: Colors.white70, fontSize: 15, height: 1.6),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "Aplikasi Bug WhatsApp Xeternalz Crasher juga memiliki banyak feature-feature cangih contohnya seperti, Spotify, Music, Donghua, Anime, Ai Xeternalz, Comics, Nonton Film, Jadwal Sholat, Al-Quran dan masih ada Tools lainya yang berguna, Menu Bug nya juga tidak kalah keren, banyak pilihan Bug yang dapat dipakai dan ada menu Bug Group nya.",
                      style: TextStyle(color: Colors.white70, fontSize: 15, height: 1.6),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "Pakai lah aplikasi ini dengan bijak, dan ikuti lah peraturan-peraturan yang ada, terimakasih untuk all member Xeternalz Crasher yang sudah support",
                      style: TextStyle(color: Colors.white70, fontSize: 15, height: 1.6),
                    ),
                  ],
                ),
              ),

              // PAGE 3: LANDING ASLI (LOGIN + BUY)
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      greyDark.withOpacity(0.5),
                      bgBlack,
                      Colors.black,
                    ],
                  ),
                ),
                child: SafeArea(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 40),
                        
                        // LOGO / ILUSTRASI
                        Container(
                          width: 320,
                          height: 400,
                          child: Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Positioned.fill(
                                child: Image.asset(
                                  "assets/images/login.jpg",
                                  fit: BoxFit.contain,
                                  errorBuilder: (context, error, stackTrace) {
                                    return Container(
                                      color: Colors.transparent,
                                      padding: const EdgeInsets.all(8.0),
                                      alignment: Alignment.center,
                                      child: const Icon(
                                        Icons.bug_report,
                                        size: 100,
                                        color: Colors.white54,
                                      ),
                                    );
                                  },
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(bottom: 30),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const SizedBox(height: 5),
                                    const Text(
                                      "Please Log in or Buy Access to continue",
                                      style: TextStyle(
                                        color: Colors.white70,
                                        fontSize: 12,
                                        shadows: [
                                          Shadow(
                                            blurRadius: 4,
                                            color: Colors.black,
                                            offset: Offset(0, 1),
                                          ),
                                        ],
                                      ),
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 20),

                        // TOMBOL SIGN IN
                        Container(
                          width: double.infinity,
                          height: 55,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [greyDark, greyMedium],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.4),
                                blurRadius: 15,
                                offset: const Offset(0, 5),
                              ),
                            ],
                          ),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            onPressed: () {
                              Navigator.pushReplacement(
                                context, 
                                MaterialPageRoute(builder: (_) => LoginPage())
                              );
                            },
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.login, color: Colors.white, size: 20),
                                SizedBox(width: 10),
                                Text(
                                  "Sign In",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 16),

                        // TOMBOL BUY ACCESS
                        Container(
                          width: double.infinity,
                          height: 55,
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: greyLight.withOpacity(0.7), width: 1.5),
                          ),
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              side: BorderSide.none,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => const BuyAccountPage()),
                              );
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.shopping_bag,
                                  color: greyLight,
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  "Buy Account For Login Access",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: greyLight,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 30),

                        // Tombol Telegram Channel
                        Row(
                          children: [
                            Expanded(
                              child: _buildContactButton(
                                icon: FontAwesomeIcons.telegram,
                                label: "Telegram Channel",
                                url: "https://t.me/xeternalz_info",
                                color: greyLight,
                              ),
                            ),
                          ],
                        ),

                        const SizedBox(height: 40),
                        const Text(
                          "© 2026 Xeternalz Crasher Application Bugs", 
                          style: TextStyle(color: Colors.white38, fontSize: 11)
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),

          // HEADER TETAP
          Positioned(
            top: 0, 
            left: 0, 
            right: 0,
            child: SafeArea(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Text(
                        "XETERNALZ APPS", 
                        style: TextStyle(
                          color: Colors.white, 
                          fontWeight: FontWeight.bold, 
                          fontSize: 16, 
                          fontFamily: 'Orbitron'
                        )
                      ),
                      SizedBox(width: 5),
                      Icon(FontAwesomeIcons.vimeoV, color: Colors.grey, size: 16),
                    ],
                  ),
                  const SizedBox(height: 5),
                  const Text(
                    "App Version: 18.0", 
                    style: TextStyle(color: Colors.white54, fontSize: 12)
                  ),
                ],
              ),
            ),
          ),

          // FOOTER SWIPE
          Positioned(
            bottom: 30, 
            left: 0, 
            right: 0,
            child: Center(
              child: AnimatedOpacity(
                duration: const Duration(milliseconds: 300),
                opacity: _currentPage == 2 ? 0.0 : 1.0,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 22, 
                      height: 45,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white54, width: 2), 
                        borderRadius: BorderRadius.circular(20)
                      ),
                      alignment: Alignment.topCenter,
                      child: AnimatedBuilder(
                        animation: _indicatorAnimation,
                        builder: (context, child) => Padding(
                          padding: EdgeInsets.only(top: _indicatorAnimation.value),
                          child: Container(
                            width: 6, 
                            height: 6, 
                            decoration: const BoxDecoration(
                              color: Colors.white54, 
                              shape: BoxShape.circle
                            )
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      "Swipe Up to continue", 
                      style: TextStyle(color: Colors.white70, fontSize: 14)
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactButton({
    required IconData icon,
    required String label,
    required String url,
    required Color color,
  }) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: cardBg,
          border: Border.all(color: glassBorder),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: color, size: 20),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w600,
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }
}