import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'background_widget.dart';
import 'app_theme.dart';

// ─── ONBOARDING DATA MODEL ─────────────────────────────────────────────────────
class OnboardingPage {
  final IconData icon;
  final String title;
  final String subtitle;
  final String description;

  const OnboardingPage({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.description,
  });
}

// ─── ONBOARDING + LANDING ENTRY POINT ─────────────────────────────────────────
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  // ── Onboarding state ──────────────────────────────────────────────────────
  int _currentPage = 0;
  bool _showOnboarding = true;

  // ── Animation controllers ─────────────────────────────────────────────────
  late AnimationController _fadeInController;
  late AnimationController _buttonController;
  late AnimationController _pulseController;
  late AnimationController _landingEntranceController;
  late AnimationController _orbController;

  late Animation<double> _opacityAnim;
  late Animation<double> _buttonAnim;
  late Animation<double> _pulseAnim;
  late Animation<double> _landingFade;
  late Animation<Offset> _landingSlide;
  late Animation<double> _orbRotate;

  // ── Onboarding pages ──────────────────────────────────────────────────────
  final List<OnboardingPage> _onboardingPages = const [
    OnboardingPage(
      icon: FontAwesomeIcons.shieldHalved,
      title: 'ALICIA',
      subtitle: 'MBG RIZQY',
      description: 'TAP TO CONTINUE',
    ),
    OnboardingPage(
      icon: FontAwesomeIcons.satellite,
      title: 'SISTEM ONLINE',
      subtitle: 'TERPANTAU MASIH AMAN',
      description: 'TAP TO CONTINUE',
    ),
    OnboardingPage(
      icon: FontAwesomeIcons.code,
      title: 'RIZQYNST',
      subtitle: 'DEVELOPER APK ALICIA',
      description: 'TAP TO CONTINUE',
    ),
    OnboardingPage(
      icon: FontAwesomeIcons.lock,
      title: 'ALICIA AND RIZQY',
      subtitle: 'THANK FOR BUY APK ALICIA',
      description: 'TAP TO CONTINUE',
    ),
  ];

  @override
  void initState() {
    super.initState();

    // Onboarding fade + pulse
    _fadeInController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _opacityAnim = CurvedAnimation(
        parent: _fadeInController, curve: Curves.easeOutCubic);
    _fadeInController.forward();

    _pulseController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200));
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
    _pulseController.repeat(reverse: true);

    // Landing page button
    _buttonController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _buttonAnim = CurvedAnimation(
        parent: _buttonController, curve: Curves.easeOutCubic);

    // Landing entrance animation
    _landingEntranceController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900));
    _landingFade = CurvedAnimation(
        parent: _landingEntranceController, curve: Curves.easeOut);
    _landingSlide = Tween<Offset>(
      begin: const Offset(0, 0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(
        parent: _landingEntranceController, curve: Curves.easeOutCubic));

    // Orbiting decoration
    _orbController = AnimationController(
        vsync: this, duration: const Duration(seconds: 12));
    _orbRotate = Tween<double>(begin: 0, end: 2 * math.pi)
        .animate(_orbController);
    _orbController.repeat();
  }

  @override
  void dispose() {
    _fadeInController.dispose();
    _pulseController.dispose();
    _buttonController.dispose();
    _landingEntranceController.dispose();
    _orbController.dispose();
    super.dispose();
  }

  // ── Tap handler onboarding ────────────────────────────────────────────────
  void _onOnboardingTap() {
    HapticFeedback.lightImpact();

    if (_currentPage < _onboardingPages.length - 1) {
      _fadeInController.reverse().then((_) {
        setState(() => _currentPage++);
        _fadeInController.forward();
      });
    } else {
      _fadeInController.reverse().then((_) {
        setState(() => _showOnboarding = false);
        _landingEntranceController.forward();
        _buttonController.forward();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final themeNotifier = ThemeScope.of(context);
    return AnimatedBuilder(
      animation: themeNotifier,
      builder: (context, _) => Scaffold(
        backgroundColor: Colors.transparent,
        body: BackgroundWrapper(
          child: _showOnboarding ? _buildOnboarding() : _buildLanding(),
        ),
      ),
    );
  }

  // ─── ONBOARDING SCREEN ─────────────────────────────────────────────────────
  Widget _buildOnboarding() {
    final page = _onboardingPages[_currentPage];

    return GestureDetector(
      onTap: _onOnboardingTap,
      behavior: HitTestBehavior.opaque,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(color: Colors.black.withOpacity(0.50)),
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
              child: Container(color: Colors.transparent),
            ),
          ),
          FadeTransition(
            opacity: _opacityAnim,
            child: SafeArea(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(flex: 2),
                  AnimatedBuilder(
                    animation: _pulseAnim,
                    builder: (_, __) => Transform.scale(
                      scale: _pulseAnim.value,
                      child: _buildOnboardingIcon(page),
                    ),
                  ),
                  const SizedBox(height: 48),
                  Builder(
                    builder: (ctx) {
                      final titleColor = AppColors.accent1;
                      return Text(
                        page.title,
                        style: TextStyle(
                          color: titleColor,
                          fontSize: 36,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 6,
                          shadows: [
                            Shadow(
                              color: titleColor.withOpacity(0.6),
                              blurRadius: 20,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 12),
                  Text(
                    page.subtitle,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 4,
                    ),
                  ),
                  const Spacer(flex: 2),
                  _buildDotIndicators(),
                  const SizedBox(height: 32),
                  _buildTapHint(page.description),
                  const SizedBox(height: 60),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOnboardingIcon(OnboardingPage page) {
    return Builder(builder: (ctx) {
      final accent = AppColors.accent1;
      return Container(
        width: 130,
        height: 130,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: accent.withOpacity(0.6), width: 2),
          boxShadow: [
            BoxShadow(
              color: accent.withOpacity(0.35),
              blurRadius: 40,
              spreadRadius: 4,
            ),
          ],
          gradient: RadialGradient(
            colors: [
              accent.withOpacity(0.25),
              Colors.black.withOpacity(0.6),
            ],
          ),
        ),
        child: Center(
          child: FaIcon(page.icon, color: Colors.white, size: 52),
        ),
      );
    });
  }

  Widget _buildDotIndicators() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(_onboardingPages.length, (i) {
        final isActive = i == _currentPage;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          margin: const EdgeInsets.symmetric(horizontal: 5),
          width: isActive ? 28 : 8,
          height: 8,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            color: isActive
                ? Colors.white
                : Colors.white.withOpacity(0.3),
          ),
        );
      }),
    );
  }

  Widget _buildTapHint(String text) {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) => Opacity(
        opacity: (_pulseAnim.value - 1.0) / 0.08 * 0.5 + 0.5,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.touch_app_rounded,
                color: Colors.white54, size: 16),
            const SizedBox(width: 8),
            Text(
              text,
              style: const TextStyle(
                color: Colors.white54,
                fontSize: 11,
                letterSpacing: 3,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── LANDING PAGE (dirombak total) ─────────────────────────────────────────
  Widget _buildLanding() {
    final accent = AppColors.accent1;
    final size = MediaQuery.of(context).size;

    return Stack(
      fit: StackFit.expand,
      children: [
        // ── Layer 1: Dark overlay
        Container(color: Colors.black.withOpacity(0.55)),

        // ── Layer 2: Blur
        Positioned.fill(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 2, sigmaY: 2),
            child: Container(color: Colors.transparent),
          ),
        ),

        // ── Layer 3: Orbiting decorative rings
        AnimatedBuilder(
          animation: _orbRotate,
          builder: (_, __) {
            return Positioned(
              top: -size.width * 0.25,
              left: -size.width * 0.2,
              child: Transform.rotate(
                angle: _orbRotate.value,
                child: Container(
                  width: size.width * 0.9,
                  height: size.width * 0.9,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: accent.withOpacity(0.07), width: 1),
                  ),
                ),
              ),
            );
          },
        ),
        AnimatedBuilder(
          animation: _orbRotate,
          builder: (_, __) {
            return Positioned(
              bottom: -size.width * 0.3,
              right: -size.width * 0.3,
              child: Transform.rotate(
                angle: -_orbRotate.value * 0.7,
                child: Container(
                  width: size.width * 1.1,
                  height: size.width * 1.1,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: accent.withOpacity(0.05), width: 1.5),
                  ),
                ),
              ),
            );
          },
        ),

        // ── Layer 4: Main content
        FadeTransition(
          opacity: _landingFade,
          child: SlideTransition(
            position: _landingSlide,
            child: SafeArea(
              child: Column(
                children: [
                  const Spacer(flex: 3),

                  // ── Top badge / label
                  _buildStatusBadge(accent),
                  const SizedBox(height: 36),

                  // ── Logo circle with glow rings
                  _buildLogoSection(accent),
                  const SizedBox(height: 32),

                  // ── Brand title
                  _buildBrandTitle(accent),
                  const SizedBox(height: 8),

                  // ── Tagline
                  Text(
                    "POWERED BY RIZQY AND ALICIA",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.35),
                      fontSize: 10,
                      letterSpacing: 5,
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  const Spacer(flex: 2),

                  // ── Feature pills row
                  _buildFeaturePills(accent),

                  const Spacer(flex: 2),

                  // ── Divider line
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 40),
                    child: Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            accent.withOpacity(0.3),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),

                  // ── LANJUT button (animated)
                  AnimatedBuilder(
                    animation: _buttonAnim,
                    builder: (context, child) => IgnorePointer(
                      ignoring: _buttonAnim.value < 0.1,
                      child: Opacity(
                        opacity: _buttonAnim.value,
                        child: Transform.translate(
                          offset: Offset(0, 20 * (1 - _buttonAnim.value)),
                          child: child,
                        ),
                      ),
                    ),
                    child: _buildLanjutButton(accent),
                  ),

                  const SizedBox(height: 16),

                  // ── Already have account link
                  AnimatedBuilder(
                    animation: _buttonAnim,
                    builder: (context, child) => IgnorePointer(
                      ignoring: _buttonAnim.value < 0.1,
                      child: Opacity(
                        opacity: _buttonAnim.value * 0.6,
                        child: child,
                      ),
                    ),
                    child: TextButton(
                      onPressed: () =>
                          Navigator.pushNamed(context, '/login'),
                      child: Text(
                        "Sudah punya akun?  Login",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.45),
                          fontSize: 12,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),

                  const Spacer(flex: 2),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Status badge ──────────────────────────────────────────────────────────
  Widget _buildStatusBadge(Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: accent.withOpacity(0.1),
        border: Border.all(color: accent.withOpacity(0.25), width: 1),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.greenAccent.shade400,
              boxShadow: [
                BoxShadow(
                  color: Colors.greenAccent.withOpacity(0.6),
                  blurRadius: 6,
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            "SISTEM AKTIF",
            style: TextStyle(
              color: Colors.white.withOpacity(0.7),
              fontSize: 10,
              letterSpacing: 3,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  // ── Logo dengan glow rings bertingkat ─────────────────────────────────────
  Widget _buildLogoSection(Color accent) {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) {
        return SizedBox(
          width: 180,
          height: 180,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer ring
              Transform.scale(
                scale: _pulseAnim.value,
                child: Container(
                  width: 168,
                  height: 168,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: accent.withOpacity(0.1), width: 1),
                  ),
                ),
              ),
              // Mid ring
              Container(
                width: 136,
                height: 136,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: accent.withOpacity(0.2), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.08),
                      blurRadius: 20,
                      spreadRadius: 4,
                    ),
                  ],
                ),
              ),
              // Logo
              Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: accent.withOpacity(0.55), width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.35),
                      blurRadius: 30,
                      spreadRadius: 2,
                    ),
                    BoxShadow(
                      color: accent.withOpacity(0.15),
                      blurRadius: 60,
                      spreadRadius: 8,
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/logo.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: accent.withOpacity(0.2),
                      child: const Icon(
                        FontAwesomeIcons.shieldHalved,
                        color: Colors.white,
                        size: 40,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── Brand title ───────────────────────────────────────────────────────────
  Widget _buildBrandTitle(Color accent) {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [
              Colors.white,
              accent.withOpacity(0.85),
              Colors.white,
            ],
            stops: const [0.0, 0.5, 1.0],
          ).createShader(bounds),
          child: const Text(
            "MBG ALICIA",
            style: TextStyle(
              color: Colors.white,
              fontSize: 42,
              fontWeight: FontWeight.w900,
              letterSpacing: 5,
              height: 1,
            ),
          ),
        ),
      ],
    );
  }

  // ── Feature pills ─────────────────────────────────────────────────────────
  Widget _buildFeaturePills(Color accent) {
    final features = [
      (FontAwesomeIcons.shieldHalved, 'SECURE'),
      (FontAwesomeIcons.bolt, 'FAST'),
      (FontAwesomeIcons.satellite, 'REMOTE'),
    ];

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: features.asMap().entries.map((e) {
        final idx = e.key;
        final (icon, label) = e.value;
        return Padding(
          padding: EdgeInsets.only(
            left: idx == 0 ? 0 : 10,
          ),
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: Colors.white.withOpacity(0.04),
              border: Border.all(
                  color: accent.withOpacity(0.18), width: 1),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                FaIcon(icon,
                    size: 12, color: accent.withOpacity(0.8)),
                const SizedBox(width: 7),
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.55),
                    fontSize: 10,
                    letterSpacing: 2,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  // ── Tombol LANJUT ─────────────────────────────────────────────────────────
  Widget _buildLanjutButton(Color accent) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: SizedBox(
        width: double.infinity,
        height: 58,
        child: GestureDetector(
          onTap: () {
            HapticFeedback.mediumImpact();
            Navigator.pushNamed(context, '/login');
          },
          child: AnimatedBuilder(
            animation: _pulseAnim,
            builder: (_, child) => Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    accent.withOpacity(0.55),
                    accent.withOpacity(0.85),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: accent
                        .withOpacity(0.35 + (_pulseAnim.value - 1) * 2),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                    spreadRadius: 0,
                  ),
                ],
              ),
              child: child,
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Subtle inner shine
                Positioned(
                  top: 0,
                  left: 32,
                  right: 32,
                  child: Container(
                    height: 1,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          Colors.white.withOpacity(0.3),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text(
                      "LANJUT",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 4,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.15),
                      ),
                      child: const Icon(
                        Icons.arrow_forward_rounded,
                        color: Colors.white,
                        size: 16,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
