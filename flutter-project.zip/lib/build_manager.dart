// ════════════════════════════════════════════════════════════════
// BUILD MANAGER — Zero Crash
// Singleton: build tetap jalan meski halaman ditutup.
// Foreground Service menjaga Dart isolate hidup di background.
// ════════════════════════════════════════════════════════════════
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

// ─────────────────────────────────────────────────────────────
// MODELS
// ─────────────────────────────────────────────────────────────
enum BuildLogLevel { info, success, error, warning }

class BuildLog {
  final String timestamp;
  final String message;
  final BuildLogLevel level;
  BuildLog(this.timestamp, this.message, this.level);
}

class BuildSession {
  final String sessionId;
  final String sessionKey;
  final String fileName;
  String status;
  double progress;
  int percent;
  String currentStep;
  final List<BuildLog> logs;
  String? apkDownloadUrl;
  String? apkFileName;
  String? error;

  BuildSession({
    required this.sessionId,
    required this.sessionKey,
    required this.fileName,
    this.status = 'queued',
    this.progress = 0.1,
    this.percent = 10,
    this.currentStep = 'Build dimulai...',
    List<BuildLog>? logs,
    this.apkDownloadUrl,
    this.apkFileName,
    this.error,
  }) : logs = logs ?? [];

  bool get isFinished  => status == 'completed' || status == 'failed';
  bool get isCompleted => status == 'completed';
  bool get isFailed    => status == 'failed';
}

// ─────────────────────────────────────────────────────────────
// BUILD MANAGER — Singleton ChangeNotifier
// ─────────────────────────────────────────────────────────────
class BuildManager extends ChangeNotifier {
  BuildManager._();
  static final BuildManager instance = BuildManager._();

  BuildSession? _session;
  Timer?        _pollingTimer;
  bool          _notifiedFinish = false; // Pastikan notif hanya tampil sekali

  BuildSession? get session     => _session;
  bool get hasActiveSession     => _session != null;
  bool get isBuilding           => _session != null && !_session!.isFinished;

  // ── Start Session ─────────────────────────────────────────
  void startSession(BuildSession session) {
    _pollingTimer?.cancel();
    _notifiedFinish = false;
    _session = session;
    _startPolling();
    notifyListeners();
  }

  // ── Public: dipanggil dari build_apk.dart setelah trigger ─
  void startPollingFromOutside() {
    final s = _session;
    if (s == null || s.isFinished) return;
    _startPolling();
  }

  // ── Add Log ───────────────────────────────────────────────
  void addLog(String msg, {BuildLogLevel level = BuildLogLevel.info}) {
    final s = _session;
    if (s == null) return;
    s.logs.add(BuildLog(_ts(), msg, level));
    if (s.logs.length > 300) s.logs.removeAt(0);
    notifyListeners();
  }

  // ── Internal Polling ──────────────────────────────────────
  void _startPolling() {
    _pollingTimer?.cancel();
    // Poll tiap 4 detik agar lebih responsif
    _pollingTimer = Timer.periodic(
      const Duration(seconds: 4),
      (_) => _poll(),
    );
  }

  Future<void> _poll() async {
    final s = _session;
    if (s == null) return;
    if (s.isFinished) {
      _pollingTimer?.cancel();
      return;
    }

    try {
      final resp = await http.get(
        Uri.parse('$apiBaseUrl/api/buildStatus?sessionId=${s.sessionId}'),
        headers: {'x-session-key': s.sessionKey},
      ).timeout(const Duration(seconds: 10));

      if (resp.statusCode != 200) return;
      final data = jsonDecode(resp.body);
      if (data['success'] != true) return;

      final status   = (data['status']      as String?) ?? 'unknown';
      final progress = ((data['progress']   as num?)    ?? 0).toDouble();
      final step     = (data['currentStep'] as String?) ?? '';
      final rawLogs  = data['logs'] as List? ?? [];

      // Append new logs (deduplicate)
      for (final l in rawLogs) {
        final msg = (l['message'] as String?) ?? '';
        if (msg.isEmpty) continue;
        final key = msg.length > 40 ? msg.substring(0, 40) : msg;
        if (s.logs.any((e) => e.message.contains(key))) continue;

        BuildLogLevel lvl = BuildLogLevel.info;
        if (msg.contains('✅') || msg.contains('success'))              lvl = BuildLogLevel.success;
        else if (msg.contains('❌') || msg.contains('error') ||
                 msg.contains('failed'))                                 lvl = BuildLogLevel.error;
        else if (msg.contains('⚠️') || msg.contains('Warning'))        lvl = BuildLogLevel.warning;

        s.logs.add(BuildLog(_ts(), msg, lvl));
        if (s.logs.length > 300) s.logs.removeAt(0);
      }

      s.status      = status;
      s.progress    = (progress / 100).clamp(0.0, 1.0);
      s.percent     = progress.toInt();
      s.currentStep = step;

      // ── Update notifikasi progress di foreground service ──
      if (!s.isFinished) {
        await NotificationService.instance.updateForegroundProgress(
          percent: s.percent,
          step: step.isNotEmpty ? step : 'Compiling...',
          fileName: s.fileName,
        );
      }

      // ── Build Selesai ─────────────────────────────────────
      if (status == 'completed' && !_notifiedFinish) {
        _notifiedFinish = true;
        _pollingTimer?.cancel();
        s.apkDownloadUrl = data['apkDownloadUrl'] as String?;
        s.apkFileName    = data['apkFileName']    as String?;
        s.progress       = 1.0;
        s.percent        = 100;
        s.currentStep    = '✅ Build Selesai!';

        s.logs.add(BuildLog(_ts(), '', BuildLogLevel.info));
        s.logs.add(BuildLog(_ts(), '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', BuildLogLevel.info));
        s.logs.add(BuildLog(_ts(), '🎉 BUILD SUKSES! APK siap didownload.', BuildLogLevel.success));
        s.logs.add(BuildLog(_ts(), '📱 Buka halaman Build APK untuk download.', BuildLogLevel.info));
        s.logs.add(BuildLog(_ts(), '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', BuildLogLevel.info));

        // Stop foreground service → tampilkan notifikasi sukses HIGH priority
        await NotificationService.instance.stopForegroundAndShowSuccess(
          s.apkFileName ?? 'app.apk',
        );

      // ── Build Gagal ───────────────────────────────────────
      } else if (status == 'failed' && !_notifiedFinish) {
        _notifiedFinish = true;
        _pollingTimer?.cancel();
        s.error       = (data['error'] as String?) ?? 'Build gagal tanpa keterangan.';
        s.currentStep = '❌ Build Gagal';

        s.logs.add(BuildLog(_ts(), '', BuildLogLevel.info));
        s.logs.add(BuildLog(_ts(), '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', BuildLogLevel.error));
        s.logs.add(BuildLog(_ts(), '❌ BUILD GAGAL!', BuildLogLevel.error));
        s.logs.add(BuildLog(_ts(), '💥 ${s.error}', BuildLogLevel.error));
        s.logs.add(BuildLog(_ts(), '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━', BuildLogLevel.error));

        // Stop foreground service → tampilkan notifikasi error HIGH priority
        await NotificationService.instance.stopForegroundAndShowError(s.error!);
      }

      notifyListeners();
    } catch (_) {
      // Polling gagal — coba lagi berikutnya
    }
  }

  // ── Helpers ───────────────────────────────────────────────
  String _ts() {
    final n = DateTime.now();
    return '${n.hour.toString().padLeft(2,'0')}:${n.minute.toString().padLeft(2,'0')}:${n.second.toString().padLeft(2,'0')}';
  }

  void clearSession() {
    _pollingTimer?.cancel();
    _session = null;
    _notifiedFinish = false;
    notifyListeners();
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }
}

// ─────────────────────────────────────────────────────────────
// NOTIFICATION SERVICE — Singleton
// ─────────────────────────────────────────────────────────────
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  // ID notifikasi
  static const int _idProgress = 9000; // Foreground progress (ongoing)
  static const int _idSuccess  = 9001; // Build sukses
  static const int _idError    = 9002; // Build error

  static const String _channelId      = 'zero_crash_build';
  static const String _channelName    = 'Zero Crash — Build APK';
  static const String _channelDesc    = 'Notifikasi status build Flutter APK';
  static const String _channelIdHigh  = 'zero_crash_build_result';
  static const String _channelNameHigh = 'Zero Crash — Hasil Build';

  // ── Init — panggil dari main.dart ─────────────────────────
  Future<void> init() async {
    if (_initialized) return;

    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings    = InitializationSettings(android: androidSettings);

    await _plugin.initialize(
      initSettings,
      onDidReceiveNotificationResponse: (_) {},
    );

    final androidImpl = _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

    // Channel progress (low importance, tidak mengganggu)
    await androidImpl?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelId,
        _channelName,
        description: _channelDesc,
        importance: Importance.low,
        playSound: false,
        enableVibration: false,
      ),
    );

    // Channel hasil build (high importance, bunyi + vibrate)
    await androidImpl?.createNotificationChannel(
      const AndroidNotificationChannel(
        _channelIdHigh,
        _channelNameHigh,
        description: 'Notifikasi saat build selesai atau error',
        importance: Importance.high,
        playSound: true,
        enableVibration: true,
      ),
    );

    // Minta izin notifikasi Android 13+
    await androidImpl?.requestNotificationsPermission();

    _initialized = true;
  }

  // ── Start Foreground Service (build dimulai) ──────────────
  // Ini yang MENJAGA Dart isolate tetap hidup di background!
  Future<void> startForegroundBuild(String fileName) async {
    await _ensureInit();

    const details = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDesc,
      importance: Importance.low,
      priority:   Priority.low,
      icon:  '@mipmap/ic_launcher',
      color: Color(0xFF6A1B9A),
      showProgress: true,
      maxProgress:  100,
      progress:     5,
      ongoing:      true,     // Tidak bisa diswipe
      autoCancel:   false,
      onlyAlertOnce: true,
      ticker: 'Build APK dimulai',
    );

    // startForegroundService → Android tidak akan suspend isolate
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.startForegroundService(
          _idProgress,
          '🔨 Compiling $fileName...',
          'Build dimulai... (5%)',
          notificationDetails: details,
          startType: AndroidServiceStartType.startSticky,
          foregroundServiceTypes: {AndroidServiceForegroundType.foregroundServiceTypeDataSync},
        );
  }

  // ── Update Progress Notification tiap poll ────────────────
  Future<void> updateForegroundProgress({
    required int percent,
    required String step,
    required String fileName,
  }) async {
    await _ensureInit();

    // Bersihkan step dari emoji berlebihan untuk notifikasi
    final cleanStep = step
        .replaceAll('✅ ', '')
        .replaceAll('❌ ', '')
        .replaceAll('🔨 ', '')
        .replaceAll('📦 ', '')
        .replaceAll('📂 ', '')
        .replaceAll('🧹 ', '')
        .trim();

    final details = AndroidNotificationDetails(
      _channelId,
      _channelName,
      channelDescription: _channelDesc,
      importance: Importance.low,
      priority:   Priority.low,
      icon:  '@mipmap/ic_launcher',
      color: const Color(0xFF6A1B9A),
      showProgress: true,
      maxProgress:  100,
      progress:     percent,
      ongoing:      true,
      autoCancel:   false,
      onlyAlertOnce: true,  // Tidak vibrate tiap update
      ticker: 'Build $percent%',
    );

    // Update foreground service notification dengan progress terbaru
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.startForegroundService(
          _idProgress,
          '🔨 Compiling... $percent%',
          '$cleanStep — $fileName',
          notificationDetails: details,
          startType: AndroidServiceStartType.startNotSticky,
          foregroundServiceTypes: {AndroidServiceForegroundType.foregroundServiceTypeDataSync},
        );
  }

  // ── Stop Foreground + Tampilkan Notif Sukses ──────────────
  Future<void> stopForegroundAndShowSuccess(String apkName) async {
    await _ensureInit();

    // Stop foreground service dulu
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.stopForegroundService();

    // Hapus notifikasi progress
    await _plugin.cancel(_idProgress);

    // Tampilkan notif sukses dengan HIGH priority → muncul sebagai heads-up
    await _plugin.show(
      _idSuccess,
      '✅ Build APK Selesai! 🎉',
      'APK siap didownload. Tap untuk buka Zero Crash.',
      NotificationDetails(
        android: AndroidNotificationDetails(
          _channelIdHigh,
          _channelNameHigh,
          channelDescription: 'Notifikasi saat build selesai atau error',
          importance: Importance.high,
          priority:   Priority.high,
          icon:  '@mipmap/ic_launcher',
          color: const Color(0xFF00C853),
          largeIcon: const DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
          styleInformation: BigTextStyleInformation(
            '🎉 APK "$apkName" berhasil dibuild!\n\nBuka Zero Crash → Build APK → DOWNLOAD & INSTALL APK.',
            contentTitle: '✅ Build APK Selesai!',
            summaryText:  'Zero Crash Builder',
          ),
          fullScreenIntent: false,
          ticker:     'Build APK berhasil!',
          autoCancel: true,
          playSound:  true,
          enableVibration: true,
        ),
      ),
    );
  }

  // ── Stop Foreground + Tampilkan Notif Error ───────────────
  Future<void> stopForegroundAndShowError(String errorMsg) async {
    await _ensureInit();

    // Stop foreground service
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.stopForegroundService();

    // Hapus notifikasi progress
    await _plugin.cancel(_idProgress);

    final shortErr = errorMsg.length > 120
        ? '${errorMsg.substring(0, 120)}...'
        : errorMsg;

    await _plugin.show(
      _idError,
      '❌ Build APK Gagal',
      'Build error. Tap untuk lihat log.',
      NotificationDetails(
        android: AndroidNotificationDetails(
          _channelIdHigh,
          _channelNameHigh,
          channelDescription: 'Notifikasi saat build selesai atau error',
          importance: Importance.high,
          priority:   Priority.high,
          icon:  '@mipmap/ic_launcher',
          color: const Color(0xFFD32F2F),
          largeIcon: const DrawableResourceAndroidBitmap('@mipmap/ic_launcher'),
          styleInformation: BigTextStyleInformation(
            '💥 Error: $shortErr\n\nBuka Zero Crash → Build APK untuk lihat detail.',
            contentTitle: '❌ Build APK Gagal',
            summaryText:  'Zero Crash Builder',
          ),
          ticker:     'Build APK gagal',
          autoCancel: true,
          playSound:  true,
          enableVibration: true,
        ),
      ),
    );
  }

  // ── Legacy: dipakai dari build_apk.dart saat build mulai ─
  Future<void> showBuildStarted(String fileName) async {
    // Delegasikan ke foreground service
    await startForegroundBuild(fileName);
  }

  // ── Legacy: masih ada supaya tidak break ─────────────────
  Future<void> showBuildSuccess(String apkName) async {
    await stopForegroundAndShowSuccess(apkName);
  }
  Future<void> showBuildError(String errorMsg) async {
    await stopForegroundAndShowError(errorMsg);
  }

  Future<void> dismissBuildNotification() async {
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.stopForegroundService();
    await _plugin.cancel(_idProgress);
  }

  Future<void> _ensureInit() async {
    if (!_initialized) await init();
  }
}
