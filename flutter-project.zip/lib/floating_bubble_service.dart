// lib/floating_bubble_service.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

const String _apiBase = 'http://panelinstltess.sanzcloud.biz.id:4560';

class FloatingBubbleService {
  FloatingBubbleService._();
  static final FloatingBubbleService instance = FloatingBubbleService._();

  bool _isShowing = false;
  bool get isShowing => _isShowing;

  // ─── Cek izin ───────────────────────────────────────────────
  Future<bool> isPermissionGranted() async {
    try {
      return await FlutterOverlayWindow.isPermissionGranted();
    } catch (_) {
      return false;
    }
  }

  // ─── Minta izin "tampilkan di atas aplikasi lain" ──────────
  Future<bool> requestPermission(BuildContext context) async {
    bool granted = false;
    try {
      granted = await FlutterOverlayWindow.isPermissionGranted();
    } catch (_) {}

    if (granted) return true;

    // Tampilkan dialog
    bool? confirm;
    if (context.mounted) {
      confirm = await showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF1A0030),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18)),
          title: const Row(children: [
            Icon(Icons.bubble_chart_rounded,
                color: Colors.purpleAccent, size: 26),
            SizedBox(width: 10),
            Text('Izin Diperlukan',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 16)),
          ]),
          content: const Text(
            'Aplikasi memerlukan izin "Tampilkan di atas aplikasi lain" '
            'agar bubble bisa muncul saat kamu berada di aplikasi lain.\n\n'
            'Tekan OK untuk membuka pengaturan izin.',
            style: TextStyle(
                color: Colors.white70, fontSize: 13, height: 1.5),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal',
                  style: TextStyle(color: Colors.white54)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purpleAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('OK, Buka Izin',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      );
    }

    if (confirm != true) return false;

    // Buka halaman izin sistem
    try {
      await FlutterOverlayWindow.requestPermission();
    } catch (_) {}

    // Tunggu user kembali ke app
    await Future.delayed(const Duration(seconds: 2));

    try {
      return await FlutterOverlayWindow.isPermissionGranted();
    } catch (_) {
      return false;
    }
  }

  // ─── Fetch MySender dari API (background) ──────────────────
  Future<void> fetchAndUpdateSenders(String sessionKey) async {
    if (sessionKey.isEmpty) return;
    try {
      final res = await http
          .get(Uri.parse('$_apiBase/mySender?key=$sessionKey'))
          .timeout(const Duration(seconds: 15));

      if (res.statusCode != 200) return;
      final data = jsonDecode(res.body) as Map<String, dynamic>;
      if (data['valid'] != true) return;

      final globalList =
          (data['globalConnections'] as List<dynamic>? ?? []);
      final privateList =
          (data['privateConnections'] as List<dynamic>? ?? []);

      final globalCount = globalList.length;
      final privateCount = privateList.length;
      final globalSenders = globalList
          .whereType<Map>()
          .map((e) =>
              e['sessionName']?.toString() ??
              e['id']?.toString() ??
              'Unknown')
          .toList();
      final privateSenders = privateList
          .whereType<Map>()
          .map((e) =>
              e['sessionName']?.toString() ??
              e['id']?.toString() ??
              'Unknown')
          .toList();

      // Kirim data terbaru ke overlay yang sudah aktif
      try {
        final prefs = await SharedPreferences.getInstance();
        final raw = prefs.getString('bubble_session_data');
        if (raw != null) {
          final map = jsonDecode(raw) as Map<String, dynamic>;
          map['globalSenderCount'] = globalCount;
          map['privateSenderCount'] = privateCount;
          map['globalSenders'] = globalSenders;
          map['privateSenders'] = privateSenders;
          await prefs.setString('bubble_session_data', jsonEncode(map));
          // Update overlay yang aktif via shareData
          await FlutterOverlayWindow.shareData(jsonEncode(map));
        }
      } catch (_) {}
    } catch (_) {}
  }

  // ══════════════════════════════════════════════════════════════
  //  SHOW BUBBLE — tampilkan overlay di atas semua apps
  //  Urutan: izin → simpan data → showOverlay → fetch sender background
  // ══════════════════════════════════════════════════════════════
  Future<bool> showBubble({
    required BuildContext context,
    required String sessionKey,
    required List<Map<String, dynamic>> listBug,
    required int globalSenderCount,
    required bool canGlobal,
  }) async {
    // 1. Cek & minta izin
    bool hasPermission = false;
    try {
      hasPermission = await requestPermission(context);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Error cek izin: $e'),
          backgroundColor: Colors.red,
        ));
      }
      return false;
    }

    if (!hasPermission) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('⚠️ Izin ditolak. Aktifkan dari Pengaturan > Izin Aplikasi.'),
            backgroundColor: Color(0xFF8B0000),
            duration: Duration(seconds: 4),
          ),
        );
      }
      return false;
    }

    // 2. Simpan data dasar ke SharedPreferences dulu (tanpa nunggu API)
    final basicData = {
      'sessionKey': sessionKey,
      'listBug': listBug,
      'globalSenderCount': globalSenderCount,
      'privateSenderCount': 0,
      'globalSenders': <String>[],
      'privateSenders': <String>[],
      'canGlobal': canGlobal,
    };

    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('bubble_session_data', jsonEncode(basicData));
    } catch (_) {}

    // 3. LANGSUNG tampilkan overlay — jangan tunggu network!
    try {
      final isActive = await FlutterOverlayWindow.isActive();
      if (!isActive) {
        await FlutterOverlayWindow.showOverlay(
          height: 65,
          width: 65,
          alignment: OverlayAlignment.bottomCenter,
          flag: OverlayFlag.defaultFlag,
          enableDrag: true,
          positionGravity: PositionGravity.auto,
        );
        // Beri waktu overlay init
        await Future.delayed(const Duration(milliseconds: 500));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Gagal tampilkan bubble: $e'),
          backgroundColor: Colors.red,
        ));
      }
      return false;
    }

    // 4. Kirim data dasar ke overlay
    try {
      await FlutterOverlayWindow.shareData(jsonEncode(basicData));
    } catch (_) {}

    _isShowing = true;

    // 5. Fetch sender dari API di background (tidak blokir UI)
    fetchAndUpdateSenders(sessionKey);

    return true;
  }

  // ─── Sembunyikan bubble ─────────────────────────────────────
  Future<void> hideBubble() async {
    try {
      final isActive = await FlutterOverlayWindow.isActive();
      if (isActive) await FlutterOverlayWindow.closeOverlay();
    } catch (_) {}
    _isShowing = false;
  }

  // ─── Toggle bubble ──────────────────────────────────────────
  Future<bool> toggleBubble({
    required BuildContext context,
    required String sessionKey,
    required List<Map<String, dynamic>> listBug,
    required int globalSenderCount,
    required bool canGlobal,
  }) async {
    bool isActive = false;
    try {
      isActive = await FlutterOverlayWindow.isActive();
    } catch (_) {}

    if (isActive) {
      await hideBubble();
      return false;
    } else {
      return showBubble(
        context: context,
        sessionKey: sessionKey,
        listBug: listBug,
        globalSenderCount: globalSenderCount,
        canGlobal: canGlobal,
      );
    }
  }
}
