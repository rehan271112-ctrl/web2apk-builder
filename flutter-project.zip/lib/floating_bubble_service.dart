// lib/floating_bubble_service.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FloatingBubbleService {
  FloatingBubbleService._();
  static final FloatingBubbleService instance = FloatingBubbleService._();

  bool _isShowing = false;
  bool get isShowing => _isShowing;

  // ─── Cek izin SYSTEM_ALERT_WINDOW ──────────────────────────
  Future<bool> isPermissionGranted() async {
    try {
      return await FlutterOverlayWindow.isPermissionGranted();
    } catch (_) {
      return false;
    }
  }

  // ─── Minta izin "tampilkan di atas aplikasi lain" ───────────
  Future<bool> requestPermission(BuildContext context) async {
    final granted = await isPermissionGranted();
    if (granted) return true;

    // Tampilkan dialog penjelasan
    if (context.mounted) {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: const Color(0xFF1A0030),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Row(children: [
            Icon(Icons.bubble_chart_rounded,
                color: Colors.purpleAccent, size: 26),
            SizedBox(width: 10),
            Text('Izin Diperlukan',
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 16)),
          ]),
          content: const Text(
            'Aplikasi memerlukan izin "Tampilkan di atas aplikasi lain" agar bubble bisa muncul saat kamu berada di aplikasi lain.\n\nTekan OK untuk membuka pengaturan.',
            style: TextStyle(color: Colors.white70, fontSize: 13, height: 1.5),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal',
                  style: TextStyle(color: Colors.white54)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purpleAccent,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child: const Text('OK, Buka Izin',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      );

      if (confirm != true) return false;
    }

    // Buka halaman izin sistem
    await FlutterOverlayWindow.requestPermission();

    // Tunggu user kembali ke app dan cek ulang
    await Future.delayed(const Duration(seconds: 2));
    return await isPermissionGranted();
  }

  // ─── Tampilkan bubble ───────────────────────────────────────
  Future<bool> showBubble({
    required BuildContext context,
    required String sessionKey,
    required List<Map<String, dynamic>> listBug,
    required int globalSenderCount,
    required bool canGlobal,
  }) async {
    // 1. Cek & minta izin
    final hasPermission = await requestPermission(context);
    if (!hasPermission) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('⚠️ Izin ditolak. Aktifkan dari Pengaturan.'),
            backgroundColor: Color(0xFF8B0000),
          ),
        );
      }
      return false;
    }

    // 2. Simpan data ke SharedPreferences (dibaca oleh overlay)
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'bubble_session_data',
      jsonEncode({
        'sessionKey': sessionKey,
        'listBug': listBug,
        'globalSenderCount': globalSenderCount,
        'canGlobal': canGlobal,
      }),
    );

    // 3. Tampilkan overlay jika belum aktif
    final isActive = await FlutterOverlayWindow.isActive();
    if (!isActive) {
      await FlutterOverlayWindow.showOverlay(
        height: 65,
        width: 65,
        alignment: OverlayAlignment.bottomCenter,
        flag: OverlayFlag.defaultFlag,
        enableDrag: true,
        positionGravity: PositionGravity.auto,
        overlayTitle: 'Zero Crash Bubble',
        overlayContent: 'Bubble aktif — tap untuk kirim bug',
        notificationVisibility: NotificationVisibility.visibilityPublic,
      );
    }

    // 4. Kirim data ke overlay (jika sudah aktif)
    try {
      await FlutterOverlayWindow.shareData(jsonEncode({
        'sessionKey': sessionKey,
        'listBug': listBug,
        'globalSenderCount': globalSenderCount,
        'canGlobal': canGlobal,
      }));
    } catch (_) {}

    _isShowing = true;
    return true;
  }

  // ─── Sembunyikan bubble ─────────────────────────────────────
  Future<void> hideBubble() async {
    try {
      final isActive = await FlutterOverlayWindow.isActive();
      if (isActive) {
        await FlutterOverlayWindow.closeOverlay();
      }
    } catch (_) {}
    _isShowing = false;
  }

  // ─── Toggle bubble ──────────────────────────────────────────
  Future<bool> toggleBubble({
    required BuildContext context,
    required String sessionKey,
    required List<Map<String, dynamic>> listBug,
    required int globalSenderCount,
    required bool canGlobal,
  }) async {
    final isActive = await FlutterOverlayWindow.isActive();
    if (isActive) {
      await hideBubble();
      return false;
    } else {
      return showBubble(
        context: context,
        sessionKey: sessionKey,
        listBug: listBug,
        globalSenderCount: globalSenderCount,
        canGlobal: canGlobal,
      );
    }
  }
}
