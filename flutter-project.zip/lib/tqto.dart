// tqto.dart (Modified with DeviceDashboard style)

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'app_theme.dart';
import 'background_notifier.dart';

// ─── METALLIC GOLD THEME COLORS ──────────────────────────────────────────────
class TqTheme {
  static const bg            = Color(0xFFFFC107);
  static const surface       = Color(0xFFFFCA28);
  static const surface2      = Color(0xFFFFD54F);
  static const surface3      = Color(0xFFFFE082);
  static const cardDark      = Color(0xFFFFB300);
  
  // Metallic Red Gradient Colors
  static const red1          = Color(0xFFFFD600);
  static const red2          = Color(0xFFFFAB00);
  static const red3          = Color(0xFFFF6F00);
  static const red4          = Color(0xFF6B4E00);
  
  // Metallic Accents
  static const gold          = Color(0xFFFFD700);
  static const silver        = Color(0xFFC0C0C0);
  static const chrome        = Color(0xFFE8E8E8);
  
  static const accent1       = Color(0xFFFFD600);
  static const accent2       = Color(0xFFFFAB00);
  static const accent3       = Color(0xFFFF6F00);
  static const success       = Color(0xFF4CAF50);
  static const warning       = Color(0xFFFFAB40);
  static const error         = Color(0xFFFF1744);
  
  static const textPrimary   = Color(0xFFBF360C);
  static const textSec       = Color(0xCCBF360C);
  static const textMuted     = Color(0x99BF360C);
  
  static const shadow        = Color(0x40000000);
  static const shadowHeavy   = Color(0x80000000);
}

// ─── SHADOW UTILITIES ──────────────────────────────────────────────────────
class TqShadowUtils {
  static List<BoxShadow> get soft {
    return const [
      BoxShadow(color: AppColors.shadow, blurRadius: 8, offset: Offset(0, 2)),
      BoxShadow(color: AppColors.shadowHeavy, blurRadius: 2, offset: Offset(0, 1)),
    ];
  }
  
  static List<BoxShadow> get medium {
    return const [
      BoxShadow(color: AppColors.shadow, blurRadius: 16, offset: Offset(0, 4)),
      BoxShadow(color: AppColors.shadowHeavy, blurRadius: 4, offset: Offset(0, 2)),
    ];
  }
  
  static List<BoxShadow> get heavy {
    return const [
      BoxShadow(color: AppColors.shadow, blurRadius: 24, offset: Offset(0, 8)),
      BoxShadow(color: AppColors.shadowHeavy, blurRadius: 8, offset: Offset(0, 4)),
      BoxShadow(color: AppColors.shadowHeavy, blurRadius: 2, offset: Offset(0, 1)),
    ];
  }
  
  static List<BoxShadow> get card {
    return const [
      BoxShadow(color: AppColors.shadowHeavy, blurRadius: 20, offset: Offset(0, 10)),
      BoxShadow(color: AppColors.shadow, blurRadius: 6, offset: Offset(0, 2)),
    ];
  }
  
  static List<BoxShadow> get glow {
    return [
      BoxShadow(color: AppColors.accent1.withOpacity(0.4), blurRadius: 12, offset: Offset(0, 0)),
      BoxShadow(color: AppColors.shadowHeavy, blurRadius: 8, offset: Offset(0, 4)),
    ];
  }
}

class ThanksToPage extends StatefulWidget {
  const ThanksToPage({super.key});

  @override
  State<ThanksToPage> createState() => ThanksToPageState();
}

class ThanksToPageState extends State<ThanksToPage> {
  static const String _baseUrl = 'http://alanwinter.alannxd.my.id:3298';

  List<dynamic> _tqList = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _initializePage();
  }

  Future<void> _initializePage() async {
    await _fetchTqData();
  }

  Future<void> _fetchTqData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/tq'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        if (data['status'] == true && data['result'] != null) {
          setState(() {
            _tqList = data['result'];
            _isLoading = false;
          });
        } else {
          setState(() {
            _errorMessage = 'Failed to load data';
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _errorMessage = 'Error: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Connection error';
        _isLoading = false;
      });
    }
  }

  Future<void> _launchTelegram(String contact) async {
    String telegramUrl = contact;
    if (!contact.startsWith('http')) {
      telegramUrl = 'https://$contact';
    }
    final Uri url = Uri.parse(telegramUrl);
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Could not launch $contact', style: const TextStyle(color: Colors.white)),
          backgroundColor: AppColors.accent1,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      );
    }
  }

  // ─── ENHANCED GLASS CARD ─────────────────────────────────────────────────
  Widget _buildGlassCard({
    required Widget child,
    EdgeInsetsGeometry padding = const EdgeInsets.all(16),
    BorderRadiusGeometry borderRadius = const BorderRadius.all(Radius.circular(20)),
    List<Color>? gradient,
    bool hasShadow = true,
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        gradient: gradient != null
            ? LinearGradient(colors: gradient, begin: Alignment.topLeft, end: Alignment.bottomRight)
            : LinearGradient(
                colors: [AppColors.surfaceLight, AppColors.surface2],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        borderRadius: borderRadius,
        border: Border.all(
          color: AppColors.accent1.withOpacity(0.15),
          width: 0.5,
        ),
        boxShadow: hasShadow ? ShadowUtils.card : null,
      ),
      child: child,
    );
  }

  // ─── ENHANCED HEADER ─────────────────────────────────────────────────────
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border(
          bottom: BorderSide(
            color: AppColors.accent1.withOpacity(0.2),
            width: 0.5,
          ),
        ),
        boxShadow: ShadowUtils.soft,
      ),
      child: Row(
        children: [
          // Menghapus back button
          const SizedBox(width: 0),
          const SizedBox(width: 16),
          Expanded(
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppColors.accent1, AppColors.accent3],
                    ),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: AppColors.accent1.withOpacity(0.2),
                      width: 0.5,
                    ),
                  ),
                  child: const Icon(
                    Icons.people_rounded,
                    color: Colors.white,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'SPECIAL THANKS TO',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                        letterSpacing: 1.5,
                      ),
                    ),
                    Text(
                      '${_tqList.length} contributors',
                      style: TextStyle(
                        color: AppColors.textMuted,
                        fontSize: 11,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _fetchTqData,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.surfaceLight, AppColors.surface2],
                ),
                shape: BoxShape.circle,
                border: Border.all(
                  color: AppColors.accent1.withOpacity(0.3),
                  width: 1,
                ),
                boxShadow: ShadowUtils.soft,
              ),
              child: Icon(
                Icons.refresh_rounded,
                color: AppColors.accent1,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── ENHANCED CONTRIBUTOR CARD ───────────────────────────────────────────
  Widget _buildTqCard(Map<String, dynamic> item, int index) {
    final name = item['name']?.toString().replaceAll(RegExp(r'<[^>]*>'), '') ?? 'Unknown';
    final status = item['status'] ?? 'Member';
    final ppUrl = item['ppUrl'] ?? '';
    final contact = item['contac'] ?? '';
    
    // Determine status color - Metallic Red theme
    Color statusColor;
    if (status.toLowerCase().contains('owner')) {
      statusColor = AppColors.accent1;
    } else if (status.toLowerCase().contains('dev') || status.toLowerCase().contains('developer')) {
      statusColor = AppColors.accent1;
    } else if (status.toLowerCase().contains('mod') || status.toLowerCase().contains('moderator')) {
      statusColor = AppColors.accent2;
    } else {
      statusColor = AppColors.success;
    }
    
    return Container(
      margin: EdgeInsets.only(
        left: 16,
        right: 16,
        bottom: index == _tqList.length - 1 ? 20 : 12,
      ),
      child: _buildGlassCard(
        padding: const EdgeInsets.all(16),
        borderRadius: BorderRadius.circular(20),
        child: Row(
          children: [
            // Avatar with gradient border
            Container(
              width: 65,
              height: 65,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [statusColor, AppColors.accent3],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                boxShadow: ShadowUtils.medium,
              ),
              child: Padding(
                padding: const EdgeInsets.all(2),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: AppColors.surfaceLight,
                  ),
                  child: ClipOval(
                    child: ppUrl.isNotEmpty
                        ? Image.network(
                            ppUrl,
                            fit: BoxFit.cover,
                            width: 65,
                            height: 65,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Container(
                                color: AppColors.surface2,
                                child: Center(
                                  child: CircularProgressIndicator(
                                    color: statusColor,
                                    strokeWidth: 2,
                                  ),
                                ),
                              );
                            },
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                color: AppColors.surface2,
                                child: Icon(
                                  Icons.person,
                                  color: AppColors.textMuted,
                                  size: 30,
                                ),
                              );
                            },
                          )
                        : Container(
                            color: AppColors.surface2,
                            child: Icon(
                              Icons.person,
                              color: AppColors.textMuted,
                              size: 30,
                            ),
                          ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
            // User info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      color: AppColors.textPrimary,
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: statusColor.withOpacity(0.3),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      status.toUpperCase(),
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Telegram button - Metallic Red
            GestureDetector(
              onTap: () => _launchTelegram(contact),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.accent1, AppColors.accent3],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: ShadowUtils.soft,
                  border: Border.all(
                    color: AppColors.accent1.withOpacity(0.2),
                    width: 0.5,
                  ),
                ),
                child: const Icon(
                  FontAwesomeIcons.telegram,
                  color: Colors.white,
                  size: 20,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── LOADING STATE ───────────────────────────────────────────────────────
  Widget _buildLoadingState() {
    final accent = AppColors.accent1;
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [accent, accent.withOpacity(0.6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: accent.withOpacity(0.4), blurRadius: 16),
                BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 8, offset: const Offset(0, 4)),
              ],
              border: Border.all(color: accent.withOpacity(0.3), width: 1),
            ),
            child: const Center(
              child: SizedBox(
                width: 50,
                height: 50,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  color: Colors.white,
                  backgroundColor: Colors.transparent,
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Loading Contributors...',
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w500,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Fetching data from server',
            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
          ),
        ],
      ),
    );
  }

  // ─── ERROR STATE ─────────────────────────────────────────────────────────
  Widget _buildErrorState() {
    final accent = AppColors.accent1;
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFE53935), Color(0xFFB71C1C)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: Colors.red.withOpacity(0.4), blurRadius: 16),
              ],
              border: Border.all(color: accent.withOpacity(0.2), width: 1),
            ),
            child: const Icon(Icons.error_outline_rounded, color: Colors.white, size: 40),
          ),
          const SizedBox(height: 20),
          const Text(
            'Error Loading Data',
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1),
          ),
          const SizedBox(height: 8),
          Text(
            _errorMessage ?? 'Something went wrong',
            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          GestureDetector(
            onTap: _fetchTqData,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 12),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [accent, accent.withOpacity(0.6)]),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [BoxShadow(color: accent.withOpacity(0.3), blurRadius: 8)],
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.refresh_rounded, color: Colors.white, size: 18),
                  SizedBox(width: 8),
                  Text('TRY AGAIN', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 1)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── EMPTY STATE ─────────────────────────────────────────────────────────
  Widget _buildEmptyState() {
    final accent = AppColors.accent1;
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [accent, accent.withOpacity(0.6)]),
              shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: accent.withOpacity(0.3), blurRadius: 16)],
              border: Border.all(color: accent.withOpacity(0.2), width: 1),
            ),
            child: const Icon(Icons.people_outline_rounded, color: Colors.white, size: 40),
          ),
          const SizedBox(height: 20),
          const Text(
            'No Contributors Found',
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1),
          ),
          const SizedBox(height: 8),
          Text(
            'The list is currently empty',
            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 13),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Ambil background & tema dari notifier global (sama seperti halaman lain)
    final bgNotifier    = BackgroundScope.of(context);
    final themeNotifier = ThemeScope.of(context);

    return AnimatedBuilder(
      animation: Listenable.merge([bgNotifier, themeNotifier]),
      builder: (ctx, _) {
        // Warna tema aktif (kuning default, bisa berubah sesuai pilihan user)
        final accent  = AppColors.accent1;
        final surface = AppColors.surface;

        return Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: Column(
              children: [
                _buildDynamicHeader(ctx, accent, surface),
                Expanded(
                  child: _isLoading
                      ? _buildLoadingState()
                      : _errorMessage != null
                          ? _buildErrorState()
                          : _tqList.isEmpty
                              ? _buildEmptyState()
                              : ListView.builder(
                                  padding: const EdgeInsets.only(top: 12, bottom: 20),
                                  physics: const BouncingScrollPhysics(),
                                  itemCount: _tqList.length,
                                  itemBuilder: (context, index) {
                                    return _buildDynamicCard(_tqList[index], index, accent);
                                  },
                                ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ─── HEADER DINAMIS (ikut tema) ──────────────────────────────────────────
  Widget _buildDynamicHeader(BuildContext context, Color accent, Color surface) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.5),
        border: Border(
          bottom: BorderSide(color: accent.withOpacity(0.3), width: 0.5),
        ),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 2)),
        ],
      ),
      child: Row(
        children: [
          // Back button
          GestureDetector(
            onTap: () => Navigator.maybePop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: accent.withOpacity(0.3), width: 0.5),
              ),
              child: Icon(Icons.arrow_back_ios_new_rounded, color: accent, size: 14),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [accent, accent.withOpacity(0.6)],
                    ),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: accent.withOpacity(0.2), width: 0.5),
                  ),
                  child: const Icon(Icons.people_rounded, color: Colors.white, size: 18),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'SPECIAL THANKS TO',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: 1.5,
                      ),
                    ),
                    Text(
                      '${_tqList.length} contributors',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 11,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: _fetchTqData,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: accent.withOpacity(0.3), width: 1),
              ),
              child: Icon(Icons.refresh_rounded, color: accent, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  // ─── CARD DINAMIS (ikut tema) ─────────────────────────────────────────────
  Widget _buildDynamicCard(Map<String, dynamic> item, int index, Color accent) {
    final name    = item['name']?.toString().replaceAll(RegExp(r'<[^>]*>'), '') ?? 'Unknown';
    final status  = item['status'] ?? 'Member';
    // API menggunakan field 'contac' (tanpa t) dan 'ppUrl'
    final contact = item['contac'] ?? item['contact'] ?? '';
    final photo   = item['ppUrl']  ?? item['photo']   ?? '';

    Color statusColor;
    switch (status.toString().toLowerCase()) {
      case 'vip':
        statusColor = const Color(0xFFFFD700);
        break;
      case 'admin':
        statusColor = accent;
        break;
      default:
        statusColor = const Color(0xFF4CAF50);
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.45),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: accent.withOpacity(0.2), width: 0.5),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.3), blurRadius: 8, offset: const Offset(0, 2)),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            // Avatar
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(colors: [accent, accent.withOpacity(0.5)]),
                border: Border.all(color: accent.withOpacity(0.3), width: 1),
              ),
              child: photo.isNotEmpty
                  ? ClipOval(
                      child: Image.network(
                        photo,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Icon(Icons.person_rounded, color: Colors.white, size: 24),
                      ),
                    )
                  : Icon(Icons.person_rounded, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 12),
            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 5),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: statusColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: statusColor.withOpacity(0.4), width: 1),
                    ),
                    child: Text(
                      status.toString().toUpperCase(),
                      style: TextStyle(
                        color: statusColor,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // Telegram button
            GestureDetector(
              onTap: () => _launchTelegram(contact),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [accent, accent.withOpacity(0.6)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: accent.withOpacity(0.3), blurRadius: 8),
                  ],
                ),
                child: const Icon(FontAwesomeIcons.telegram, color: Colors.white, size: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}