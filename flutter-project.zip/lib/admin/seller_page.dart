import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> {
  final _newUser = TextEditingController();
  final _newPass = TextEditingController();
  final _days = TextEditingController();
  final _editUser = TextEditingController();
  final _editDays = TextEditingController();
  bool loading = false;

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _neoButton({
    required String label,
    required VoidCallback onTap,
    Color bg = NeoBrutalismColors.yellow,
    Color textColor = NeoBrutalismColors.black,
    double fontSize = 14,
    bool isLoading = false,
    double width = double.infinity,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: width,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
          boxShadow: [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.1),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    color: textColor,
                    strokeWidth: 2.5,
                  ),
                )
              : Text(
                  label,
                  style: TextStyle(
                    fontSize: fontSize,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                    color: textColor,
                    fontFamily: 'Inter',
                  ),
                ),
        ),
      ),
    );
  }

  Widget _neoInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    bool isNumber = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      style: const TextStyle(
        color: NeoBrutalismColors.black,
        fontSize: 14,
        fontWeight: FontWeight.w600,
        fontFamily: 'Inter',
      ),
      cursorColor: NeoBrutalismColors.black,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
          color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w600,
        ),
        prefixIcon: Icon(
          icon,
          color: NeoBrutalismColors.darkGrey,
          size: 20,
        ),
        filled: true,
        fillColor: NeoBrutalismColors.grey,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
      ),
    );
  }

  // ==================== API LOGIC ====================
  Future<void> _create() async {
    final u = _newUser.text.trim();
    final p = _newPass.text.trim();
    final d = _days.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      return _showNotification("Semua field wajib diisi", isError: true);
    }
    setState(() => loading = true);
    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/api/user/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _showNotification("Akun berhasil dibuat!");
        _newUser.clear();
        _newPass.clear();
        _days.clear();
        Navigator.pop(context);
      } else {
        _showNotification(data['message'] ?? 'Gagal membuat akun.', isError: true);
      }
    } catch (e) {
      _showNotification("Terjadi kesalahan: ${e.toString()}", isError: true);
    }
    setState(() => loading = false);
  }

  Future<void> _edit() async {
    final u = _editUser.text.trim();
    final d = _editDays.text.trim();
    if (u.isEmpty || d.isEmpty) {
      return _showNotification("Username dan durasi wajib diisi", isError: true);
    }
    setState(() => loading = true);
    try {
      final res = await http.get(Uri.parse(
          "$baseUrl/api/user/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _showNotification("Durasi berhasil diperbarui.");
        _editUser.clear();
        _editDays.clear();
        Navigator.pop(context);
      } else {
        _showNotification(data['message'] ?? 'Gagal mengubah durasi.', isError: true);
      }
    } catch (e) {
      _showNotification("Terjadi kesalahan: ${e.toString()}", isError: true);
    }
    setState(() => loading = false);
  }

  void _showNotification(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: NeoBrutalismColors.white,
              size: 20,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                message,
                style: const TextStyle(
                  color: NeoBrutalismColors.white,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ),
          ],
        ),
        backgroundColor: isError ? NeoBrutalismColors.pink : NeoBrutalismColors.purple,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  // ==================== DIALOGS ====================
  void _showCreateAccountDialog() {
    _newUser.clear();
    _newPass.clear();
    _days.clear();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ===== HEADER =====
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.purple,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                    ),
                    child: const Icon(
                      Icons.person_add,
                      color: NeoBrutalismColors.white,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "BUAT USER BARU",
                    style: TextStyle(
                      color: NeoBrutalismColors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Inter',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                "Role: MEMBER",
                style: TextStyle(
                  color: NeoBrutalismColors.darkGrey,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
              ),
              const SizedBox(height: 20),

              // ===== FIELDS =====
              _neoInput(
                controller: _newUser,
                hint: "contoh: jokowiddo",
                icon: Icons.person_outline,
              ),
              const SizedBox(height: 14),
              _neoInput(
                controller: _newPass,
                hint: "contoh: 123",
                icon: Icons.lock_outline,
                obscure: true,
              ),
              const SizedBox(height: 14),
              _neoInput(
                controller: _days,
                hint: "contoh: 30",
                icon: Icons.calendar_today,
                isNumber: true,
              ),
              const SizedBox(height: 20),

              // ===== BUTTONS =====
              _neoButton(
                label: "BUAT AKUN",
                onTap: _create,
                bg: NeoBrutalismColors.yellow,
                textColor: NeoBrutalismColors.black,
                fontSize: 14,
                isLoading: loading,
              ),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: loading ? null : () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.grey,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                  ),
                  child: const Center(
                    child: Text(
                      "BATAL",
                      style: TextStyle(
                        color: NeoBrutalismColors.black,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        fontFamily: 'Inter',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showEditDurationDialog() {
    _editUser.clear();
    _editDays.clear();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // ===== HEADER =====
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.blue,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                    ),
                    child: const Icon(
                      Icons.edit_calendar,
                      color: NeoBrutalismColors.white,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "UBAH DURASI HARI",
                    style: TextStyle(
                      color: NeoBrutalismColors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Inter',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                "Perpanjang durasi akun",
                style: TextStyle(
                  color: NeoBrutalismColors.darkGrey,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
              ),
              const SizedBox(height: 20),

              // ===== FIELDS =====
              _neoInput(
                controller: _editUser,
                hint: "ketik username nya",
                icon: Icons.person_outline,
              ),
              const SizedBox(height: 14),
              _neoInput(
                controller: _editDays,
                hint: "batas 30 hari untuk reseller",
                icon: Icons.calendar_today,
                isNumber: true,
              ),
              const SizedBox(height: 12),

              // ===== INFO =====
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.grey,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                ),
                child: Row(
                  children: [
                    const Icon(
                      Icons.info_outline,
                      color: NeoBrutalismColors.darkGrey,
                      size: 14,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        "UNLIMITED UNTUK SELAIN RESELLER",
                        style: TextStyle(
                          color: NeoBrutalismColors.darkGrey,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Inter',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // ===== BUTTONS =====
              _neoButton(
                label: "UBAH DURASI",
                onTap: _edit,
                bg: NeoBrutalismColors.yellow,
                textColor: NeoBrutalismColors.black,
                fontSize: 14,
                isLoading: loading,
              ),
              const SizedBox(height: 10),
              GestureDetector(
                onTap: loading ? null : () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.grey,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                  ),
                  child: const Center(
                    child: Text(
                      "BATAL",
                      style: TextStyle(
                        color: NeoBrutalismColors.black,
                        fontWeight: FontWeight.w800,
                        fontSize: 13,
                        fontFamily: 'Inter',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== MAIN BUILD ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ===== HEADER (TANPA BACK BUTTON) =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.purple,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.storefront,
                          color: NeoBrutalismColors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Reseller Panel",
                        style: TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 4),
                    child: Text(
                      "Kelola akun pelanggan dengan mudah",
                      style: TextStyle(
                        color: NeoBrutalismColors.darkGrey,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // ===== CARD 1: BUAT USER BARU =====
                  GestureDetector(
                    onTap: _showCreateAccountDialog,
                    child: _neoCard(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.purple.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: NeoBrutalismColors.purple, width: 2),
                            ),
                            child: const Icon(
                              Icons.person_add,
                              color: NeoBrutalismColors.purple,
                              size: 24,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "BUAT USER BARU",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.black,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                Text(
                                  "Role: MEMBER",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.darkGrey,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios,
                            color: NeoBrutalismColors.darkGrey,
                            size: 14,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ===== CARD 2: UBAH DURASI HARI =====
                  GestureDetector(
                    onTap: _showEditDurationDialog,
                    child: _neoCard(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.blue.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: NeoBrutalismColors.blue, width: 2),
                            ),
                            child: const Icon(
                              Icons.edit_calendar,
                              color: NeoBrutalismColors.blue,
                              size: 24,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "UBAH DURASI HARI",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.black,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                                Text(
                                  "Perpanjang durasi akun",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.darkGrey,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios,
                            color: NeoBrutalismColors.darkGrey,
                            size: 14,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}