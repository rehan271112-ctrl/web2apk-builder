// ghost_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'config.dart';
import 'color_theme.dart';

enum GhostSection { none, deleteAccount, createAccount, listUser }

class GhostPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const GhostPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<GhostPage> createState() => _GhostPageState();
}

class _GhostPageState extends State<GhostPage> with SingleTickerProviderStateMixin {
  // ── Theme color getters ──
  Color get bgDark => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;
  Color get lightPurple => AppThemeController.instance.theme.lightPurple;
  Color get cardGlass => AppThemeController.instance.theme.cardGlass;
  Color get borderGlass => AppThemeController.instance.theme.borderGlass;

  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  
  // ── Statistik Users ──
  int totalUsers = 0;
  Map<String, int> roleStats = {};
  bool isStatsLoading = false;

  // Permission system - sama seperti di backend
  final Map<String, List<String>> rolePermissions = {
    'ghost': ['member', 'reseller', 'vip', 'owner', 'admin', 'dev', 'ghost', 'helper', 'founder', 'pt', 'tk'],
    'owner': ['member', 'reseller', 'vip', 'owner', 'admin', 'dev', 'tk', 'pt'],
    'dev': ['member', 'reseller', 'vip', 'owner', 'admin', 'dev', 'tk', 'pt'],
    'admin': ['member', 'reseller', 'vip', 'admin'],
    'founder': ['member', 'reseller', 'vip', 'admin', 'founder'],
    'helper': ['member', 'reseller', 'helper'],
    'pt': ['member', 'pt'],
    'tk': ['member', 'tk'],
    'reseller': ['member'],
    'vip': [],
    'member': []
  };

  late List<String> roleOptions;
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  GhostSection _activeSection = GhostSection.none;
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;

  // --- TEMA PURPLE/DARK (sama seperti dashboard) ---
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    sessionKey = widget.sessionKey;
    
    // ✅ FIX: Inisialisasi roleOptions dengan benar
    // Ghost bisa membuat semua role, jadi ambil dari rolePermissions
    roleOptions = rolePermissions['ghost'] ?? ['member'];
    selectedRole = roleOptions.isNotEmpty ? roleOptions.first : 'member';
    
    _animController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeInOut);
    _scaleAnim = Tween<double>(begin: 0.96, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeOutCubic),
    );
    _animController.forward();
    _fetchUserStats(); // Fetch stats saat page load
  }

  // ✅ FIX: Perbaiki penempatan @override
  @override
  void dispose() {
    _animController.dispose();
    deleteController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void _selectSection(GhostSection section) {
    setState(() => _activeSection = section);
    _animController.forward(from: 0);
    if (section == GhostSection.listUser) _fetchUsers();
  }

  // ── FETCH USER STATS ──
  Future<void> _fetchUserStats() async {
    if (!mounted) return;
    setState(() => isStatsLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/userRoleStats?key=$sessionKey'),
      );
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (mounted) {
          setState(() {
            totalUsers = data['totalUsers'] ?? 0;
            roleStats = Map<String, int>.from(
              (data['roleStats'] ?? {}).map((k, v) => MapEntry(k, v is int ? v : 0))
            );
            isStatsLoading = false;
          });
        }
      }
    } catch (e) {
      print('Error fetching stats: $e');
      if (mounted) setState(() => isStatsLoading = false);
    }
  }

  void _goBack() {
    setState(() => _activeSection = GhostSection.none);
    _animController.forward(from: 0);
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Tidak diizinkan melihat daftar user.');
      }
    } catch (_) {
      _alert("Error", "Gagal memuat user list.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
          '$apiBaseUrl/deleteUser?key=$sessionKey&username=$username',
        ),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Tidak dapat menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        '$apiBaseUrl/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat sebagai ${newUserRole.toUpperCase()}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        setState(() => newUserRole = 'member');
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Tidak dapat menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentPurple.withOpacity(0.3)),
        ),
        title: Text(title, style: TextStyle(color: primaryWhite)),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: accentPurple)),
          ),
        ],
      ),
    );
  }

  // ── SELECTOR PAGE (MENU UTAMA) ──
  Widget _buildSelectorPage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              children: [
                Icon(FontAwesomeIcons.ghost, color: accentPurple, size: 28),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "GHOST PANEL",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                    Text(
                      "Kelola User Management",
                      style: TextStyle(color: textGrey, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Stats Section
          if (!isStatsLoading)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cardGlass,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: borderGlass),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      _buildStatChip(
                        label: "TOTAL USER",
                        value: "$totalUsers",
                        icon: Icons.people,
                      ),
                      const SizedBox(width: 12),
                      _buildStatChip(
                        label: "ROLE AKTIF",
                        value: "${roleStats.length}",
                        icon: Icons.shield,
                      ),
                    ],
                  ),
                  if (roleStats.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: roleStats.entries.map((e) {
                        return Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: accentPurple.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: accentPurple.withOpacity(0.3)),
                          ),
                          child: Text(
                            "${e.key.toUpperCase()}: ${e.value}",
                            style: TextStyle(
                              color: accentPurple,
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ]
                ],
              ),
            ),
          const SizedBox(height: 24),

          // Menu Buttons
          Text(
            "Pilih Menu",
            style: TextStyle(
              color: primaryWhite,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          _buildMenuButton(
            icon: Icons.person_add_alt_1,
            title: "Buat Akun",
            subtitle: "Create new user account",
            onTap: () => _selectSection(GhostSection.createAccount),
          ),
          const SizedBox(height: 12),
          _buildMenuButton(
            icon: Icons.person_remove_alt_1,
            title: "Hapus Akun",
            subtitle: "Delete existing user",
            onTap: () => _selectSection(GhostSection.deleteAccount),
          ),
          const SizedBox(height: 12),
          _buildMenuButton(
            icon: Icons.list,
            title: "Daftar User",
            subtitle: "View all users (paginated)",
            onTap: () => _selectSection(GhostSection.listUser),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuButton({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardGlass,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderGlass),
          boxShadow: [
            BoxShadow(
              color: primaryPurple.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: accentPurple.withOpacity(0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(icon, color: accentPurple, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      color: primaryWhite,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: TextStyle(color: textGrey.withOpacity(0.6), fontSize: 12),
                  ),
                ],
              ),
            ),
            Icon(Icons.arrow_forward_ios, color: accentPurple.withOpacity(0.5), size: 16),
          ],
        ),
      ),
    );
  }

  // ── DELETE SECTION ──
  Widget _buildDeleteSection() {
    return ScaleTransition(
      scale: _scaleAnim,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with Back Button
            Row(
              children: [
                GestureDetector(
                  onTap: _goBack,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: accentPurple.withOpacity(0.1),
                      shape: BoxShape.circle,
                      border: Border.all(color: accentPurple.withOpacity(0.3)),
                    ),
                    child: Icon(Icons.arrow_back, color: accentPurple),
                  ),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "HAPUS AKUN",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Delete existing user account",
                      style: TextStyle(color: textGrey, fontSize: 12),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Input Field
            Text(
              "Username",
              style: TextStyle(color: primaryWhite, fontSize: 13, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Container(
              decoration: BoxDecoration(
                color: cardGlass,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: borderGlass),
              ),
              child: TextField(
                controller: deleteController,
                style: TextStyle(color: primaryWhite),
                decoration: InputDecoration(
                  hintText: "Masukkan username...",
                  hintStyle: TextStyle(color: textGrey.withOpacity(0.5)),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  prefixIcon: Icon(Icons.person_outline, color: accentPurple.withOpacity(0.5)),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Delete Button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: isLoading ? null : _deleteUser,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent,
                  disabledBackgroundColor: Colors.redAccent.withOpacity(0.5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: isLoading
                    ? SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(primaryWhite),
                        ),
                      )
                    : const Text(
                        "HAPUS AKUN",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: Colors.white,
                        ),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── CREATE SECTION ──
  Widget _buildCreateSection() {
    return ScaleTransition(
      scale: _scaleAnim,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with Back Button
              Row(
                children: [
                  GestureDetector(
                    onTap: _goBack,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: accentPurple.withOpacity(0.1),
                        shape: BoxShape.circle,
                        border: Border.all(color: accentPurple.withOpacity(0.3)),
                      ),
                      child: Icon(Icons.arrow_back, color: accentPurple),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "BUAT AKUN",
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        "Create new user account",
                        style: TextStyle(color: textGrey, fontSize: 12),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // Form Fields
              _buildFormField(
                label: "Username",
                controller: createUsernameController,
                icon: Icons.person_outline,
              ),
              const SizedBox(height: 14),
              _buildFormField(
                label: "Password",
                controller: createPasswordController,
                icon: Icons.lock_outline,
                isPassword: true,
              ),
              const SizedBox(height: 14),
              _buildFormField(
                label: "Days (Durasi Hari)",
                controller: createDayController,
                icon: Icons.calendar_today,
              ),
              const SizedBox(height: 14),

              // Role Dropdown
              Text(
                "Role",
                style: TextStyle(color: primaryWhite, fontSize: 13, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Container(
                decoration: BoxDecoration(
                  color: cardGlass,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: borderGlass),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: newUserRole,
                    items: roleOptions.map((role) {
                      return DropdownMenuItem(
                        value: role,
                        child: Text(
                          role.toUpperCase(),
                          style: TextStyle(
                            color: primaryWhite,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      );
                    }).toList(),
                    onChanged: (value) => setState(() => newUserRole = value ?? 'member'),
                    dropdownColor: bgDark,
                    isExpanded: true,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    icon: Icon(Icons.arrow_drop_down, color: accentPurple),
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Create Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: isLoading ? null : _createAccount,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: accentPurple,
                    disabledBackgroundColor: accentPurple.withOpacity(0.5),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  child: isLoading
                      ? SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(primaryWhite),
                          ),
                        )
                      : const Text(
                          "BUAT AKUN",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            color: Colors.white,
                          ),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFormField({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    bool isPassword = false,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(color: primaryWhite, fontSize: 13, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: cardGlass,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: borderGlass),
          ),
          child: TextField(
            controller: controller,
            obscureText: isPassword,
            style: TextStyle(color: primaryWhite),
            decoration: InputDecoration(
              hintText: "Masukkan $label...",
              hintStyle: TextStyle(color: textGrey.withOpacity(0.5)),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              prefixIcon: Icon(icon, color: accentPurple.withOpacity(0.5)),
            ),
          ),
        ),
      ],
    );
  }

  // ── LIST USER SECTION ──
  Widget _buildListUserSection() {
    return Column(
      children: [
        // Header with back button
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Row(
            children: [
              GestureDetector(
                onTap: _goBack,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: accentPurple.withOpacity(0.1),
                    shape: BoxShape.circle,
                    border: Border.all(color: accentPurple.withOpacity(0.3)),
                  ),
                  child: Icon(Icons.arrow_back, color: accentPurple),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "DAFTAR USER",
                      style: TextStyle(
                        color: primaryWhite,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      "Total: ${filteredList.length} user",
                      style: TextStyle(color: textGrey, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        // Role Filter
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          child: Container(
            decoration: BoxDecoration(
              color: cardGlass,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: borderGlass),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: selectedRole,
                items: ['all', ...fullUserList.map((u) => u['role'] as String).toSet().toList()].map((role) {
                  return DropdownMenuItem(
                    value: role,
                    child: Text(
                      role == 'all' ? 'SEMUA ROLE' : role.toUpperCase(),
                      style: TextStyle(
                        color: primaryWhite,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      selectedRole = value;
                      _filterAndPaginate();
                    });
                  }
                },
                dropdownColor: bgDark,
                isExpanded: true,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                icon: Icon(Icons.filter_list, color: accentPurple),
              ),
            ),
          ),
        ),

        // User List
        Expanded(
          child: isLoading
              ? Center(child: CircularProgressIndicator(color: accentPurple))
              : filteredList.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.person_outline, color: textGrey, size: 52),
                          const SizedBox(height: 12),
                          Text("Tidak ada user ditemukan", style: TextStyle(color: textGrey)),
                        ],
                      ),
                    )
                  : ListView(
                      padding: const EdgeInsets.only(bottom: 20),
                      children: [
                        ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                        if (totalPages > 1)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            child: _buildPagination(),
                          ),
                      ],
                    ),
        ),
      ],
    );
  }

  Widget _buildStatChip({
    required String label,
    required String value,
    required IconData icon,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: primaryPurple.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accentPurple.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Icon(icon, color: accentPurple, size: 16),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: textGrey, fontSize: 10)),
                Text(
                  value,
                  style: TextStyle(
                    color: primaryWhite,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: accentPurple.withOpacity(0.3)),
            ),
            child: Icon(Icons.person, color: accentPurple),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(
                    color: primaryWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()}  •  EXP: ${user['expiredDate']}",
                  style: TextStyle(color: textGrey.withOpacity(0.6), fontSize: 11),
                ),
                if (user['parent'] != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    "PARENT: ${user['parent'] ?? 'SYSTEM'}",
                    style: TextStyle(color: textGrey.withOpacity(0.4), fontSize: 10),
                  ),
                ],
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.redAccent.withOpacity(0.08),
              shape: BoxShape.circle,
              border: Border.all(color: Colors.redAccent.withOpacity(0.25)),
            ),
            child: IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
              onPressed: () async {
                final confirm = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    backgroundColor: bgDark,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(color: accentPurple.withOpacity(0.3)),
                    ),
                    title: Text("Konfirmasi", style: TextStyle(color: primaryWhite)),
                    content: Text(
                      "Hapus user '${user['username']}'?",
                      style: TextStyle(color: textGrey),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(context, false),
                        child: Text("Batal", style: TextStyle(color: accentPurple)),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(context, true),
                        child: const Text("Hapus", style: TextStyle(color: Colors.redAccent)),
                      ),
                    ],
                  ),
                );
                if (confirm == true) {
                  deleteController.text = user['username'];
                  await _deleteUser();
                  _fetchUsers();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isActive = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isActive ? accentPurple : const Color(0xFF0D0D0D),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: isActive ? accentPurple : borderGlass),
              boxShadow: isActive
                  ? [BoxShadow(color: accentPurple.withOpacity(0.3), blurRadius: 8)]
                  : [],
            ),
            child: Center(
              child: Text(
                "$page",
                style: TextStyle(
                  color: isActive ? Colors.white : textGrey,
                  fontSize: 13,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  // ── BUILD ─────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, primaryPurple.withOpacity(0.06), bgDark],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: _activeSection == GhostSection.none
                ? _buildSelectorPage()
                : _activeSection == GhostSection.deleteAccount
                    ? _buildDeleteSection()
                    : _activeSection == GhostSection.createAccount
                        ? _buildCreateSection()
                        : _buildListUserSection(),
          ),
        ),
      ),
    );
  }
}
