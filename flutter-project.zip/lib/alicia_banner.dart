// ═══════════════════════════════════════════════════════════════════
// alicia_banner.dart  —  Widget banner Alicia (Ejen Ali)
// Versi 2.0 — dengan fitur "Mampus" permanen via server
//
// CARA PAKAI di dashboard_page.dart:
//   import 'alicia_banner.dart';
//
//   // Ganti ini:
//   const _VideoBanner(videoPath: 'assets/videos/flux.mp4'),
//   // Dengan ini:
//   AliciaBanner(sessionKey: sessionKey),
//
// ASET yang dibutuhkan (taruh di assets/images/):
//   - alicia.png          → pose normal
//   - alicia_senyum.png   → pose senyum lebar (setelah minta maaf)
//   - alicia_ngambek.png  → ekspresi ngambek (klik 1)
//   - alicia_marah1.png   → ekspresi marah dikit (klik 2)
//   - alicia_marah2.png   → ekspresi paling marah (klik 3)
//   - xp.png              → background (sudah ada)
//
// CATATAN: Jika gambar belum lengkap, widget pakai placeholder otomatis.
// ═══════════════════════════════════════════════════════════════════

import 'dart:convert';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// ── Base URL server (sama dengan _kBase di dashboard_page.dart) ──
const _kBase = 'http://alanwinter.alannxd.my.id:3298';

class AliciaBanner extends StatefulWidget {
  final String sessionKey;
  const AliciaBanner({super.key, required this.sessionKey});

  @override
  State<AliciaBanner> createState() => _AliciaBannerState();
}

class _AliciaBannerState extends State<AliciaBanner>
    with TickerProviderStateMixin {
  // ── State utama ──────────────────────────────────────────────────
  bool _isLoading = true;   // sedang load dari server
  bool _isHidden = false;   // Alicia disembunyikan permanen (Mampus)
  bool _isSmiley = false;   // ekspresi senyum (setelah Minta Maaf)

  int  _clickCount = 0;     // 0=normal, 1=ngambek, 2=marah1, 3+=marah2
  bool _isDizzy = false;    // sedang animasi pening
  bool _showPopup = false;  // tampilkan popup pilihan

  // ── Animation Controllers ────────────────────────────────────────
  late AnimationController _shakeCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _eyeCtrl;
  late AnimationController _popupCtrl;
  late AnimationController _smileCtrl;   // efek senyum (scale in)
  late AnimationController _vanishCtrl;  // efek menghilang (fade+slide)

  late Animation<double> _shakeAnim;
  late Animation<double> _orbitAnim;
  late Animation<double> _eyeAnim;
  late Animation<double> _popupAnim;
  late Animation<double> _smileAnim;
  late Animation<double> _vanishAnim;

  static const double _orbitRadius = 30;
  static const int    _miniHeadCount = 3;

  // ─────────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    _initControllers();
    _loadStatus();
  }

  void _initControllers() {
    _shakeCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 600));
    _shakeAnim = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 0, end: -9), weight: 1),
      TweenSequenceItem(tween: Tween(begin: -9, end: 9), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 9, end: -7), weight: 2),
      TweenSequenceItem(tween: Tween(begin: -7, end: 7), weight: 2),
      TweenSequenceItem(tween: Tween(begin: 7, end: 0),  weight: 1),
    ]).animate(CurvedAnimation(parent: _shakeCtrl, curve: Curves.easeInOut));

    _orbitCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1600));
    _orbitAnim = Tween<double>(begin: 0, end: 2 * pi)
        .animate(CurvedAnimation(parent: _orbitCtrl, curve: Curves.linear));

    _eyeCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1000));
    _eyeAnim = Tween<double>(begin: 0, end: 2 * pi)
        .animate(CurvedAnimation(parent: _eyeCtrl, curve: Curves.linear));

    _popupCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 280));
    _popupAnim = CurvedAnimation(parent: _popupCtrl, curve: Curves.easeOutBack);

    _smileCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 500));
    _smileAnim = CurvedAnimation(parent: _smileCtrl, curve: Curves.elasticOut);

    _vanishCtrl = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 700));
    _vanishAnim = CurvedAnimation(parent: _vanishCtrl, curve: Curves.easeIn);
  }

  @override
  void dispose() {
    _shakeCtrl.dispose();
    _orbitCtrl.dispose();
    _eyeCtrl.dispose();
    _popupCtrl.dispose();
    _smileCtrl.dispose();
    _vanishCtrl.dispose();
    super.dispose();
  }

  // ── Load status dari server (+ SharedPreferences sebagai cache) ──
  Future<void> _loadStatus() async {
    // 1. Cek cache lokal dulu (biar langsung tahu state-nya tanpa nunggu API)
    final prefs = await SharedPreferences.getInstance();
    final cachedHidden = prefs.getBool('alicia_hidden_${_username}') ?? false;
    if (cachedHidden && mounted) {
      setState(() { _isHidden = true; _isLoading = false; });
      return;
    }

    // 2. Sinkronisasi dengan server
    try {
      final res = await http.get(
        Uri.parse('$_kBase/api/user/profile?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 8));

      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        if (body['success'] == true) {
          final aliciaHidden = body['profile']['aliciaHidden'] == true;
          await prefs.setBool('alicia_hidden_${_username}', aliciaHidden);
          if (mounted) setState(() { _isHidden = aliciaHidden; _isLoading = false; });
          return;
        }
      }
    } catch (_) {}

    if (mounted) setState(() => _isLoading = false);
  }

  String get _username => widget.sessionKey; // dipakai sebagai key cache

  // ── Kirim status ke server ────────────────────────────────────────
  Future<void> _setAliciaHidden(bool hidden) async {
    // Simpan ke SharedPreferences sebagai fallback offline
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('alicia_hidden_${_username}', hidden);

    // Kirim ke server
    try {
      await http.post(
        Uri.parse('$_kBase/api/user/alicia-hidden'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'hidden': hidden,
        }),
      ).timeout(const Duration(seconds: 8));
    } catch (_) {
      // Kalau server tidak bisa dicapai, SharedPreferences tetap
      // menjaga state-nya — Alicia tetap hilang saat restart
    }
  }

  // ── Aksi klik karakter ────────────────────────────────────────────
  void _onTap() {
    if (_isSmiley) {
      // Sedang pose senyum, klik = kembali normal lalu pening
      setState(() { _isSmiley = false; });
    }

    setState(() {
      _clickCount = (_clickCount >= 3) ? 3 : _clickCount + 1;
      _isDizzy = true;
      _showPopup = true;
    });

    _shakeCtrl.forward(from: 0);
    _orbitCtrl.repeat();
    _eyeCtrl.repeat();
    _popupCtrl.forward(from: 0);

    // Berhenti pening setelah 2.5 detik
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (!mounted) return;
      _orbitCtrl.stop();
      _eyeCtrl.stop();
      setState(() => _isDizzy = false);
    });
  }

  // ── Tombol "Minta Maaf" ──────────────────────────────────────────
  void _onSorry() async {
    _popupCtrl.reverse();
    _orbitCtrl.stop();
    _eyeCtrl.stop();

    setState(() {
      _isDizzy = false;
      _showPopup = false;
      _clickCount = 0;
      _isSmiley = true;  // pose senyum
    });

    _smileCtrl.forward(from: 0);

    // Kembali pose normal setelah 2 detik
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) {
      _smileCtrl.reverse();
      await Future.delayed(const Duration(milliseconds: 400));
      if (mounted) setState(() => _isSmiley = false);
    }
  }

  // ── Tombol "Mampus" ──────────────────────────────────────────────
  void _onMampus() async {
    _popupCtrl.reverse();
    setState(() { _showPopup = false; });

    // Animasi menghilang
    _vanishCtrl.forward(from: 0);
    await Future.delayed(const Duration(milliseconds: 700));

    // Simpan ke server + lokal
    await _setAliciaHidden(true);

    if (mounted) setState(() { _isHidden = true; });
  }

  // ── Helper: nama aset gambar sesuai ekspresi ──────────────────────
  String get _aliciaAsset {
    if (_isSmiley)       return 'assets/images/alicia_senyum.png';
    switch (_clickCount) {
      case 1:  return 'assets/images/alicia_ngambek.png';
      case 2:  return 'assets/images/alicia_marah1.png';
      case 3:  return 'assets/images/alicia_marah2.png';
      default: return 'assets/images/alicia.png';
    }
  }

  String get _expressionLabel {
    if (_isSmiley) return '😊 Oke deh...';
    switch (_clickCount) {
      case 1:  return '😤 Ngambek!';
      case 2:  return '😠 Marah nih!';
      case 3:  return '🤬 MARAH BANGET!!!';
      default: return '';
    }
  }

  Color get _expressionColor {
    switch (_clickCount) {
      case 1:  return Colors.orange;
      case 2:  return Colors.deepOrange;
      case 3:  return Colors.red;
      default: return Colors.white;
    }
  }

  // ════════════════════════════════════════════════════════════════
  // BUILD
  // ════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    // Loading state
    if (_isLoading) {
      return _buildShell(
        child: const Center(
          child: CircularProgressIndicator(color: Colors.white38, strokeWidth: 2),
        ),
      );
    }

    // Alicia sudah di-"mampus"-in — return kosong total
    if (_isHidden) return const SizedBox.shrink();

    return _buildMainBanner();
  }

  // ── Shell card (border + blur background) ────────────────────────
  Widget _buildShell({required Widget child}) {
    return Container(
      width: double.infinity,
      height: 210,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.22), width: 1.5),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.4), blurRadius: 20, spreadRadius: 2),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          children: [
            // Background blur
            Positioned.fill(
              child: ImageFiltered(
                imageFilter: ImageFilter.blur(sigmaX: 7, sigmaY: 7),
                child: Image.asset(
                  'assets/images/xp.png',
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: const Color(0xFF1A1A2E)),
                ),
              ),
            ),
            // Overlay gelap
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.black.withOpacity(0.15), Colors.black.withOpacity(0.6)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
            child,
          ],
        ),
      ),
    );
  }

  // ── Banner utama ─────────────────────────────────────────────────
  Widget _buildMainBanner() {
    return LayoutBuilder(builder: (context, constraints) {
      final cardW  = constraints.maxWidth;
      final cardH  = 210.0;
      final centerX = cardW / 2;

      return AnimatedBuilder(
        animation: _vanishAnim,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, _vanishAnim.value * cardH),
            child: Opacity(
              opacity: 1 - _vanishAnim.value,
              child: child,
            ),
          );
        },
        child: GestureDetector(
          onTap: _onTap,
          child: _buildShell(
            child: Stack(
              children: [
                // ── TANGAN KIRI ─────────────────────────────────────
                Positioned(
                  bottom: 0, left: 0,
                  child: _buildHand(isLeft: true),
                ),

                // ── TANGAN KANAN ────────────────────────────────────
                Positioned(
                  bottom: 0, right: 0,
                  child: _buildHand(isLeft: false),
                ),

                // ── KARAKTER ALICIA ─────────────────────────────────
                Positioned(
                  bottom: 0, left: 0, right: 0,
                  child: Center(
                    child: AnimatedBuilder(
                      animation: _shakeAnim,
                      builder: (context, child) => Transform.translate(
                        offset: Offset(_shakeAnim.value, 0),
                        child: child,
                      ),
                      child: ScaleTransition(
                        scale: _isSmiley
                            ? Tween(begin: 1.0, end: 1.08).animate(_smileAnim)
                            : const AlwaysStoppedAnimation(1.0),
                        child: SizedBox(
                          height: cardH * 0.88,
                          child: Stack(
                            alignment: Alignment.topCenter,
                            children: [
                              // Gambar karakter
                              AnimatedSwitcher(
                                duration: const Duration(milliseconds: 250),
                                child: Image.asset(
                                  _aliciaAsset,
                                  key: ValueKey(_aliciaAsset),
                                  fit: BoxFit.contain,
                                  alignment: Alignment.bottomCenter,
                                  errorBuilder: (_, __, ___) => _buildPlaceholderAlicia(),
                                ),
                              ),
                              // Mata anime berputar (dizzy)
                              if (_isDizzy)
                                Positioned(
                                  top: 30,
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      _DizzyEye(animation: _eyeAnim, size: 14),
                                      const SizedBox(width: 10),
                                      _DizzyEye(animation: _eyeAnim, size: 14),
                                    ],
                                  ),
                                ),
                              // Bintang senyum
                              if (_isSmiley)
                                Positioned(
                                  top: 10,
                                  right: 10,
                                  child: _buildSparkles(),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                // ── KEPALA MINI BERPUTAR ─────────────────────────────
                if (_isDizzy) _buildOrbitingHeads(centerX),

                // ── LABEL EKSPRESI ───────────────────────────────────
                if (_clickCount > 0 || _isSmiley)
                  Positioned(
                    bottom: 8, left: 0, right: 0,
                    child: Center(
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        child: Text(
                          _expressionLabel,
                          key: ValueKey('$_clickCount$_isSmiley'),
                          style: TextStyle(
                            color: _isSmiley ? Colors.greenAccent : _expressionColor,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            shadows: const [
                              Shadow(color: Colors.black, blurRadius: 6, offset: Offset(1, 1))
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),

                // ── POPUP PILIHAN ────────────────────────────────────
                if (_showPopup) _buildPopup(),

                // ── HINT TAP ────────────────────────────────────────
                if (_clickCount == 0 && !_isDizzy && !_isSmiley)
                  Positioned(
                    bottom: 8, right: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text(
                        '👆 Ketuk Alicia',
                        style: TextStyle(color: Colors.white54, fontSize: 9),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    });
  }

  // ── Popup kanan atas ─────────────────────────────────────────────
  Widget _buildPopup() {
    return Positioned(
      top: 10, right: 10,
      child: ScaleTransition(
        scale: _popupAnim,
        alignment: Alignment.topRight,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // ● Minta Maaf ─ kembali normal + senyum
              GestureDetector(
                onTap: _onSorry,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 9, height: 9,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: Color(0xFF4CAF50)),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Minta Maaf',
                      style: TextStyle(
                        color: Color(0xFF1B5E20),
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 6),
              // ● Mampus ─ Alicia hilang selamanya
              GestureDetector(
                onTap: _onMampus,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 9, height: 9,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle, color: Color(0xFFE53935)),
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Mampus',
                      style: TextStyle(
                        color: Color(0xFFB71C1C),
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Kepala mini berputar di orbit ─────────────────────────────────
  Widget _buildOrbitingHeads(double centerX) {
    return AnimatedBuilder(
      animation: _orbitAnim,
      builder: (context, _) {
        return Stack(
          children: List.generate(_miniHeadCount, (i) {
            final angle = _orbitAnim.value + (2 * pi * i / _miniHeadCount);
            final dx = centerX + _orbitRadius * cos(angle) - 14;
            final dy = 8 + _orbitRadius * 0.5 * sin(angle);
            return Positioned(
              left: dx, top: dy,
              child: Container(
                width: 26, height: 26,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white54, width: 1),
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/alicia.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const Text('👧', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }

  // ── Bintang sparkle setelah maaf ─────────────────────────────────
  Widget _buildSparkles() {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('✨', style: TextStyle(fontSize: 14)),
        Text('  ✨', style: TextStyle(fontSize: 10)),
        Text('✨', style: TextStyle(fontSize: 12)),
      ],
    );
  }

  // ── Tangan bentuk gunung (CustomPainter) ──────────────────────────
  Widget _buildHand({required bool isLeft}) {
    return Transform(
      alignment: Alignment.center,
      transform: isLeft ? Matrix4.identity() : Matrix4.diagonal3Values(-1, 1, 1),
      child: SizedBox(
        width: 72, height: 95,
        child: CustomPaint(painter: _HandPainter()),
      ),
    );
  }

  // ── Placeholder jika aset gambar belum ada ────────────────────────
  Widget _buildPlaceholderAlicia() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        // Kepala
        Container(
          width: 78, height: 78,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFFFFD6C0),
            border: Border.all(color: const Color(0xFFFFB300), width: 3),
          ),
          child: Stack(
            children: [
              // Rambut
              Positioned(
                top: 0, left: 4, right: 4,
                child: Container(
                  height: 32,
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A1A),
                    borderRadius: BorderRadius.circular(40),
                  ),
                ),
              ),
              // Mata
              Positioned(
                top: 36, left: 0, right: 0,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _isDizzy
                        ? _DizzyEye(animation: _eyeAnim, size: 13)
                        : _NormalEye(expression: _clickCount),
                    _isDizzy
                        ? _DizzyEye(animation: _eyeAnim, size: 13)
                        : _NormalEye(expression: _clickCount),
                  ],
                ),
              ),
              // Senyum (jika minta maaf)
              if (_isSmiley)
                Positioned(
                  bottom: 12, left: 0, right: 0,
                  child: Center(
                    child: Container(
                      width: 24, height: 10,
                      decoration: const BoxDecoration(
                        color: Color(0xFFFF6B6B),
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        // Badan armor Alicia
        Container(
          width: 100, height: 75,
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFFFFB300), Color(0xFF616161)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: const Center(
            child: Icon(Icons.shield_rounded, color: Colors.white54, size: 28),
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════
// Widget: mata normal dengan ekspresi
// ═══════════════════════════════════════════════════════════════════
class _NormalEye extends StatelessWidget {
  final int expression; // 0=normal, 1=ngambek, 2,3=marah
  const _NormalEye({required this.expression});

  @override
  Widget build(BuildContext context) {
    if (expression >= 2) {
      // Mata V terbalik (marah)
      return CustomPaint(
        size: const Size(13, 13),
        painter: _AngryEyePainter(),
      );
    }
    if (expression == 1) {
      // Mata setengah tertutup (ngambek)
      return Container(
        width: 13, height: 13,
        decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black),
        child: const Align(
          alignment: Alignment.bottomCenter,
          child: SizedBox(
            height: 6,
            child: DecoratedBox(
              decoration: BoxDecoration(color: Color(0xFFFFD6C0)),
            ),
          ),
        ),
      );
    }
    // Mata normal
    return Container(
      width: 13, height: 13,
      decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.black),
      child: const Center(
        child: SizedBox(
          width: 4, height: 4,
          child: DecoratedBox(
            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white),
          ),
        ),
      ),
    );
  }
}

class _AngryEyePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = Colors.black
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    // Alis miring (garis V terbalik)
    canvas.drawLine(
      Offset(0, size.height * 0.3),
      Offset(size.width * 0.5, 0),
      p,
    );
    canvas.drawLine(
      Offset(size.width * 0.5, 0),
      Offset(size.width, size.height * 0.3),
      p,
    );

    // Bola mata
    canvas.drawCircle(
      Offset(size.width / 2, size.height * 0.7),
      size.width * 0.25,
      Paint()..color = Colors.black,
    );
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ═══════════════════════════════════════════════════════════════════
// Widget: mata dizzy (spiral berputar)
// ═══════════════════════════════════════════════════════════════════
class _DizzyEye extends StatelessWidget {
  final Animation<double> animation;
  final double size;
  const _DizzyEye({required this.animation, required this.size});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: animation,
      builder: (_, __) => CustomPaint(
        painter: _SpiralingEyePainter(animation.value),
        size: Size(size, size),
      ),
    );
  }
}

class _SpiralingEyePainter extends CustomPainter {
  final double angle;
  _SpiralingEyePainter(this.angle);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;

    // Putih mata
    canvas.drawCircle(center, radius, Paint()..color = Colors.white);

    // Spiral
    final spiralPaint = Paint()
      ..color = Colors.black
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;

    for (int i = 0; i < 3; i++) {
      final startA = angle + (2 * pi * i / 3);
      final path = Path();
      bool first = true;
      for (double t = 0.0; t <= 1.0; t += 0.04) {
        final r = radius * t * 0.85;
        final a = startA + t * 4 * pi;
        final x = center.dx + r * cos(a);
        final y = center.dy + r * sin(a);
        if (first) { path.moveTo(x, y); first = false; }
        else path.lineTo(x, y);
      }
      canvas.drawPath(path, spiralPaint);
    }

    // Border
    canvas.drawCircle(center, radius - 0.5,
        Paint()..color = Colors.black..strokeWidth = 1.2..style = PaintingStyle.stroke);
  }

  @override
  bool shouldRepaint(covariant _SpiralingEyePainter old) => old.angle != angle;
}

// ═══════════════════════════════════════════════════════════════════
// Custom Painter: tangan Alicia memegang pinggiran card
// Bentuk "gunung" dengan 3 jari
// ═══════════════════════════════════════════════════════════════════
class _HandPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Sarung tangan kuning
    final glovePaint = Paint()
      ..color = const Color(0xFFFFB300)
      ..style = PaintingStyle.fill;

    // Kulit jari
    final skinPaint = Paint()
      ..color = const Color(0xFFFFD6A5)
      ..style = PaintingStyle.fill;

    // Outline
    final outlinePaint = Paint()
      ..color = const Color(0xFFE65100).withOpacity(0.5)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;

    // Bentuk telapak / gunung
    final palmPath = Path();
    palmPath.moveTo(0, size.height);
    palmPath.cubicTo(
      0, size.height * 0.45,
      size.width * 0.25, 0,
      size.width * 0.5, 0,
    );
    palmPath.cubicTo(
      size.width * 0.68, 0,
      size.width * 0.85, size.height * 0.25,
      size.width, size.height * 0.4,
    );
    palmPath.lineTo(size.width, size.height);
    palmPath.close();
    canvas.drawPath(palmPath, glovePaint);
    canvas.drawPath(palmPath, outlinePaint);

    // 3 jari menonjol di atas puncak gunung
    final fingerPositions = [
      Offset(size.width * 0.18, size.height * 0.04),
      Offset(size.width * 0.42, -size.height * 0.02), // jari tengah paling tinggi
      Offset(size.width * 0.66, size.height * 0.06),
    ];

    for (final pos in fingerPositions) {
      final fingerPath = Path();
      fingerPath.addRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: pos, width: 13, height: 22),
          const Radius.circular(6),
        ),
      );
      canvas.drawPath(fingerPath, skinPaint);
      canvas.drawPath(fingerPath, outlinePaint);

      // Ruas jari
      canvas.drawLine(
        Offset(pos.dx - 4, pos.dy + 5),
        Offset(pos.dx + 4, pos.dy + 5),
        Paint()..color = const Color(0xFFE65100).withOpacity(0.3)..strokeWidth = 0.8,
      );
    }

    // Highlight sarung tangan
    canvas.drawLine(
      Offset(size.width * 0.15, size.height * 0.6),
      Offset(size.width * 0.35, size.height * 0.25),
      Paint()..color = Colors.white.withOpacity(0.2)..strokeWidth = 3..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
