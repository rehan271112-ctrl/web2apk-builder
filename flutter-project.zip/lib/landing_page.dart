import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'login_page.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _videoController;

  @override
  void initState() {
    super.initState();
    
    _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      });
  }
  
  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }
  
  void _navigateToLogin() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
    );
  }
  
  Future<void> _launchUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  // ==================== NEOBRUTALISM UI HELPERS ====================
  
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _neoButton({
    required String label,
    required VoidCallback onTap,
    Color bg = NeoBrutalismColors.yellow,
    Color textColor = NeoBrutalismColors.black,
    double fontSize = 14,
    bool isOutlined = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isOutlined ? Colors.transparent : bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isOutlined ? NeoBrutalismColors.white : NeoBrutalismColors.borderColor,
            width: isOutlined ? 2 : 3,
          ),
          boxShadow: isOutlined ? null : [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.1),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              color: isOutlined ? NeoBrutalismColors.white : textColor,
              fontFamily: 'Inter',
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSocialButton({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
            boxShadow: [
              BoxShadow(
                color: NeoBrutalismColors.black.withOpacity(0.1),
                offset: const Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: NeoBrutalismColors.white, size: 18),
              const SizedBox(width: 8),
              Text(
                label,
                style: const TextStyle(
                  color: NeoBrutalismColors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Inter',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 30),
          child: Column(
            children: [
              // ===== VIDEO BANNER =====
              Container(
                width: double.infinity,
                height: 220,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.black.withOpacity(0.08),
                      offset: const Offset(5, 5),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: _videoController.value.isInitialized
                      ? FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _videoController.value.size.width,
                            height: _videoController.value.size.height,
                            child: VideoPlayer(_videoController),
                          ),
                        )
                      : Container(
                          color: NeoBrutalismColors.purple,
                          child: const Center(
                            child: CircularProgressIndicator(
                              color: NeoBrutalismColors.white,
                              strokeWidth: 3,
                            ),
                          ),
                        ),
                ),
              ),

              const SizedBox(height: 16),

              // ===== ICON & TITLE =====
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.purple,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.1),
                          offset: const Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.handshake,
                      color: NeoBrutalismColors.white,
                      size: 28,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "RZYN",
                          style: TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w900,
                            color: NeoBrutalismColors.black,
                            fontFamily: 'Orbitron',
                            letterSpacing: 4,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                          decoration: BoxDecoration(
                            color: NeoBrutalismColors.yellow,
                            border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                            borderRadius: BorderRadius.circular(6),
                            boxShadow: [
                              BoxShadow(
                                color: NeoBrutalismColors.black.withOpacity(0.08),
                                offset: const Offset(3, 3),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: const Text(
                            "PREMIUM ACCESS",
                            style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.w800,
                              color: NeoBrutalismColors.black,
                              letterSpacing: 2,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              // ===== CORE CARD =====
              _neoCard(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "RZYN PROJECT 2026",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: NeoBrutalismColors.black,
                        letterSpacing: 2,
                        fontFamily: 'Inter',
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      "Welcome to RZYN App. Join our community on Telegram or WhatsApp to get updates and premium access.",
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: NeoBrutalismColors.black.withOpacity(0.7),
                        height: 1.5,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // ===== ENTER TO LOGIN BUTTON =====
              _neoButton(
                label: "ENTER TO LOGIN",
                onTap: _navigateToLogin,
                bg: NeoBrutalismColors.yellow,
                textColor: NeoBrutalismColors.black,
                fontSize: 16,
              ),

              const SizedBox(height: 16),

              // ===== BUY PREMIUM ACCESS BUTTON =====
              _neoButton(
                label: "🛒 BUY PREMIUM ACCESS",
                onTap: () => _launchUrl("https://t.me/Rizzisreal01"),
                bg: NeoBrutalismColors.purple,
                textColor: NeoBrutalismColors.white,
                fontSize: 14,
              ),

              const SizedBox(height: 20),

              // ===== SOCIAL BUTTONS =====
              Row(
                children: [
                  _buildSocialButton(
                    icon: Icons.telegram,
                    label: "ch Telegram",
                    color: NeoBrutalismColors.blue,
                    onTap: () => _launchUrl("https://t.me/RXTcommunitygen1"),
                  ),
                  const SizedBox(width: 12),
                  _buildSocialButton(
                    icon: Icons.message_outlined,
                    label: "WhatsApp",
                    color: NeoBrutalismColors.green,
                    onTap: () => _launchUrl("https://whatsapp.com/channel/0029VbC6tAE4yltIJOYGCS1e"),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // ===== COPYRIGHT =====
              Column(
                children: [
                  Container(
                    width: 40,
                    height: 3,
                    color: NeoBrutalismColors.borderColor,
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                    style: TextStyle(
                      fontSize: 9,
                      letterSpacing: 2,
                      color: NeoBrutalismColors.darkGrey,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}