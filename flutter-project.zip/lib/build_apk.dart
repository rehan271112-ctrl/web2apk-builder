// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show MethodChannel, PlatformException;
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:open_file/open_file.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'config.dart';
import 'color_theme.dart';
import 'build_manager.dart';
import 'riwayat_build_page.dart';

class BuildApkPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  const BuildApkPage({super.key, required this.sessionKey, required this.username});

  @override
  State<BuildApkPage> createState() => _BuildApkPageState();
}

class _BuildApkPageState extends State<BuildApkPage> with TickerProviderStateMixin {
  Color get bgDark       => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple=> AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;
  Color get lightPurple  => AppThemeController.instance.theme.lightPurple;
  Color get cardGlass    => AppThemeController.instance.theme.cardGlass;
  Color get borderGlass  => AppThemeController.instance.theme.borderGlass;
  Color get cardSolid    => AppThemeController.instance.theme.cardSolid;
  Color get accentGrey   => AppThemeController.instance.theme.accentGrey;

  late AnimationController _glowCtrl;
  late AnimationController _pulseCtrl;

  // File picker state
  String?    _selectedFileName;
  List<int>? _selectedFileBytes;
  double     _fileSizeMB = 0;
  String     _buildType  = 'release';

  // Download state
  bool   _isDownloading = false;
  double _dlProgress    = 0;
  String? _localApkPath;

  // Upload state (local only – setelah upload selesai diserahkan ke BuildManager)
  bool _isUploading = false;

  final ScrollController _scrollCtrl = ScrollController();

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onTheme);
    BuildManager.instance.addListener(_onBuild);

    _glowCtrl = AnimationController(duration: const Duration(seconds: 3), vsync: this)..repeat();
    _pulseCtrl = AnimationController(duration: const Duration(milliseconds: 800), vsync: this)
      ..repeat(reverse: true);
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _pulseCtrl.dispose();
    _scrollCtrl.dispose();
    AppThemeController.instance.removeListener(_onTheme);
    BuildManager.instance.removeListener(_onBuild);
    // ⚠️ TIDAK cancel build! BuildManager terus jalan di background.
    super.dispose();
  }

  void _onTheme() => mounted ? setState(() {}) : null;
  void _onBuild() {
    if (!mounted) return;
    setState(() {});
    // Auto-scroll console ke bawah
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ── Ambil session dari BuildManager (bisa null kalau belum ada build) ──
  BuildSession? get _sess => BuildManager.instance.session;

  // ──────────────────────────────────────────────
  // FILE PICKER — support semua file manager
  // ──────────────────────────────────────────────
  static const MethodChannel _anyFilePicker = MethodChannel('com.riven.sex/anyfile_picker');

  Future<void> _pickZip() async {
    if (_isUploading || BuildManager.instance.isBuilding || _isDownloading) return;

    // Pakai channel native (bukan package file_picker) supaya sheet "Buka dari"
    // menampilkan SEMUA app (Pengelola File, Manajer MT, File Manager+,
    // ZArchiver, dll), bukan cuma akun Google Drive / cloud provider.
    // Penyebabnya: ACTION_GET_CONTENT + CATEGORY_OPENABLE (dipakai file_picker)
    // di banyak ROM (termasuk MIUI/HyperOS) dialihkan ke DocumentsUI yang cuma
    // menampilkan DocumentsProvider (Drive, TeraBox, Termux, dst). Tanpa
    // CATEGORY_OPENABLE, Android memakai app-chooser biasa yang mendaftar semua
    // app pemegang ACTION_GET_CONTENT.
    Map<dynamic, dynamic>? picked;
    try {
      picked = await _anyFilePicker.invokeMethod('pickAnyFile');
    } on PlatformException catch (e) {
      _snack('❌ Gagal membuka pemilih file: ${e.message}');
      return;
    }

    if (picked == null) return; // user membatalkan
    final String? path = picked['path'] as String?;
    final String name = (picked['name'] as String?) ?? 'file.zip';

    if (path == null || path.isEmpty) {
      _snack('❌ Gagal membaca file yang dipilih.');
      return;
    }

    // Validasi ekstensi manual (best-effort; nama file dari beberapa file
    // manager kadang tidak menyertakan ekstensi, jadi ini cuma warning awal,
    // pengecekan utama tetap di magic bytes ZIP di bawah)
    if (name.isNotEmpty && !name.toLowerCase().endsWith('.zip')) {
      _snack('⚠️ File "$name" bukan .zip, tapi tetap dicoba dibaca...');
    }

    setState(() {
      _selectedFileName  = null;
      _selectedFileBytes = null;
    });

    try {
      final file = File(path);
      if (!await file.exists()) {
        _snack('❌ Gagal membaca file. Coba pilih dari penyimpanan internal.');
        return;
      }
      final bytes = await file.readAsBytes();

      if (bytes.isEmpty) {
        _snack('❌ Gagal membaca file. Coba pilih dari penyimpanan internal.');
        return;
      }

      // Validasi magic bytes ZIP (harus diawali PK\x03\x04)
      if (bytes.length < 4 ||
          bytes[0] != 0x50 || bytes[1] != 0x4B ||
          bytes[2] != 0x03 || bytes[3] != 0x04) {
        _snack('❌ File bukan ZIP yang valid.');
        return;
      }

      setState(() {
        _selectedFileName  = name;
        _selectedFileBytes = bytes;
        _fileSizeMB        = bytes.length / 1024 / 1024;
        _localApkPath      = null;
      });

      _snack('✅ File dipilih: $name (${_fileSizeMB.toStringAsFixed(1)} MB)');
    } catch (e) {
      _snack('❌ Error membaca file: $e');
    }
  }


  // ──────────────────────────────────────────────
  // UPLOAD + BUILD — serahkan ke BuildManager
  // ──────────────────────────────────────────────
  Future<void> _startBuild() async {
    if (_selectedFileBytes == null) { _snack('⚠️ Pilih file ZIP dulu!'); return; }
    if (BuildManager.instance.isBuilding) { _snack('⚠️ Build sedang berjalan!'); return; }

    setState(() { _isUploading = true; _localApkPath = null; });

    // Buat session baru di BuildManager
    final tempSession = BuildSession(
      sessionId: '__pending__',
      sessionKey: widget.sessionKey,
      fileName: _selectedFileName!,
      status: 'uploading',
      progress: 0.05,
      percent: 5,
      currentStep: 'Uploading file...',
    );
    BuildManager.instance.startSession(tempSession);
    BuildManager.instance.addLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    BuildManager.instance.addLog('🚀 Zero Crash Flutter Builder');
    BuildManager.instance.addLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    BuildManager.instance.addLog('📁 File : $_selectedFileName');
    BuildManager.instance.addLog('📏 Size : ${_fileSizeMB.toStringAsFixed(2)} MB');
    BuildManager.instance.addLog('🔧 Type : ${_buildType.toUpperCase()}');
    BuildManager.instance.addLog('');
    BuildManager.instance.addLog('📤 Uploading ke server...');

    try {
      // ── Step 1: Upload ZIP ──
      final uri     = Uri.parse('$apiBaseUrl/api/uploadBuildZip');
      final request = http.MultipartRequest('POST', uri)
        ..headers['x-session-key'] = widget.sessionKey
        ..fields['buildType']       = _buildType
        ..files.add(http.MultipartFile.fromBytes('file', _selectedFileBytes!, filename: _selectedFileName!));

      final streamed    = await request.send().timeout(const Duration(minutes: 5));
      final uploadResp  = await http.Response.fromStream(streamed);
      if (uploadResp.statusCode != 200) throw Exception('HTTP ${uploadResp.statusCode}');

      final uploadData = jsonDecode(uploadResp.body);
      if (uploadData['success'] != true) throw Exception(uploadData['message']);

      final sessionId = uploadData['sessionId'] as String;
      BuildManager.instance.addLog('✅ Upload berhasil! Session: ${sessionId.substring(0, 10)}...',
          level: BuildLogLevel.success);

      // Update session dengan sessionId yang benar
      final realSession = BuildSession(
        sessionId: sessionId,
        sessionKey: widget.sessionKey,
        fileName: _selectedFileName!,
        status: 'queued',
        progress: 0.1,
        percent: 10,
        currentStep: 'Memulai build...',
        logs: List.from(BuildManager.instance.session?.logs ?? []),
      );
      BuildManager.instance.startSession(realSession);

      // ── Step 2: Trigger Build ──
      BuildManager.instance.addLog('🔨 Memulai GitHub Actions build...');
      final buildResp = await http.post(
        Uri.parse('$apiBaseUrl/api/buildFlutterApk'),
        headers: {'Content-Type': 'application/json', 'x-session-key': widget.sessionKey},
        body: jsonEncode({'sessionId': sessionId, 'buildType': _buildType}),
      ).timeout(const Duration(seconds: 30));

      final buildData = jsonDecode(buildResp.body);
      if (buildData['success'] != true) throw Exception(buildData['message']);

      BuildManager.instance.addLog('✅ Build queued di GitHub Actions!', level: BuildLogLevel.success);
      BuildManager.instance.addLog('⏳ Menunggu workflow... (5-15 menit)');
      BuildManager.instance.addLog('📊 Kamu bisa keluar halaman ini, build tetap berjalan!',
          level: BuildLogLevel.warning);
      BuildManager.instance.addLog('🔔 Notifikasi akan muncul saat build selesai/error.');

      // Kirim notifikasi "build dimulai"
      await NotificationService.instance.showBuildStarted(_selectedFileName!);

      // Mulai polling di BuildManager (berjalan meski page ditutup)
      BuildManager.instance.startPollingFromOutside();

      setState(() { _isUploading = false; });
    } catch (e) {
      setState(() { _isUploading = false; });
      BuildManager.instance.addLog('❌ ERROR: ${e.toString()}', level: BuildLogLevel.error);
      BuildManager.instance.session?.status      = 'failed';
      BuildManager.instance.session?.currentStep = 'Upload/Build gagal';
      BuildManager.instance.session?.error       = e.toString();
      _snack('❌ ${e.toString()}');
    }
  }

  // ──────────────────────────────────────────────
  // DOWNLOAD + INSTALL APK
  // ──────────────────────────────────────────────
  Future<void> _downloadAndInstall() async {
    final s = _sess;
    if (s == null || s.apkDownloadUrl == null) return;
    if (_isDownloading) return;

    // Jika sudah ada di lokal
    if (_localApkPath != null && File(_localApkPath!).existsSync()) {
      BuildManager.instance.addLog('📱 Membuka APK yang sudah ada...');
      final r = await OpenFile.open(_localApkPath!);
      if (r.type != ResultType.done) _snack('⚠️ ${r.message}');
      return;
    }

    if (Platform.isAndroid) {
      final status = await Permission.requestInstallPackages.request();
      if (!status.isGranted) {
        _snack('❌ Izin "Install dari sumber tidak dikenal" diperlukan.');
        await openAppSettings();
        return;
      }
    }

    setState(() { _isDownloading = true; _dlProgress = 0; });
    BuildManager.instance.addLog('⬇️ Mendownload APK ke HP...');

    try {
      final url      = '$apiBaseUrl${s.apkDownloadUrl}';
      final client   = http.Client();
      final req      = http.Request('GET', Uri.parse(url));
      req.headers['x-session-key'] = widget.sessionKey;
      final response = await client.send(req);
      final total    = response.contentLength ?? 0;
      final bytes    = <int>[];
      int downloaded = 0;

      await for (final chunk in response.stream) {
        bytes.addAll(chunk);
        downloaded += chunk.length;
        if (total > 0 && mounted) setState(() => _dlProgress = downloaded / total);
      }
      client.close();

      final dir      = await getTemporaryDirectory();
      final fileName = s.apkFileName ?? 'zero_crash.apk';
      final apkFile  = File('${dir.path}/$fileName');
      await apkFile.writeAsBytes(bytes);

      BuildManager.instance.addLog('✅ APK tersimpan: $fileName', level: BuildLogLevel.success);
      setState(() { _isDownloading = false; _dlProgress = 1; _localApkPath = apkFile.path; });

      final r = await OpenFile.open(apkFile.path);
      if (r.type != ResultType.done) _snack('⚠️ ${r.message}');
    } catch (e) {
      setState(() { _isDownloading = false; _dlProgress = 0; });
      BuildManager.instance.addLog('❌ Download gagal: $e', level: BuildLogLevel.error);
      _snack('❌ Download gagal: $e');
    }
  }

  // ──────────────────────────────────────────────
  // SHARE APK
  // ──────────────────────────────────────────────
  Future<void> _shareApk() async {
    final s = _sess;
    if (s == null || s.apkDownloadUrl == null) return;

    // Kalau sudah ada di lokal, langsung share
    if (_localApkPath != null && File(_localApkPath!).existsSync()) {
      await Share.shareXFiles(
        [XFile(_localApkPath!)],
        text: '📱 APK dari Zero Crash Builder\n📦 ${s.apkFileName ?? 'app.apk'}',
        subject: 'Zero Crash APK',
      );
      return;
    }

    // Download dulu TANPA buka installer, baru share
    final path = await _downloadOnly(s.apkDownloadUrl!, s.apkFileName);
    if (path != null) {
      await Share.shareXFiles(
        [XFile(path)],
        text: '📱 APK dari Zero Crash Builder\n📦 ${s.apkFileName ?? 'app.apk'}',
        subject: 'Zero Crash APK',
      );
    }
  }

  // Download APK ke temp folder, TIDAK buka installer — return path atau null
  Future<String?> _downloadOnly(String apkDownloadUrl, String? apkFileName) async {
    setState(() { _isDownloading = true; _dlProgress = 0; });
    BuildManager.instance.addLog('⬇️ Mendownload APK untuk dibagikan...');

    try {
      final url    = '$apiBaseUrl$apkDownloadUrl';
      final client = http.Client();
      final req    = http.Request('GET', Uri.parse(url));
      req.headers['x-session-key'] = widget.sessionKey;
      final response = await client.send(req);
      final total    = response.contentLength ?? 0;
      final bytes    = <int>[];
      int downloaded = 0;

      await for (final chunk in response.stream) {
        bytes.addAll(chunk);
        downloaded += chunk.length;
        if (total > 0 && mounted) setState(() => _dlProgress = downloaded / total);
      }
      client.close();

      final dir      = await getTemporaryDirectory();
      final fileName = apkFileName ?? 'zero_crash.apk';
      final apkFile  = File('${dir.path}/$fileName');
      await apkFile.writeAsBytes(bytes);

      if (!mounted) return null;
      setState(() { _isDownloading = false; _dlProgress = 1; _localApkPath = apkFile.path; });
      BuildManager.instance.addLog('✅ APK siap dibagikan: $fileName', level: BuildLogLevel.success);
      return apkFile.path;
    } catch (e) {
      if (mounted) setState(() { _isDownloading = false; _dlProgress = 0; });
      BuildManager.instance.addLog('❌ Download gagal: $e', level: BuildLogLevel.error);
      _snack('❌ Download gagal: $e');
      return null;
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: primaryPurple.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(12),
    ));
  }

  // ──────────────────────────────────────────────
  // UI HELPERS
  // ──────────────────────────────────────────────
  String _statusLabel() {
    final s = _sess;
    if (s == null) return '💤 Ready';
    switch (s.status) {
      case 'uploading':  return '📤 Uploading...';
      case 'queued':     return '⏳ Dalam Antrian...';
      case 'extracting': return '📂 Extracting ZIP...';
      case 'cleaning':   return '🧹 Flutter Clean...';
      case 'pubget':     return '📦 Pub Get...';
      case 'building':   return '🔨 Compiling APK...';
      case 'completed':  return '✅ Build Selesai!';
      case 'failed':     return '❌ Build Gagal';
      default:           return s.currentStep.isNotEmpty ? '⏳ ${s.currentStep}' : '💤 Ready';
    }
  }

  Color _statusColor() {
    final s = _sess;
    if (s == null) return accentGrey;
    switch (s.status) {
      case 'completed': return Colors.greenAccent;
      case 'failed':    return Colors.redAccent;
      case 'uploading':
      case 'building':  return accentPurple;
      default:          return Colors.orangeAccent;
    }
  }

  // ──────────────────────────────────────────────
  // BUILD UI
  // ──────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([AppThemeController.instance, BuildManager.instance]),
      builder: (context, _) {
        final sess     = _sess;
        final building = BuildManager.instance.isBuilding || _isUploading;
        final done     = sess?.isCompleted == true;
        final failed   = sess?.isFailed    == true;
        final hasSession = sess != null;

        return Scaffold(
          backgroundColor: bgDark,
          appBar: _appBar(building),
          body: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Banner build berjalan di background
                if (building && !_isUploading) _backgroundBanner(),
                if (building && !_isUploading) const SizedBox(height: 12),

                _uploadCard(building),
                const SizedBox(height: 14),
                _buildTypeCard(building),
                const SizedBox(height: 14),
                _actionButton(building),
                const SizedBox(height: 14),
                if (hasSession) ...[_progressCard(), const SizedBox(height: 14)],
                _consoleCard(sess),
                const SizedBox(height: 14),
                if (done) _downloadSection(sess!),
              ],
            ),
          ),
        );
      },
    );
  }

  // ── AppBar ──
  AppBar _appBar(bool building) => AppBar(
    backgroundColor: bgDark,
    elevation: 0,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios_new_rounded, color: accentPurple, size: 20),
      onPressed: () {
        if (building) {
          _snack('🔔 Build tetap berjalan di background. Notif akan muncul saat selesai!');
        }
        Navigator.pop(context);
      },
    ),
    titleSpacing: 0,
    title: Row(children: [
      AnimatedBuilder(
        animation: _glowCtrl,
        builder: (_, __) => Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [primaryPurple, accentPurple]),
            borderRadius: BorderRadius.circular(10),
            boxShadow: [BoxShadow(
              color: primaryPurple.withOpacity(0.3 + 0.2 * _glowCtrl.value),
              blurRadius: 12,
            )],
          ),
          child: const Icon(Icons.build_rounded, color: Colors.white, size: 16),
        ),
      ),
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('BUILD APK', style: TextStyle(
          color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800,
          fontFamily: 'Orbitron', letterSpacing: 1,
        )),
        Text('Flutter → APK via GitHub Actions', style: TextStyle(
          color: accentGrey, fontSize: 9, fontFamily: 'ShareTechMono',
        )),
      ]),
      const Spacer(),
      // Tombol Riwayat Build
      GestureDetector(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => RiwayatBuildPage(
              sessionKey: widget.sessionKey,
              username: widget.username,
            ),
          ),
        ),
        child: Container(
          margin: const EdgeInsets.only(right: 6),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: accentPurple.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: accentPurple.withOpacity(0.35)),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.history_rounded, color: accentPurple, size: 15),
            const SizedBox(width: 5),
            Text('RIWAYAT', style: TextStyle(
              color: accentPurple, fontSize: 9,
              fontFamily: 'Orbitron', fontWeight: FontWeight.w700,
            )),
          ]),
        ),
      ),
      // Indikator build berjalan di appbar
      if (building)
        AnimatedBuilder(
          animation: _pulseCtrl,
          builder: (_, __) => Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: accentPurple.withOpacity(0.15 + 0.1 * _pulseCtrl.value),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: accentPurple.withOpacity(0.5)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              SizedBox(width: 8, height: 8, child: CircularProgressIndicator(
                strokeWidth: 1.5, color: accentPurple,
              )),
              const SizedBox(width: 5),
              Text('BUILDING', style: TextStyle(
                color: accentPurple, fontSize: 8, fontFamily: 'Orbitron', fontWeight: FontWeight.w700,
              )),
            ]),
          ),
        ),
    ]),
    bottom: PreferredSize(
      preferredSize: const Size.fromHeight(1),
      child: Container(height: 1, decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Colors.transparent, primaryPurple, Colors.transparent]),
      )),
    ),
  );

  // ── Banner: Build berjalan di background ──
  Widget _backgroundBanner() => AnimatedBuilder(
    animation: _pulseCtrl,
    builder: (_, __) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: accentPurple.withOpacity(0.08 + 0.04 * _pulseCtrl.value),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentPurple.withOpacity(0.4)),
      ),
      child: Row(children: [
        SizedBox(width: 16, height: 16, child: CircularProgressIndicator(
          strokeWidth: 2, color: accentPurple,
        )),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Build berjalan di background!', style: TextStyle(
            color: accentPurple, fontWeight: FontWeight.w700, fontSize: 12, fontFamily: 'Orbitron',
          )),
          Text(
            'Kamu bisa keluar halaman ini — notifikasi muncul saat selesai.',
            style: TextStyle(color: accentGrey, fontSize: 10, fontFamily: 'ShareTechMono'),
          ),
        ])),
      ]),
    ),
  );

  // ── Upload Card ──
  Widget _uploadCard(bool building) {
    final hasFile = _selectedFileName != null;
    final activeSess = _sess;

    return GestureDetector(
      onTap: _pickZip,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: cardSolid,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: hasFile ? primaryPurple.withOpacity(0.6) : borderGlass,
            width: hasFile ? 1.5 : 1,
          ),
          gradient: hasFile ? LinearGradient(colors: [
            primaryPurple.withOpacity(0.07), accentPurple.withOpacity(0.03),
          ]) : null,
        ),
        child: Column(children: [
          AnimatedBuilder(
            animation: _glowCtrl,
            builder: (_, __) => Container(
              width: 64, height: 64,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: primaryPurple.withOpacity(0.12),
                border: Border.all(color: primaryPurple.withOpacity(0.2 + 0.12 * _glowCtrl.value)),
                boxShadow: hasFile ? [BoxShadow(
                  color: primaryPurple.withOpacity(0.15 + 0.1 * _glowCtrl.value), blurRadius: 16,
                )] : [],
              ),
              child: Icon(
                hasFile ? Icons.folder_zip_rounded : Icons.upload_file_rounded,
                color: hasFile ? accentPurple : Colors.white38, size: 30,
              ),
            ),
          ),
          const SizedBox(height: 14),
          if (hasFile) ...[
            Text(_selectedFileName!, style: TextStyle(
              color: accentPurple, fontSize: 13, fontWeight: FontWeight.w700, fontFamily: 'ShareTechMono',
            ), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 8),
            _chip('📏 ${_fileSizeMB.toStringAsFixed(2)} MB', primaryPurple),
            const SizedBox(height: 8),
            Text(building ? 'Sedang build — tidak bisa ganti file' : 'Tap untuk ganti file',
              style: TextStyle(color: accentGrey, fontSize: 11)),
          ] else if (activeSess != null && !activeSess.isFinished) ...[
            Text('Build sedang berjalan!', style: TextStyle(
              color: accentPurple, fontSize: 14, fontWeight: FontWeight.w700, fontFamily: 'Orbitron',
            )),
            const SizedBox(height: 6),
            Text(activeSess.fileName, style: TextStyle(
              color: accentGrey, fontSize: 11, fontFamily: 'ShareTechMono',
            )),
          ] else ...[
            Text('Upload File ZIP', style: TextStyle(
              color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800, fontFamily: 'Orbitron',
            )),
            const SizedBox(height: 6),
            Text('Tap untuk pilih ZIP project Flutter kamu',
              style: TextStyle(color: accentGrey, fontSize: 12), textAlign: TextAlign.center),
            const SizedBox(height: 14),
            Wrap(spacing: 8, runSpacing: 6, alignment: WrapAlignment.center, children: [
              _chip('📦 .zip', null), _chip('📁 Max 500MB', null),
              _chip('💾 Storage', null), _chip('☁️ Cloud', null),
            ]),
          ],
        ]),
      ),
    );
  }

  Widget _chip(String text, Color? color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(
      color: (color ?? primaryPurple).withOpacity(0.12),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: (color ?? borderGlass).withOpacity(0.4)),
    ),
    child: Text(text, style: TextStyle(color: color ?? accentGrey, fontSize: 10, fontFamily: 'ShareTechMono')),
  );

  // ── Build Type Card ──
  Widget _buildTypeCard(bool building) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: cardSolid, borderRadius: BorderRadius.circular(18), border: Border.all(color: borderGlass)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Icon(Icons.tune_rounded, color: accentPurple, size: 15),
        const SizedBox(width: 8),
        Text('BUILD TYPE', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800, fontFamily: 'Orbitron', letterSpacing: 1)),
      ]),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: _typeBtn('release', '🚀 Release', 'Optimized & signed', Colors.greenAccent, building)),
        const SizedBox(width: 10),
        Expanded(child: _typeBtn('debug', '🐞 Debug', 'Dev & testing', Colors.orangeAccent, building)),
      ]),
    ]),
  );

  Widget _typeBtn(String val, String label, String sub, Color color, bool disabled) {
    final sel = _buildType == val;
    return GestureDetector(
      onTap: disabled ? null : () => setState(() => _buildType = val),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: sel ? color.withOpacity(0.1) : bgDark,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: sel ? color.withOpacity(0.6) : borderGlass, width: sel ? 1.5 : 1),
        ),
        child: Column(children: [
          Text(label, style: TextStyle(color: sel ? color : Colors.white38, fontWeight: FontWeight.w700, fontSize: 12, fontFamily: 'Orbitron')),
          Text(sub, style: TextStyle(color: accentGrey, fontSize: 10)),
        ]),
      ),
    );
  }

  // ── Action Button ──
  Widget _actionButton(bool building) {
    final canBuild = _selectedFileName != null && !building && !_isDownloading;
    return GestureDetector(
      onTap: canBuild ? _startBuild : null,
      child: AnimatedBuilder(
        animation: _pulseCtrl,
        builder: (_, __) => AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height: 58,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: canBuild ? [primaryPurple, accentPurple] : [Colors.grey.shade800, Colors.grey.shade700],
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: canBuild ? [BoxShadow(
              color: primaryPurple.withOpacity(0.3 + 0.15 * _pulseCtrl.value),
              blurRadius: 20 + 8 * _pulseCtrl.value, offset: const Offset(0, 5),
            )] : [],
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (building)
              const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
            else
              const Icon(Icons.build_circle_rounded, color: Colors.white, size: 22),
            const SizedBox(width: 10),
            Text(
              _isUploading ? 'UPLOADING...' : building ? 'BUILDING...' : 'BUILD APK',
              style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', letterSpacing: 2),
            ),
          ]),
        ),
      ),
    );
  }

  // ── Progress Card ──
  Widget _progressCard() {
    final s = _sess!;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cardSolid, borderRadius: BorderRadius.circular(18), border: Border.all(color: borderGlass)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Expanded(child: Text(_statusLabel(), style: TextStyle(
            color: _statusColor(), fontWeight: FontWeight.w700, fontFamily: 'Orbitron', fontSize: 11,
          ), overflow: TextOverflow.ellipsis)),
          Text('${s.percent}%', style: TextStyle(
            color: _statusColor(), fontWeight: FontWeight.w900, fontFamily: 'ShareTechMono', fontSize: 18,
          )),
        ]),
        const SizedBox(height: 12),
        ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: LinearProgressIndicator(
            value: s.progress, backgroundColor: borderGlass,
            valueColor: AlwaysStoppedAnimation(_statusColor()), minHeight: 10,
          ),
        ),
        if (s.currentStep.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text('▸ ${s.currentStep}', style: TextStyle(color: accentGrey, fontSize: 11, fontFamily: 'ShareTechMono')),
        ],
      ]),
    );
  }

  // ── Console Card ──
  Widget _consoleCard(BuildSession? s) {
    final logs = s?.logs ?? [];
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF060610), borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: cardSolid,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            border: Border(bottom: BorderSide(color: borderGlass)),
          ),
          child: Row(children: [
            _dot(Colors.redAccent), const SizedBox(width: 5),
            _dot(Colors.orangeAccent), const SizedBox(width: 5),
            _dot(Colors.greenAccent), const SizedBox(width: 12),
            Icon(Icons.terminal_rounded, color: accentPurple, size: 13),
            const SizedBox(width: 7),
            Text('Build Console', style: TextStyle(color: Colors.white70, fontSize: 11, fontFamily: 'ShareTechMono', fontWeight: FontWeight.w600)),
            const Spacer(),
            Text('${logs.length} lines', style: TextStyle(color: accentGrey, fontSize: 9)),
          ]),
        ),
        SizedBox(
          height: 260,
          child: logs.isEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.terminal_rounded, color: accentGrey.withOpacity(0.3), size: 36),
                  const SizedBox(height: 10),
                  Text('Log kosong...', style: TextStyle(color: accentGrey, fontSize: 13)),
                  Text('Upload ZIP & klik BUILD APK', style: TextStyle(color: accentGrey.withOpacity(0.6), fontSize: 11)),
                ]))
              : ListView.builder(
                  controller: _scrollCtrl,
                  padding: const EdgeInsets.all(12),
                  itemCount: logs.length,
                  itemBuilder: (_, i) {
                    final e = logs[i];
                    Color c;
                    switch (e.level) {
                      case BuildLogLevel.success: c = Colors.greenAccent.shade400; break;
                      case BuildLogLevel.error:   c = Colors.redAccent.shade200;   break;
                      case BuildLogLevel.warning: c = Colors.orangeAccent;         break;
                      default:                    c = Colors.white54;
                    }
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 2),
                      child: RichText(text: TextSpan(children: [
                        TextSpan(text: '[${e.timestamp}] ', style: TextStyle(color: accentGrey.withOpacity(0.4), fontSize: 10, fontFamily: 'ShareTechMono')),
                        TextSpan(text: e.message, style: TextStyle(color: c, fontSize: 10.5, fontFamily: 'ShareTechMono', height: 1.55)),
                      ])),
                    );
                  },
                ),
        ),
      ]),
    );
  }

  Widget _dot(Color c) => Container(width: 10, height: 10, decoration: BoxDecoration(color: c, shape: BoxShape.circle));

  // ── Download Section ──
  Widget _downloadSection(BuildSession s) => AnimatedBuilder(
    animation: _glowCtrl,
    builder: (_, __) => Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Colors.greenAccent.withOpacity(0.08), Colors.teal.withOpacity(0.04)]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.greenAccent.withOpacity(0.3 + 0.12 * _glowCtrl.value), width: 1.5),
        boxShadow: [BoxShadow(color: Colors.greenAccent.withOpacity(0.05 + 0.04 * _glowCtrl.value), blurRadius: 20)],
      ),
      child: Column(children: [
        Row(children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.greenAccent.withOpacity(0.12), borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.greenAccent.withOpacity(0.3))),
            child: const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('APK SIAP DIDOWNLOAD!', style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', fontSize: 12)),
            Text(s.apkFileName ?? 'app.apk', style: const TextStyle(color: Colors.white60, fontSize: 10, fontFamily: 'ShareTechMono'), overflow: TextOverflow.ellipsis),
          ])),
          if (_localApkPath != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(color: Colors.greenAccent.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
              child: const Text('✓ Di HP', style: TextStyle(color: Colors.greenAccent, fontSize: 9, fontFamily: 'ShareTechMono')),
            ),
        ]),

        if (_isDownloading) ...[
          const SizedBox(height: 14),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('⬇️ Mendownload...', style: TextStyle(color: Colors.greenAccent, fontSize: 11, fontFamily: 'ShareTechMono')),
            Text('${(_dlProgress * 100).toInt()}%', style: const TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.w700, fontFamily: 'ShareTechMono')),
          ]),
          const SizedBox(height: 8),
          ClipRRect(borderRadius: BorderRadius.circular(8),
            child: LinearProgressIndicator(value: _dlProgress, backgroundColor: Colors.greenAccent.withOpacity(0.1),
              valueColor: const AlwaysStoppedAnimation(Colors.greenAccent), minHeight: 8)),
        ],

        const SizedBox(height: 16),

        // ── Tombol Download & Install ──
        GestureDetector(
          onTap: _isDownloading ? null : _downloadAndInstall,
          child: Container(
            height: 52,
            decoration: BoxDecoration(
              gradient: _isDownloading
                  ? LinearGradient(colors: [Colors.grey.shade700, Colors.grey.shade600])
                  : const LinearGradient(colors: [Color(0xFF00C853), Color(0xFF00BFA5)]),
              borderRadius: BorderRadius.circular(14),
              boxShadow: _isDownloading ? [] : [BoxShadow(color: Colors.greenAccent.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 4))],
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              if (_isDownloading)
                const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              else
                const Icon(Icons.download_rounded, color: Colors.white, size: 22),
              const SizedBox(width: 10),
              Text(
                _isDownloading ? 'DOWNLOADING...' : _localApkPath != null ? 'INSTALL ULANG APK' : 'DOWNLOAD & INSTALL APK',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', fontSize: 12, letterSpacing: 1),
              ),
            ]),
          ),
        ),

        const SizedBox(height: 10),

        // ── Tombol Bagikan APK ──
        GestureDetector(
          onTap: _isDownloading ? null : _shareApk,
          child: Container(
            height: 52,
            decoration: BoxDecoration(
              color: cardSolid,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: Colors.greenAccent.withOpacity(0.5), width: 1.5),
            ),
            child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.share_rounded, color: Colors.greenAccent, size: 22),
              SizedBox(width: 10),
              Text('BAGIKAN APK', style: TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', fontSize: 14, letterSpacing: 1.2)),
            ]),
          ),
        ),

        const SizedBox(height: 12),
        Row(children: [
          Icon(Icons.info_outline_rounded, color: accentGrey, size: 12),
          const SizedBox(width: 6),
          Expanded(child: Text(
            'Download → langsung install di HP.\nBagikan → kirim file APK ke WhatsApp/Telegram/dll.',
            style: TextStyle(color: accentGrey, fontSize: 10, fontFamily: 'ShareTechMono', height: 1.5),
          )),
        ]),
      ]),
    ),
  );
}
