// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'config.dart';
import 'color_theme.dart';

// ═══════════════════════════════════════════════════════════════
// BUILD APK PAGE — Zero Crash
// Upload ZIP → Build via GitHub Actions → Download APK
// ═══════════════════════════════════════════════════════════════

class BuildApkPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const BuildApkPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<BuildApkPage> createState() => _BuildApkPageState();
}

class _BuildApkPageState extends State<BuildApkPage>
    with TickerProviderStateMixin {
  // ── Theme color getters ──────────────────────────────────────
  Color get bgDark => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;
  Color get lightPurple => AppThemeController.instance.theme.lightPurple;
  Color get glowMagenta => AppThemeController.instance.theme.glowMagenta;
  Color get cardGlass => AppThemeController.instance.theme.cardGlass;
  Color get borderGlass => AppThemeController.instance.theme.borderGlass;
  Color get cardSolid => AppThemeController.instance.theme.cardSolid;
  Color get accentGrey => AppThemeController.instance.theme.accentGrey;
  Color get cardSolidSelected =>
      AppThemeController.instance.theme.cardSolidSelected;

  // ── Animation Controllers ────────────────────────────────────
  late AnimationController _glowController;
  late AnimationController _pulseController;
  late AnimationController _entranceController;

  // ── State: File Upload ───────────────────────────────────────
  String? _selectedFileName;
  List<int>? _selectedFileBytes;
  double _fileSizeMB = 0;

  // ── State: Build ─────────────────────────────────────────────
  bool _isUploading = false;
  bool _isBuilding = false;
  String? _sessionId;
  String _buildStatus = '';
  double _buildProgress = 0;
  int _buildPercent = 0;
  String _currentStep = '';

  // ── State: Logs & APK ────────────────────────────────────────
  final List<_LogEntry> _consoleLogs = [];
  String? _apkDownloadUrl;
  String? _apkFileName;
  Timer? _statusTimer;

  // ── Config ───────────────────────────────────────────────────
  String _buildType = 'release';
  final ScrollController _consoleScrollController = ScrollController();
  final int _maxDisplayLogs = 200;

  // ─────────────────────────────────────────────────────────────
  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);

    _glowController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..repeat(reverse: true);

    _entranceController = AnimationController(
      duration: const Duration(milliseconds: 700),
      vsync: this,
    )..forward();
  }

  @override
  void dispose() {
    _glowController.dispose();
    _pulseController.dispose();
    _entranceController.dispose();
    _statusTimer?.cancel();
    _consoleScrollController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _onThemeChanged() => mounted ? setState(() {}) : null;

  // ─────────────────────────────────────────────────────────────
  // FILE PICKER
  // ─────────────────────────────────────────────────────────────
  Future<void> _pickZipFile() async {
    if (_isUploading || _isBuilding) return;

    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['zip'],
        withData: true,
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        if (file.bytes == null) {
          _showSnack('❌ Gagal membaca file. Coba lagi.');
          return;
        }

        setState(() {
          _selectedFileName = file.name;
          _selectedFileBytes = file.bytes;
          _fileSizeMB = (file.bytes!.length) / 1024 / 1024;
          // Reset build state
          _apkDownloadUrl = null;
          _apkFileName = null;
          _consoleLogs.clear();
          _buildStatus = '';
          _buildProgress = 0;
          _buildPercent = 0;
          _currentStep = '';
          _sessionId = null;
        });
      }
    } catch (e) {
      _showSnack('❌ Error pilih file: ${e.toString()}');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // LOGGING
  // ─────────────────────────────────────────────────────────────
  void _addLog(String message, {_LogLevel level = _LogLevel.info}) {
    final now = DateTime.now();
    final ts =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
    setState(() {
      _consoleLogs.add(_LogEntry(ts, message, level));
      // Trim jika terlalu banyak
      if (_consoleLogs.length > _maxDisplayLogs) {
        _consoleLogs.removeAt(0);
      }
    });

    // Auto-scroll ke bawah
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_consoleScrollController.hasClients) {
        _consoleScrollController.animateTo(
          _consoleScrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 150),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ─────────────────────────────────────────────────────────────
  // UPLOAD + BUILD
  // ─────────────────────────────────────────────────────────────
  Future<void> _startBuild() async {
    if (_selectedFileBytes == null || _selectedFileName == null) {
      _showSnack('⚠️ Pilih file ZIP terlebih dahulu!');
      return;
    }

    setState(() {
      _isUploading = true;
      _isBuilding = false;
      _consoleLogs.clear();
      _apkDownloadUrl = null;
      _apkFileName = null;
      _buildStatus = 'uploading';
      _buildProgress = 0.05;
      _buildPercent = 5;
      _currentStep = 'Uploading file...';
    });

    _addLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    _addLog('🚀 Zero Crash Flutter Builder');
    _addLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    _addLog('📁 File: $_selectedFileName');
    _addLog('📏 Size: ${_fileSizeMB.toStringAsFixed(2)} MB');
    _addLog('🔧 Type: ${_buildType.toUpperCase()}');
    _addLog('');
    _addLog('📤 Uploading ke server...', level: _LogLevel.info);

    try {
      // ── STEP 1: Upload ZIP ───────────────────────────────────
      final uri = Uri.parse('$apiBaseUrl/api/uploadBuildZip');
      final request = http.MultipartRequest('POST', uri)
        ..headers['x-session-key'] = widget.sessionKey
        ..fields['buildType'] = _buildType
        ..files.add(
          http.MultipartFile.fromBytes(
            'file',
            _selectedFileBytes!,
            filename: _selectedFileName!,
          ),
        );

      final streamedResp = await request.send().timeout(
            const Duration(minutes: 5),
            onTimeout: () => throw Exception('Upload timeout (5 menit)'),
          );
      final uploadResp = await http.Response.fromStream(streamedResp);

      if (uploadResp.statusCode != 200) {
        throw Exception('HTTP ${uploadResp.statusCode}: Upload gagal');
      }

      final uploadData = jsonDecode(uploadResp.body);
      if (uploadData['success'] != true) {
        throw Exception(uploadData['message'] ?? 'Upload gagal');
      }

      _sessionId = uploadData['sessionId'] as String;
      final shortId = _sessionId!.substring(0, 10);

      _addLog('✅ Upload berhasil!', level: _LogLevel.success);
      _addLog('🆔 Session ID: $shortId...');
      _addLog('📦 File: ${uploadData['fileName']}');
      _addLog('');

      setState(() {
        _isUploading = false;
        _isBuilding = true;
        _buildStatus = 'queued';
        _buildProgress = 0.1;
        _buildPercent = 10;
        _currentStep = 'Memulai build...';
      });

      // ── STEP 2: Trigger Build ────────────────────────────────
      _addLog('🔨 Memulai GitHub Actions build...', level: _LogLevel.info);

      final buildResp = await http.post(
        Uri.parse('$apiBaseUrl/api/buildFlutterApk'),
        headers: {
          'Content-Type': 'application/json',
          'x-session-key': widget.sessionKey,
        },
        body: jsonEncode({
          'sessionId': _sessionId,
          'buildType': _buildType,
        }),
      ).timeout(const Duration(seconds: 30));

      final buildData = jsonDecode(buildResp.body);
      if (buildData['success'] != true) {
        throw Exception(buildData['message'] ?? 'Gagal memulai build');
      }

      _addLog('✅ Build queued di GitHub Actions!', level: _LogLevel.success);
      _addLog('⏳ Menunggu workflow... (bisa 5-15 menit)');
      _addLog('📊 Polling status setiap 5 detik...');
      _addLog('');

      // ── STEP 3: Start Polling ────────────────────────────────
      _startPolling();
    } catch (e) {
      setState(() {
        _isUploading = false;
        _isBuilding = false;
        _buildStatus = 'failed';
        _buildProgress = 0;
        _buildPercent = 0;
        _currentStep = 'Gagal';
      });
      _addLog('❌ ERROR: ${e.toString()}', level: _LogLevel.error);
      _showSnack('❌ ${e.toString()}');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // POLLING STATUS
  // ─────────────────────────────────────────────────────────────
  void _startPolling() {
    _statusTimer?.cancel();
    _statusTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _pollStatus();
    });
  }

  Future<void> _pollStatus() async {
    if (_sessionId == null || !_isBuilding) return;

    try {
      final resp = await http.get(
        Uri.parse('$apiBaseUrl/api/buildStatus?sessionId=$_sessionId'),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 10));

      if (resp.statusCode != 200) return;

      final data = jsonDecode(resp.body);
      if (data['success'] != true) return;

      final status = (data['status'] as String?) ?? 'unknown';
      final progress = ((data['progress'] as num?) ?? 0).toDouble();
      final percent = progress.toInt();
      final step = (data['currentStep'] as String?) ?? '';
      final rawLogs = data['logs'] as List? ?? [];

      // Append new logs (deduplicate)
      for (final l in rawLogs) {
        final msg = (l['message'] as String?) ?? '';
        if (msg.isEmpty) continue;
        final alreadyHas = _consoleLogs.any((e) => e.message.contains(
              msg.length > 40 ? msg.substring(0, 40) : msg,
            ));
        if (!alreadyHas) {
          _LogLevel lvl = _LogLevel.info;
          if (msg.contains('✅') || msg.contains('success') || msg.contains('completed')) {
            lvl = _LogLevel.success;
          } else if (msg.contains('❌') || msg.contains('Error') || msg.contains('error') || msg.contains('failed')) {
            lvl = _LogLevel.error;
          } else if (msg.contains('⚠️') || msg.contains('Warning')) {
            lvl = _LogLevel.warning;
          }
          _addLog(msg, level: lvl);
        }
      }

      setState(() {
        _buildStatus = status;
        _buildProgress = (progress / 100).clamp(0.0, 1.0);
        _buildPercent = percent;
        _currentStep = step;
      });

      if (status == 'completed') {
        _statusTimer?.cancel();
        setState(() {
          _isBuilding = false;
          _buildProgress = 1.0;
          _buildPercent = 100;
          _apkDownloadUrl = data['apkDownloadUrl'] as String?;
          _apkFileName = data['apkFileName'] as String?;
          _currentStep = 'Build Selesai!';
        });
        _addLog('');
        _addLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        _addLog('🎉 BUILD SUKSES! APK siap didownload.', level: _LogLevel.success);
        _addLog('📱 Klik tombol DOWNLOAD APK di bawah.');
        _addLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      } else if (status == 'failed') {
        _statusTimer?.cancel();
        setState(() {
          _isBuilding = false;
          _currentStep = 'Build Gagal';
        });
        final errMsg = (data['error'] as String?) ?? 'Unknown error';
        _addLog('');
        _addLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        _addLog('❌ BUILD GAGAL!', level: _LogLevel.error);
        _addLog('💥 Error: $errMsg', level: _LogLevel.error);
        _addLog('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
      }
    } catch (_) {
      // Polling error — tidak fatal, coba lagi berikutnya
    }
  }

  // ─────────────────────────────────────────────────────────────
  // DOWNLOAD APK
  // ─────────────────────────────────────────────────────────────
  Future<void> _downloadApk() async {
    if (_apkDownloadUrl == null) return;
    final fullUrl = '$apiBaseUrl$_apkDownloadUrl';
    final uri = Uri.parse(fullUrl);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      _showSnack('❌ Tidak bisa membuka link download.');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────────────────────
  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
        backgroundColor: primaryPurple.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  String _statusLabel() {
    switch (_buildStatus) {
      case 'uploading':
        return '📤 Uploading...';
      case 'queued':
        return '⏳ Dalam Antrian...';
      case 'extracting':
        return '📂 Extracting ZIP...';
      case 'cleaning':
        return '🧹 Flutter Clean...';
      case 'pubget':
        return '📦 Pub Get Deps...';
      case 'building':
        return '🔨 Compiling APK...';
      case 'completed':
        return '✅ Build Selesai!';
      case 'failed':
        return '❌ Build Gagal';
      default:
        return _currentStep.isNotEmpty ? '⏳ $_currentStep' : '💤 Ready';
    }
  }

  Color _statusColor() {
    switch (_buildStatus) {
      case 'completed':
        return Colors.greenAccent;
      case 'failed':
        return Colors.redAccent;
      case 'building':
      case 'uploading':
        return accentPurple;
      default:
        return Colors.orangeAccent;
    }
  }

  // ─────────────────────────────────────────────────────────────
  // BUILD UI
  // ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppThemeController.instance,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: bgDark,
          appBar: _buildAppBar(),
          body: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildUploadCard(),
                const SizedBox(height: 14),
                _buildBuildTypeCard(),
                const SizedBox(height: 14),
                _buildActionButton(),
                const SizedBox(height: 14),
                if (_buildStatus.isNotEmpty) ...[
                  _buildProgressCard(),
                  const SizedBox(height: 14),
                ],
                _buildConsoleCard(),
                const SizedBox(height: 14),
                if (_apkDownloadUrl != null) _buildDownloadCard(),
              ],
            ),
          ),
        );
      },
    );
  }

  // ── AppBar ───────────────────────────────────────────────────
  AppBar _buildAppBar() {
    return AppBar(
      backgroundColor: bgDark,
      elevation: 0,
      leading: IconButton(
        icon:
            Icon(Icons.arrow_back_ios_new_rounded, color: accentPurple, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      titleSpacing: 0,
      title: Row(
        children: [
          AnimatedBuilder(
            animation: _glowController,
            builder: (_, __) => Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: [primaryPurple, accentPurple],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: primaryPurple
                        .withOpacity(0.25 + 0.2 * _glowController.value),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: const Icon(Icons.build_rounded, color: Colors.white, size: 16),
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'BUILD APK',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              Text(
                'Flutter → APK via GitHub Actions',
                style: TextStyle(
                    color: accentGrey, fontSize: 9, fontFamily: 'ShareTechMono'),
              ),
            ],
          ),
        ],
      ),
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [Colors.transparent, primaryPurple, Colors.transparent]),
          ),
        ),
      ),
    );
  }

  // ── Upload Card ──────────────────────────────────────────────
  Widget _buildUploadCard() {
    final hasFile = _selectedFileName != null;
    return GestureDetector(
      onTap: _pickZipFile,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          color: cardSolid,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: hasFile ? primaryPurple.withOpacity(0.6) : borderGlass,
            width: hasFile ? 1.5 : 1,
          ),
          gradient: hasFile
              ? LinearGradient(
                  colors: [
                    primaryPurple.withOpacity(0.07),
                    accentPurple.withOpacity(0.03),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
        ),
        child: Column(
          children: [
            // Icon with glow
            AnimatedBuilder(
              animation: _glowController,
              builder: (_, __) => Container(
                width: 68,
                height: 68,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: primaryPurple.withOpacity(0.12),
                  border: Border.all(
                    color: primaryPurple.withOpacity(
                        0.2 + 0.15 * _glowController.value),
                  ),
                  boxShadow: hasFile
                      ? [
                          BoxShadow(
                            color: primaryPurple.withOpacity(
                                0.2 + 0.15 * _glowController.value),
                            blurRadius: 18,
                          ),
                        ]
                      : [],
                ),
                child: Icon(
                  hasFile
                      ? Icons.folder_zip_rounded
                      : Icons.upload_file_rounded,
                  color: hasFile ? accentPurple : Colors.white38,
                  size: 32,
                ),
              ),
            ),
            const SizedBox(height: 14),

            if (hasFile) ...[
              Text(
                _selectedFileName!,
                style: TextStyle(
                  color: accentPurple,
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'ShareTechMono',
                ),
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _chipTag(
                      '📏 ${_fileSizeMB.toStringAsFixed(2)} MB', primaryPurple),
                  const SizedBox(width: 8),
                  _chipTag('✅ ZIP Valid', Colors.greenAccent),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                'Tap untuk ganti file',
                style: TextStyle(color: accentGrey, fontSize: 11),
              ),
            ] else ...[
              Text(
                'Upload File ZIP',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 6),
              Text(
                'Tap untuk pilih ZIP project Flutter kamu',
                style: TextStyle(color: accentGrey, fontSize: 12),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 6,
                alignment: WrapAlignment.center,
                children: [
                  _chipTag('📦 .zip', null),
                  _chipTag('📁 Max 500MB', null),
                  _chipTag('🔒 Google Drive', null),
                  _chipTag('💾 File Manager', null),
                  _chipTag('☁️ Cloud Storage', null),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _chipTag(String text, Color? color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: (color ?? primaryPurple).withOpacity(0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: (color ?? borderGlass).withOpacity(0.4)),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color ?? accentGrey,
          fontSize: 10,
          fontFamily: 'ShareTechMono',
        ),
      ),
    );
  }

  // ── Build Type Card ──────────────────────────────────────────
  Widget _buildBuildTypeCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardSolid,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.tune_rounded, color: accentPurple, size: 15),
              const SizedBox(width: 8),
              Text(
                'BUILD TYPE',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                  child: _buildTypeOption('release', '🚀 Release',
                      'Optimized & signed', Colors.greenAccent)),
              const SizedBox(width: 10),
              Expanded(
                  child: _buildTypeOption(
                      'debug', '🐞 Debug', 'Dev & testing', Colors.orangeAccent)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTypeOption(
      String value, String label, String subtitle, Color accentColor) {
    final isSelected = _buildType == value;
    return GestureDetector(
      onTap: (_isUploading || _isBuilding)
          ? null
          : () => setState(() => _buildType = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: isSelected ? accentColor.withOpacity(0.1) : bgDark,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? accentColor.withOpacity(0.6) : borderGlass,
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(
                color: isSelected ? accentColor : Colors.white54,
                fontWeight: FontWeight.w700,
                fontSize: 12,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 3),
            Text(
              subtitle,
              style: TextStyle(color: accentGrey, fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }

  // ── Action Button ────────────────────────────────────────────
  Widget _buildActionButton() {
    final bool canBuild =
        _selectedFileName != null && !_isUploading && !_isBuilding;

    return GestureDetector(
      onTap: canBuild ? _startBuild : null,
      child: AnimatedBuilder(
        animation: _pulseController,
        builder: (_, __) => AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          height: 58,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: canBuild
                  ? [primaryPurple, accentPurple]
                  : [Colors.grey.shade800, Colors.grey.shade700],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: canBuild
                ? [
                    BoxShadow(
                      color: primaryPurple.withOpacity(
                          0.3 + 0.15 * _pulseController.value),
                      blurRadius: 20 + 8 * _pulseController.value,
                      offset: const Offset(0, 5),
                    ),
                  ]
                : [],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_isUploading || _isBuilding) ...[
                SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    color: Colors.white,
                  ),
                ),
              ] else ...[
                const Icon(Icons.build_circle_rounded,
                    color: Colors.white, size: 22),
              ],
              const SizedBox(width: 10),
              Text(
                _isUploading
                    ? 'UPLOADING...'
                    : _isBuilding
                        ? 'BUILDING...'
                        : 'BUILD APK',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Progress Card ────────────────────────────────────────────
  Widget _buildProgressCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardSolid,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  _statusLabel(),
                  style: TextStyle(
                    color: _statusColor(),
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Orbitron',
                    fontSize: 11,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              AnimatedBuilder(
                animation: _pulseController,
                builder: (_, __) => Text(
                  '$_buildPercent%',
                  style: TextStyle(
                    color: _statusColor(),
                    fontWeight: FontWeight.w900,
                    fontFamily: 'ShareTechMono',
                    fontSize: 18,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: AnimatedBuilder(
              animation: _pulseController,
              builder: (_, __) => LinearProgressIndicator(
                value: _buildProgress,
                backgroundColor: borderGlass,
                valueColor: AlwaysStoppedAnimation(
                  _buildStatus == 'completed'
                      ? Colors.greenAccent
                      : _buildStatus == 'failed'
                          ? Colors.redAccent
                          : Color.lerp(
                              primaryPurple,
                              accentPurple,
                              _pulseController.value,
                            )!,
                ),
                minHeight: 10,
              ),
            ),
          ),
          if (_currentStep.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              '▸ $_currentStep',
              style: TextStyle(
                color: accentGrey,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ── Console Card ─────────────────────────────────────────────
  Widget _buildConsoleCard() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF060610),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.06),
            blurRadius: 20,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── Console Header ──
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: cardSolid,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(18)),
              border: Border(bottom: BorderSide(color: borderGlass)),
            ),
            child: Row(
              children: [
                _consoleDot(Colors.redAccent),
                const SizedBox(width: 5),
                _consoleDot(Colors.orangeAccent),
                const SizedBox(width: 5),
                _consoleDot(Colors.greenAccent),
                const SizedBox(width: 12),
                Icon(Icons.terminal_rounded, color: accentPurple, size: 13),
                const SizedBox(width: 7),
                Text(
                  'Build Console',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                    fontWeight: FontWeight.w600,
                    letterSpacing: 0.5,
                  ),
                ),
                const Spacer(),
                Text(
                  '${_consoleLogs.length} lines',
                  style: TextStyle(color: accentGrey, fontSize: 9),
                ),
                const SizedBox(width: 10),
                if (_consoleLogs.isNotEmpty)
                  GestureDetector(
                    onTap: () => setState(() => _consoleLogs.clear()),
                    child: Icon(Icons.clear_all_rounded,
                        color: accentGrey, size: 16),
                  ),
              ],
            ),
          ),

          // ── Console Body ──
          SizedBox(
            height: 260,
            child: _consoleLogs.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.terminal_rounded,
                            color: accentGrey.withOpacity(0.3), size: 36),
                        const SizedBox(height: 10),
                        Text(
                          'Log kosong...',
                          style:
                              TextStyle(color: accentGrey, fontSize: 13),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'Upload ZIP & klik BUILD APK',
                          style: TextStyle(
                              color: accentGrey.withOpacity(0.6), fontSize: 11),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    controller: _consoleScrollController,
                    padding: const EdgeInsets.all(12),
                    itemCount: _consoleLogs.length,
                    itemBuilder: (context, i) {
                      final entry = _consoleLogs[i];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 2),
                        child: RichText(
                          text: TextSpan(
                            children: [
                              TextSpan(
                                text: '[${entry.timestamp}] ',
                                style: TextStyle(
                                  color: accentGrey.withOpacity(0.4),
                                  fontSize: 10,
                                  fontFamily: 'ShareTechMono',
                                ),
                              ),
                              TextSpan(
                                text: entry.message,
                                style: TextStyle(
                                  color: _logColor(entry.level),
                                  fontSize: 10.5,
                                  fontFamily: 'ShareTechMono',
                                  height: 1.55,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _consoleDot(Color color) {
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    );
  }

  Color _logColor(_LogLevel level) {
    switch (level) {
      case _LogLevel.success:
        return Colors.greenAccent.shade400;
      case _LogLevel.error:
        return Colors.redAccent.shade200;
      case _LogLevel.warning:
        return Colors.orangeAccent;
      case _LogLevel.highlight:
        return accentPurple;
      default:
        return Colors.white54;
    }
  }

  // ── Download Card ────────────────────────────────────────────
  Widget _buildDownloadCard() {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (_, __) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.greenAccent.withOpacity(0.08),
              Colors.teal.withOpacity(0.04),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: Colors.greenAccent
                .withOpacity(0.3 + 0.15 * _glowController.value),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.greenAccent.withOpacity(
                  0.08 + 0.06 * _glowController.value),
              blurRadius: 20,
            ),
          ],
        ),
        child: Column(
          children: [
            // Header row
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.greenAccent.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: Colors.greenAccent.withOpacity(0.3)),
                  ),
                  child: const Icon(Icons.check_circle_rounded,
                      color: Colors.greenAccent, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'APK SIAP DIDOWNLOAD!',
                        style: TextStyle(
                          color: Colors.greenAccent,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Orbitron',
                          fontSize: 12,
                          letterSpacing: 0.5,
                        ),
                      ),
                      Text(
                        _apkFileName ?? 'app-release.apk',
                        style: TextStyle(
                          color: Colors.white60,
                          fontSize: 10,
                          fontFamily: 'ShareTechMono',
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Download button
            GestureDetector(
              onTap: _downloadApk,
              child: Container(
                height: 52,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF00C853), Color(0xFF00BFA5)],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.greenAccent.withOpacity(
                          0.25 + 0.1 * _glowController.value),
                      blurRadius: 16,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.download_rounded, color: Colors.white, size: 22),
                    SizedBox(width: 10),
                    Text(
                      'DOWNLOAD APK',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron',
                        fontSize: 14,
                        letterSpacing: 1.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// LOG MODELS
// ═══════════════════════════════════════════════════════════════

enum _LogLevel { info, success, error, warning, highlight }

class _LogEntry {
  final String timestamp;
  final String message;
  final _LogLevel level;

  const _LogEntry(this.timestamp, this.message, this.level);
}
