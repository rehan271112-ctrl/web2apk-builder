import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

// ─── BACKGROUND SERVICE ──────────────────────────────────────────────
class BackgroundService {
  static const String _bgPathKey = 'bg_image_path';
  static const String _bgTypeKey = 'bg_type'; // 'image', 'video', 'default'
  static const String _bgCustomDirKey = 'bg_custom_dir';

  static Future<String?> getBackgroundPath() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_bgPathKey);
  }

  static Future<String> getBackgroundType() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_bgTypeKey) ?? 'default';
  }

  static Future<bool> setImageBackground(File imageFile) async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final customBgDir = Directory('${appDir.path}/backgrounds');
      
      if (!await customBgDir.exists()) {
        await customBgDir.create(recursive: true);
      }

      final fileName = 'bg_image_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final savedFile = File('${customBgDir.path}/$fileName');
      
      await imageFile.copy(savedFile.path);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_bgPathKey, savedFile.path);
      await prefs.setString(_bgTypeKey, 'image');
      await prefs.setString(_bgCustomDirKey, customBgDir.path);
      
      return true;
    } catch (e) {
      print('Error setting image background: $e');
      return false;
    }
  }

  static Future<bool> setVideoBackground(File videoFile) async {
    try {
      final appDir = await getApplicationDocumentsDirectory();
      final customBgDir = Directory('${appDir.path}/backgrounds');
      
      if (!await customBgDir.exists()) {
        await customBgDir.create(recursive: true);
      }

      final fileName = 'bg_video_${DateTime.now().millisecondsSinceEpoch}.mp4';
      final savedFile = File('${customBgDir.path}/$fileName');
      
      await videoFile.copy(savedFile.path);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_bgPathKey, savedFile.path);
      await prefs.setString(_bgTypeKey, 'video');
      await prefs.setString(_bgCustomDirKey, customBgDir.path);
      
      return true;
    } catch (e) {
      print('Error setting video background: $e');
      return false;
    }
  }

  static Future<bool> resetToDefault() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_bgPathKey);
      await prefs.setString(_bgTypeKey, 'default');
      return true;
    } catch (e) {
      print('Error resetting background: $e');
      return false;
    }
  }

  static Future<File?> pickImage() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickImage(source: ImageSource.gallery);
      
      if (pickedFile != null) {
        return File(pickedFile.path);
      }
    } catch (e) {
      print('Error picking image: $e');
    }
    return null;
  }

  static Future<File?> pickVideo() async {
    try {
      final picker = ImagePicker();
      final pickedFile = await picker.pickVideo(source: ImageSource.gallery);
      
      if (pickedFile != null) {
        return File(pickedFile.path);
      }
    } catch (e) {
      print('Error picking video: $e');
    }
    return null;
  }

  static Future<bool> deleteBackground() async {
    try {
      final bgPath = await getBackgroundPath();
      if (bgPath != null) {
        final file = File(bgPath);
        if (await file.exists()) {
          await file.delete();
        }
      }
      await resetToDefault();
      return true;
    } catch (e) {
      print('Error deleting background: $e');
      return false;
    }
  }

  static Future<bool> backgroundExists() async {
    try {
      final bgType = await getBackgroundType();
      if (bgType == 'default') return true;
      
      final bgPath = await getBackgroundPath();
      if (bgPath != null) {
        final file = File(bgPath);
        return await file.exists();
      }
    } catch (e) {
      print('Error checking background: $e');
    }
    return false;
  }
}
