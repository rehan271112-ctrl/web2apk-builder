import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'config.dart';

// ═══════════════════════════════════════════════════════════════
// MODELS
// ═══════════════════════════════════════════════════════════════

class StoryItem {
  final String id;
  final String mediaUrl;
  final String mediaType; // 'image' atau 'video'
  final String caption;
  final String song;
  final DateTime createdAt;
  final DateTime expiresAt;
  final int viewersCount;

  StoryItem({
    required this.id,
    required this.mediaUrl,
    required this.mediaType,
    required this.caption,
    required this.song,
    required this.createdAt,
    required this.expiresAt,
    required this.viewersCount,
  });

  bool get isVideo => mediaType == 'video';

  factory StoryItem.fromJson(Map<String, dynamic> json) {
    return StoryItem(
      id: (json['id'] ?? '').toString(),
      mediaUrl: (json['mediaUrl'] ?? '').toString(),
      mediaType: (json['mediaType'] ?? 'image').toString(),
      caption: (json['caption'] ?? '').toString(),
      song: (json['song'] ?? '').toString(),
      viewersCount: int.tryParse(json['viewersCount'].toString()) ?? 0,
      createdAt: DateTime.fromMillisecondsSinceEpoch(
          int.tryParse(json['createdAt'].toString()) ?? 0),
      expiresAt: DateTime.fromMillisecondsSinceEpoch(
          int.tryParse(json['expiresAt'].toString()) ?? 0),
    );
  }
}


class StoryGroup {
  final String username;
  final String? avatarUrl;
  final bool isMe;
  final List<StoryItem> stories;

  StoryGroup({
    required this.username,
    required this.avatarUrl,
    required this.isMe,
    required this.stories,
  });

  factory StoryGroup.fromJson(Map<String, dynamic> json) {
    return StoryGroup(
      username: (json['username'] ?? '').toString(),
      avatarUrl: json['avatarUrl']?.toString(),
      isMe: json['isMe'] == true,
      stories: ((json['stories'] ?? []) as List)
          .map((e) => StoryItem.fromJson(e))
          .toList(),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// STORY WIDGET (bar horizontal di dashboard)
// ═══════════════════════════════════════════════════════════════

class StoryWidget extends StatefulWidget {
  final String username;
  final String sessionKey;

  const StoryWidget({
    Key? key,
    required this.username,
    required this.sessionKey,
  }) : super(key: key);

  @override
  State<StoryWidget> createState() => _StoryWidgetState();
}

class _StoryWidgetState extends State<StoryWidget> {
  static const List<Color> ringActive = [Color(0xFFFF4D6D), Color(0xFFE91E8C)];
  static const Color ringViewed = Color(0xFF3A3A3A);
  static const Color letterBg = Color(0xFFF5F0E8);
  static const Color letterText = Color(0xFF1A1A1A);

  File? _profileImage;
  List<StoryGroup> groups = [];
  Set<String> viewedIds = {};
  bool isLoading = true;
  bool isUploading = false;
  Timer? _autoRefresh;

  @override
  void initState() {
    super.initState();
    _init();
    _autoRefresh = Timer.periodic(const Duration(seconds: 45), (_) {
      _fetchStories(silent: true);
    });
  }

  @override
  void dispose() {
    _autoRefresh?.cancel();
    super.dispose();
  }

  Future<void> _init() async {
    await _loadLocalProfileImage();
    await _loadViewedIds();
    await _fetchStories();
  }

  Future<void> _loadLocalProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_${widget.username}');
    if (imagePath != null && File(imagePath).existsSync()) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _loadViewedIds() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList('viewed_story_ids_${widget.username}') ?? [];
    setState(() {
      viewedIds = saved.toSet();
    });
  }

  Future<void> _saveViewedIds() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      'viewed_story_ids_${widget.username}',
      viewedIds.toList(),
    );
  }

  Future<void> _fetchStories({bool silent = false}) async {
    if (!silent) setState(() => isLoading = true);
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/api/story/list?key=${widget.sessionKey}'),
        headers: {'Accept': 'application/json'},
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          final list = (data['result'] as List)
              .map((e) => StoryGroup.fromJson(e))
              .toList();
          if (mounted) {
            setState(() {
              groups = list;
            });
          }
        }
      }
    } catch (e) {
      debugPrint('Error fetching stories: $e');
    } finally {
      if (mounted && !silent) setState(() => isLoading = false);
    }
  }

  Future<String?> _pickMediaType() {
    return showModalBottomSheet<String>(
      context: context,
      backgroundColor: const Color(0xFF161616),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Buat Story',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.image_outlined, color: Color(0xFFEC1361)),
                title: const Text('Foto', style: TextStyle(color: Colors.white)),
                onTap: () => Navigator.pop(context, 'image'),
              ),
              ListTile(
                leading: const Icon(Icons.videocam_outlined, color: Color(0xFFEC1361)),
                title: const Text('Video', style: TextStyle(color: Colors.white)),
                onTap: () => Navigator.pop(context, 'video'),
              ),
              ListTile(
                leading: const Icon(Icons.close, color: Colors.white70),
                title: const Text('Batal', style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.pop(context, null),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _createStory() async {
    final String? type = await _pickMediaType();
    if (type == null) return;

    final ImagePicker picker = ImagePicker();
    XFile? media;
    if (type == 'video') {
      media = await picker.pickVideo(
        source: ImageSource.gallery,
        maxDuration: const Duration(seconds: 60),
      );
    } else {
      media = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );
    }
    if (media == null) return;

    setState(() => isUploading = true);
    try {
      final mediaBytes = await File(media.path).readAsBytes();
      final mediaBase64 = base64Encode(mediaBytes);

      String? avatarBase64;
      if (_profileImage != null && await _profileImage!.exists()) {
        final avatarBytes = await _profileImage!.readAsBytes();
        avatarBase64 = base64Encode(avatarBytes);
      }

      final response = await http.post(
        Uri.parse('$apiBaseUrl/api/story/upload'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'mediaBase64': mediaBase64,
          'mediaType': type,
          if (avatarBase64 != null) 'avatarBase64': avatarBase64,
        }),
      );

      final data = response.statusCode == 200 ? jsonDecode(response.body) : null;

      if (data != null && data['status'] == true) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Story berhasil dibuat!')),
          );
        }
        await _fetchStories();
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data?['message']?.toString() ?? 'Gagal upload story')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal upload story')),
        );
      }
    } finally {
      if (mounted) setState(() => isUploading = false);
    }
  }

  void _openViewer(int groupIndex) async {
    final group = groups[groupIndex];
    await Navigator.push(
      context,
      PageRouteBuilder(
        opaque: false,
        barrierColor: Colors.black,
        transitionDuration: const Duration(milliseconds: 220),
        pageBuilder: (context, anim, __) => FadeTransition(
          opacity: anim,
          child: _StoryViewerPage(
            groups: groups,
            initialGroupIndex: groupIndex,
            myUsername: widget.username,
            sessionKey: widget.sessionKey,
            onViewed: (id) {
              viewedIds.add(id);
              _saveViewedIds();
            },
            onDeleted: () => _fetchStories(silent: true),
          ),
        ),
      ),
    );
    if (mounted) setState(() {}); // refresh ring warna setelah dilihat
  }

  bool _isGroupFullyViewed(StoryGroup g) {
    return g.stories.every((s) => viewedIds.contains(s.id));
  }

  String _initial(String username) {
    if (username.trim().isEmpty) return '?';
    return username.trim().substring(0, 1).toUpperCase();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 140,
      decoration: BoxDecoration(
        color: const Color(0xFF0A0A0A),
        border: Border.all(color: const Color(0xFF1F1F1F)),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                const Icon(Icons.star_rounded, color: Color(0xFF7C3AED), size: 16),
                const SizedBox(width: 6),
                const Text(
                  'STATUS ZEROGRAM',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
                const Spacer(),
                Text(
                  '${groups.length} aktif',
                  style: const TextStyle(
                    color: Color(0xFF888888),
                    fontSize: 10,
                  ),
                ),
              ],
            ),
          ),
          // Story circles
          Expanded(
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              // Tombol "Buat" selalu tampil. Kalau belum selesai memuat,
              // hanya tambahkan 1 slot loading kecil di sebelahnya. Kalau
              // tidak ada story dari siapa pun, tidak ada slot tambahan
              // sama sekali — cuma "Buat" saja yang muncul.
              itemCount: 1 + (isLoading ? 1 : groups.length),
              itemBuilder: (context, index) {
                if (index == 0) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 12),
                    child: _CreateStoryCircle(
                      isUploading: isUploading,
                      onTap: _createStory,
                    ),
                  );
                }
                if (isLoading) {
                  return const Padding(
                    padding: EdgeInsets.only(right: 12),
                    child: SizedBox(
                      width: 70,
                      child: Center(
                        child: SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Color(0xFF7C3AED),
                          ),
                        ),
                      ),
                    ),
                  );
                }
                final group = groups[index - 1];
                final viewed = _isGroupFullyViewed(group);
                final fullAvatarUrl = group.avatarUrl != null
                    ? '$apiBaseUrl${group.avatarUrl}'
                    : null;
                return Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: _StoryCircle(
                    label: group.isMe ? 'Cerita Anda' : group.username,
                    avatarUrl: fullAvatarUrl,
                    initial: _initial(group.username),
                    viewed: viewed,
                    ringActive: ringActive,
                    ringViewed: ringViewed,
                    letterBg: letterBg,
                    letterText: letterText,
                    onTap: () => _openViewer(index - 1),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _CreateStoryCircle extends StatelessWidget {
  final bool isUploading;
  final VoidCallback onTap;

  const _CreateStoryCircle({required this.isUploading, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isUploading ? null : onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 70,
            height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFF1F1F1F), width: 2),
              gradient: const LinearGradient(
                colors: [Color(0xFF1F1F1F), Color(0xFF2A2A2A)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Center(
              child: isUploading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.add, color: Colors.white, size: 32),
            ),
          ),
          const SizedBox(height: 6),
          const SizedBox(
            width: 70,
            child: Text(
              'Buat',
              style: TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}

class _StoryCircle extends StatelessWidget {
  final String label;
  final String? avatarUrl;
  final String initial;
  final bool viewed;
  final List<Color> ringActive;
  final Color ringViewed;
  final Color letterBg;
  final Color letterText;
  final VoidCallback onTap;

  const _StoryCircle({
    required this.label,
    required this.avatarUrl,
    required this.initial,
    required this.viewed,
    required this.ringActive,
    required this.ringViewed,
    required this.letterBg,
    required this.letterText,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 70,
            height: 70,
            padding: const EdgeInsets.all(2.6),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: viewed
                  ? null
                  : LinearGradient(
                      colors: ringActive,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
              color: viewed ? ringViewed : null,
            ),
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF0A0A0A),
              ),
              child: ClipOval(
                child: avatarUrl != null
                    ? Image.network(
                        avatarUrl!,
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                        errorBuilder: (context, error, stackTrace) =>
                            _letterAvatar(),
                        loadingBuilder: (context, child, progress) {
                          if (progress == null) return child;
                          return Container(
                            color: letterBg,
                            child: const Center(
                              child: SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(strokeWidth: 1.6),
                              ),
                            ),
                          );
                        },
                      )
                    : _letterAvatar(),
              ),
            ),
          ),
          const SizedBox(height: 6),
          SizedBox(
            width: 70,
            child: Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _letterAvatar() {
    return Container(
      color: letterBg,
      child: Center(
        child: Text(
          initial,
          style: TextStyle(
            color: letterText,
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// STORY VIEWER (fullscreen, gaya Instagram — lihat foto referensi 3)
// ═══════════════════════════════════════════════════════════════

class _StoryViewerPage extends StatefulWidget {
  final List<StoryGroup> groups;
  final int initialGroupIndex;
  final String myUsername;
  final String sessionKey;
  final void Function(String storyId) onViewed;
  final VoidCallback onDeleted;

  const _StoryViewerPage({
    required this.groups,
    required this.initialGroupIndex,
    required this.myUsername,
    required this.sessionKey,
    required this.onViewed,
    required this.onDeleted,
  });

  @override
  State<_StoryViewerPage> createState() => _StoryViewerPageState();
}

class _StoryViewerPageState extends State<_StoryViewerPage>
    with SingleTickerProviderStateMixin {
  late int groupIndex;
  int storyIndex = 0;
  late AnimationController _progressController;
  static const Duration _imageDuration = Duration(seconds: 5);
  static const Duration _fallbackVideoDuration = Duration(seconds: 15);

  VideoPlayerController? _videoController;
  bool _mediaReady = false;

  StoryGroup get currentGroup => widget.groups[groupIndex];
  StoryItem get currentStory => currentGroup.stories[storyIndex];
  String _mediaUrlFor(StoryItem s) => '$apiBaseUrl${s.mediaUrl}';

  @override
  void initState() {
    super.initState();
    groupIndex = widget.initialGroupIndex;
    _progressController = AnimationController(
      vsync: this,
      duration: _imageDuration,
    )..addStatusListener((status) {
        if (status == AnimationStatus.completed) _goNext();
      });
    _startCurrent();
  }

  @override
  void dispose() {
    _progressController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _startCurrent() async {
    widget.onViewed(currentStory.id);
    _reportView(currentStory.id);
    _progressController.stop();

    // Bersihkan video controller sebelumnya
    final oldController = _videoController;
    _videoController = null;
    setState(() => _mediaReady = currentStory.isVideo ? false : true);
    oldController?.dispose();

    if (currentStory.isVideo) {
      final controller = VideoPlayerController.networkUrl(
        Uri.parse(_mediaUrlFor(currentStory)),
      );
      try {
        await controller.initialize();
        if (!mounted) {
          controller.dispose();
          return;
        }
        _videoController = controller;
        final videoDuration = controller.value.duration;
        _progressController.duration =
            videoDuration > Duration.zero ? videoDuration : _fallbackVideoDuration;
        controller.play();
        controller.setLooping(false);
        setState(() => _mediaReady = true);
        _progressController.forward(from: 0);
      } catch (e) {
        // Gagal load video, tetap lanjut dengan durasi fallback
        _progressController.duration = _fallbackVideoDuration;
        setState(() => _mediaReady = true);
        _progressController.forward(from: 0);
      }
    } else {
      _progressController.duration = _imageDuration;
      _progressController.forward(from: 0);
    }
  }

  void _goNext() {
    if (storyIndex < currentGroup.stories.length - 1) {
      setState(() => storyIndex++);
      _startCurrent();
    } else if (groupIndex < widget.groups.length - 1) {
      setState(() {
        groupIndex++;
        storyIndex = 0;
      });
      _startCurrent();
    } else {
      Navigator.of(context).pop();
    }
  }

  void _goPrev() {
    if (storyIndex > 0) {
      setState(() => storyIndex--);
      _startCurrent();
    } else if (groupIndex > 0) {
      setState(() {
        groupIndex--;
        storyIndex = widget.groups[groupIndex].stories.length - 1;
      });
      _startCurrent();
    } else {
      _progressController.forward(from: 0);
    }
  }

  void _pause() {
    _progressController.stop();
    _videoController?.pause();
  }

  void _resume() {
    _progressController.forward();
    _videoController?.play();
  }

  // Kirim ke server bahwa story ini sudah dilihat. Fire-and-forget —
  // tidak perlu menunggu/menghambat tampilan story.
  void _reportView(String storyId) {
    if (_isOwner) return; // pemilik tidak dihitung sebagai penonton
    http
        .post(
          Uri.parse('$apiBaseUrl/api/story/view'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'key': widget.sessionKey, 'id': storyId}),
        )
        .catchError((_) {});
  }

  Future<void> _showViewersSheet(BuildContext context) async {
    _pause();
    final storyId = currentStory.id;

    await showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF161616),
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return _ViewersSheet(
          apiBaseUrl: apiBaseUrl,
          sessionKey: widget.sessionKey,
          storyId: storyId,
        );
      },
    );
    _resume();
  }

  Future<void> _deleteCurrentStory() async {
    try {
      final response = await http.get(
        Uri.parse(
          '$apiBaseUrl/api/story/delete?key=${widget.sessionKey}&id=${currentStory.id}',
        ),
      );
      final data = response.statusCode == 200 ? jsonDecode(response.body) : null;
      if (data != null && data['status'] == true) {
        widget.onDeleted();
        if (mounted) Navigator.of(context).pop();
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data?['message']?.toString() ?? 'Gagal menghapus story')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal menghapus story')),
        );
      }
    }
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inDays >= 1) return '${diff.inDays} hari';
    if (diff.inHours >= 1) return '${diff.inHours} jam';
    if (diff.inMinutes >= 1) return '${diff.inMinutes} menit';
    return 'Baru saja';
  }

  bool get _isOwner => currentGroup.username == widget.myUsername;

  Widget _buildImageMedia(String url) {
    return Container(
      color: Colors.black,
      alignment: Alignment.center,
      child: Image.network(
        url,
        fit: BoxFit.contain,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (context, error, stackTrace) => Container(
          color: const Color(0xFF111111),
          child: const Center(
            child: Icon(Icons.broken_image, color: Colors.white24, size: 48),
          ),
        ),
        loadingBuilder: (context, child, progress) {
          if (progress == null) return child;
          return Container(
            color: const Color(0xFF111111),
            child: const Center(
              child: CircularProgressIndicator(color: Colors.white54),
            ),
          );
        },
      ),
    );
  }

  Widget _buildVideoMedia() {
    final controller = _videoController;
    if (!_mediaReady || controller == null || !controller.value.isInitialized) {
      return Container(
        color: const Color(0xFF111111),
        child: const Center(
          child: CircularProgressIndicator(color: Colors.white54),
        ),
      );
    }
    return Container(
      color: Colors.black,
      alignment: Alignment.center,
      child: AspectRatio(
        aspectRatio: controller.value.aspectRatio,
        child: VideoPlayer(controller),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final group = currentGroup;
    final story = currentStory;
    final fullMediaUrl = '$apiBaseUrl${story.mediaUrl}';
    final fullAvatarUrl =
        group.avatarUrl != null ? '$apiBaseUrl${group.avatarUrl}' : null;

    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onLongPressStart: (_) => _pause(),
        onLongPressEnd: (_) => _resume(),
        onTapUp: (details) {
          final width = MediaQuery.of(context).size.width;
          if (details.globalPosition.dx < width / 3) {
            _goPrev();
          } else {
            _goNext();
          }
        },
        onVerticalDragEnd: (details) {
          if ((details.primaryVelocity ?? 0) > 200) {
            Navigator.of(context).pop();
          }
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            // Media
            story.isVideo ? _buildVideoMedia() : _buildImageMedia(fullMediaUrl),
            // Gradasi gelap atas untuk keterbacaan header
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              height: 140,
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.black54, Colors.transparent],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
            SafeArea(
              child: Column(
                children: [
                  // Progress bar segmented
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
                    child: Row(
                      children: List.generate(group.stories.length, (i) {
                        return Expanded(
                          child: Container(
                            height: 2.4,
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            decoration: BoxDecoration(
                              color: Colors.white24,
                              borderRadius: BorderRadius.circular(2),
                            ),
                            child: AnimatedBuilder(
                              animation: _progressController,
                              builder: (context, _) {
                                double widthFactor;
                                if (i < storyIndex) {
                                  widthFactor = 1.0;
                                } else if (i > storyIndex) {
                                  widthFactor = 0.0;
                                } else {
                                  widthFactor = _progressController.value;
                                }
                                return FractionallySizedBox(
                                  alignment: Alignment.centerLeft,
                                  widthFactor: widthFactor,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        );
                      }),
                    ),
                  ),
                  // Header
                  Padding(
                    padding: const EdgeInsets.fromLTRB(12, 10, 8, 0),
                    child: Row(
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFFF5F0E8),
                            image: fullAvatarUrl != null
                                ? DecorationImage(
                                    image: NetworkImage(fullAvatarUrl),
                                    fit: BoxFit.cover,
                                  )
                                : null,
                          ),
                          child: fullAvatarUrl == null
                              ? Center(
                                  child: Text(
                                    group.username.isNotEmpty
                                        ? group.username[0].toUpperCase()
                                        : '?',
                                    style: const TextStyle(
                                      color: Color(0xFF1A1A1A),
                                      fontWeight: FontWeight.w800,
                                      fontSize: 14,
                                    ),
                                  ),
                                )
                              : null,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                children: [
                                  Flexible(
                                    child: Text(
                                      group.username,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 14,
                                      ),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    _timeAgo(story.createdAt),
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 12,
                                    ),
                                  ),
                                ],
                              ),
                              if (story.song.trim().isNotEmpty)
                                Text(
                                  story.song,
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 11,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                            ],
                          ),
                        ),
                        if (_isOwner)
                          IconButton(
                            icon: const Icon(Icons.more_vert, color: Colors.white, size: 20),
                            onPressed: () => _showOptions(context),
                          )
                        else
                          IconButton(
                            icon: const Icon(Icons.close, color: Colors.white, size: 22),
                            onPressed: () => Navigator.of(context).pop(),
                          ),
                      ],
                    ),
                  ),
                  const Spacer(),
                  if (_isOwner)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: GestureDetector(
                          onTap: () => _showViewersSheet(context),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 6,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.black45,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.remove_red_eye_outlined,
                                  color: Colors.white,
                                  size: 18,
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  '${story.viewersCount}',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (story.caption.trim().isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                      child: Text(
                        story.caption,
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                        textAlign: TextAlign.center,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showOptions(BuildContext context) {
    _pause();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF161616),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (context) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.delete_outline, color: Colors.redAccent),
                title: const Text('Hapus Story', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pop(context);
                  _deleteCurrentStory();
                },
              ),
              ListTile(
                leading: const Icon(Icons.close, color: Colors.white70),
                title: const Text('Batal', style: TextStyle(color: Colors.white70)),
                onTap: () {
                  Navigator.pop(context);
                  _resume();
                },
              ),
            ],
          ),
        );
      },
    ).then((_) => _resume());
  }
}

// ═══════════════════════════════════════════════════════════════
// DAFTAR PENONTON STORY (bottom sheet, khusus pemilik story)
// ═══════════════════════════════════════════════════════════════

class _StoryViewer {
  final String username;
  final String? avatarUrl;
  final DateTime viewedAt;

  _StoryViewer({
    required this.username,
    required this.avatarUrl,
    required this.viewedAt,
  });

  factory _StoryViewer.fromJson(Map<String, dynamic> json) {
    return _StoryViewer(
      username: (json['username'] ?? '').toString(),
      avatarUrl: json['avatarUrl']?.toString(),
      viewedAt: DateTime.fromMillisecondsSinceEpoch(
          int.tryParse(json['viewedAt'].toString()) ?? 0),
    );
  }
}

class _ViewersSheet extends StatefulWidget {
  final String apiBaseUrl;
  final String sessionKey;
  final String storyId;

  const _ViewersSheet({
    required this.apiBaseUrl,
    required this.sessionKey,
    required this.storyId,
  });

  @override
  State<_ViewersSheet> createState() => _ViewersSheetState();
}

class _ViewersSheetState extends State<_ViewersSheet> {
  List<_StoryViewer> viewers = [];
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchViewers();
  }

  Future<void> _fetchViewers() async {
    try {
      final response = await http.get(
        Uri.parse(
          '${widget.apiBaseUrl}/api/story/viewers?key=${widget.sessionKey}&id=${widget.storyId}',
        ),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            viewers = ((data['viewers'] ?? []) as List)
                .map((e) => _StoryViewer.fromJson(e))
                .toList();
            isLoading = false;
          });
          return;
        } else {
          setState(() {
            errorMessage = data['message']?.toString() ?? 'Gagal memuat daftar penonton';
            isLoading = false;
          });
          return;
        }
      }
      setState(() {
        errorMessage = 'Gagal memuat daftar penonton';
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = 'Gagal memuat daftar penonton';
        isLoading = false;
      });
    }
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inDays >= 1) return '${diff.inDays} hari lalu';
    if (diff.inHours >= 1) return '${diff.inHours} jam lalu';
    if (diff.inMinutes >= 1) return '${diff.inMinutes} menit lalu';
    return 'Baru saja';
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.6,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Row(
                children: [
                  const Icon(Icons.remove_red_eye_outlined, color: Colors.white, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'Dilihat oleh ${viewers.length} orang',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
            const Divider(color: Color(0xFF2A2A2A), height: 1),
            Flexible(
              child: isLoading
                  ? const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(
                        child: CircularProgressIndicator(color: Color(0xFF7C3AED)),
                      ),
                    )
                  : errorMessage != null
                      ? Padding(
                          padding: const EdgeInsets.all(24),
                          child: Center(
                            child: Text(
                              errorMessage!,
                              style: const TextStyle(color: Colors.white70),
                            ),
                          ),
                        )
                      : viewers.isEmpty
                          ? const Padding(
                              padding: EdgeInsets.all(24),
                              child: Center(
                                child: Text(
                                  'Belum ada yang melihat story ini',
                                  style: TextStyle(color: Colors.white70),
                                ),
                              ),
                            )
                          : ListView.builder(
                              shrinkWrap: true,
                              padding: const EdgeInsets.symmetric(vertical: 4),
                              itemCount: viewers.length,
                              itemBuilder: (context, index) {
                                final v = viewers[index];
                                final fullAvatarUrl = v.avatarUrl != null
                                    ? '${widget.apiBaseUrl}${v.avatarUrl}'
                                    : null;
                                return ListTile(
                                  leading: Container(
                                    width: 38,
                                    height: 38,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: const Color(0xFFF5F0E8),
                                      image: fullAvatarUrl != null
                                          ? DecorationImage(
                                              image: NetworkImage(fullAvatarUrl),
                                              fit: BoxFit.cover,
                                            )
                                          : null,
                                    ),
                                    child: fullAvatarUrl == null
                                        ? Center(
                                            child: Text(
                                              v.username.isNotEmpty
                                                  ? v.username[0].toUpperCase()
                                                  : '?',
                                              style: const TextStyle(
                                                color: Color(0xFF1A1A1A),
                                                fontWeight: FontWeight.w800,
                                                fontSize: 14,
                                              ),
                                            ),
                                          )
                                        : null,
                                  ),
                                  title: Text(
                                    v.username,
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w600,
                                      fontSize: 14,
                                    ),
                                  ),
                                  trailing: Text(
                                    _timeAgo(v.viewedAt),
                                    style: const TextStyle(
                                      color: Colors.white54,
                                      fontSize: 12,
                                    ),
                                  ),
                                );
                              },
                            ),
            ),
          ],
        ),
      ),
    );
  }
}
