// chat.dart
// ============================================================
//  Enhanced Public Chat dengan fitur:
//   1. Group Profile (viewable - info grup + daftar member)
//   2. Private Chat antar user (1-on-1)
//   3. User Profile (edit foto profil + nama)
//   4. Tema hitam dengan chat bubble clear natural (glassmorphism)
//   5. Text Reaction (long press → pilih emoji)
// ============================================================
//
//  DEPENDENCY YANG DIBUTUHKAN DI pubspec.yaml:
//  --------------------------------------------
//  dependencies:
//    flutter:
//      sdk: flutter
//    http: ^1.2.0
//    shared_preferences: ^2.2.0
//    intl: ^0.19.0
//    image_picker: ^1.0.7     # <-- TAMBAHKAN untuk upload foto profil
//
//  ENDPOINT API YANG DIPAKAI (sesuaikan dengan backend Anda):
//  ----------------------------------------------------------
//  GET  $apiBaseUrl/publicChat?key=...                 -> ambil pesan grup
//  POST $apiBaseUrl/publicChat                          -> kirim pesan grup
//  GET  $apiBaseUrl/groupProfile?key=...                -> info grup + member
//  GET  $apiBaseUrl/userProfile?username=...            -> profil user
//  POST $apiBaseUrl/userProfile                         -> update profil (nama/foto)
//  GET  $apiBaseUrl/privateChat?user1=...&user2=...     -> pesan private
//  POST $apiBaseUrl/privateChat                         -> kirim pesan private
//  POST $apiBaseUrl/reactMessage                        -> beri reaction
//  GET  $apiBaseUrl/privateChatList?username=...        -> list private chat
// ============================================================

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'color_theme.dart';
import 'package:flutter/rendering.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:image_picker/image_picker.dart';
import 'config.dart'; // file yang berisi `apiBaseUrl`

// ============================================================
//  WARNA TEMA HITAM — Black + Clear Natural Glass Bubbles
// ============================================================
class AppColors {
  static Color bgBlack = Color(0xFF000000); // pure black
  static Color bgDark = Color(0xFF050507); // near black
  static Color bgElevated = Color(0xFF0F0F14);

  // Glassmorphism — clear natural bubble
  static Color bubbleOwn = Color(0x1FFFFFFF); // white 12%
  static Color bubbleOther = Color(0x0FFFFFFF); // white 6%
  static Color surfaceGlass = Color(0x14FFFFFF); // white 8%
  static Color surfaceGlassStrong = Color(0x1FFFFFFF); // white 12%
  static Color get borderGlass => AppThemeController.instance.borderGlass; // white 12%
  static Color borderGlassStrong = Color(0x33FFFFFF); // white 20%

  // Aksen
  static Color get primaryPurple => AppThemeController.instance.primaryPurple;
  static Color get accentPurple => AppThemeController.instance.accentPurple;
  static Color get lightPurple => AppThemeController.instance.lightPurple;
  static Color get glowMagenta => AppThemeController.instance.glowMagenta;

  // Status
  static Color online = Color(0xFF22C55E);
  static Color offline = Color(0xFF6B7280);

  // Role
  static Color roleOwner = Color(0xFFF59E0B);
  static Color get roleVip => AppThemeController.instance.primaryPurple;
  static Color roleReseller = Color(0xFFA3E635);
  static Color rolePremium = Color(0xFFFB923C);
}

// ============================================================
//  HELPER
// ============================================================
Color getRoleColor(String? role) {
  switch ((role ?? '').toLowerCase()) {
    case 'owner':
      return AppColors.roleOwner;
    case 'vip':
      return AppColors.roleVip;
    case 'reseller':
      return AppColors.roleReseller;
    case 'premium':
      return AppColors.rolePremium;
    default:
      return AppColors.accentPurple;
  }
}

String formatTime(String isoString) {
  try {
    final date = DateTime.parse(isoString);
    return DateFormat('HH:mm').format(date);
  } catch (_) {
    return '';
  }
}

String formatDate(String isoString) {
  try {
    final date = DateTime.parse(isoString);
    return DateFormat('dd MMM yyyy, HH:mm').format(date);
  } catch (_) {
    return '';
  }
}

String initialOf(String? name) {
  if (name == null || name.isEmpty) return '?';
  return name.trim().substring(0, 1).toUpperCase();
}

// Avatar dengan fallback initial
Widget buildAvatar({
  String? photoUrl,
  String? name,
  double radius = 20,
  Color? ringColor,
}) {
  final child = (photoUrl != null && photoUrl.isNotEmpty)
      ? ClipOval(
          child: Image.network(
            photoUrl,
            width: radius * 2,
            height: radius * 2,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _initialBubble(name, radius),
          ),
        )
      : _initialBubble(name, radius);

  return Container(
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      border: ringColor != null
          ? Border.all(color: ringColor, width: 2)
          : null,
    ),
    child: child,
  );
}

Widget _initialBubble(String? name, double radius) {
  return Container(
    width: radius * 2,
    height: radius * 2,
    decoration: BoxDecoration(
      shape: BoxShape.circle,
      gradient: LinearGradient(
        colors: [AppColors.primaryPurple, AppColors.glowMagenta],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
    alignment: Alignment.center,
    child: Text(
      initialOf(name),
      style: TextStyle(
        color: Colors.white,
        fontSize: radius * 0.9,
        fontWeight: FontWeight.bold,
      ),
    ),
  );
}

// ============================================================
//  REACTION PICKER DIALOG
// ============================================================
List<String> kReactions = [
  '👍', '❤️', '😂', '😮', '😢', '🔥', '🎉', '🙏', '👏', '💯'
];

/// Menampilkan bottom sheet picker reaction
Future<String?> showReactionPicker(BuildContext context) {
  return showModalBottomSheet<String>(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (ctx) {
      return Container(
        margin: EdgeInsets.all(12),
        padding: EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: AppColors.bgElevated,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: AppColors.borderGlass),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Pick a reaction',
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 12),
            GridView.count(
              crossAxisCount: 5,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 1,
              children: kReactions.map((e) {
                return InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () => Navigator.pop(ctx, e),
                  child: Center(
                    child: Text(e, style: const TextStyle(fontSize: 28)),
                  ),
                );
              }).toList(),
            ),
          ],
        ),
      );
    },
  );
}

// ============================================================
//  REACTION BUILDER (bubble kecil di bawah pesan)
// ============================================================
Widget buildReactionChips(
  Map<String, dynamic> message,
  String currentUsername, {
  required Future<void> Function(String emoji) onReact,
}) {
  final reactions = message['reactions'];
  if (reactions == null || reactions is! List || reactions.isEmpty) {
    return const SizedBox.shrink();
  }

  // Group by emoji
  final Map<String, List<String>> grouped = {};
  for (final r in reactions) {
    final emoji = r['emoji'] as String?;
    final user = r['username'] as String?;
    if (emoji == null || user == null) continue;
    grouped.putIfAbsent(emoji, () => []).add(user);
  }
  if (grouped.isEmpty) return SizedBox.shrink();

  return Padding(
    padding: EdgeInsets.only(top: 4, left: 4),
    child: Wrap(
      spacing: 4,
      runSpacing: 4,
      children: grouped.entries.map((entry) {
        final emoji = entry.key;
        final users = entry.value;
        final reactedByMe = users.contains(currentUsername);
        return GestureDetector(
          onTap: () => onReact(emoji),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 6, vertical: 3),
            decoration: BoxDecoration(
              color: reactedByMe
                  ? AppColors.primaryPurple.withOpacity(0.25)
                  : Colors.white.withOpacity(0.06),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: reactedByMe
                    ? AppColors.primaryPurple.withOpacity(0.5)
                    : Colors.white.withOpacity(0.1),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(emoji, style: TextStyle(fontSize: 12)),
                SizedBox(width: 4),
                Text(
                  '${users.length}',
                  style: TextStyle(
                    color: reactedByMe ? AppColors.accentPurple : Colors.white70,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        );
      }).toList(),
    ),
  );
}

// ============================================================
//  MESSAGE BUBBLE — Clear Natural Glass (shared widget)
// ============================================================
class ChatBubble extends StatelessWidget {
  final Map<String, dynamic> message;
  final bool isOwn;
  final String currentUsername;
  final List<Map<String, dynamic>> allMessages;
  final Future<void> Function(String emoji) onReact;
  final VoidCallback? onReply;
  final VoidCallback? onTapUser;
  final VoidCallback? onLongPressUser;

  ChatBubble({
    super.key,
    required this.message,
    required this.isOwn,
    required this.currentUsername,
    required this.allMessages,
    required this.onReact,
    this.onReply,
    this.onTapUser,
    this.onLongPressUser,
  });

  Map<String, dynamic>? get _repliedMessage {
    final replyId = message['replyTo'];
    if (replyId == null) return null;
    try {
      return allMessages.firstWhere((m) => m['id'] == replyId);
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final replied = _repliedMessage;
    final username = message['username'] ?? 'Unknown';
    final role = message['role'] ?? 'member';
    final photoUrl = message['photoUrl'] as String?;
    final reactions = message['reactions'] as List?;

    return Container(
      margin: EdgeInsets.only(
        left: isOwn ? 64 : 8,
        right: isOwn ? 8 : 64,
        top: 6,
        bottom: reactions != null && reactions.isNotEmpty ? 2 : 6,
      ),
      child: Column(
        crossAxisAlignment:
            isOwn ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          // Reply preview
          if (replied != null)
            Container(
              margin: EdgeInsets.only(bottom: 4, left: 4, right: 4),
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.primaryPurple.withOpacity(0.12),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(10),
                  topRight: Radius.circular(10),
                ),
                border: Border(
                  left: BorderSide(color: AppColors.accentPurple, width: 2),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '@${replied['username'] ?? 'Unknown'}',
                    style: TextStyle(
                      color: AppColors.accentPurple,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    replied['message'] ?? '',
                    style: const TextStyle(color: Colors.white54, fontSize: 11),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),

          // Bubble
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment:
                isOwn ? MainAxisAlignment.end : MainAxisAlignment.start,
            children: [
              if (!isOwn) ...[
                GestureDetector(
                  onTap: onLongPressUser,
                  child: buildAvatar(
                    photoUrl: photoUrl,
                    name: username,
                    radius: 14,
                  ),
                ),
                const SizedBox(width: 6),
              ],
              Flexible(
                child: GestureDetector(
                  onLongPress: () async {
                    final emoji = await showReactionPicker(context);
                    if (emoji != null) {
                      await onReact(emoji);
                    }
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: isOwn
                          ? AppColors.bubbleOwn
                          : AppColors.bubbleOther,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(18),
                        topRight: const Radius.circular(18),
                        bottomLeft: isOwn
                            ? const Radius.circular(18)
                            : const Radius.circular(4),
                        bottomRight: isOwn
                            ? const Radius.circular(4)
                            : const Radius.circular(18),
                      ),
                      border: Border.all(
                        color: Colors.white.withOpacity(
                            isOwn ? 0.12 : 0.06),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (!isOwn)
                          GestureDetector(
                            onTap: onTapUser,
                            onLongPress: onLongPressUser,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  username,
                                  style: TextStyle(
                                    color: getRoleColor(role),
                                    fontSize: 12,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 5, vertical: 1),
                                  decoration: BoxDecoration(
                                    color:
                                        getRoleColor(role).withOpacity(0.18),
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    role.toString().toUpperCase(),
                                    style: TextStyle(
                                      color: getRoleColor(role),
                                      fontSize: 8,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.4,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        if (!isOwn) const SizedBox(height: 4),
                        SelectableText(
                          message['message'] ?? '',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            height: 1.35,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (isOwn)
                              Icon(
                                Icons.done_all,
                                size: 12,
                                color: Colors.white.withOpacity(0.4),
                              ),
                            if (isOwn) const SizedBox(width: 4),
                            Text(
                              formatTime(message['timestamp'] ?? ''),
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.4),
                                fontSize: 9,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),

          // Reaction chips
          buildReactionChips(message, currentUsername, onReact: onReact),
        ],
      ),
    );
  }
}

// ============================================================
//  PUBLIC CHAT PAGE (Main — Enhanced)
// ============================================================
class PublicChatPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  PublicChatPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<Map<String, dynamic>> _messages = [];
  Map<String, dynamic>? _groupInfo;
  bool _isLoading = true;
  bool _isSending = false;
  String? _lastMessageId;
  Timer? _pollingTimer;

  // Reply state
  Map<String, dynamic>? _replyTo;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _fadeController = AnimationController(
      duration: Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _fadeController.forward();

    _loadMessages();
    _loadGroupInfo();
    _pollingTimer =
        Timer.periodic(Duration(seconds: 3), (_) => _pollNewMessages());
  }

  @override

  void _onThemeChanged() => mounted ? setState(() {}) : null;
  void dispose() {
    _fadeController.dispose();
    _pollingTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  // ---------- API ----------
  Future<void> _loadMessages() async {
    setState(() => _isLoading = true);
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/publicChat?key=${widget.sessionKey}'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _messages =
                List<Map<String, dynamic>>.from(data['messages'] ?? []);
            if (_messages.isNotEmpty) {
              _lastMessageId = _messages.last['id']?.toString();
            }
            _isLoading = false;
          });
          _scrollToBottom();
        }
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadGroupInfo() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/groupProfile?key=${widget.sessionKey}'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() => _groupInfo = data['group']);
        }
      }
    } catch (_) {}
  }

  Future<void> _pollNewMessages() async {
    if (_isLoading || _messages.isEmpty) return;
    try {
      final response = await http.get(
        Uri.parse(
          '$apiBaseUrl/publicChat?key=${widget.sessionKey}&lastId=${_lastMessageId ?? ''}',
        ),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['hasNew'] == true) {
          final newMessages =
              List<Map<String, dynamic>>.from(data['messages'] ?? []);
          if (newMessages.isNotEmpty) {
            setState(() {
              _messages.addAll(newMessages);
              _lastMessageId = _messages.last['id']?.toString();
            });
            _scrollToBottom();
          }
        }
      }
    } catch (_) {}
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _isSending) return;
    setState(() => _isSending = true);
    try {
      final body = {
        'key': widget.sessionKey,
        'username': widget.username,
        'message': text,
        if (_replyTo != null) 'replyTo': _replyTo!['id'],
      };
      final response = await http.post(
        Uri.parse('$apiBaseUrl/publicChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _replyTo = null;
            _messageController.clear();
          });
          final newMsg = data['message'] as Map<String, dynamic>;
          setState(() {
            _messages.add(newMsg);
            _lastMessageId = newMsg['id']?.toString();
          });
          _scrollToBottom();
        }
      }
    } catch (_) {} finally {
      setState(() => _isSending = false);
    }
  }

  Future<void> _reactToMessage(Map<String, dynamic> msg, String emoji) async {
    try {
      await http.post(
        Uri.parse('$apiBaseUrl/reactMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'messageId': msg['id'],
          'username': widget.username,
          'emoji': emoji,
          'scope': 'public',
        }),
      );
      // Optimistic update
      setState(() {
        final reactions =
            List<Map<String, dynamic>>.from(msg['reactions'] ?? []);
        final existingIdx = reactions.indexWhere(
            (r) => r['emoji'] == emoji && r['username'] == widget.username);
        if (existingIdx >= 0) {
          reactions.removeAt(existingIdx);
        } else {
          reactions.add({'emoji': emoji, 'username': widget.username});
        }
        msg['reactions'] = reactions;
      });
    } catch (_) {}
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ---------- UI ----------
  void _openGroupProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GroupProfilePage(
          sessionKey: widget.sessionKey,
          groupInfo: _groupInfo,
          currentUsername: widget.username,
        ),
      ),
    ).then((_) => _loadGroupInfo());
  }

  void _openUserProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => UserProfilePage(username: widget.username),
      ),
    );
  }

  void _openOtherUser(String username) {
    if (username == widget.username) {
      _openUserProfile();
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OtherUserProfilePage(
          username: username,
          currentUsername: widget.username,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBlack,
      appBar: AppBar(
        backgroundColor: AppColors.bgBlack,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: GestureDetector(
          onTap: _openGroupProfile,
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [AppColors.primaryPurple, AppColors.glowMagenta],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: const Icon(Icons.group, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _groupInfo?['name'] ?? 'Public Chat',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '${_groupInfo?['memberCount'] ?? _messages.map((m) => m['username']).toSet().length} members',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        actions: [
          IconButton(
            onPressed: _openUserProfile,
            icon: const Icon(Icons.person_outline, color: Colors.white),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            color: AppColors.bgElevated,
            onSelected: (v) {
              switch (v) {
                case 'group':
                  _openGroupProfile();
                  break;
                case 'profile':
                  _openUserProfile();
                  break;
                case 'private':
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          PrivateChatListPage(username: widget.username),
                    ),
                  );
                  break;
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'group',
                child: Row(children: [
                  Icon(Icons.group, color: Colors.white70, size: 18),
                  SizedBox(width: 10),
                  Text('Group Profile',
                      style: TextStyle(color: Colors.white)),
                ]),
              ),
              PopupMenuItem(
                value: 'private',
                child: Row(children: [
                  Icon(Icons.chat_bubble_outline,
                      color: Colors.white70, size: 18),
                  SizedBox(width: 10),
                  Text('Private Messages',
                      style: TextStyle(color: Colors.white)),
                ]),
              ),
              PopupMenuItem(
                value: 'profile',
                child: Row(children: [
                  Icon(Icons.person, color: Colors.white70, size: 18),
                  SizedBox(width: 10),
                  Text('My Profile',
                      style: TextStyle(color: Colors.white)),
                ]),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          if (_replyTo != null) _buildReplyBar(),
          Expanded(
            child: _isLoading
                ? Center(
                    child: CircularProgressIndicator(
                        color: AppColors.primaryPurple),
                  )
                : _messages.isEmpty
                    ? _buildEmptyState()
                    : FadeTransition(
                        opacity: _fadeAnimation,
                        child: ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 16),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final msg = _messages[index];
                            final isOwn =
                                msg['username'] == widget.username;
                            return ChatBubble(
                              message: msg,
                              isOwn: isOwn,
                              currentUsername: widget.username,
                              allMessages: _messages,
                              onReact: (emoji) =>
                                  _reactToMessage(msg, emoji),
                              onReply: () {
                                setState(() => _replyTo = msg);
                              },
                              onTapUser: () =>
                                  _openOtherUser(msg['username']),
                              onLongPressUser: () =>
                                  _openOtherUser(msg['username']),
                            );
                          },
                        ),
                      ),
          ),
          _buildInputBar(),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.chat_bubble_outline,
              color: Colors.white24, size: 64),
          SizedBox(height: 16),
          Text(
            'No messages yet',
            style: TextStyle(
              color: Colors.white38,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Be the first to send a message!',
            style: TextStyle(color: Colors.white24, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildReplyBar() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.primaryPurple.withOpacity(0.08),
        border: Border(
          top: BorderSide(color: AppColors.primaryPurple.withOpacity(0.2)),
        ),
      ),
      child: Row(
        children: [
          Icon(Icons.reply, color: AppColors.accentPurple, size: 16),
          SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Replying to @${_replyTo!['username']}',
                  style: TextStyle(
                    color: AppColors.accentPurple,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  _replyTo!['message'] ?? '',
                  style: TextStyle(color: Colors.white60, fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          IconButton(
            onPressed: () => setState(() => _replyTo = null),
            icon: Icon(Icons.close, color: Colors.white54, size: 18),
            padding: EdgeInsets.zero,
            constraints: BoxConstraints(),
          ),
        ],
      ),
    );
  }

  Widget _buildInputBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: AppColors.bgBlack,
          border: Border(
            top: BorderSide(color: AppColors.borderGlass),
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: AppColors.surfaceGlass,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: AppColors.borderGlass),
                ),
                child: TextField(
                  controller: _messageController,
                  style: const TextStyle(color: Colors.white),
                  decoration: InputDecoration(
                    hintText: _replyTo != null
                        ? 'Reply to @${_replyTo!['username']}...'
                        : 'Type a message...',
                    hintStyle: const TextStyle(
                        color: Colors.white38, fontSize: 14),
                    border: InputBorder.none,
                    suffixIcon: _messageController.text.isNotEmpty
                        ? IconButton(
                            onPressed: () {
                              _messageController.clear();
                              setState(() {});
                            },
                            icon: Icon(Icons.clear,
                                color: Colors.white38, size: 18),
                            padding: EdgeInsets.zero,
                            constraints: BoxConstraints(),
                          )
                        : null,
                  ),
                  onChanged: (_) => setState(() {}),
                  onSubmitted: (_) => _sendMessage(),
                  maxLength: 500,
                  maxLines: null,
                  textCapitalization: TextCapitalization.sentences,
                ),
              ),
            ),
            SizedBox(width: 8),
            GestureDetector(
              onTap: _isSending ? null : _sendMessage,
              child: AnimatedContainer(
                duration: Duration(milliseconds: 200),
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: (_messageController.text.isNotEmpty || _isSending)
                      ? LinearGradient(
                          colors: [
                            AppColors.primaryPurple,
                            AppColors.glowMagenta
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        )
                      : LinearGradient(
                          colors: [
                            Colors.grey.shade900,
                            Colors.grey.shade800
                          ],
                        ),
                ),
                child: _isSending
                    ? SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white),
                      )
                    : Icon(
                        _replyTo != null ? Icons.reply : Icons.send,
                        color: _messageController.text.isNotEmpty
                            ? Colors.white
                            : Colors.white38,
                        size: 20,
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
//  GROUP PROFILE PAGE
// ============================================================
class GroupProfilePage extends StatefulWidget {
  final String sessionKey;
  final Map<String, dynamic>? groupInfo;
  final String currentUsername;

  GroupProfilePage({
    super.key,
    required this.sessionKey,
    required this.currentUsername,
    this.groupInfo,
  });

  @override
  State<GroupProfilePage> createState() => _GroupProfilePageState();
}

class _GroupProfilePageState extends State<GroupProfilePage> {
  Map<String, dynamic>? _group;
  List<Map<String, dynamic>> _members = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _group = widget.groupInfo;
    _loadGroupProfile();
  }
  void _onThemeChanged() => mounted ? setState(() {}) : null;


  Future<void> _loadGroupProfile() async {
    setState(() => _isLoading = true);
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/groupProfile?key=${widget.sessionKey}'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _group = data['group'];
            _members =
                List<Map<String, dynamic>>.from(data['members'] ?? []);
            _isLoading = false;
          });
        }
      }
    } catch (_) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBlack,
      appBar: AppBar(
        backgroundColor: AppColors.bgBlack,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Group Info',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: _isLoading
          ? Center(
              child:
                  CircularProgressIndicator(color: AppColors.primaryPurple))
          : RefreshIndicator(
              color: AppColors.primaryPurple,
              onRefresh: _loadGroupProfile,
              child: ListView(
                padding: EdgeInsets.all(16),
                children: [
                  // Header group
                  Center(
                    child: Column(
                      children: [
                        Container(
                          width: 96,
                          height: 96,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: LinearGradient(
                              colors: [
                                AppColors.primaryPurple,
                                AppColors.glowMagenta
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primaryPurple
                                    .withOpacity(0.4),
                                blurRadius: 24,
                                spreadRadius: 4,
                              ),
                            ],
                          ),
                          child: const Icon(Icons.group,
                              color: Colors.white, size: 40),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _group?['name'] ?? 'Public Chat',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          _group?['description'] ??
                              'Group chat untuk semua member',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.6),
                            fontSize: 13,
                          ),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _infoChip(
                              icon: Icons.people,
                              label:
                                  '${_group?['memberCount'] ?? _members.length}',
                              sublabel: 'Members',
                            ),
                            SizedBox(width: 12),
                            _infoChip(
                              icon: Icons.tag,
                              label:
                                  _group?['code'] ?? widget.sessionKey,
                              sublabel: 'Code',
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 24),
                  // Members
                  Container(
                    padding: EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceGlass,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.borderGlass),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Text(
                              'Members',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Spacer(),
                            Text(
                              '${_members.length}',
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.5),
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 12),
                        ..._members.map((m) {
                          final isMe = m['username'] == widget.currentUsername;
                          return _memberTile(m, isMe);
                        }),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _infoChip({
    required IconData icon,
    required String label,
    required String sublabel,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surfaceGlass,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderGlass),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: AppColors.accentPurple, size: 16),
          const SizedBox(width: 6),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                sublabel,
                style: TextStyle(
                    color: Colors.white.withOpacity(0.5), fontSize: 10),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _memberTile(Map<String, dynamic> m, bool isMe) {
    final username = m['username'] ?? 'Unknown';
    final role = m['role'] ?? 'member';
    final photoUrl = m['photoUrl'] as String?;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 4),
      leading: buildAvatar(
        photoUrl: photoUrl,
        name: username,
        radius: 22,
        ringColor: isMe ? AppColors.online : null,
      ),
      title: Row(
        children: [
          Text(
            username + (isMe ? ' (You)' : ''),
            style: const TextStyle(
                color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
          ),
          const SizedBox(width: 6),
          if (role.toString().toLowerCase() == 'owner')
            Icon(Icons.star, color: AppColors.roleOwner, size: 12),
        ],
      ),
      subtitle: Text(
        role.toString().toUpperCase(),
        style: TextStyle(
          color: getRoleColor(role),
          fontSize: 10,
          fontWeight: FontWeight.w600,
        ),
      ),
      trailing: isMe
          ? null
          : IconButton(
              icon: const Icon(Icons.chat_bubble_outline,
                  color: Colors.white54, size: 18),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PrivateChatPage(
                      currentUsername: widget.currentUsername,
                      otherUsername: username,
                      otherPhotoUrl: photoUrl,
                    ),
                  ),
                );
              },
            ),
      onTap: () {
        if (!isMe) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => OtherUserProfilePage(
                username: username,
                currentUsername: widget.currentUsername,
              ),
            ),
          );
        }
      },
    );
  }
}

// ============================================================
//  USER PROFILE PAGE (Edit profil sendiri)
// ============================================================
class UserProfilePage extends StatefulWidget {
  final String username;

  UserProfilePage({super.key, required this.username});

  @override
  State<UserProfilePage> createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  final _nameController = TextEditingController();
  final _bioController = TextEditingController();
  String? _photoUrl;
  File? _pickedImage;
  bool _isLoading = true;
  bool _isSaving = false;
  String? _role;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _loadProfile();
  }
  void _onThemeChanged() => mounted ? setState(() {}) : null;


  Future<void> _loadProfile() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/userProfile?username=${widget.username}'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final user = data['user'] ?? {};
          setState(() {
            _nameController.text = user['name'] ?? user['username'] ?? '';
            _bioController.text = user['bio'] ?? '';
            _photoUrl = user['photoUrl'];
            _role = user['role'];
            _isLoading = false;
          });
        }
      }
    } catch (_) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _pickImage() async {
    try {
      final picker = ImagePicker();
      final picked =
          await picker.pickImage(source: ImageSource.gallery, imageQuality: 75);
      if (picked != null) {
        setState(() => _pickedImage = File(picked.path));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal memilih foto: $e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }

  Future<void> _saveProfile() async {
    if (_nameController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Nama tidak boleh kosong'),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }
    setState(() => _isSaving = true);
    try {
      // Catatan: jika backend mendukung multipart upload, kirim file di sini.
      // Untuk demo, kirim sebagai base64 string jika ada gambar.
      String? base64Photo;
      if (_pickedImage != null) {
        final bytes = await _pickedImage!.readAsBytes();
        base64Photo = base64Encode(bytes);
      }

      final response = await http.post(
        Uri.parse('$apiBaseUrl/userProfile'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'username': widget.username,
          'name': _nameController.text.trim(),
          'bio': _bioController.text.trim(),
          if (base64Photo != null) 'photoBase64': base64Photo,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _photoUrl = data['photoUrl'] ?? _photoUrl;
            _pickedImage = null;
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Profil berhasil disimpan'),
              backgroundColor: AppColors.online,
            ),
          );
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    } finally {
      setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBlack,
      appBar: AppBar(
        backgroundColor: AppColors.bgBlack,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'My Profile',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _saveProfile,
            child: _isSaving
                ? SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white),
                  )
                : Text(
                    'Save',
                    style: TextStyle(
                        color: AppColors.accentPurple,
                        fontWeight: FontWeight.bold),
                  ),
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child:
                  CircularProgressIndicator(color: AppColors.primaryPurple))
          : ListView(
              padding: EdgeInsets.all(24),
              children: [
                // Photo
                Center(
                  child: GestureDetector(
                    onTap: _pickImage,
                    child: Stack(
                      children: [
                        _pickedImage != null
                            ? ClipOval(
                                child: Image.file(
                                  _pickedImage!,
                                  width: 110,
                                  height: 110,
                                  fit: BoxFit.cover,
                                ),
                              )
                            : buildAvatar(
                                photoUrl: _photoUrl,
                                name: _nameController.text,
                                radius: 55,
                                ringColor: AppColors.primaryPurple,
                              ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: Container(
                            padding: EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: AppColors.primaryPurple,
                              shape: BoxShape.circle,
                              border: Border.all(
                                  color: AppColors.bgBlack, width: 2),
                            ),
                            child: Icon(Icons.camera_alt,
                                color: Colors.white, size: 16),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 8),
                Center(
                  child: Text(
                    'Tap foto untuk mengganti',
                    style: TextStyle(
                        color: Colors.white.withOpacity(0.5), fontSize: 11),
                  ),
                ),
                SizedBox(height: 32),

                // Username (read-only)
                _label('Username'),
                Container(
                  padding: EdgeInsets.symmetric(
                      horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: AppColors.surfaceGlass,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderGlass),
                  ),
                  child: Text(
                    widget.username,
                    style: const TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ),
                if (_role != null) ...[
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: getRoleColor(_role).withOpacity(0.18),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      _role!.toUpperCase(),
                      style: TextStyle(
                        color: getRoleColor(_role),
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 20),

                // Display Name
                _label('Display Name'),
                TextField(
                  controller: _nameController,
                  style: TextStyle(color: Colors.white),
                  decoration: _inputDecoration('Masukkan nama tampilan'),
                  textCapitalization: TextCapitalization.words,
                ),
                SizedBox(height: 20),

                // Bio
                _label('Bio'),
                TextField(
                  controller: _bioController,
                  style: TextStyle(color: Colors.white),
                  decoration: _inputDecoration('Tulis bio singkat...'),
                  maxLines: 3,
                  maxLength: 150,
                ),
              ],
            ),
    );
  }

  Widget _label(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Text(
        text,
        style: TextStyle(
          color: Colors.white.withOpacity(0.6),
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.white30, fontSize: 13),
      filled: true,
      fillColor: AppColors.surfaceGlass,
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: AppColors.borderGlass),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: AppColors.primaryPurple, width: 1.5),
      ),
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    );
  }
}

// ============================================================
//  OTHER USER PROFILE PAGE (view-only + tombol Private Chat)
// ============================================================
class OtherUserProfilePage extends StatefulWidget {
  final String username;
  final String currentUsername;

  OtherUserProfilePage({
    super.key,
    required this.username,
    required this.currentUsername,
  });

  @override
  State<OtherUserProfilePage> createState() => _OtherUserProfilePageState();
}

class _OtherUserProfilePageState extends State<OtherUserProfilePage> {
  Map<String, dynamic>? _user;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _loadProfile();
  }
  void _onThemeChanged() => mounted ? setState(() {}) : null;


  Future<void> _loadProfile() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/userProfile?username=${widget.username}'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _user = data['user'] ?? {};
            _isLoading = false;
          });
        }
      }
    } catch (_) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBlack,
      appBar: AppBar(
        backgroundColor: AppColors.bgBlack,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Profile',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: _isLoading
          ? Center(
              child:
                  CircularProgressIndicator(color: AppColors.primaryPurple))
          : Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    buildAvatar(
                      photoUrl: _user?['photoUrl'],
                      name: _user?['name'] ?? widget.username,
                      radius: 60,
                      ringColor: AppColors.primaryPurple,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      _user?['name'] ?? widget.username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '@${widget.username}',
                      style: TextStyle(
                          color: Colors.white.withOpacity(0.5), fontSize: 13),
                    ),
                    const SizedBox(height: 12),
                    if (_user?['role'] != null)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: getRoleColor(_user!['role'])
                              .withOpacity(0.18),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          _user!['role'].toString().toUpperCase(),
                          style: TextStyle(
                            color: getRoleColor(_user!['role']),
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    if (_user?['bio'] != null &&
                        (_user!['bio'] as String).isNotEmpty) ...[
                      SizedBox(height: 16),
                      Text(
                        _user!['bio'],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                            fontSize: 13,
                            height: 1.5),
                      ),
                    ],
                    SizedBox(height: 32),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (_) => PrivateChatPage(
                                currentUsername: widget.currentUsername,
                                otherUsername: widget.username,
                                otherPhotoUrl: _user?['photoUrl'],
                              ),
                            ),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryPurple,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        icon: Icon(Icons.chat_bubble, size: 18),
                        label: Text(
                          'Private Message',
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

// ============================================================
//  PRIVATE CHAT LIST PAGE (daftar private chat user)
// ============================================================
class PrivateChatListPage extends StatefulWidget {
  final String username;

  PrivateChatListPage({super.key, required this.username});

  @override
  State<PrivateChatListPage> createState() => _PrivateChatListPageState();
}

class _PrivateChatListPageState extends State<PrivateChatListPage> {
  List<Map<String, dynamic>> _chats = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _loadChats();
  }
  void _onThemeChanged() => mounted ? setState(() {}) : null;


  Future<void> _loadChats() async {
    try {
      final response = await http.get(
        Uri.parse(
            '$apiBaseUrl/privateChatList?username=${widget.username}'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _chats =
                List<Map<String, dynamic>>.from(data['chats'] ?? []);
            _isLoading = false;
          });
          return;
        }
      }
    } catch (_) {}
    setState(() => _isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBlack,
      appBar: AppBar(
        backgroundColor: AppColors.bgBlack,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Private Messages',
          style: TextStyle(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: _isLoading
          ? Center(
              child:
                  CircularProgressIndicator(color: AppColors.primaryPurple))
          : _chats.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.mail_outline,
                          color: Colors.white24, size: 64),
                      SizedBox(height: 16),
                      Text(
                        'Belum ada private chat',
                        style: TextStyle(
                            color: Colors.white38, fontSize: 14),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Buka profil user untuk mulai chat private',
                        style: TextStyle(
                            color: Colors.white24, fontSize: 12),
                      ),
                    ],
                  ),
                )
              : ListView.separated(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  itemCount: _chats.length,
                  separatorBuilder: (_, __) => Divider(
                    color: AppColors.borderGlass,
                    height: 1,
                    indent: 72,
                  ),
                  itemBuilder: (context, index) {
                    final chat = _chats[index];
                    final other = chat['otherUsername'] ?? 'Unknown';
                    final lastMsg = chat['lastMessage'] ?? '';
                    final time = chat['timestamp'] ?? '';
                    final unread = chat['unread'] ?? 0;
                    return ListTile(
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 6),
                      leading: buildAvatar(
                        photoUrl: chat['photoUrl'],
                        name: other,
                        radius: 24,
                      ),
                      title: Text(
                        other,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 14,
                        ),
                      ),
                      subtitle: Text(
                        lastMsg,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: Colors.white.withOpacity(0.5),
                            fontSize: 12),
                      ),
                      trailing: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            formatTime(time),
                            style: TextStyle(
                                color: Colors.white.withOpacity(0.4),
                                fontSize: 10),
                          ),
                          if (unread > 0) ...[
                            SizedBox(height: 4),
                            Container(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: AppColors.primaryPurple,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                '$unread',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => PrivateChatPage(
                              currentUsername: widget.username,
                              otherUsername: other,
                              otherPhotoUrl: chat['photoUrl'],
                            ),
                          ),
                        ).then((_) => _loadChats());
                      },
                    );
                  },
                ),
    );
  }
}

// ============================================================
//  PRIVATE CHAT PAGE (1-on-1)
// ============================================================
class PrivateChatPage extends StatefulWidget {
  final String currentUsername;
  final String otherUsername;
  final String? otherPhotoUrl;

  PrivateChatPage({
    super.key,
    required this.currentUsername,
    required this.otherUsername,
    this.otherPhotoUrl,
  });

  @override
  State<PrivateChatPage> createState() => _PrivateChatPageState();
}

class _PrivateChatPageState extends State<PrivateChatPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<Map<String, dynamic>> _messages = [];
  Map<String, dynamic>? _otherUser;
  bool _isLoading = true;
  bool _isSending = false;
  String? _lastMessageId;
  Timer? _pollingTimer;

  String get _pairKey {
    final a = widget.currentUsername;
    final b = widget.otherUsername;
    final sorted = [a, b]..sort();
    return '${sorted[0]}__${sorted[1]}';
  }

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _fadeController = AnimationController(
      duration: Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnimation =
        CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _fadeController.forward();

    _loadMessages();
    _loadOtherProfile();
    _pollingTimer =
        Timer.periodic(Duration(seconds: 3), (_) => _pollNewMessages());
  }

  @override

  void _onThemeChanged() => mounted ? setState(() {}) : null;
  void dispose() {
    _fadeController.dispose();
    _pollingTimer?.cancel();
    _messageController.dispose();
    _scrollController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  Future<void> _loadMessages() async {
    setState(() => _isLoading = true);
    try {
      final response = await http.get(
        Uri.parse(
          '$apiBaseUrl/privateChat?pairKey=$_pairKey&user=${widget.currentUsername}',
        ),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _messages =
                List<Map<String, dynamic>>.from(data['messages'] ?? []);
            if (_messages.isNotEmpty) {
              _lastMessageId = _messages.last['id']?.toString();
            }
            _isLoading = false;
          });
          _scrollToBottom();
        }
      }
    } catch (_) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _loadOtherProfile() async {
    try {
      final response = await http.get(
        Uri.parse(
            '$apiBaseUrl/userProfile?username=${widget.otherUsername}'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() => _otherUser = data['user']);
        }
      }
    } catch (_) {}
  }

  Future<void> _pollNewMessages() async {
    if (_isLoading || _messages.isEmpty) return;
    try {
      final response = await http.get(
        Uri.parse(
          '$apiBaseUrl/privateChat?pairKey=$_pairKey&user=${widget.currentUsername}&lastId=${_lastMessageId ?? ''}',
        ),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['hasNew'] == true) {
          final newMessages =
              List<Map<String, dynamic>>.from(data['messages'] ?? []);
          if (newMessages.isNotEmpty) {
            setState(() {
              _messages.addAll(newMessages);
              _lastMessageId = _messages.last['id']?.toString();
            });
            _scrollToBottom();
          }
        }
      }
    } catch (_) {}
  }

  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty || _isSending) return;
    setState(() => _isSending = true);
    try {
      final response = await http.post(
        Uri.parse('$apiBaseUrl/privateChat'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'pairKey': _pairKey,
          'from': widget.currentUsername,
          'to': widget.otherUsername,
          'message': text,
        }),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() => _messageController.clear());
          final newMsg = data['message'] as Map<String, dynamic>;
          setState(() {
            _messages.add(newMsg);
            _lastMessageId = newMsg['id']?.toString();
          });
          _scrollToBottom();
        }
      }
    } catch (_) {} finally {
      setState(() => _isSending = false);
    }
  }

  Future<void> _reactToMessage(Map<String, dynamic> msg, String emoji) async {
    try {
      await http.post(
        Uri.parse('$apiBaseUrl/reactMessage'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'pairKey': _pairKey,
          'messageId': msg['id'],
          'username': widget.currentUsername,
          'emoji': emoji,
          'scope': 'private',
        }),
      );
      setState(() {
        final reactions =
            List<Map<String, dynamic>>.from(msg['reactions'] ?? []);
        final idx = reactions.indexWhere(
            (r) => r['emoji'] == emoji && r['username'] == widget.currentUsername);
        if (idx >= 0) {
          reactions.removeAt(idx);
        } else {
          reactions.add({'emoji': emoji, 'username': widget.currentUsername});
        }
        msg['reactions'] = reactions;
      });
    } catch (_) {}
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgBlack,
      appBar: AppBar(
        backgroundColor: AppColors.bgBlack,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: GestureDetector(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => OtherUserProfilePage(
                username: widget.otherUsername,
                currentUsername: widget.currentUsername,
              ),
            ),
          ),
          child: Row(
            children: [
              buildAvatar(
                photoUrl: widget.otherPhotoUrl ?? _otherUser?['photoUrl'],
                name: widget.otherUsername,
                radius: 18,
              ),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _otherUser?['name'] ?? widget.otherUsername,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '@${widget.otherUsername}',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.5),
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _isLoading
                ? Center(
                    child: CircularProgressIndicator(
                        color: AppColors.primaryPurple),
                  )
                : _messages.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.lock_outline,
                                color: Colors.white24, size: 56),
                            const SizedBox(height: 16),
                            const Text(
                              'Private chat',
                              style: TextStyle(
                                  color: Colors.white38, fontSize: 14),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'Kirim pesan pertama ke @${widget.otherUsername}',
                              style: TextStyle(
                                  color: Colors.white24, fontSize: 12),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      )
                    : FadeTransition(
                        opacity: _fadeAnimation,
                        child: ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 16),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final msg = _messages[index];
                            final isOwn = msg['from'] == widget.currentUsername ||
                                msg['username'] == widget.currentUsername;
                            final displayMsg = {
                              ...msg,
                              'username':
                                  isOwn ? widget.currentUsername : widget.otherUsername,
                              'message': msg['message'],
                              'timestamp': msg['timestamp'],
                              'reactions': msg['reactions'] ?? [],
                            };
                            return ChatBubble(
                              message: displayMsg,
                              isOwn: isOwn,
                              currentUsername: widget.currentUsername,
                              allMessages: _messages,
                              onReact: (emoji) =>
                                  _reactToMessage(msg, emoji),
                            );
                          },
                        ),
                      ),
          ),
          SafeArea(
            top: false,
            child: Container(
              padding:
                  EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AppColors.bgBlack,
                border: Border(
                  top: BorderSide(color: AppColors.borderGlass),
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: AppColors.surfaceGlass,
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: AppColors.borderGlass),
                      ),
                      child: TextField(
                        controller: _messageController,
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Message @${widget.otherUsername}...',
                          hintStyle: const TextStyle(
                              color: Colors.white38, fontSize: 14),
                          border: InputBorder.none,
                          suffixIcon: _messageController.text.isNotEmpty
                              ? IconButton(
                                  onPressed: () {
                                    _messageController.clear();
                                    setState(() {});
                                  },
                                  icon: Icon(Icons.clear,
                                      color: Colors.white38, size: 18),
                                  padding: EdgeInsets.zero,
                                  constraints: BoxConstraints(),
                                )
                              : null,
                        ),
                        onChanged: (_) => setState(() {}),
                        onSubmitted: (_) => _sendMessage(),
                        maxLength: 1000,
                        maxLines: null,
                        textCapitalization: TextCapitalization.sentences,
                      ),
                    ),
                  ),
                  SizedBox(width: 8),
                  GestureDetector(
                    onTap: _isSending ? null : _sendMessage,
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 200),
                      width: 48,
                      height: 48,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: (_messageController.text.isNotEmpty ||
                                _isSending)
                            ? LinearGradient(
                                colors: [
                                  AppColors.primaryPurple,
                                  AppColors.glowMagenta
                                ],
                              )
                            : LinearGradient(
                                colors: [
                                  Colors.grey.shade900,
                                  Colors.grey.shade800
                                ],
                              ),
                      ),
                      child: _isSending
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                  strokeWidth: 2, color: Colors.white),
                            )
                          : Icon(
                              Icons.send,
                              color: _messageController.text.isNotEmpty
                                  ? Colors.white
                                  : Colors.white38,
                              size: 20,
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
