// RZYN by @Rizzisreal01
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'dart:ui';
import 'dart:io';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== IMPORTS HALAMAN ====================
import 'tols/telegram.dart';
import 'admin/admin_page.dart';
import 'admin/seller_page.dart';
import 'admin/change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'menu/menu.dart';
import 'tols/ddos_panel.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'spam/spam_otp.dart';
import 'public_page.dart';
import 'colorbckd_page.dart';
import 'profile_page.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
  static const Color paperDark = Color(0xFF1E1E2E);
  static const Color paperLight = Color(0xFF2A2A3E);
  static const Color paperFold = Color(0xFF0D0D1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  final GlobalKey _bugButtonKey = GlobalKey();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final PageController _mediaPageController = PageController(viewportFraction: 0.92);
  final PageController _newsPageController = PageController(viewportFraction: 0.92);
  
  int _currentMediaIndex = 0;
  int _currentNewsIndex = 0;
  
  Timer? _mediaAutoSlideTimer;
  Timer? _newsAutoSlideTimer;

  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  VideoPlayerController? _videoController;
  bool _isVideoInitialized = false;

  Color _backgroundColor = NeoBrutalismColors.grey;

  int _totalUsers = 0;
  int _senderActive = 0;
  bool _isLoadingStats = false;

  // ===== MEDIA CUSTOM (2 SLIDE) =====
  List<Map<String, dynamic>> _mediaItems = [];

  // ===== BTC CHART =====
  List<double> _btcPrices = [];
  double _currentBTCPrice = 118240.34;
  double _btcHigh = 118240.34;
  double _btcLow = 118240.34;
  double _btcVolume = 42133.45;
  double _btcFunding = 0.0064;
  String _btcChange = '+0.00';
  bool _isPriceUp = true;
  Timer? _btcTimer;
  final Random _random = Random();

  // ===== AUDIO PLAYER =====
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isMusicPlaying = false;
  String _currentMusicTitle = '';
  int _currentMusicIndex = 0;
  late AnimationController _spinController;
  
  final List<Map<String, String>> _musicList = [
    {'title': 'BIRDS OF A FEATHER', 'url': 'https://www.image2url.com/r2/default/audio/1782960521468-e6386e2c-a1c7-4ebc-836a-1131829870f3.mp3'},
    {'title': 'The one that got', 'url': 'https://cdn.imageurlgenerator.com/uploads/eaee7c37-6ea8-4d43-bf69-88dd63621169.mp3'},
    {'title': 'Hindia', 'url': 'https://cdn.imageurlgenerator.com/uploads/5d3d9c92-aa68-472b-aeab-5c511a8a6af6.mp3'},
    {'title': 'Blank Space', 'url': 'https://www.image2url.com/r2/default/audio/1787296942224-7376e10b-8c1e-4a89-b6bf-c95d077e9bcc.m4a'},
  ];

  // ===== TYPING TEXT =====
  String _displayText = '';
  int _typingIndex = 0;
  Timer? _typingTimer;
  final String _fullText = 'RZYN';
  bool _isTypingForward = true;

  // ===== PROFILE IMAGE =====
  File? _profileImage;

  // ===== REAL TIME CLOCK =====
  String _currentTime = '';
  Timer? _clockTimer;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _controller.forward();

    _spinController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _fetchActivityLogs();
    _initializeVideo();
    _loadSavedBackground();
    _fetchStats();
    _initMediaItems();
    _startMediaAutoSlide();
    _startNewsAutoSlide();
    _initBTCChart();
    _startTypingAnimation();
    _loadProfileImage();
    _startClock();
    
    _audioPlayer.onPlayerComplete.listen((event) {
      _playNextMusic();
    });
  }

  // ==================== LOAD PROFILE IMAGE ====================
  Future<void> _loadProfileImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final imagePath = prefs.getString('profile_image_${widget.username}');
      if (imagePath != null && imagePath.isNotEmpty) {
        final file = File(imagePath);
        if (await file.exists()) {
          setState(() {
            _profileImage = file;
          });
        }
      }
    } catch (e) {
      print('Error loading profile image: $e');
    }
  }

  // ==================== REAL TIME CLOCK ====================
  void _startClock() {
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _updateClock();
    });
  }

  void _updateClock() {
    final now = DateTime.now();
    final time = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}';
    if (mounted) {
      setState(() {
        _currentTime = time;
      });
    }
  }

  // ==================== TYPING ANIMATION ====================
  void _startTypingAnimation() {
    _typingTimer?.cancel();
    _typingIndex = 0;
    _displayText = '';
    _isTypingForward = true;
    
    _typingTimer = Timer.periodic(const Duration(milliseconds: 400), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      
      setState(() {
        if (_isTypingForward) {
          _typingIndex++;
          _displayText = _fullText.substring(0, _typingIndex);
          if (_typingIndex >= _fullText.length) {
            _isTypingForward = false;
            Future.delayed(const Duration(milliseconds: 800), () {
              if (mounted) {
                setState(() {
                  _isTypingForward = false;
                });
              }
            });
          }
        } else {
          _typingIndex--;
          _displayText = _fullText.substring(0, _typingIndex);
          if (_typingIndex <= 0) {
            _isTypingForward = true;
            Future.delayed(const Duration(milliseconds: 400), () {
              if (mounted) {
                setState(() {
                  _isTypingForward = true;
                });
              }
            });
          }
        }
      });
    });
  }

  // ==================== AUDIO PLAYER ====================
  void _playMusic(int index) async {
    if (index < 0 || index >= _musicList.length) return;
    
    try {
      await _audioPlayer.stop();
      _currentMusicIndex = index;
      _currentMusicTitle = _musicList[index]['title'] ?? '';
      
      await _audioPlayer.play(UrlSource(_musicList[index]['url']!));
      setState(() {
        _isMusicPlaying = true;
      });
    } catch (e) {
      print('Error playing music: $e');
    }
  }

  void _playNextMusic() {
    int nextIndex = (_currentMusicIndex + 1) % _musicList.length;
    _playMusic(nextIndex);
  }

  void _toggleMusic() {
    if (_isMusicPlaying) {
      _audioPlayer.stop();
      setState(() {
        _isMusicPlaying = false;
      });
    } else {
      if (_currentMusicTitle.isEmpty) {
        _playMusic(0);
      } else {
        _playMusic(_currentMusicIndex);
      }
    }
  }

  void _showMusicMenu() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.purple,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: const Icon(Icons.music_note, color: NeoBrutalismColors.white, size: 20),
            ),
            const SizedBox(width: 10),
            const Text(
              '🎵 Pilih Lagu',
              style: TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (_isMusicPlaying)
                Container(
                  padding: const EdgeInsets.all(10),
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.grey,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: NeoBrutalismColors.green, width: 2),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.play_circle, color: NeoBrutalismColors.green, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Now Playing: $_currentMusicTitle',
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontWeight: FontWeight.w700,
                            fontSize: 13,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ..._musicList.asMap().entries.map((entry) {
                final idx = entry.key;
                final music = entry.value;
                final isActive = _isMusicPlaying && _currentMusicIndex == idx;
                return GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    _playMusic(idx);
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    margin: const EdgeInsets.only(bottom: 6),
                    decoration: BoxDecoration(
                      color: isActive ? NeoBrutalismColors.yellow : NeoBrutalismColors.grey,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isActive ? NeoBrutalismColors.borderColor : NeoBrutalismColors.darkGrey,
                        width: isActive ? 2 : 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isActive ? Icons.play_circle : Icons.music_note,
                          color: isActive ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
                          size: 18,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            music['title'] ?? '',
                            style: TextStyle(
                              color: isActive ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
                              fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
                              fontSize: 13,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ),
                        if (isActive)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.green,
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                            ),
                            child: const Text(
                              'PLAYING',
                              style: TextStyle(
                                color: NeoBrutalismColors.white,
                                fontSize: 8,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Inter',
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ],
          ),
        ),
        actions: [
          if (_isMusicPlaying)
            TextButton(
              onPressed: () {
                _audioPlayer.stop();
                setState(() {
                  _isMusicPlaying = false;
                });
                Navigator.pop(context);
              },
              style: TextButton.styleFrom(
                backgroundColor: NeoBrutalismColors.pink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                ),
              ),
              child: const Text(
                '⏹ Stop',
                style: TextStyle(
                  color: NeoBrutalismColors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                  fontFamily: 'Inter',
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: NeoBrutalismColors.yellow,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
              ),
            ),
            child: const Text(
              'Tutup',
              style: TextStyle(
                color: NeoBrutalismColors.black,
                fontWeight: FontWeight.w800,
                fontSize: 12,
                fontFamily: 'Inter',
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== BTC CHART (JALAN NAIK TURUN) ====================
  void _initBTCChart() {
    _btcPrices = [];
    double price = 118240.34;
    double trend = 0;
    
    // Buat 100 data awal
    for (int i = 0; i < 100; i++) {
      trend += (_random.nextDouble() - 0.5) * 20;
      trend = trend.clamp(-40, 40);
      
      double change = trend + (_random.nextDouble() - 0.5) * 30;
      price += change;
      
      if (price < 115000) price = 115000 + _random.nextDouble() * 300;
      if (price > 122000) price = 122000 - _random.nextDouble() * 300;
      
      _btcPrices.add(price);
    }
    
    _currentBTCPrice = _btcPrices.last;
    _btcHigh = _btcPrices.reduce(max);
    _btcLow = _btcPrices.reduce(min);
    
    if (_btcPrices.length > 10) {
      double oldPrice = _btcPrices[_btcPrices.length - 10];
      double changePercent = ((_currentBTCPrice - oldPrice) / oldPrice) * 100;
      _isPriceUp = changePercent >= 0;
      _btcChange = (changePercent >= 0 ? '+' : '') + changePercent.toStringAsFixed(2);
    }
    
    // ===== UPDATE TIAP 100ms =====
    _btcTimer = Timer.periodic(const Duration(milliseconds: 100), (timer) {
      _updateBTCChart();
    });
  }

  void _updateBTCChart() {
    // Random walk dengan momentum agar terlihat bergerak
    double momentum = (_random.nextDouble() - 0.5) * 40;
    double volatility = 25 + _random.nextDouble() * 40;
    double change = momentum + (_random.nextDouble() - 0.5) * volatility;
    
    double newPrice = _currentBTCPrice + change;
    
    if (newPrice < 115000) {
      newPrice = 115000 + _random.nextDouble() * 150;
    }
    if (newPrice > 122000) {
      newPrice = 122000 - _random.nextDouble() * 150;
    }
    
    newPrice += (_random.nextDouble() - 0.5) * 3;
    
    _btcPrices.add(newPrice);
    if (_btcPrices.length > 250) _btcPrices.removeAt(0);
    _currentBTCPrice = newPrice;
    
    if (newPrice > _btcHigh) _btcHigh = newPrice;
    if (newPrice < _btcLow) _btcLow = newPrice;
    
    if (_btcPrices.length > 10) {
      double oldPrice = _btcPrices[_btcPrices.length - 10];
      double changePercent = ((newPrice - oldPrice) / oldPrice) * 100;
      _isPriceUp = changePercent >= 0;
      _btcChange = (changePercent >= 0 ? '+' : '') + changePercent.toStringAsFixed(2);
    }
    
    _btcVolume += (_random.nextDouble() - 0.5) * 60;
    if (_btcVolume < 40000) _btcVolume = 40000 + _random.nextDouble() * 600;
    if (_btcVolume > 45000) _btcVolume = 45000 - _random.nextDouble() * 600;
    
    _btcFunding += (_random.nextDouble() - 0.5) * 0.0004;
    if (_btcFunding > 0.015) _btcFunding = 0.015;
    if (_btcFunding < 0.005) _btcFunding = 0.005;
    
    if (mounted) setState(() {});
  }

  Widget _buildBTCChart() {
    return _neoCard(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.yellow,
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.15),
                          offset: const Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: const Text(
                      'BTC',
                      style: TextStyle(
                        color: NeoBrutalismColors.black,
                        fontSize: 10,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.grey,
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                    ),
                    child: const Text(
                      'SPOT',
                      style: TextStyle(
                        color: NeoBrutalismColors.darkGrey,
                        fontSize: 8,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                ],
              ),
              Text(
                '${_btcChange}%',
                style: TextStyle(
                  color: _isPriceUp ? NeoBrutalismColors.green : NeoBrutalismColors.pink,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Inter',
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Text(
                '\$${_currentBTCPrice.toStringAsFixed(2)}',
                style: const TextStyle(
                  color: NeoBrutalismColors.black,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Inter',
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: _isPriceUp ? NeoBrutalismColors.green.withOpacity(0.15) : NeoBrutalismColors.pink.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: _isPriceUp ? NeoBrutalismColors.green : NeoBrutalismColors.pink,
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.black.withOpacity(0.1),
                      offset: const Offset(3, 3),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: Text(
                  '${_isPriceUp ? '▲' : '▼'} ${_btcChange}%',
                  style: TextStyle(
                    color: _isPriceUp ? NeoBrutalismColors.green : NeoBrutalismColors.pink,
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Inter',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          // ===== CHART GARIS (JALAN NAIK TURUN) =====
          SizedBox(
            height: 80,
            child: CustomPaint(
              painter: BTCChartPainter(
                prices: _btcPrices,
                color: _isPriceUp ? NeoBrutalismColors.green : NeoBrutalismColors.pink,
              ),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _buildBTCStat('24h High', '\$${_btcHigh.toStringAsFixed(2)}', NeoBrutalismColors.green),
              _buildBTCStat('24h Low', '\$${_btcLow.toStringAsFixed(2)}', NeoBrutalismColors.pink),
              _buildBTCStat('24h Vol', '${_btcVolume.toStringAsFixed(2)} BTC', NeoBrutalismColors.blue),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _buildBTCStat('Market Cap', '\$2.34T', NeoBrutalismColors.purple),
              _buildBTCStat('Funding / 8h', '${_btcFunding.toStringAsFixed(4)}%', NeoBrutalismColors.yellow),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Real Time · Update otomatis tiap 100ms',
                style: TextStyle(
                  color: NeoBrutalismColors.darkGrey,
                  fontSize: 9,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
              ),
              Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.green,
                      shape: BoxShape.circle,
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                    ),
                  ),
                  const SizedBox(width: 4),
                  const Text(
                    'LIVE',
                    style: TextStyle(
                      color: NeoBrutalismColors.green,
                      fontSize: 8,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBTCStat(String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 4),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: color.withOpacity(0.2), width: 1),
        ),
        child: Column(
          children: [
            Text(
              label,
              style: TextStyle(
                color: NeoBrutalismColors.darkGrey,
                fontSize: 8,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
            ),
            Text(
              value,
              style: TextStyle(
                color: color,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== MEDIA ITEMS ====================
  void _initMediaItems() {
    _mediaItems = [
      {
        'image': 'https://files.catbox.moe/07reqr.jpg',
        'title': 'NEW UI TAMPILAN 2026',
        'desc': 'spesial dev @Rizzisreal01',
      },
      {
        'image': 'https://files.catbox.moe/7zmi2y.jpg',
        'title': 'UPDATE BUG GACOR 2026',
        'desc': 'main project 1 X•Miyabi',
      },
    ];
  }

  void _startMediaAutoSlide() {
    _mediaAutoSlideTimer?.cancel();
    if (_mediaItems.length <= 1) return;
    _mediaAutoSlideTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        _currentMediaIndex = (_currentMediaIndex + 1) % _mediaItems.length;
        _mediaPageController.animateToPage(
          _currentMediaIndex,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      });
    });
  }

  void _startNewsAutoSlide() {
    _newsAutoSlideTimer?.cancel();
    if (newsList.length <= 1) return;
    _newsAutoSlideTimer = Timer.periodic(const Duration(seconds: 4), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        _currentNewsIndex = (_currentNewsIndex + 1) % newsList.length;
        _newsPageController.animateToPage(
          _currentNewsIndex,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );
      });
    });
  }

  // ==================== FETCH STATS ====================
  Future<void> _fetchStats() async {
    setState(() {
      _isLoadingStats = true;
    });

    try {
      final userResponse = await http.get(
        Uri.parse('$baseUrl/api/user/listUsers?key=$sessionKey'),
      );
      if (userResponse.statusCode == 200) {
        final userData = jsonDecode(userResponse.body);
        if (userData['valid'] == true && userData['users'] != null) {
          setState(() {
            _totalUsers = userData['users'].length;
          });
        }
      }

      final senderResponse = await http.get(
        Uri.parse('$baseUrl/api/whatsapp/mySender?key=$sessionKey'),
      );
      if (senderResponse.statusCode == 200) {
        final senderData = jsonDecode(senderResponse.body);
        if (senderData['valid'] == true && senderData['senders'] != null) {
          setState(() {
            _senderActive = senderData['senders'].length;
          });
        }
      }
    } catch (e) {
      print('Error fetching stats: $e');
    }

    setState(() {
      _isLoadingStats = false;
    });
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: _backgroundColor,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  Future<void> _loadSavedBackground() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final saved = prefs.getString('selected_background') ?? 'grey';
      
      Color? bgColor;
      
      switch (saved) {
        case 'hitam':
          bgColor = Colors.black;
          break;
        case 'hitblu':
          bgColor = const Color(0xFF0A0A2E);
          break;
        case 'putih':
          bgColor = Colors.white;
          break;
        case 'abu_putih':
          bgColor = const Color(0xFFE8E8E8);
          break;
        case 'hitam_abu':
          bgColor = const Color(0xFF2A2A2A);
          break;
        case 'biru_kotak':
          bgColor = const Color(0xFF0A1628);
          break;
        case 'abu_kotak':
          bgColor = const Color(0xFF1A1A1A);
          break;
        default:
          bgColor = NeoBrutalismColors.grey;
      }
      
      if (mounted) {
        setState(() {
          _backgroundColor = bgColor ?? NeoBrutalismColors.grey;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _backgroundColor = NeoBrutalismColors.grey;
        });
      }
    }
  }

  void _changeBackground(Color? color) {
    if (mounted) {
      setState(() {
        _backgroundColor = color ?? NeoBrutalismColors.grey;
      });
    }
  }

  void _initializeVideo() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banerUi.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _isVideoInitialized = true;
            });
            _videoController?.setLooping(true);
            _videoController?.play();
          }
        }).catchError((error) {
          _tryLoadVideoFromFile();
        });
    } catch (e) {
      _tryLoadVideoFromFile();
    }
  }

  void _tryLoadVideoFromFile() {
    try {
      final file = File('assets/videos/banerUi.mp4');
      if (file.existsSync()) {
        _videoController = VideoPlayerController.file(file)
          ..initialize().then((_) {
            if (mounted) {
              setState(() {
                _isVideoInitialized = true;
              });
              _videoController?.setLooping(true);
              _videoController?.play();
            }
          }).catchError((error) {
            _handleVideoError();
          });
      } else {
        _handleVideoError();
      }
    } catch (e) {
      _handleVideoError();
    }
  }

  void _handleVideoError() {
    if (mounted) {
      setState(() {
        _isVideoInitialized = false;
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('$baseUrl'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
    }, onError: (error) {
      // Handle error
    });
  }

  Future<void> _fetchActivityLogs() async {
    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/user/getActivityLogs?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          setState(() {
            _activityLogs = List<Map<String, dynamic>>.from(data['logs']);
            _isLoadingActivityLogs = false;
          });
        } else {
          setState(() {
            _isLoadingActivityLogs = false;
            _hasActivityLogsError = true;
          });
        }
      } else {
        setState(() {
          _isLoadingActivityLogs = false;
          _hasActivityLogsError = true;
        });
      }
    } catch (e) {
      print('Error fetching activity logs: $e');
      setState(() {
        _isLoadingActivityLogs = false;
        _hasActivityLogsError = true;
      });
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.pink,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: const Icon(Icons.warning_rounded, color: NeoBrutalismColors.white, size: 20),
            ),
            const SizedBox(width: 12),
            const Text("⚠️ Session Expired", style: TextStyle(color: NeoBrutalismColors.black, fontSize: 16, fontWeight: FontWeight.w800, fontFamily: 'Inter')),
          ],
        ),
        content: Text(message, style: TextStyle(color: NeoBrutalismColors.black.withOpacity(0.7), fontSize: 14, fontFamily: 'Inter')),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            style: TextButton.styleFrom(
              backgroundColor: NeoBrutalismColors.yellow,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
              ),
            ),
            child: const Text("OK", style: TextStyle(color: NeoBrutalismColors.black, fontWeight: FontWeight.w800, fontFamily: 'Inter')),
          ),
        ],
      ),
    );
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _controller.reset();
      _controller.forward();

      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = SpamOtpPage(
          sessionKey: sessionKey,
          username: username,
          role: role, 
        );
      } else if (index == 2) {
        _selectedPage = MenuPage(
          username: username,
          password: password,
          sessionKey: sessionKey,
          role: role,
          expiredDate: expiredDate,
          listBug: listBug,
          listPayload: listPayload,
        );
      } else if (index == 3) {
        _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role);
      } else if (index == 4) {
        _selectedPage = ProfilePage(
          username: username,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      }
    });
  }

  void _selectFromDrawer(String page) {
    Navigator.pop(context);
    setState(() {
      if (page == 'reseller') {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (page == 'admin') {
        _selectedPage = AdminPage(sessionKey: sessionKey, role: role);
      } else if (page == 'sender') {
        _selectedPage = SenderPage(sessionKey: sessionKey);
      }
    });
  }

  // ==================== NEOBRUTALISM UI HELPERS ====================
  
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 6,
    EdgeInsets padding = const EdgeInsets.all(16),
    double? height,
    EdgeInsets? margin,
  }) {
    return Container(
      margin: margin,
      height: height,
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.15),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  // ==================== CARD STATUS API GACOR ====================
  Widget _buildServerStatusCard() {
    return _neoCard(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _buildStatusItem(FontAwesomeIcons.code, "API", "GACOR", NeoBrutalismColors.green),
          Container(width: 1, height: 30, color: NeoBrutalismColors.borderColor.withOpacity(0.3)),
          _buildStatusItem(FontAwesomeIcons.server, "SERVER", "AKTIF", NeoBrutalismColors.yellow),
          Container(width: 1, height: 30, color: NeoBrutalismColors.borderColor.withOpacity(0.3)),
          _buildStatusItem(FontAwesomeIcons.database, "DATA", "AMAN", NeoBrutalismColors.blue),
        ],
      ),
    );
  }

  Widget _buildStatusItem(IconData icon, String label, String value, Color color) {
    return Row(
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: NeoBrutalismColors.darkGrey, fontSize: 9, fontWeight: FontWeight.w700, fontFamily: 'Inter')),
            Text(value, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12, fontFamily: 'Inter')),
          ],
        ),
      ],
    );
  }

  // ==================== CARD WELCOME BACK DENGAN EFEK KERTAS ====================
  Widget _buildProfileCard() {
    return _neoCard(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          // ===== HEADER =====
          Row(
            children: [
              Expanded(
                child: Text(
                  "Welcome Back: $username",
                  style: const TextStyle(
                    color: NeoBrutalismColors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Inter',
                    letterSpacing: 1,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              // LOG OUT button
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.pink,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                ),
                child: const Text(
                  'LOG OUT',
                  style: TextStyle(
                    color: NeoBrutalismColors.white,
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Inter',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          
          // ===== MAIN CONTENT =====
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ===== SISI KIRI (AVATAR + INFO) =====
              Expanded(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Avatar
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: NeoBrutalismColors.purple, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: NeoBrutalismColors.black.withOpacity(0.15),
                            offset: const Offset(4, 4),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: _profileImage != null
                            ? Image.file(
                                _profileImage!,
                                width: 60,
                                height: 60,
                                fit: BoxFit.cover,
                              )
                            : Image.asset(
                                'assets/images/profil.jpg',
                                width: 60,
                                height: 60,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Container(
                                  width: 60,
                                  height: 60,
                                  color: NeoBrutalismColors.purple,
                                  child: const Icon(Icons.person, color: NeoBrutalismColors.white, size: 30),
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    
                    // Role
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                      decoration: BoxDecoration(
                        color: _getRoleColor().withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _getRoleColor().withOpacity(0.4), width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: NeoBrutalismColors.black.withOpacity(0.1),
                            offset: const Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: TextStyle(
                          color: _getRoleColor(),
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 10),
                    
                    // Expired
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "EXPIRED",
                          style: TextStyle(
                            color: NeoBrutalismColors.darkGrey,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Inter',
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          expiredDate.split(' ').first,
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              
              const SizedBox(width: 12),
              
              // ===== SISI KANAN (KERTAS HITAM DENGAN LIPATAN) =====
              Expanded(
                flex: 3,
                child: Stack(
                  children: [
                    // Card hitam utama
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.paperDark,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: NeoBrutalismColors.black.withOpacity(0.25),
                            offset: const Offset(5, 5),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Teks R Z Y N x B u g
                          const Text(
                            'R Z Y N',
                            style: TextStyle(
                              color: NeoBrutalismColors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Inter',
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 2),
                          const Text(
                            'x B u g',
                            style: TextStyle(
                              color: NeoBrutalismColors.yellow,
                              fontSize: 16,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Inter',
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 10),
                          
                          // SYSTEM PROFILE - Server Performance
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.paperLight,
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: const [
                                Icon(Icons.speed, color: NeoBrutalismColors.white, size: 12),
                                SizedBox(width: 6),
                                Text(
                                  'SERVER PERFORMANCE',
                                  style: TextStyle(
                                    color: NeoBrutalismColors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Inter',
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          
                          // ===== JAM REAL TIME =====
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.paperLight,
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.access_time, color: NeoBrutalismColors.white, size: 14),
                                const SizedBox(width: 6),
                                Text(
                                  _currentTime.isNotEmpty ? _currentTime : '00:00:00',
                                  style: const TextStyle(
                                    color: NeoBrutalismColors.white,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                    fontFamily: 'Inter',
                                    letterSpacing: 2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    // ===== EFEK LIPATAN KERTAS DI SISI KANAN BAWAH =====
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.paperFold,
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(8),
                          ),
                          border: Border(
                            left: BorderSide(color: NeoBrutalismColors.borderColor.withOpacity(0.3), width: 1),
                            top: BorderSide(color: NeoBrutalismColors.borderColor.withOpacity(0.3), width: 1),
                          ),
                        ),
                      ),
                    ),
                    
                    // ===== EFEK LIPATAN KERTAS DI SISI KANAN ATAS =====
                    Positioned(
                      top: 0,
                      right: 0,
                      child: Container(
                        width: 20,
                        height: 20,
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.paperFold,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(8),
                          ),
                          border: Border(
                            bottom: BorderSide(color: NeoBrutalismColors.borderColor.withOpacity(0.3), width: 1),
                            left: BorderSide(color: NeoBrutalismColors.borderColor.withOpacity(0.3), width: 1),
                          ),
                        ),
                      ),
                    ),
                    
                    // ===== GARIS LIPATAN DIAGONAL =====
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: CustomPaint(
                        size: const Size(30, 30),
                        painter: _FoldLinePainter(),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // ===== DIVIDER =====
          Container(
            height: 2,
            color: NeoBrutalismColors.borderColor.withOpacity(0.3),
          ),
          const SizedBox(height: 14),
          
          // ===== STATS =====
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem2D(
                icon: Icons.people,
                label: "TOTAL USER",
                value: _isLoadingStats ? "..." : "$_totalUsers",
                color: NeoBrutalismColors.purple,
              ),
              Container(width: 1, height: 30, color: NeoBrutalismColors.borderColor.withOpacity(0.3)),
              _buildStatItem2D(
                icon: Icons.send,
                label: "SENDER AKTIF",
                value: _isLoadingStats ? "..." : "$_senderActive",
                color: NeoBrutalismColors.green,
              ),
              Container(width: 1, height: 30, color: NeoBrutalismColors.borderColor.withOpacity(0.3)),
              _buildStatItem2D(
                icon: Icons.battery_4_bar,
                label: "BATTERAI",
                value: "98%",
                color: NeoBrutalismColors.yellow,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem2D({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: color.withOpacity(0.3), width: 1),
          ),
          child: Icon(icon, color: color, size: 16),
        ),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: NeoBrutalismColors.darkGrey, fontSize: 8, fontWeight: FontWeight.w700, fontFamily: 'Inter')),
            Text(value, style: TextStyle(color: NeoBrutalismColors.black, fontSize: 14, fontWeight: FontWeight.w900, fontFamily: 'Inter')),
          ],
        ),
      ],
    );
  }

  // ==================== VIDEO PLAYER ====================
  Widget _buildVideoPlayer() {
    return Container(
      height: 180,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.15),
            offset: const Offset(6, 6),
            blurRadius: 0,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: _isVideoInitialized && _videoController != null
            ? Stack(
                alignment: Alignment.center,
                children: [
                  VideoPlayer(_videoController!),
                  Positioned(
                    bottom: 10,
                    right: 10,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          if (_videoController!.value.isPlaying) {
                            _videoController!.pause();
                          } else {
                            _videoController!.play();
                          }
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.white,
                          shape: BoxShape.circle,
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.15),
                              offset: const Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: Icon(
                          _videoController!.value.isPlaying 
                              ? Icons.pause 
                              : Icons.play_arrow,
                          color: NeoBrutalismColors.black,
                          size: 20,
                        ),
                      ),
                    ),
                  ),
                ],
              )
            : Container(
                height: 180,
                color: NeoBrutalismColors.purple,
                child: const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator(color: NeoBrutalismColors.white, strokeWidth: 2),
                      SizedBox(height: 10),
                      Text("Loading Video...", style: TextStyle(color: NeoBrutalismColors.white, fontSize: 12, fontFamily: 'Inter', fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  // ==================== APPBAR ====================
  Widget _buildDynamicAppBar() {
    return SafeArea(
      child: Container(
        height: 70,
        margin: const EdgeInsets.only(top: 20, left: 16, right: 16),
        decoration: BoxDecoration(
          color: NeoBrutalismColors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
          boxShadow: [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.15),
              offset: const Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                icon: const Icon(Icons.menu, color: NeoBrutalismColors.black, size: 24),
                onPressed: () {
                  _scaffoldKey.currentState?.openDrawer();
                },
              ),
              Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.green,
                      shape: BoxShape.circle,
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Text(
                      _displayText,
                      style: const TextStyle(
                        color: NeoBrutalismColors.black,
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                        letterSpacing: 1.5,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                  Container(
                    width: 2,
                    height: 22,
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.black,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  GestureDetector(
                    onTap: _toggleMusic,
                    child: AnimatedBuilder(
                      animation: _spinController,
                      builder: (context, child) {
                        return Transform.rotate(
                          angle: _isMusicPlaying ? _spinController.value * 2 * 3.14159 : 0,
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: _isMusicPlaying ? NeoBrutalismColors.purple : NeoBrutalismColors.grey,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: _isMusicPlaying ? NeoBrutalismColors.borderColor : NeoBrutalismColors.darkGrey,
                                width: 2,
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoBrutalismColors.black.withOpacity(0.1),
                                  offset: const Offset(3, 3),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: Icon(
                              Icons.music_note,
                              color: _isMusicPlaying ? NeoBrutalismColors.white : NeoBrutalismColors.darkGrey,
                              size: 20,
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    icon: const Icon(Icons.palette, color: NeoBrutalismColors.black, size: 22),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ColorBackgroundPage(
                            onBackgroundChanged: _changeBackground,
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    icon: const Icon(Icons.more_vert, color: NeoBrutalismColors.black, size: 24),
                    onPressed: _showMusicMenu,
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                    icon: const Icon(Icons.person_outline, color: NeoBrutalismColors.black, size: 24),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ProfilePage(
                            username: username,
                            role: role,
                            expiredDate: expiredDate,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== NEWS PAGE ====================
  Widget _buildNewsPage() {
    return RefreshIndicator(
      color: NeoBrutalismColors.black,
      backgroundColor: NeoBrutalismColors.white,
      onRefresh: () async {
        await _fetchActivityLogs();
        await _fetchStats();
        await _loadProfileImage();
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildVideoPlayer(),
            const SizedBox(height: 12),
            _buildProfileCard(),
            const SizedBox(height: 12),
            _buildServerStatusCard(),
            const SizedBox(height: 16),
            _buildBTCChart(),
            const SizedBox(height: 16),
            _buildMediaCarousel(),
            const SizedBox(height: 16),
            _buildQuickActionsHorizontal(),
            const SizedBox(height: 16),
            _buildNewsCarousel(),
            const SizedBox(height: 16),
            _buildRecentActivity(),
          ],
        ),
      ),
    );
  }

  Color _getRoleColor() {
    switch (role.toLowerCase()) {
      case 'dev': 
        return NeoBrutalismColors.pink;
      case 'high_pt': 
        return NeoBrutalismColors.purple;
      case 'pt': 
        return Colors.deepPurple;
      case 'helper': 
        return NeoBrutalismColors.green;
      case 'admin': 
        return NeoBrutalismColors.blue;
      case 'reseller': 
        return NeoBrutalismColors.yellow;
      case 'vip': 
        return Colors.amber;
      case 'member': 
        return NeoBrutalismColors.darkGrey;
      default: 
        return NeoBrutalismColors.darkGrey;
    }
  }

  // ==================== MEDIA CAROUSEL ====================
  Widget _buildMediaCarousel() {
    if (_mediaItems.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            "Media",
            style: TextStyle(
              color: NeoBrutalismColors.black,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              fontFamily: 'Inter',
            ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _mediaPageController,
            itemCount: _mediaItems.length,
            onPageChanged: (index) {
              setState(() {
                _currentMediaIndex = index;
              });
            },
            itemBuilder: (context, index) {
              final item = _mediaItems[index];
              final imageUrl = item['image'] ?? '';
              final title = item['title'] ?? 'Media';
              final desc = item['desc'] ?? '';

              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.black.withOpacity(0.15),
                      offset: const Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (imageUrl.isNotEmpty)
                        SizedBox(
                          width: double.infinity,
                          height: double.infinity,
                          child: NewsMedia(url: imageUrl),
                        )
                      else
                        Container(color: NeoBrutalismColors.purple),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              NeoBrutalismColors.black.withOpacity(0.7),
                              Colors.transparent,
                              Colors.transparent,
                            ],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 15,
                        left: 15,
                        right: 15,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                color: NeoBrutalismColors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Inter',
                                shadows: [Shadow(color: Colors.black, blurRadius: 4)],
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              desc,
                              style: TextStyle(
                                color: NeoBrutalismColors.white.withOpacity(0.85),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter',
                                shadows: [Shadow(color: Colors.black, blurRadius: 4)],
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        if (_mediaItems.length > 1)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _mediaItems.length,
              (index) => AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                height: 6,
                width: _currentMediaIndex == index ? 20 : 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: _currentMediaIndex == index
                      ? NeoBrutalismColors.borderColor
                      : NeoBrutalismColors.borderColor.withOpacity(0.3),
                ),
              ),
            ),
          ),
      ],
    );
  }

  // ==================== NEWS CAROUSEL ====================
  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return _neoCard(
        height: 120,
        child: const Center(
          child: Text(
            "No news available",
            style: TextStyle(color: NeoBrutalismColors.darkGrey, fontFamily: 'Inter', fontWeight: FontWeight.w600),
          ),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            "News",
            style: TextStyle(
              color: NeoBrutalismColors.black,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              fontFamily: 'Inter',
            ),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _newsPageController,
            itemCount: newsList.length,
            onPageChanged: (index) {
              setState(() {
                _currentNewsIndex = index;
              });
            },
            itemBuilder: (context, index) {
              final item = newsList[index];
              final imageUrl = item['image'] ?? '';
              final title = item['title'] ?? 'Server Info';
              final desc = item['desc'] ?? 'Description here';

              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.black.withOpacity(0.15),
                      offset: const Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (imageUrl.isNotEmpty)
                        SizedBox(
                          width: double.infinity,
                          height: double.infinity,
                          child: NewsMedia(url: imageUrl),
                        )
                      else
                        Container(color: NeoBrutalismColors.purple),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              NeoBrutalismColors.black.withOpacity(0.7),
                              Colors.transparent,
                              Colors.transparent,
                            ],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 15,
                        left: 15,
                        right: 15,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: const TextStyle(
                                color: NeoBrutalismColors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                fontFamily: 'Inter',
                                shadows: [Shadow(color: Colors.black, blurRadius: 4)],
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              desc,
                              style: TextStyle(
                                color: NeoBrutalismColors.white.withOpacity(0.85),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter',
                                shadows: [Shadow(color: Colors.black, blurRadius: 4)],
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        if (newsList.length > 1)
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              newsList.length,
              (index) => AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                height: 6,
                width: _currentNewsIndex == index ? 20 : 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: _currentNewsIndex == index
                      ? NeoBrutalismColors.borderColor
                      : NeoBrutalismColors.borderColor.withOpacity(0.3),
                ),
              ),
            ),
          ),
      ],
    );
  }

  // ==================== QUICK ACTIONS ====================
  Widget _buildQuickActionsHorizontal() {
    final bool hasAdminAccess = ["dev", "high_pt", "pt", "helper", "admin"].contains(role.toLowerCase());
    final bool hasResellerAccess = ["dev", "high_pt", "pt", "helper", "admin"].contains(role.toLowerCase());
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 4),
          child: Text(
            "Quick Actions",
            style: TextStyle(
              color: NeoBrutalismColors.black,
              fontSize: 18,
              fontWeight: FontWeight.w900,
              fontFamily: 'Inter',
            ),
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          child: Row(
            children: [
              if (hasAdminAccess)
                _buildActionCard(
                  icon: Icons.admin_panel_settings,
                  title: "Admin Page",
                  color: NeoBrutalismColors.purple,
                  onTap: () {
                    setState(() {
                      _selectedPage = AdminPage(sessionKey: sessionKey, role: role);
                    });
                  },
                ),
              if (hasAdminAccess) const SizedBox(width: 12),
              if (hasResellerAccess)
                _buildActionCard(
                  icon: Icons.store,
                  title: "Seller Page",
                  color: NeoBrutalismColors.blue,
                  onTap: () {
                    setState(() {
                      _selectedPage = SellerPage(keyToken: sessionKey);
                    });
                  },
                ),
              if (hasResellerAccess) const SizedBox(width: 12),
              _buildActionCard(
                icon: FontAwesomeIcons.comments,
                title: "Public Chat",
                color: NeoBrutalismColors.green,
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => PublicChatPage(username: username)));
                },
              ),
              const SizedBox(width: 12),
              _buildActionCard(
                icon: Icons.phone_android,
                title: "Sender",
                color: NeoBrutalismColors.yellow,
                onTap: () {
                  setState(() {
                    _selectedPage = SenderPage(sessionKey: sessionKey);
                  });
                },
              ),
              const SizedBox(width: 12),
              _buildActionCard(
                icon: FontAwesomeIcons.whatsapp,
                title: "WA Spam",
                color: NeoBrutalismColors.pink,
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => ReportWaPage(sessionKey: sessionKey, username: username, role: role)));
                },
              ),
              const SizedBox(width: 12),
              _buildActionCard(
                icon: FontAwesomeIcons.telegram,
                title: "Group All buyer",
                color: NeoBrutalismColors.blue,
                onTap: () async {
                  final uri = Uri.parse("tg://resolve?domain=nullxteam");
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  } else {
                    await launchUrl(Uri.parse("https://t.me/+I5F7uH-EfCBiMzdl"), mode: LaunchMode.externalApplication);
                  }
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 120,
        height: 100,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: NeoBrutalismColors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
          boxShadow: [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.15),
              offset: const Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: color.withOpacity(0.3), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: NeoBrutalismColors.black.withOpacity(0.1),
                    offset: const Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: NeoBrutalismColors.black,
                fontFamily: 'Inter',
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // ==================== RECENT ACTIVITY ====================
  Widget _buildRecentActivity() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              "Recent Activity",
              style: TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                fontFamily: 'Inter',
              ),
            ),
            TextButton(
              onPressed: () {
                setState(() {
                  _selectedIndex = 4;
                  _selectedPage = _buildActivityLogsPage();
                });
              },
              style: TextButton.styleFrom(
                backgroundColor: NeoBrutalismColors.yellow,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                ),
              ),
              child: const Text(
                "View All",
                style: TextStyle(
                  color: NeoBrutalismColors.black,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Inter',
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (_isLoadingActivityLogs)
          _neoCard(
            height: 120,
            child: const Center(child: CircularProgressIndicator(color: NeoBrutalismColors.purple)),
          )
        else if (_hasActivityLogsError)
          _neoCard(
            height: 120,
            child: const Center(
              child: Text(
                "Failed to load activity logs",
                style: TextStyle(color: NeoBrutalismColors.darkGrey, fontFamily: 'Inter', fontWeight: FontWeight.w600),
              ),
            ),
          )
        else if (_activityLogs.isEmpty)
          _neoCard(
            height: 120,
            child: const Center(
              child: Text(
                "No activity logs available",
                style: TextStyle(color: NeoBrutalismColors.darkGrey, fontFamily: 'Inter', fontWeight: FontWeight.w600),
              ),
            ),
          )
        else
          ..._activityLogs.take(3).map((log) {
            final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
            final formattedTime = _formatDateTime(timestamp);

            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _neoCard(
                padding: const EdgeInsets.all(14),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: _getActivityColor(log['activity']).withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: _getActivityColor(log['activity']).withOpacity(0.3), width: 2),
                      ),
                      child: Icon(_getActivityIcon(log['activity']), color: _getActivityColor(log['activity']), size: 18),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            log['activity'] ?? 'Unknown Activity',
                            style: const TextStyle(color: NeoBrutalismColors.black, fontWeight: FontWeight.w800, fontFamily: 'Inter', fontSize: 13),
                          ),
                          if (log['details'] != null && log['details']['target'] != null)
                            Text(
                              "Target: ${log['details']['target']}",
                              style: TextStyle(color: NeoBrutalismColors.darkGrey, fontSize: 11, fontFamily: 'Inter', fontWeight: FontWeight.w600),
                            ),
                        ],
                      ),
                    ),
                    Text(
                      formattedTime,
                      style: TextStyle(color: NeoBrutalismColors.darkGrey, fontSize: 11, fontFamily: 'Inter', fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
      ],
    );
  }

  Widget _buildActivityLogsPage() {
    return RefreshIndicator(
      color: NeoBrutalismColors.black,
      backgroundColor: NeoBrutalismColors.white,
      onRefresh: () async {
        await _fetchActivityLogs();
      },
      child: Column(
        children: [
          _neoCard(
            padding: const EdgeInsets.all(16),
            margin: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.purple,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                  ),
                  child: const Icon(Icons.history, color: NeoBrutalismColors.white, size: 24),
                ),
                const SizedBox(width: 14),
                const Text(
                  "Activity History",
                  style: TextStyle(
                    color: NeoBrutalismColors.black,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Inter',
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoadingActivityLogs
                ? const Center(child: CircularProgressIndicator(color: NeoBrutalismColors.purple))
                : ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _activityLogs.length,
              itemBuilder: (context, index) {
                final log = _activityLogs[index];
                final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
                final formattedTime = _formatDateTime(timestamp);

                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _neoCard(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(_getActivityIcon(log['activity']), color: _getActivityColor(log['activity']), size: 18),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    log['activity'] ?? 'Unknown Activity',
                                    style: const TextStyle(color: NeoBrutalismColors.black, fontWeight: FontWeight.w800, fontFamily: 'Inter', fontSize: 13),
                                  ),
                                  Text(
                                    formattedTime,
                                    style: TextStyle(color: NeoBrutalismColors.darkGrey, fontSize: 11, fontFamily: 'Inter', fontWeight: FontWeight.w600),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        if (log['details'] != null)
                          _buildActivityDetails(log['details']),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActivityDetails(Map<String, dynamic> details) {
    return Container(
      margin: const EdgeInsets.only(top: 8, left: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.grey,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: details.entries.map((entry) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "${entry.key}:",
                  style: TextStyle(color: NeoBrutalismColors.darkGrey, fontSize: 11, fontWeight: FontWeight.w700, fontFamily: 'Inter')),
                const SizedBox(width: 5),
                Expanded(
                  child: Text(
                    entry.value.toString(),
                    style: TextStyle(color: NeoBrutalismColors.black, fontSize: 11, fontFamily: 'Inter', fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Color _getActivityColor(String? activity) {
    if (activity == null) return NeoBrutalismColors.darkGrey;
    if (activity.contains('Bug') || activity.contains('Attack') || activity.contains('Delete') || activity.contains('Failed')) return NeoBrutalismColors.pink;
    if (activity.contains('Call')) return NeoBrutalismColors.yellow;
    if (activity.contains('Create') || activity.contains('Add')) return NeoBrutalismColors.green;
    if (activity.contains('Edit') || activity.contains('Change')) return NeoBrutalismColors.blue;
    if (activity.contains('Cooldown')) return NeoBrutalismColors.purple;
    return NeoBrutalismColors.darkGrey;
  }

  IconData _getActivityIcon(String? activity) {
    if (activity == null) return Icons.info;
    if (activity.contains('Bug') || activity.contains('Attack')) return Icons.bug_report;
    if (activity.contains('Call')) return Icons.phone;
    if (activity.contains('Create') || activity.contains('Add')) return Icons.person_add;
    if (activity.contains('Delete')) return Icons.delete;
    if (activity.contains('Edit') || activity.contains('Change')) return Icons.edit;
    if (activity.contains('Cooldown')) return Icons.timer;
    if (activity.contains('DDOS')) return Icons.flash_on;
    return Icons.info;
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    if (difference.inDays > 0) return '${difference.inDays}d ago';
    if (difference.inHours > 0) return '${difference.inHours}h ago';
    if (difference.inMinutes > 0) return '${difference.inMinutes}m ago';
    return 'Just now';
  }

  // ==================== DRAWER ====================
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: NeoBrutalismColors.white,
      width: MediaQuery.of(context).size.width * 0.82,
      child: Column(
        children: [
          Container(
            height: 180,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: NeoBrutalismColors.purple,
              border: Border(
                bottom: BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
              ),
              boxShadow: [
                BoxShadow(
                  color: NeoBrutalismColors.black.withOpacity(0.1),
                  offset: const Offset(4, 4),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.15),
                          offset: const Offset(6, 6),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(7),
                      child: _profileImage != null
                          ? Image.file(
                              _profileImage!,
                              width: 64,
                              height: 64,
                              fit: BoxFit.cover,
                            )
                          : Image.asset(
                              'assets/images/profil.jpg',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(Icons.person, color: NeoBrutalismColors.darkGrey, size: 30),
                            ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    username,
                    style: const TextStyle(
                      color: NeoBrutalismColors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Inter',
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.white,
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                      borderRadius: BorderRadius.circular(6),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.1),
                          offset: const Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: Text(
                      role.toUpperCase(),
                      style: const TextStyle(
                        color: NeoBrutalismColors.black,
                        fontSize: 8,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Inter',
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
              children: [
                _buildDrawerItem(
                  icon: Icons.admin_panel_settings,
                  label: "Admin Page",
                  color: NeoBrutalismColors.purple,
                  onTap: () => _selectFromDrawer('admin'),
                  isVisible: ["dev", "high_pt", "pt", "helper", "admin"].contains(role.toLowerCase()),
                ),
                _buildDrawerItem(
                  icon: Icons.store,
                  label: "Reseller Page",
                  color: NeoBrutalismColors.blue,
                  onTap: () => _selectFromDrawer('reseller'),
                  isVisible: ["dev", "high_pt", "pt", "helper", "admin"].contains(role.toLowerCase()),
                ),
                _buildDrawerItem(
                  icon: Icons.bug_report,
                  label: "Sender Page",
                  color: NeoBrutalismColors.yellow,
                  onTap: () => _selectFromDrawer('sender'),
                  isVisible: true,
                ),
                const Divider(color: NeoBrutalismColors.borderColor, thickness: 2),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.grey,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                        ),
                        child: ClipOval(
                          child: Image.network(
                            "https://files.catbox.moe/csc5an.jpg",
                            width: 36,
                            height: 36,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              width: 36,
                              height: 36,
                              color: NeoBrutalismColors.purple,
                              child: const Icon(Icons.person, color: NeoBrutalismColors.white, size: 18),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Rizzisreal01",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                                fontFamily: 'Inter',
                              ),
                            ),
                            Text(
                              "Support dev",
                              style: TextStyle(
                                color: NeoBrutalismColors.darkGrey,
                                fontSize: 11,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.grey,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                        ),
                        child: ClipOval(
                          child: Image.network(
                            "https://files.catbox.moe/fm3vby.jpg",
                            width: 36,
                            height: 36,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              width: 36,
                              height: 36,
                              color: NeoBrutalismColors.blue,
                              child: const Icon(Icons.person, color: NeoBrutalismColors.white, size: 18),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "CH RXT COMMUNITY",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                                fontFamily: 'Inter',
                              ),
                            ),
                            Text(
                              "Channel real RXT",
                              style: TextStyle(
                                color: NeoBrutalismColors.darkGrey,
                                fontSize: 11,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                _buildDrawerItem(
                  icon: Icons.logout,
                  label: "Log Out",
                  color: NeoBrutalismColors.pink,
                  onTap: () async {
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (mounted) {
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    }
                  },
                  isVisible: true,
                  isLogout: true,
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
              ),
            ),
            child: const Text(
              'SXD PROJECT © 2026',
              style: TextStyle(
                color: NeoBrutalismColors.darkGrey,
                fontSize: 9,
                fontWeight: FontWeight.w700,
                fontFamily: 'Inter',
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
    required bool isVisible,
    bool isLogout = false,
  }) {
    if (!isVisible) return const SizedBox.shrink();
    
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 3),
      decoration: BoxDecoration(
        color: isLogout ? NeoBrutalismColors.pink.withOpacity(0.1) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: isLogout ? Border.all(color: NeoBrutalismColors.pink, width: 2) : null,
      ),
      child: ListTile(
        dense: true,
        leading: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: isLogout ? NeoBrutalismColors.pink : color,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
          ),
          child: Icon(icon, color: NeoBrutalismColors.white, size: 16),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? NeoBrutalismColors.pink : NeoBrutalismColors.black,
            fontWeight: FontWeight.w700,
            fontSize: 13,
            fontFamily: 'Inter',
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          color: isLogout ? NeoBrutalismColors.pink : NeoBrutalismColors.darkGrey,
          size: 10,
        ),
        onTap: onTap,
      ),
    );
  }

  // ==================== BOTTOM NAVIGATION ====================
  List<BottomNavigationBarItem> _buildBottomNavBarItems() {
    List<BottomNavigationBarItem> items = [
      const BottomNavigationBarItem(
        icon: Icon(Icons.home_rounded, size: 24),
        label: "Home",
      ),
      const BottomNavigationBarItem(
        icon: Icon(Icons.shield, size: 24),
        label: "Spam",
      ),
      BottomNavigationBarItem(
        key: _bugButtonKey,
        icon: const Icon(Icons.bug_report, size: 24),
        label: "Bug",
      ),
      const BottomNavigationBarItem(
        icon: Icon(Icons.build, size: 24),
        label: "Tools",
      ),
      const BottomNavigationBarItem(
        icon: Icon(Icons.person, size: 24),
        label: "Profile",
      ),
    ];
    return items;
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;
    
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: _backgroundColor,
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 90),
              child: FadeTransition(
                opacity: _animation,
                child: _selectedPage,
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: _buildDynamicAppBar(),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.fromLTRB(16, 0, 16, 16 + bottomPadding),
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
        decoration: BoxDecoration(
          color: NeoBrutalismColors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
          boxShadow: [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.15),
              offset: const Offset(6, 6),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(5, (index) {
            final icons = [
              Icons.home_rounded,
              Icons.shield,
              Icons.bug_report,
              Icons.build,
              Icons.person,
            ];
            final labels = ["Home", "Spam", "Bug", "Tools", "Profile"];
            final isActive = _selectedIndex == index;
            
            return GestureDetector(
              onTap: () => _onTabSelected(index),
              child: Container(
                padding: EdgeInsets.symmetric(
                  horizontal: isActive ? 14 : 8,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: isActive ? NeoBrutalismColors.yellow : Colors.transparent,
                  borderRadius: BorderRadius.circular(14),
                  border: isActive ? Border.all(color: NeoBrutalismColors.borderColor, width: 2) : null,
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      icons[index],
                      color: isActive ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
                      size: isActive ? 20 : 18,
                    ),
                    if (isActive) ...[
                      const SizedBox(width: 4),
                      Text(
                        labels[index],
                        style: const TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _mediaAutoSlideTimer?.cancel();
    _newsAutoSlideTimer?.cancel();
    _btcTimer?.cancel();
    _clockTimer?.cancel();
    _typingTimer?.cancel();
    _audioPlayer.dispose();
    _spinController.dispose();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _mediaPageController.dispose();
    _newsPageController.dispose();
    _videoController?.dispose();
    super.dispose();
  }
}

// ==================== FOLD LINE PAINTER ====================
class _FoldLinePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    canvas.drawLine(
      Offset(0, size.height),
      Offset(size.width, 0),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ==================== BTC CHART PAINTER ====================
class BTCChartPainter extends CustomPainter {
  final List<double> prices;
  final Color color;

  BTCChartPainter({required this.prices, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    if (prices.length < 2) return;

    final paint = Paint()
      ..color = color
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final minPrice = prices.reduce(min);
    final maxPrice = prices.reduce(max);
    final range = maxPrice - minPrice;

    final path = Path();
    final step = size.width / (prices.length - 1);

    for (int i = 0; i < prices.length; i++) {
      final x = i * step;
      final y = size.height - ((prices[i] - minPrice) / range) * size.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(BTCChartPainter oldDelegate) {
    return oldDelegate.prices != prices || oldDelegate.color != color;
  }
}

/// Widget Media (gambar/video dengan audio) - FOTO FULL LEBAR PRESISI
class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(1.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return const Center(child: CircularProgressIndicator(color: NeoBrutalismColors.purple));
      }
    } else {
      return Image.network(
        widget.url,
        width: double.infinity,
        height: double.infinity,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: NeoBrutalismColors.grey),
      );
    }
  }
}