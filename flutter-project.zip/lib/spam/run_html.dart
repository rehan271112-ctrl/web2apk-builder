import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

class RunHtmlPage extends StatefulWidget {
  const RunHtmlPage({super.key});

  @override
  State<RunHtmlPage> createState() => _RunHtmlPageState();
}

class _RunHtmlPageState extends State<RunHtmlPage> {
  // ===== CONTROLLERS =====
  late TextEditingController _codeController;
  late WebViewController _webViewController;
  final ScrollController _scrollController = ScrollController();

  // ===== STATE =====
  String _statusText = 'Ready';
  String _statusType = 'ready'; // ready, running, error, success
  int _charCount = 0;
  bool _isRunning = false;
  bool _isFullscreen = false;
  bool _hasCode = false;

  // ===== SAMPLE CODE =====
  final String _sampleCode = '''<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halo, World!</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', system-ui, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #0f172a, #1e293b);
            color: #f1f5f9;
            padding: 20px;
        }
        .card {
            max-width: 500px;
            width: 100%;
            padding: 32px 28px;
            border-radius: 20px;
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.06);
            backdrop-filter: blur(12px);
            box-shadow: 0 20px 60px rgba(0,0,0,0.4);
            text-align: center;
        }
        h1 {
            font-size: 32px;
            font-weight: 800;
            background: linear-gradient(135deg, #38bdf8, #a855f7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 12px;
        }
        p {
            color: #94a3b8;
            font-size: 16px;
            line-height: 1.7;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            padding: 12px 32px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #38bdf8, #a855f7);
            color: #fff;
            font-weight: 700;
            font-size: 15px;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
            box-shadow: 0 4px 20px rgba(56, 189, 248, 0.2);
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(56, 189, 248, 0.3);
        }
        .btn:active {
            transform: scale(0.96);
        }
        .badge {
            display: inline-block;
            margin-top: 16px;
            padding: 4px 14px;
            border-radius: 20px;
            background: rgba(56, 189, 248, 0.1);
            border: 1px solid rgba(56, 189, 248, 0.15);
            color: #38bdf8;
            font-size: 12px;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>🚀 Hello, World!</h1>
        <p>Selamat datang di <strong>RUN HTML</strong>. Kode HTML ini berhasil dijalankan secara real-time.</p>
        <button class="btn" onclick="alert('Halo dari JavaScript! 🎉')">Klik Saya</button>
        <div class="badge">✅ Live Preview</div>
    </div>
    <script>
        console.log('Selamat datang di RUN HTML!');
        console.log('Kode berhasil dijalankan.');
    </script>
</body>
</html>''';

  // ===== WARNA TEMA =====
  static const Color primaryColor = Color(0xFF00E5FF);
  static const Color secondaryColor = Color(0xFF7C4DFF);
  static const Color darkBg = Color(0xFF0A0E1A);
  static const Color cardBg = Color(0xFF121D3A);
  static const Color textColor = Color(0xFFE2E8F0);

  @override
  void initState() {
    super.initState();
    _codeController = TextEditingController(text: _sampleCode);
    _charCount = _sampleCode.length;
    _hasCode = true;

    // Inisialisasi WebView
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFFFFFFF))
      ..enableZoom(true)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (String url) {
            if (_statusType == 'running') {
              setStatus('Code berhasil dijalankan', 'success');
            }
          },
          onWebResourceError: (WebResourceError error) {
            setStatus('Preview error: ${error.description}', 'error');
            _showToast('⚠️ Error: ${error.description}', true);
          },
        ),
      );

    // Auto-run sample code
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _runCode();
    });
  }

  @override
  void dispose() {
    _codeController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ===== SET STATUS =====
  void setStatus(String text, String type) {
    setState(() {
      _statusText = text;
      _statusType = type;
    });
  }

  // ===== TOAST =====
  void _showToast(String message, bool isError) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red.shade800 : Colors.green.shade800,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // ===== RUN CODE =====
  void _runCode() {
    final String code = _codeController.text.trim();

    if (code.isEmpty) {
      _showToast('Masukkan kode HTML terlebih dahulu!', true);
      setStatus('Error: Kode kosong', 'error');
      return;
    }

    setStatus('Running...', 'running');
    _isRunning = true;

    try {
      // Load HTML ke WebView
      final String htmlContent = '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <base target="_blank">
</head>
<body style="margin:0;padding:0;height:100%;">
    $code
</body>
</html>
''';

      _webViewController.loadHtmlString(htmlContent);
      setStatus('Code berhasil dijalankan', 'success');
      _showToast('✅ Code berhasil dijalankan', false);

    } catch (e) {
      setStatus('Preview error', 'error');
      _showToast('⚠️ Error: ${e.toString()}', true);

      // Tampilkan error di WebView
      _webViewController.loadHtmlString('''
<!DOCTYPE html>
<html>
<head><style>
body{font-family:system-ui;background:#1a1a2e;color:#ef4444;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;padding:20px;text-align:center;}
div{max-width:500px;}
h2{font-size:24px;margin-bottom:12px;}
p{color:#f87171;font-size:14px;}
.sub{color:#6b7280;font-size:13px;margin-top:8px;}
</style></head>
<body>
<div>
    <h2>⚠️ Error</h2>
    <p>${e.toString()}</p>
    <p class="sub">Periksa kode HTML Anda.</p>
</div>
</body>
</html>
''');
    } finally {
      _isRunning = false;
    }
  }

  // ===== REFRESH =====
  void _refreshPreview() {
    final String code = _codeController.text.trim();
    if (code.isEmpty) {
      _showToast('Tidak ada kode untuk di-refresh', true);
      return;
    }
    _runCode();
  }

  // ===== CLEAR =====
  void _clearCode() {
    if (_codeController.text.trim().isEmpty) {
      _showToast('Editor sudah kosong', false);
      return;
    }
    setState(() {
      _codeController.clear();
      _charCount = 0;
      _hasCode = false;
    });
    setStatus('Ready', 'ready');
    _webViewController.loadHtmlString('<html><body style="background:#0A0E1A;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;color:rgba(255,255,255,0.1);font-family:system-ui;font-size:14px;"><p>Kode HTML akan ditampilkan di sini</p></body></html>');
    _showToast('🗑️ Kode dihapus', false);
  }

  // ===== COPY =====
  void _copyCode() {
    final String code = _codeController.text;
    if (code.trim().isEmpty) {
      _showToast('Tidak ada kode untuk disalin', true);
      return;
    }
    Clipboard.setData(ClipboardData(text: code));
    _showToast('📋 Kode disalin ke clipboard', false);
  }

  // ===== FULLSCREEN =====
  void _toggleFullscreen() {
    final String code = _codeController.text.trim();
    if (code.isEmpty) {
      _showToast('Tidak ada kode untuk ditampilkan', true);
      return;
    }

    setState(() {
      _isFullscreen = !_isFullscreen;
    });

    if (_isFullscreen) {
      showDialog(
        context: context,
        barrierColor: Colors.black.withOpacity(0.92),
        barrierDismissible: true,
        builder: (context) => FullscreenPreviewDialog(
          htmlCode: code,
          onClose: () {
            setState(() {
              _isFullscreen = false;
            });
          },
        ),
      ).then((_) {
        setState(() {
          _isFullscreen = false;
        });
      });
    }
  }

  // ===== BUILD =====
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      appBar: AppBar(
        title: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [primaryColor, secondaryColor],
                ),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Center(
                child: Text(
                  '▶',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'RUN HTML',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.5,
                  ),
                ),
                Text(
                  'HTML Code Runner & Preview',
                  style: TextStyle(
                    fontSize: 10,
                    color: Colors.white.withOpacity(0.35),
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ],
        ),
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.04),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.white.withOpacity(0.06),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _statusType == 'running'
                        ? Colors.amber
                        : _statusType == 'error'
                            ? Colors.red
                            : _statusType == 'success'
                                ? Colors.green
                                : Colors.grey,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _statusText,
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.white.withOpacity(0.5),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
        backgroundColor: darkBg,
        elevation: 0,
        centerTitle: false,
        systemOverlayStyle: SystemUiOverlayStyle.light,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final bool isWide = constraints.maxWidth > 820;
              return Column(
                children: [
                  Expanded(
                    child: isWide
                        ? Row(
                            children: [
                              Expanded(
                                child: _buildEditorCard(),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _buildPreviewCard(),
                              ),
                            ],
                          )
                        : Column(
                            children: [
                              Expanded(
                                child: _buildEditorCard(),
                              ),
                              const SizedBox(height: 12),
                              Expanded(
                                child: _buildPreviewCard(),
                              ),
                            ],
                          ),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  // ===== EDITOR CARD =====
  Widget _buildEditorCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.code,
                      size: 16,
                      color: Colors.white.withOpacity(0.3),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Editor HTML',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white.withOpacity(0.4),
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                _buildActionButton(
                  icon: Icons.delete_outline,
                  label: 'Clear',
                  onTap: _clearCode,
                ),
                const SizedBox(width: 4),
                _buildActionButton(
                  icon: Icons.copy_outlined,
                  label: 'Copy',
                  onTap: _copyCode,
                ),
                const SizedBox(width: 4),
                _buildActionButton(
                  icon: Icons.play_arrow,
                  label: '▶ Run',
                  onTap: _runCode,
                  color: primaryColor,
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: TextField(
                controller: _codeController,
                maxLines: null,
                expands: true,
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 13,
                  height: 1.7,
                  color: Color(0xFFE2E8F0),
                ),
                decoration: InputDecoration(
                  hintText: 'Paste code HTML Anda di sini...',
                  hintStyle: TextStyle(
                    color: Colors.white.withOpacity(0.12),
                    fontFamily: 'monospace',
                  ),
                  filled: true,
                  fillColor: Colors.black.withOpacity(0.35),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.all(14),
                ),
                onChanged: (value) {
                  setState(() {
                    _charCount = value.length;
                    _hasCode = value.trim().isNotEmpty;
                  });
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '$_charCount karakter',
                  style: TextStyle(
                    fontSize: 10,
                    color: Colors.white.withOpacity(0.12),
                    fontFamily: 'monospace',
                  ),
                ),
                Text(
                  'Ctrl+Enter untuk menjalankan',
                  style: TextStyle(
                    fontSize: 10,
                    color: Colors.white.withOpacity(0.08),
                    fontFamily: 'monospace',
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isRunning ? null : _runCode,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  backgroundColor: const Color(0xFF00E5FF),
                  foregroundColor: Colors.white,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  disabledBackgroundColor: Colors.white.withOpacity(0.1),
                ),
                child: _isRunning
                    ? const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(width: 10),
                          Text(
                            'Menjalankan...',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ],
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.play_arrow, size: 18),
                          SizedBox(width: 8),
                          Text(
                            'JALANKAN KODE HTML',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              letterSpacing: 0.6,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===== PREVIEW CARD =====
  Widget _buildPreviewCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.06),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.visibility_outlined,
                      size: 16,
                      color: Colors.white.withOpacity(0.3),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      'Preview',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white.withOpacity(0.4),
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                _buildActionButton(
                  icon: Icons.refresh,
                  label: 'Refresh',
                  onTap: _refreshPreview,
                ),
                const SizedBox(width: 4),
                _buildActionButton(
                  icon: Icons.fullscreen,
                  label: 'Fullscreen',
                  onTap: _toggleFullscreen,
                ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  color: Colors.white,
                  child: WebViewWidget(
                    controller: _webViewController,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  // ===== ACTION BUTTON =====
  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color? color,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(6),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: Colors.white.withOpacity(0.04),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 13,
              color: color ?? Colors.white.withOpacity(0.3),
            ),
            const SizedBox(width: 3),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: color ?? Colors.white.withOpacity(0.3),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ===== FULLSCREEN PREVIEW DIALOG =====
class FullscreenPreviewDialog extends StatefulWidget {
  final String htmlCode;
  final VoidCallback onClose;

  const FullscreenPreviewDialog({
    super.key,
    required this.htmlCode,
    required this.onClose,
  });

  @override
  State<FullscreenPreviewDialog> createState() => _FullscreenPreviewDialogState();
}

class _FullscreenPreviewDialogState extends State<FullscreenPreviewDialog> {
  late WebViewController _fsWebViewController;

  @override
  void initState() {
    super.initState();
    _fsWebViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFFFFFFFF))
      ..enableZoom(true)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (String url) {},
          onWebResourceError: (WebResourceError error) {
            // Handle error if needed
          },
        ),
      );

    // Load HTML setelah controller siap
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final String htmlContent = '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;height:100%;">
    ${widget.htmlCode}
</body>
</html>
''';
      _fsWebViewController.loadHtmlString(htmlContent);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(8),
      backgroundColor: Colors.transparent,
      child: Container(
        width: double.infinity,
        height: MediaQuery.of(context).size.height * 0.92,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: Colors.white.withOpacity(0.06),
          ),
        ),
        child: Stack(
          children: [
            WebViewWidget(
              controller: _fsWebViewController,
            ),
            Positioned(
              top: 14,
              right: 16,
              child: InkWell(
                onTap: () {
                  widget.onClose();
                  Navigator.pop(context);
                },
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.05),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Icon(
                        Icons.close,
                        color: Colors.white,
                        size: 18,
                      ),
                      SizedBox(width: 6),
                      Text(
                        'Tutup',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}