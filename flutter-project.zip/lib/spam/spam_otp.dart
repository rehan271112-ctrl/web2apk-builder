import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../server/domain_server.dart' show baseUrl;

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    const spacing = 30.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

const String MIYABI_BRAND = "MIYABI";

class SpamOtpPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const SpamOtpPage({
    Key? key,
    required this.sessionKey,
    required this.username,
    required this.role,
  }) : super(key: key);

  @override
  State<SpamOtpPage> createState() => _SpamOtpPageState();
}

class _SpamOtpPageState extends State<SpamOtpPage> {
  static String get BASE => baseUrl;
  static String get OTP_SPAM_URL => "$BASE/api/spamotp/send";
  static String get HEALTH_URL => "$BASE/api/spamotp/health";

  final TextEditingController _phoneController = TextEditingController();

  bool _isLoading = false;
  bool _serverOnline = false;
  String _statusMessage = "Mengecek server...";
  String _currentStatus = "Menunggu...";

  int _successCount = 0;
  int _failCount = 0;
  int _totalApiCount = 25;
  int _processedCount = 0;

  final List<Map<String, dynamic>> _logs = [];
  final ScrollController _logScrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _checkServer();
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _neoButton({
    required String label,
    required VoidCallback onTap,
    Color bg = NeoBrutalismColors.yellow,
    Color textColor = NeoBrutalismColors.black,
    double fontSize = 14,
    bool isLoading = false,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
          boxShadow: [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.1),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    color: textColor,
                    strokeWidth: 2.5,
                  ),
                )
              : Text(
                  label,
                  style: TextStyle(
                    fontSize: fontSize,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                    color: textColor,
                    fontFamily: 'Inter',
                  ),
                ),
        ),
      ),
    );
  }

  Future<void> _checkServer() async {
    try {
      final res = await http.get(
        Uri.parse(HEALTH_URL),
        headers: _buildHeaders(),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        setState(() {
          _serverOnline = true;
          _statusMessage = "ONLINE";
          _currentStatus = "Server siap";
        });
      } else {
        throw Exception("Server offline");
      }
    } catch (e) {
      setState(() {
        _serverOnline = false;
        _statusMessage = "OFFLINE";
        _currentStatus = "Server tidak terhubung";
      });
    }
  }

  Future<void> _executeSpam() async {
    if (_phoneController.text.isEmpty) {
      _addLog("❌ Nomor target wajib diisi!", true);
      return;
    }

    String phone = _formatPhone(_phoneController.text);
    if (!phone.startsWith("+62")) {
      _addLog("❌ Format nomor harus +62xxx!", true);
      return;
    }

    setState(() {
      _isLoading = true;
      _successCount = 0;
      _failCount = 0;
      _processedCount = 0;
      _logs.clear();
      _currentStatus = "🚀 Memulai spam...";
      _addLog("🚀 Memulai spam OTP ke $phone", false);
      _addLog("📋 Mengirim ke 25 API...", false);
    });

    try {
      final payload = {"phone": phone, "username": widget.username};
      final response = await http.post(
        Uri.parse(OTP_SPAM_URL),
        headers: _buildHeaders(),
        body: jsonEncode(payload),
      ).timeout(const Duration(seconds: 180));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        if (data['success'] == true) {
          final results = data['results'] ?? {};
          final success = results['success'] ?? 0;
          final failed = results['failed'] ?? 0;
          final details = results['details'] ?? [];

          setState(() {
            _successCount = success;
            _failCount = failed;
            _processedCount = success + failed;
            _currentStatus = "✅ Selesai! $success berhasil, $failed gagal";
          });

          _addLog("✅ ===== SPAM OTP SELESAI =====", false);
          _addLog("📊 Berhasil: $success | Gagal: $failed | Total: ${success + failed}", false);
          _addLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━", false);

          for (var detail in details) {
            final apiName = detail['api'] ?? 'Unknown';
            final status = detail['status'] ?? 'UNKNOWN';
            if (status == 'SUCCESS') {
              _addLog("✅ $apiName: BERHASIL", false);
            } else {
              final error = detail['error'] ?? 'Gagal';
              _addLog("❌ $apiName: GAGAL - $error", true);
            }
          }

          _addLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━", false);
          _addLog("✅ Selesai! ${success + failed} API dieksekusi", false);
        } else {
          final msg = data['message'] ?? 'Gagal mengirim spam';
          _addLog("❌ Error: $msg", true);
          setState(() => _currentStatus = "❌ Gagal: $msg");
        }
      } else {
        final msg = data['message'] ?? 'Server error (${response.statusCode})';
        _addLog("❌ Server error: $msg", true);
        setState(() => _currentStatus = "❌ Server error");
      }
    } catch (e) {
      _addLog("❌ Error: ${e.toString().replaceAll('Exception: ', '')}", true);
      setState(() {
        _currentStatus = "❌ Error: ${e.toString().replaceAll('Exception: ', '').substring(0, 30)}...";
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _addLog(String msg, bool isError) {
    if (!mounted) return;
    setState(() {
      _logs.insert(0, {
        "message": msg,
        "time": DateTime.now().toString().substring(11, 19),
        "isError": isError,
      });
    });
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_logScrollController.hasClients) {
        _logScrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  String _formatPhone(String input) {
    String digits = input.replaceAll(RegExp(r'[^\d]'), '');
    if (digits.startsWith('0')) return '+62${digits.substring(1)}';
    if (digits.startsWith('62')) return '+$digits';
    return '+$digits';
  }

  Map<String, String> _buildHeaders() {
    return {
      'Content-Type': 'application/json',
      'x-session-key': widget.sessionKey,
      'x-username': widget.username,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ===== HEADER (TANPA BACK BUTTON) =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.purple,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.shield,
                          color: NeoBrutalismColors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Spam OTP",
                        style: TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _serverOnline
                              ? NeoBrutalismColors.green.withOpacity(0.15)
                              : NeoBrutalismColors.pink.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: _serverOnline ? NeoBrutalismColors.green : NeoBrutalismColors.pink,
                            width: 2,
                          ),
                        ),
                        child: Text(
                          _statusMessage,
                          style: TextStyle(
                            color: _serverOnline ? NeoBrutalismColors.green : NeoBrutalismColors.pink,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),

                  // ===== STATUS CARD =====
                  _neoCard(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _isLoading
                                ? NeoBrutalismColors.yellow.withOpacity(0.15)
                                : _successCount > 0
                                    ? NeoBrutalismColors.green.withOpacity(0.15)
                                    : NeoBrutalismColors.grey,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: _isLoading
                                  ? NeoBrutalismColors.yellow
                                  : _successCount > 0
                                      ? NeoBrutalismColors.green
                                      : NeoBrutalismColors.darkGrey,
                              width: 2,
                            ),
                          ),
                          child: Icon(
                            _isLoading
                                ? Icons.hourglass_top
                                : _successCount > 0
                                    ? Icons.check_circle
                                    : Icons.info,
                            color: _isLoading
                                ? NeoBrutalismColors.yellow
                                : _successCount > 0
                                    ? NeoBrutalismColors.green
                                    : NeoBrutalismColors.darkGrey,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            _currentStatus,
                            style: TextStyle(
                              color: _isLoading
                                  ? NeoBrutalismColors.yellow
                                  : _successCount > 0
                                      ? NeoBrutalismColors.green
                                      : NeoBrutalismColors.darkGrey,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ),
                        if (_isLoading)
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: NeoBrutalismColors.purple,
                              strokeWidth: 2,
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // ===== INPUT FORM =====
                  _neoCard(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "MASUKKAN NOMOR TARGET",
                          style: TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 10),
                        TextField(
                          controller: _phoneController,
                          keyboardType: TextInputType.phone,
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(RegExp(r'[0-9\+]'))
                          ],
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter',
                          ),
                          cursorColor: NeoBrutalismColors.black,
                          decoration: InputDecoration(
                            hintText: "contoh: +6281234567890",
                            hintStyle: TextStyle(
                              color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
                              fontFamily: 'Inter',
                              fontWeight: FontWeight.w600,
                            ),
                            filled: true,
                            fillColor: NeoBrutalismColors.grey,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
                            ),
                            contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                            prefixIcon: Icon(
                              Icons.phone,
                              color: NeoBrutalismColors.darkGrey,
                              size: 20,
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        _neoButton(
                          label: "SPAM ALL (25 API)",
                          onTap: _executeSpam,
                          bg: NeoBrutalismColors.yellow,
                          textColor: NeoBrutalismColors.black,
                          fontSize: 14,
                          isLoading: _isLoading || !_serverOnline,
                        ),
                        const SizedBox(height: 8),
                        if (!_serverOnline)
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.pink.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: NeoBrutalismColors.pink, width: 1),
                            ),
                            child: const Row(
                              children: [
                                Icon(Icons.warning, color: NeoBrutalismColors.pink, size: 14),
                                SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    "Server tidak terhubung. Periksa koneksi.",
                                    style: TextStyle(
                                      color: NeoBrutalismColors.pink,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),

                  // ===== COUNTERS =====
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _buildCounter("Berhasil", _successCount, NeoBrutalismColors.green),
                      _buildCounter("Gagal", _failCount, NeoBrutalismColors.pink),
                      _buildCounter("Proses", _processedCount, NeoBrutalismColors.purple),
                      _buildCounter("Total", _totalApiCount, NeoBrutalismColors.darkGrey),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // ===== PROGRESS BAR =====
                  Container(
                    height: 6,
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.grey,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: LinearProgressIndicator(
                        value: _totalApiCount > 0
                            ? (_processedCount / _totalApiCount).clamp(0.0, 1.0)
                            : 0.0,
                        backgroundColor: Colors.transparent,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _processedCount == 0
                              ? NeoBrutalismColors.darkGrey
                              : _successCount > 0
                                  ? NeoBrutalismColors.green
                                  : NeoBrutalismColors.yellow,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== LOG =====
                  Container(
                    height: 220,
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.08),
                          offset: const Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(color: NeoBrutalismColors.borderColor.withOpacity(0.3)),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Icon(
                                    Icons.terminal,
                                    color: NeoBrutalismColors.purple,
                                    size: 16,
                                  ),
                                  const SizedBox(width: 8),
                                  const Text(
                                    "Log Aktivitas",
                                    style: TextStyle(
                                      color: NeoBrutalismColors.black,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                ],
                              ),
                              if (_logs.isNotEmpty)
                                GestureDetector(
                                  onTap: () {
                                    setState(() {
                                      _logs.clear();
                                      _successCount = 0;
                                      _failCount = 0;
                                      _processedCount = 0;
                                      _currentStatus = "Log dibersihkan";
                                    });
                                  },
                                  child: Text(
                                    "Hapus Log",
                                    style: TextStyle(
                                      color: NeoBrutalismColors.pink,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w700,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: _logs.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.terminal_outlined,
                                        color: NeoBrutalismColors.darkGrey.withOpacity(0.3),
                                        size: 40,
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        "Belum ada aktivitas spam",
                                        style: TextStyle(
                                          color: NeoBrutalismColors.darkGrey.withOpacity(0.5),
                                          fontFamily: 'Inter',
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      Text(
                                        "Masukkan nomor dan klik SPAM ALL",
                                        style: TextStyle(
                                          color: NeoBrutalismColors.darkGrey.withOpacity(0.3),
                                          fontFamily: 'Inter',
                                          fontSize: 10,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              : ListView.builder(
                                  controller: _logScrollController,
                                  padding: const EdgeInsets.all(8),
                                  itemCount: _logs.length,
                                  reverse: true,
                                  itemBuilder: (context, index) {
                                    final log = _logs[index];
                                    final isError = log['isError'] ?? false;
                                    final msg = log['message'] ?? '';
                                    final time = log['time'] ?? '--:--:--';
                                    final isSeparator = msg.contains('━━━');

                                    return Container(
                                      margin: const EdgeInsets.symmetric(vertical: 1),
                                      padding: EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: isSeparator ? 4 : 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: isSeparator
                                            ? Colors.transparent
                                            : isError
                                                ? NeoBrutalismColors.pink.withOpacity(0.08)
                                                : NeoBrutalismColors.green.withOpacity(0.05),
                                        borderRadius: BorderRadius.circular(4),
                                        border: isSeparator
                                            ? null
                                            : Border.all(
                                                color: isError
                                                    ? NeoBrutalismColors.pink.withOpacity(0.2)
                                                    : NeoBrutalismColors.green.withOpacity(0.15),
                                              ),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            time,
                                            style: TextStyle(
                                              color: NeoBrutalismColors.darkGrey.withOpacity(0.5),
                                              fontSize: 9,
                                              fontFamily: 'Inter',
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Expanded(
                                            child: Text(
                                              msg,
                                              style: TextStyle(
                                                color: isSeparator
                                                    ? NeoBrutalismColors.darkGrey.withOpacity(0.3)
                                                    : isError
                                                        ? NeoBrutalismColors.pink
                                                        : NeoBrutalismColors.black,
                                                fontSize: isSeparator ? 10 : 12,
                                                fontFamily: 'Inter',
                                                fontWeight: isSeparator
                                                    ? FontWeight.w400
                                                    : FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== COPYRIGHT =====
                  const Column(
                    children: [
                      SizedBox(
                        width: 40,
                        height: 3,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: NeoBrutalismColors.borderColor,
                          ),
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: NeoBrutalismColors.darkGrey,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCounter(String label, int count, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.06),
            offset: const Offset(3, 3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            label == "Berhasil"
                ? Icons.check_circle
                : label == "Gagal"
                    ? Icons.cancel
                    : label == "Proses"
                        ? Icons.play_arrow
                        : Icons.info_outline,
            color: color,
            size: 14,
          ),
          const SizedBox(width: 6),
          Text(
            "$count",
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.w900,
              fontFamily: 'Inter',
              fontSize: 14,
            ),
          ),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontFamily: 'Inter',
              fontSize: 9,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}