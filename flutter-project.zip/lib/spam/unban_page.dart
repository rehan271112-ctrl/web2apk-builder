import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class UnbanPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const UnbanPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<UnbanPage> createState() => _UnbanPageState();
}

class _UnbanPageState extends State<UnbanPage> with TickerProviderStateMixin {
  final TextEditingController _nomorController = TextEditingController();

  String _selectedJenis = 'tinjau';
  bool _isLoading = false;
  String _statusMessage = '';
  bool _isSuccess = false;

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<Map<String, dynamic>> _jenisOptions = [
    {'value': 'tinjau', 'label': 'Unban Nomor Kena Tinjau', 'icon': Icons.visibility},
    {'value': 'merah', 'label': 'Unban Nomor Fix Merah', 'icon': Icons.dangerous},
    {'value': 'daftar', 'label': 'Unban Nomor Daftar Baru', 'icon': Icons.add_box},
  ];

  // ==================== TEKS UNBAN ====================
  String getTeks(String jenis, String nomor) {
    final String formattedNomor = nomor.startsWith('+') ? nomor : '+$nomor';
    
    switch (jenis) {
      case 'tinjau':
        return '''Halo Tim Dukungan WhatsApp,

Saya ingin mengajukan permohonan peninjauan kembali terhadap nomor WhatsApp saya yang saat ini terkena pemblokiran dan tidak dapat digunakan.

Nomor yang terkena pemblokiran:
$formattedNomor

Saya dengan hormat memohon kepada pihak WhatsApp untuk melakukan pemeriksaan atau peninjauan ulang terhadap status nomor tersebut. Saya memahami bahwa WhatsApp memiliki ketentuan dan kebijakan yang harus dipatuhi oleh seluruh pengguna, dan saya menghargai sistem keamanan yang diterapkan untuk menjaga keamanan serta kenyamanan pengguna.

Apabila pemblokiran ini terjadi karena adanya aktivitas yang dianggap melanggar ketentuan, saya mohon agar pihak WhatsApp dapat memberikan kesempatan kepada saya untuk memperbaiki dan memastikan penggunaan akun saya ke depannya sesuai dengan Ketentuan Layanan dan kebijakan WhatsApp.

Saya sangat membutuhkan kembali akses ke nomor tersebut karena nomor ini penting untuk komunikasi dan aktivitas sehari-hari saya. Saya juga bersedia mengikuti seluruh aturan yang berlaku dan lebih berhati-hati dalam menggunakan WhatsApp agar kejadian seperti ini tidak terulang kembali.

Saya memohon dengan sungguh-sungguh agar permohonan ini dapat dipertimbangkan dan nomor saya dapat ditinjau secara manual oleh tim terkait. Jika setelah pemeriksaan tidak ditemukan pelanggaran yang menyebabkan pemblokiran permanen, saya sangat berharap akses akun tersebut dapat dipulihkan.

Terima kasih kepada Tim Dukungan WhatsApp atas waktu, perhatian, dan kesediaannya untuk memeriksa permohonan saya.

Saya sangat menghargai bantuan dan kesempatan yang diberikan.

Hormat saya,
Pemilik nomor $formattedNomor''';

      case 'merah':
        return '''Halo Tim Dukungan WhatsApp,

Saya ingin mengajukan permohonan peninjauan terhadap nomor WhatsApp saya yang saat ini tidak dapat digunakan untuk masuk ke akun.

Nomor WhatsApp:
$formattedNomor

Saat mencoba masuk menggunakan aplikasi WhatsApp resmi, saya mendapatkan pemberitahuan bahwa saya harus menggunakan WhatsApp resmi/asli. Namun, saya ingin menegaskan bahwa saya memang menggunakan aplikasi WhatsApp resmi dan tidak menggunakan aplikasi WhatsApp modifikasi atau aplikasi tidak resmi.

Karena itu, saya memohon kepada Tim Dukungan WhatsApp untuk melakukan pemeriksaan dan peninjauan ulang terhadap nomor saya. Saya khawatir sistem keamanan WhatsApp salah mendeteksi perangkat atau aplikasi yang saya gunakan sehingga nomor saya tidak dapat login dengan normal.

Saya sangat berharap masalah ini dapat diperiksa secara manual oleh tim terkait. Saya bersedia mengikuti seluruh ketentuan dan prosedur keamanan WhatsApp yang berlaku.

Mohon bantuannya untuk memeriksa status nomor saya dan memulihkan akses login apabila memang tidak terdapat pelanggaran pada akun tersebut.

Saya sangat membutuhkan kembali akses ke nomor ini untuk komunikasi sehari-hari.

Terima kasih atas waktu, perhatian, dan bantuan dari Tim Dukungan WhatsApp.

Hormat saya,
Pemilik nomor $formattedNomor''';

      case 'daftar':
        return '''Halo Tim Dukungan WhatsApp,

Saya ingin mengajukan permohonan peninjauan terhadap nomor WhatsApp saya yang baru saja saya daftarkan, tetapi saat ini saya tidak dapat menggunakan nomor tersebut sebagaimana mestinya.

Nomor WhatsApp:
$formattedNomor

Nomor ini merupakan nomor baru yang saya daftarkan untuk menggunakan layanan WhatsApp. Saya sangat berharap Tim Dukungan WhatsApp dapat membantu memeriksa status nomor tersebut dan memastikan apakah terjadi kesalahan pada sistem keamanan atau proses pendaftaran.

Saya memohon dengan sungguh-sungguh agar nomor ini dapat ditinjau kembali dan, apabila tidak ditemukan pelanggaran, aksesnya dapat dibuka kembali secepat mungkin.

Saya memahami bahwa WhatsApp memiliki sistem keamanan dan kebijakan untuk melindungi penggunanya. Saya bersedia mematuhi seluruh Ketentuan Layanan WhatsApp dan menggunakan akun ini secara normal serta bertanggung jawab.

Saya sangat berharap proses peninjauan tidak berlangsung terlalu lama karena nomor ini ingin saya gunakan untuk kebutuhan komunikasi sehari-hari. Jika memungkinkan, saya sangat mengharapkan penyelesaian dalam waktu yang wajar dan tidak sampai berlarut-larut selama berbulan-bulan.

Mohon bantuannya untuk melakukan pemeriksaan terhadap nomor saya dan memberikan kesempatan agar nomor tersebut dapat digunakan kembali apabila memang memenuhi ketentuan WhatsApp.

Terima kasih atas perhatian, waktu, dan bantuan dari Tim Dukungan WhatsApp.

Hormat saya,
Pemilik nomor $formattedNomor''';

      default:
        return '''Halo Tim Dukungan WhatsApp,

Saya ingin mengajukan permohonan peninjauan terhadap nomor WhatsApp saya yang saat ini tidak dapat digunakan.

Nomor WhatsApp:
$formattedNomor

Mohon bantuannya untuk melakukan peninjauan terhadap nomor saya.

Terima kasih.

Hormat saya,
Pemilik nomor $formattedNomor''';
    }
  }

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..forward();

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    )..forward();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _nomorController.dispose();
    super.dispose();
  }

  String _formatNomor(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0')) {
      return '62${cleaned.substring(1)}';
    }
    if (!cleaned.startsWith('62')) {
      return '62$cleaned';
    }
    return cleaned;
  }

  Future<void> _copyAndOpenGmail() async {
    final nomor = _nomorController.text.trim();

    if (nomor.isEmpty) {
      setState(() {
        _statusMessage = '❌ Masukkan nomor WhatsApp';
        _isSuccess = false;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _statusMessage = '⏳ Menyiapkan...';
      _isSuccess = false;
    });

    final formattedNomor = _formatNomor(nomor);
    final body = getTeks(_selectedJenis, formattedNomor);
    final subject = 'Permohonan Peninjauan Nomor +$formattedNomor';

    final fullText = '''
To: support@whatsapp.com
Subject: $subject

$body
''';

    try {
      // Copy ke clipboard
      await Clipboard.setData(ClipboardData(text: fullText));
      
      // Coba buka Gmail web
      final encodedSubject = Uri.encodeComponent(subject);
      final encodedBody = Uri.encodeComponent(body);
      final gmailUrl = 'https://mail.google.com/mail/?view=cm&fs=1&to=support@whatsapp.com&su=$encodedSubject&body=$encodedBody';
      
      final uri = Uri.parse(gmailUrl);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
        setState(() {
          _statusMessage = '✅ Teks disalin & Gmail dibuka! Paste dan kirim.';
          _isSuccess = true;
        });
        _nomorController.clear();
      } else {
        setState(() {
          _statusMessage = '✅ Teks disalin! Buka Gmail manual dan paste.';
          _isSuccess = true;
        });
        _nomorController.clear();
      }
    } catch (e) {
      setState(() {
        _statusMessage = '❌ Gagal: ${e.toString()}';
        _isSuccess = false;
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _neoInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool isNumber = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: isNumber ? TextInputType.phone : TextInputType.text,
      style: const TextStyle(
        color: NeoBrutalismColors.black,
        fontSize: 14,
        fontWeight: FontWeight.w600,
        fontFamily: 'Inter',
      ),
      cursorColor: NeoBrutalismColors.black,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
          color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w600,
        ),
        prefixIcon: Icon(icon, color: NeoBrutalismColors.darkGrey, size: 18),
        filled: true,
        fillColor: NeoBrutalismColors.grey,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
      ),
    );
  }

  Widget _neoButton({
    required String label,
    required VoidCallback onTap,
    Color bg = NeoBrutalismColors.yellow,
    Color textColor = NeoBrutalismColors.black,
    bool isLoading = false,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
          boxShadow: [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.08),
              offset: const Offset(3, 3),
              blurRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    color: textColor,
                    strokeWidth: 2,
                  ),
                )
              : Text(
                  label,
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    color: textColor,
                    fontFamily: 'Inter',
                  ),
                ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          Container(
            color: NeoBrutalismColors.grey,
            child: CustomPaint(
              painter: GridPainter(),
              size: Size.infinite,
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ===== HEADER =====
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.pink,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoBrutalismColors.black.withOpacity(0.08),
                                  offset: const Offset(4, 4),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.unpublished,
                              color: NeoBrutalismColors.white,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            "Unban WhatsApp",
                            style: TextStyle(
                              color: NeoBrutalismColors.black,
                              fontSize: 20,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Inter',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        "Salin teks & buka Gmail ke support@whatsapp.com",
                        style: TextStyle(
                          color: NeoBrutalismColors.darkGrey,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter',
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ===== NOMOR WHATSAPP =====
                      _neoCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Nomor WhatsApp",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Inter',
                              ),
                            ),
                            const SizedBox(height: 8),
                            _neoInput(
                              controller: _nomorController,
                              hint: "contoh: 628xxxxxxxxxx",
                              icon: Icons.phone,
                              isNumber: true,
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "Format: 628xxxxxxxxxx (tanpa +)",
                              style: TextStyle(
                                color: NeoBrutalismColors.darkGrey.withOpacity(0.6),
                                fontSize: 10,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter',
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== PILIH JENIS =====
                      _neoCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Pilih Jenis Unban",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Inter',
                              ),
                            ),
                            const SizedBox(height: 10),
                            ..._jenisOptions.map((option) {
                              final isSelected = _selectedJenis == option['value'];
                              return GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _selectedJenis = option['value'];
                                  });
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                  margin: const EdgeInsets.only(bottom: 6),
                                  decoration: BoxDecoration(
                                    color: isSelected
                                        ? NeoBrutalismColors.yellow
                                        : NeoBrutalismColors.grey,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: isSelected
                                          ? NeoBrutalismColors.borderColor
                                          : NeoBrutalismColors.darkGrey,
                                      width: isSelected ? 2 : 1,
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(
                                        option['icon'],
                                        color: isSelected
                                            ? NeoBrutalismColors.black
                                            : NeoBrutalismColors.darkGrey,
                                        size: 20,
                                      ),
                                      const SizedBox(width: 10),
                                      Expanded(
                                        child: Text(
                                          option['label'],
                                          style: TextStyle(
                                            color: isSelected
                                                ? NeoBrutalismColors.black
                                                : NeoBrutalismColors.darkGrey,
                                            fontSize: 12,
                                            fontWeight: isSelected
                                                ? FontWeight.w800
                                                : FontWeight.w600,
                                            fontFamily: 'Inter',
                                          ),
                                        ),
                                      ),
                                      if (isSelected)
                                        const Icon(
                                          Icons.check,
                                          color: NeoBrutalismColors.black,
                                          size: 16,
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ===== UNBAN BUTTON =====
                      _neoButton(
                        label: "📋 COPY & BUKA GMAIL",
                        onTap: _copyAndOpenGmail,
                        bg: NeoBrutalismColors.yellow,
                        textColor: NeoBrutalismColors.black,
                        isLoading: _isLoading,
                      ),
                      const SizedBox(height: 10),

                      // ===== STATUS MESSAGE =====
                      if (_statusMessage.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: _isSuccess
                                ? NeoBrutalismColors.green.withOpacity(0.1)
                                : NeoBrutalismColors.pink.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: _isSuccess
                                  ? NeoBrutalismColors.green
                                  : NeoBrutalismColors.pink,
                              width: 2,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                _isSuccess ? Icons.check_circle : Icons.error_outline,
                                color: _isSuccess
                                    ? NeoBrutalismColors.green
                                    : NeoBrutalismColors.pink,
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _statusMessage,
                                  style: TextStyle(
                                    color: _isSuccess
                                        ? NeoBrutalismColors.green
                                        : NeoBrutalismColors.pink,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      const SizedBox(height: 16),

                      // ===== DIVIDER =====
                      Container(
                        height: 2,
                        color: NeoBrutalismColors.borderColor.withOpacity(0.3),
                      ),
                      const SizedBox(height: 16),

                      // ===== INFO =====
                      _neoCard(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          children: [
                            Row(
                              children: [
                                const Icon(
                                  Icons.info_outline,
                                  color: NeoBrutalismColors.blue,
                                  size: 18,
                                ),
                                const SizedBox(width: 8),
                                const Text(
                                  "Cara Penggunaan",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.black,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              "1. Masukkan nomor WhatsApp yang kena banned\n"
                              "2. Pilih jenis unban yang sesuai\n"
                              "3. Klik COPY & BUKA GMAIL\n"
                              "4. Teks otomatis tercopy\n"
                              "5. Gmail terbuka, paste dan kirim ke support@whatsapp.com",
                              style: TextStyle(
                                color: NeoBrutalismColors.darkGrey,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter',
                                height: 1.6,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ===== COPYRIGHT =====
                      Column(
                        children: [
                          Container(
                            width: 40,
                            height: 3,
                            color: NeoBrutalismColors.borderColor,
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                            style: TextStyle(
                              fontSize: 9,
                              letterSpacing: 2,
                              color: NeoBrutalismColors.darkGrey,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}