import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'background_notifier.dart';
import 'app_theme.dart';

// ─── BACKGROUND WRAPPER ────────────────────────────────────────────────────────
// Membungkus setiap halaman.
// Auto-refresh saat BackgroundNotifier ATAU ThemeNotifier berubah.
class BackgroundWrapper extends StatelessWidget {
  final Widget child;

  const BackgroundWrapper({Key? key, required this.child}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bgNotifier    = BackgroundScope.of(context);
    final themeNotifier = ThemeScope.of(context);

    // Dengarkan KEDUANYA → background + warna tema ikut update serentak
    return AnimatedBuilder(
      animation: Listenable.merge([bgNotifier, themeNotifier]),
      builder: (ctx, _) => Stack(
        fit: StackFit.expand,
        children: [
          _buildBgLayer(bgNotifier.bgType, bgNotifier.bgPath),
          // Overlay warna tema di atas background image
          // Kurangi opacity overlay saat pakai foto/video custom agar terlihat
          Container(
            color: (bgNotifier.bgType == 'image' || bgNotifier.bgType == 'video')
                ? AppColors.overlayColor.withOpacity(0.25)
                : AppColors.overlayColor,
          ),
          child,
        ],
      ),
    );
  }

  Widget _buildBgLayer(String bgType, String? bgPath) {
    if (bgType == 'image' && bgPath != null && File(bgPath).existsSync()) {
      return _ImageBackground(imagePath: bgPath);
    }
    if (bgType == 'video' && bgPath != null && File(bgPath).existsSync()) {
      return _VideoBackground(videoPath: bgPath);
    }
    return _DefaultBackground();
  }
}

// ─── DEFAULT BACKGROUND ────────────────────────────────────────────────────────
class _DefaultBackground extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Image.asset(
      kDefaultBgAsset,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => Container(color: Colors.black),
    );
  }
}

// ─── CUSTOM IMAGE BACKGROUND ──────────────────────────────────────────────────
class _ImageBackground extends StatelessWidget {
  final String imagePath;
  const _ImageBackground({required this.imagePath});

  @override
  Widget build(BuildContext context) {
    return Image.file(
      File(imagePath),
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => _DefaultBackground(),
    );
  }
}

// ─── CUSTOM VIDEO BACKGROUND ──────────────────────────────────────────────────
class _VideoBackground extends StatefulWidget {
  final String videoPath;
  const _VideoBackground({required this.videoPath});

  @override
  State<_VideoBackground> createState() => _VideoBackgroundState();
}

class _VideoBackgroundState extends State<_VideoBackground> {
  late VideoPlayerController _ctrl;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    _ctrl = VideoPlayerController.file(File(widget.videoPath));
    await _ctrl.initialize().catchError((_) {});
    if (mounted) {
      _ctrl.setLooping(true);
      _ctrl.play();
      setState(() => _ready = true);
    }
  }

  @override
  void didUpdateWidget(_VideoBackground old) {
    super.didUpdateWidget(old);
    if (old.videoPath != widget.videoPath) {
      _ctrl.dispose();
      _init();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return _ready && _ctrl.value.isInitialized
        ? VideoPlayer(_ctrl)
        : _DefaultBackground();
  }
}
