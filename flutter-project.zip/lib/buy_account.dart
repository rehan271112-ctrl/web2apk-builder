import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class BuyAccountPage extends StatelessWidget {
  const BuyAccountPage({super.key});

  final List<Map<String, dynamic>> priceList = const [
    {
      'title': 'MEMBER HARIAN',
      'price': '10K',
      'duration': '10 Hari',
      'color': NeoBrutalismColors.grey,
      'role': 'MEMBER',
    },
    {
      'title': 'MEMBER',
      'price': '15K',
      'duration': 'PERMANEN',
      'color': NeoBrutalismColors.grey,
      'role': 'MEMBER',
    },
    {
      'title': 'RESELLER',
      'price': '20K',
      'duration': 'PERMANEN',
      'color': NeoBrutalismColors.blue,
      'role': 'RESELLER',
    },
    {
      'title': 'VIP',
      'price': '25K',
      'duration': 'PERMANEN',
      'color': Colors.amber,
      'role': 'VIP',
    },
    {
      'title': 'HELPER',
      'price': '30K',
      'duration': 'PERMANEN',
      'color': NeoBrutalismColors.green,
      'role': 'HELPER',
    },
    {
      'title': 'ADMIN',
      'price': '35K',
      'duration': 'PERMANEN',
      'color': NeoBrutalismColors.blue,
      'role': 'ADMIN',
    },
    {
      'title': 'PT',
      'price': '40K',
      'duration': 'PERMANEN',
      'color': Colors.deepPurple,
      'role': 'PT',
    },
    {
      'title': 'HIGH PT',
      'price': '50K',
      'duration': 'PERMANEN',
      'color': NeoBrutalismColors.purple,
      'role': 'HIGH_PT',
    },
  ];

  final List<String> bugList = const [
    'For Close',
    'Buldo Crash Delay',
    'Freeze',
    'Blank Pack',
    'Crash Spam',
    'Delay Invis',
    'Crash Spam B0kep',
  ];

  final List<String> fiturList = const [
    'SPAM OTP',
    'SPAM WA',
    'CUSTOM BUG',
    'GROUP BUG',
    'DDOS PANEL',
    'SENDER',
  ];

  Future<void> _contactWA(BuildContext context, String title, String price) async {
    final message = 'Bang RizzKezi beli apk RZYN harga $price role $title';
    final encodedMessage = Uri.encodeComponent(message);
    final url = 'https://wa.me/6287876074328?text=$encodedMessage';
    
    try {
      final uri = Uri.parse(url);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        // Fallback
        final fallbackUrl = 'https://wa.me/6287876074328';
        final fallbackUri = Uri.parse(fallbackUrl);
        if (await canLaunchUrl(fallbackUri)) {
          await launchUrl(fallbackUri, mode: LaunchMode.externalApplication);
        }
      }
    } catch (e) {
      // ignore
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          Container(
            color: NeoBrutalismColors.grey,
            child: CustomPaint(
              painter: GridPainter(),
              size: Size.infinite,
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ===== HEADER =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.yellow,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.shopping_cart,
                          color: NeoBrutalismColors.black,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "X•R Z Y N",
                        style: TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                          letterSpacing: 2,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.pink,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                        ),
                        child: const Text(
                          'NEW PROJECT',
                          style: TextStyle(
                            color: NeoBrutalismColors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Padding(
                    padding: const EdgeInsets.only(left: 4),
                    child: Text(
                      "Pilih paket yang sesuai dengan kebutuhan Anda",
                      style: TextStyle(
                        color: NeoBrutalismColors.darkGrey,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // ===== PRICE LIST =====
                  ...priceList.map((item) {
                    return Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: _buildPriceCard(
                        title: item['title']!,
                        price: item['price']!,
                        duration: item['duration']!,
                        color: item['color']!,
                        onTap: () => _contactWA(context, item['title']!, item['price']!),
                      ),
                    );
                  }).toList(),

                  const SizedBox(height: 16),

                  // ===== DIVIDER =====
                  Container(
                    height: 2,
                    color: NeoBrutalismColors.borderColor.withOpacity(0.3),
                  ),
                  const SizedBox(height: 16),

                  // ===== BUG LIST =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.pink.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: NeoBrutalismColors.pink, width: 2),
                        ),
                        child: const Icon(
                          Icons.bug_report,
                          color: NeoBrutalismColors.pink,
                          size: 16,
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        "Bug WhatsApp",
                        style: TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: bugList.map((bug) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.white,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.05),
                              offset: const Offset(3, 3),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: Text(
                          bug,
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Inter',
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),

                  // ===== FITUR TAMBAHAN =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.purple.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: NeoBrutalismColors.purple, width: 2),
                        ),
                        child: const Icon(
                          Icons.star,
                          color: NeoBrutalismColors.purple,
                          size: 16,
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Text(
                        "Fitur Tambahan",
                        style: TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: fiturList.map((fitur) {
                      return Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.white,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: NeoBrutalismColors.purple, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.05),
                              offset: const Offset(3, 3),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: Text(
                          fitur,
                          style: const TextStyle(
                            color: NeoBrutalismColors.purple,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Inter',
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 16),

                  // ===== DIVIDER =====
                  Container(
                    height: 2,
                    color: NeoBrutalismColors.borderColor.withOpacity(0.3),
                  ),
                  const SizedBox(height: 16),

                  // ===== INFO ORDER =====
                  _neoCard(
                    padding: const EdgeInsets.all(14),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            const Icon(
                              Icons.info_outline,
                              color: NeoBrutalismColors.blue,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            const Text(
                              "Cara Order",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.w800,
                                fontFamily: 'Inter',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          "1. Pilih paket yang diinginkan\n"
                          "2. Klik paket tersebut\n"
                          "3. Otomatis terhubung ke WhatsApp\n"
                          "4. Pesan otomatis terisi\n"
                          "5. Kirim pesan untuk lanjutkan",
                          style: TextStyle(
                            color: NeoBrutalismColors.darkGrey,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter',
                            height: 1.6,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // ===== COPYRIGHT =====
                  Column(
                    children: [
                      Container(
                        width: 40,
                        height: 3,
                        color: NeoBrutalismColors.borderColor,
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: NeoBrutalismColors.darkGrey,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPriceCard({
    required String title,
    required String price,
    required String duration,
    required Color color,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: NeoBrutalismColors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color, width: 3),
          boxShadow: [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.1),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: color, width: 2),
              ),
              child: Icon(
                Icons.verified,
                color: color,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: NeoBrutalismColors.black,
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      fontFamily: 'Inter',
                    ),
                  ),
                  Row(
                    children: [
                      Text(
                        price,
                        style: TextStyle(
                          color: color,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: color, width: 1),
                        ),
                        child: Text(
                          duration,
                          style: TextStyle(
                            color: color,
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.yellow,
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: const Icon(
                Icons.arrow_forward_ios,
                color: NeoBrutalismColors.black,
                size: 14,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }
}