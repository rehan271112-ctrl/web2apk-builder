// lib/bubble_overlay.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const String _apiBase = 'http://cyberscurty.rzhosts.my.id:34978';

// ══════════════════════════════════════════════════════════════
//  OVERLAY ENTRY POINT
// ══════════════════════════════════════════════════════════════
@pragma("vm:entry-point")
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: BubbleOverlayRoot(),
    ),
  );
}

// ══════════════════════════════════════════════════════════════
//  ROOT WIDGET
// ══════════════════════════════════════════════════════════════
class BubbleOverlayRoot extends StatefulWidget {
  const BubbleOverlayRoot({super.key});
  @override
  State<BubbleOverlayRoot> createState() => _BubbleOverlayRootState();
}

class _BubbleOverlayRootState extends State<BubbleOverlayRoot>
    with SingleTickerProviderStateMixin {
  // ── Data sesi ──
  String _sessionKey = '';
  List<Map<String, dynamic>> _listBug = [];
  bool _canGlobal = false;

  // ── Sender info (dari MySender endpoint) ──
  int _globalSenderCount = 0;
  int _privateSenderCount = 0;
  List<String> _globalSenders = [];
  List<String> _privateSenders = [];
  bool _isLoadingSenders = false;
  String? _senderError;

  // ── State panel ──
  bool _panelOpen = false;
  bool _showSenderDetail = false;
  String _selectedBugId = '';
  String _senderType = 'private';
  bool _isSending = false;
  String? _statusMessage;
  bool _statusOk = false;

  // ── Input ──
  final _targetCtrl = TextEditingController();

  // ── Posisi bubble ──
  double _dx = 0;
  double _dy = 0;
  bool _posInit = false;
  bool _atEdge = false;
  bool _leftEdge = true;

  // ── Animasi pulse ──
  late AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _loadSavedData();
    _listenFromMainApp();
  }

  @override
  void dispose() {
    _pulse.dispose();
    _targetCtrl.dispose();
    super.dispose();
  }

  // ─── Muat data tersimpan dari SharedPreferences ─────────────
  Future<void> _loadSavedData() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('bubble_session_data');
    if (raw != null) {
      try {
        _applyData(jsonDecode(raw) as Map<String, dynamic>);
      } catch (_) {}
    }
    final savedTarget = prefs.getString('bubble_saved_target') ?? '';
    if (savedTarget.isNotEmpty) _targetCtrl.text = savedTarget;

    // Kalau sudah ada sessionKey, langsung fetch sender
    if (_sessionKey.isNotEmpty) _fetchMySender();
  }

  // ─── Dengarkan data dari main app ──────────────────────────
  void _listenFromMainApp() {
    FlutterOverlayWindow.overlayListener.listen((data) {
      if (data is String) {
        try {
          _applyData(jsonDecode(data) as Map<String, dynamic>);
          // Refresh sender setiap kali dapat data baru
          if (_sessionKey.isNotEmpty) _fetchMySender();
        } catch (_) {}
      }
    });
  }

  void _applyData(Map<String, dynamic> map) {
    setState(() {
      _sessionKey = map['sessionKey'] ?? '';
      _listBug = (map['listBug'] as List<dynamic>? ?? [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
      _canGlobal = map['canGlobal'] ?? false;
      // Pakai nilai dari map dulu, nanti di-overwrite setelah fetch API
      _globalSenderCount =
          (map['globalSenderCount'] as num?)?.toInt() ?? 0;
      _privateSenderCount =
          (map['privateSenderCount'] as num?)?.toInt() ?? 0;
      _globalSenders =
          List<String>.from(map['globalSenders'] as List? ?? []);
      _privateSenders =
          List<String>.from(map['privateSenders'] as List? ?? []);
      if (_listBug.isNotEmpty && _selectedBugId.isEmpty) {
        _selectedBugId = _listBug[0]['bug_id'] ?? '';
      }
    });
  }

  // ══════════════════════════════════════════════════════════════
  //  MySender ENDPOINT — fetch sender global & private
  // ══════════════════════════════════════════════════════════════
  Future<void> _fetchMySender() async {
    if (_sessionKey.isEmpty) return;
    setState(() {
      _isLoadingSenders = true;
      _senderError = null;
    });
    try {
      final res = await http
          .get(Uri.parse('$_apiBase/mySender?key=$_sessionKey'))
          .timeout(const Duration(seconds: 15));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body) as Map<String, dynamic>;
        if (data['valid'] == true) {
          final globalList =
              (data['globalConnections'] as List<dynamic>? ?? []);
          final privateList =
              (data['privateConnections'] as List<dynamic>? ?? []);

          setState(() {
            _globalSenderCount = globalList.length;
            _privateSenderCount = privateList.length;
            _globalSenders = globalList
                .whereType<Map>()
                .map((e) =>
                    e['sessionName']?.toString() ??
                    e['id']?.toString() ??
                    'Unknown')
                .toList();
            _privateSenders = privateList
                .whereType<Map>()
                .map((e) =>
                    e['sessionName']?.toString() ??
                    e['id']?.toString() ??
                    'Unknown')
                .toList();
            _isLoadingSenders = false;
            _senderError = null;
          });

          // Simpan ke prefs untuk load ulang berikutnya
          final prefs = await SharedPreferences.getInstance();
          final existing = prefs.getString('bubble_session_data');
          if (existing != null) {
            try {
              final map =
                  jsonDecode(existing) as Map<String, dynamic>;
              map['globalSenderCount'] = _globalSenderCount;
              map['privateSenderCount'] = _privateSenderCount;
              map['globalSenders'] = _globalSenders;
              map['privateSenders'] = _privateSenders;
              await prefs.setString(
                  'bubble_session_data', jsonEncode(map));
            } catch (_) {}
          }
        } else {
          setState(() {
            _senderError =
                data['message'] ?? 'Gagal memuat sender';
            _isLoadingSenders = false;
          });
        }
      } else {
        setState(() {
          _senderError = 'Server error: ${res.statusCode}';
          _isLoadingSenders = false;
        });
      }
    } catch (e) {
      setState(() {
        _senderError = 'Koneksi gagal';
        _isLoadingSenders = false;
      });
    }
  }

  // ─── Inisialisasi posisi bubble ─────────────────────────────
  void _initPos(BoxConstraints box) {
    if (_posInit) return;
    _posInit = true;
    _dx = box.maxWidth / 2 - 32;
    _dy = box.maxHeight - 120;
  }

  // ─── Drag bubble ───────────────────────────────────────────
  void _onPanUpdate(DragUpdateDetails d, BoxConstraints box) {
    if (_panelOpen) return;
    setState(() {
      _dx = (_dx + d.delta.dx).clamp(-32.0, box.maxWidth - 33.0);
      _dy = (_dy + d.delta.dy).clamp(0.0, box.maxHeight - 65.0);
      _atEdge = false;
    });
  }

  void _onPanEnd(DragEndDetails _, BoxConstraints box) {
    if (_panelOpen) return;
    final midX = box.maxWidth / 2;
    setState(() {
      if (_dx + 32 < midX) {
        _dx = -32;
        _leftEdge = true;
      } else {
        _dx = box.maxWidth - 33;
        _leftEdge = false;
      }
      _atEdge = true;
    });
  }

  // ─── Buka panel ─────────────────────────────────────────────
  Future<void> _openPanel() async {
    setState(() {
      _panelOpen = true;
      _atEdge = false;
      _showSenderDetail = false;
    });
    // Refresh sender saat panel dibuka
    _fetchMySender();
    try {
      await FlutterOverlayWindow.resizeOverlay(370, 620, false);
    } catch (_) {}
  }

  Future<void> _closePanel() async {
    setState(() {
      _panelOpen = false;
      _statusMessage = null;
      _showSenderDetail = false;
    });
    try {
      await FlutterOverlayWindow.resizeOverlay(65, 65, true);
    } catch (_) {}
  }

  // ─── Kirim bug ──────────────────────────────────────────────
  Future<void> _sendBug() async {
    String raw = _targetCtrl.text.trim();
    if (raw.isEmpty || _selectedBugId.isEmpty || _sessionKey.isEmpty) {
      setState(() {
        _statusMessage = '❌ Isi nomor target terlebih dahulu';
        _statusOk = false;
      });
      return;
    }

    raw = raw.replaceAll(RegExp(r'[^\d+]'), '');
    if (raw.startsWith('08')) raw = '+62${raw.substring(1)}';
    else if (raw.startsWith('62') && !raw.startsWith('+')) raw = '+$raw';
    if (!raw.startsWith('+') || raw.length < 8) {
      setState(() {
        _statusMessage = '❌ Format salah. Gunakan +62xxxxx';
        _statusOk = false;
      });
      return;
    }

    setState(() { _isSending = true; _statusMessage = null; });
    try {
      final url = Uri.parse(
        '$_apiBase/sendBug?key=$_sessionKey'
        '&target=$raw&bug=$_selectedBugId&senderType=$_senderType',
      );
      final res =
          await http.get(url).timeout(const Duration(seconds: 30));
      final data = jsonDecode(res.body) as Map<String, dynamic>;

      if (data['sended'] == true) {
        setState(() {
          _statusMessage = '✅ Target $raw — bug terkirim';
          _statusOk = true;
          _targetCtrl.clear();
        });
        _fetchMySender(); // refresh setelah kirim
      } else if (data['cooldown'] == true) {
        setState(() {
          _statusMessage = '⏳ Tunggu sebentar sebelum kirim lagi';
          _statusOk = false;
        });
      } else {
        setState(() {
          _statusMessage = data['message'] ?? '❌ Gagal mengirim bug';
          _statusOk = false;
        });
      }
    } catch (_) {
      setState(() {
        _statusMessage = '❌ Koneksi gagal. Coba lagi';
        _statusOk = false;
      });
    } finally {
      setState(() => _isSending = false);
    }
  }

  // ══════════════════════════════════════════════════════════════
  //  BUILD
  // ══════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: LayoutBuilder(builder: (ctx, box) {
        _initPos(box);
        return Stack(children: [
          if (!_panelOpen)
            Positioned(
              left: _dx,
              top: _dy,
              child: GestureDetector(
                onPanUpdate: (d) => _onPanUpdate(d, box),
                onPanEnd: (d) => _onPanEnd(d, box),
                onTap: _openPanel,
                child: _buildBubble(),
              ),
            ),
          if (_panelOpen) Positioned.fill(child: _buildPanel()),
        ]);
      }),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  BUBBLE WIDGET
  // ══════════════════════════════════════════════════════════════
  Widget _buildBubble() {
    return AnimatedBuilder(
      animation: _pulse,
      builder: (_, __) => Container(
        width: 65,
        height: 65,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const RadialGradient(
            colors: [Color(0xFFAA44EE), Color(0xFF1A0030)],
            center: Alignment(-0.3, -0.3),
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF7B2FF7)
                  .withOpacity(0.45 + 0.25 * _pulse.value),
              blurRadius: 14 + 8 * _pulse.value,
              spreadRadius: 2,
            ),
          ],
          border: Border.all(
            color: Colors.white.withOpacity(0.25 + 0.1 * _pulse.value),
            width: 1.5,
          ),
        ),
        child: Stack(alignment: Alignment.center, children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Colors.purpleAccent
                    .withOpacity(0.25 + 0.2 * _pulse.value),
                width: 2,
              ),
            ),
          ),
          const Icon(Icons.bug_report_rounded,
              color: Colors.white, size: 28),
          // Badge jumlah sender aktif
          if (_globalSenderCount > 0)
            Positioned(
              top: 4,
              right: 4,
              child: Container(
                padding: const EdgeInsets.all(3),
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Color(0xFF27AE60),
                ),
                child: Text(
                  '$_globalSenderCount',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          if (_atEdge)
            Positioned(
              bottom: 6,
              right: _leftEdge ? null : 6,
              left: _leftEdge ? 6 : null,
              child: Container(
                width: 9,
                height: 9,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.greenAccent,
                  boxShadow: [
                    BoxShadow(color: Colors.green, blurRadius: 4)
                  ],
                ),
              ),
            ),
        ]),
      ),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  PANEL UI
  // ══════════════════════════════════════════════════════════════
  Widget _buildPanel() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.22),
            blurRadius: 24,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(children: [
        _buildPanelHeader(),
        const Divider(height: 1, thickness: 1, color: Color(0xFFEEEEEE)),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(14),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              // ── Sender Info Card ──
              _buildSenderInfoCard(),
              const SizedBox(height: 14),
              // ── Input nomor ──
              _buildTargetInput(),
              const SizedBox(height: 14),
              // ── Menu Bug ──
              _buildLabel('MENU BUG'),
              const SizedBox(height: 8),
              _buildBugMenu(),
              const SizedBox(height: 14),
              // ── Sender selector ──
              _buildLabel('SENDER'),
              const SizedBox(height: 8),
              _buildSenderRow(),
              const SizedBox(height: 6),
              _buildQuotaInfo(),
              // ── Status ──
              if (_statusMessage != null) ...[
                const SizedBox(height: 10),
                _buildStatus(),
              ],
            ]),
          ),
        ),
        _buildSendBtn(),
      ]),
    );
  }

  // ── Header ──────────────────────────────────────────────────
  Widget _buildPanelHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      child: Row(children: [
        Container(
          width: 36,
          height: 36,
          decoration: const BoxDecoration(
              shape: BoxShape.circle, color: Color(0xFFCC0000)),
          child: const Icon(Icons.bug_report_rounded,
              color: Colors.white, size: 19),
        ),
        const SizedBox(width: 10),
        const Expanded(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('KIRIM BUG',
                    style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                        letterSpacing: 0.8)),
                Text('@ZeroTyz',
                    style:
                        TextStyle(fontSize: 11, color: Color(0xFF888888))),
              ]),
        ),
        // Refresh sender button
        GestureDetector(
          onTap: _fetchMySender,
          child: Container(
            width: 28,
            height: 28,
            margin: const EdgeInsets.only(right: 6),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFFDDDDDD)),
            ),
            child: _isLoadingSenders
                ? const Padding(
                    padding: EdgeInsets.all(6),
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Color(0xFF888888)),
                  )
                : const Icon(Icons.refresh_rounded,
                    size: 15, color: Color(0xFF666666)),
          ),
        ),
        // Close button
        GestureDetector(
          onTap: _closePanel,
          child: Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFFDDDDDD)),
            ),
            child: const Icon(Icons.close_rounded,
                size: 15, color: Color(0xFF666666)),
          ),
        ),
      ]),
    );
  }

  // ══════════════════════════════════════════════════════════════
  //  SENDER INFO CARD — menampilkan data dari /mySender
  // ══════════════════════════════════════════════════════════════
  Widget _buildSenderInfoCard() {
    return GestureDetector(
      onTap: () => setState(() => _showSenderDetail = !_showSenderDetail),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF1A0030), Color(0xFF2A0050)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: const Color(0xFF7B2FF7).withOpacity(0.5),
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            // Title
            const Icon(Icons.wifi_tethering_rounded,
                color: Colors.purpleAccent, size: 16),
            const SizedBox(width: 7),
            const Text('SENDER STATUS',
                style: TextStyle(
                  color: Colors.purpleAccent,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                  letterSpacing: 1,
                )),
            const Spacer(),
            if (_isLoadingSenders)
              const SizedBox(
                width: 14,
                height: 14,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.purpleAccent),
              )
            else
              Icon(
                _showSenderDetail
                    ? Icons.expand_less_rounded
                    : Icons.expand_more_rounded,
                color: Colors.purpleAccent,
                size: 18,
              ),
          ]),
          const SizedBox(height: 10),
          // ── 2 kolom: Global & Private ──
          Row(children: [
            // Global
            Expanded(
              child: _buildSenderStatBox(
                label: 'GLOBAL',
                count: _globalSenderCount,
                icon: Icons.public_rounded,
                color: const Color(0xFF27AE60),
              ),
            ),
            const SizedBox(width: 8),
            // Private
            Expanded(
              child: _buildSenderStatBox(
                label: 'PRIVATE',
                count: _privateSenderCount,
                icon: Icons.person_rounded,
                color: const Color(0xFF2196F3),
              ),
            ),
          ]),

          // ── Error info ──
          if (_senderError != null) ...[
            const SizedBox(height: 8),
            Row(children: [
              const Icon(Icons.error_outline_rounded,
                  color: Colors.redAccent, size: 13),
              const SizedBox(width: 5),
              Expanded(
                child: Text(_senderError!,
                    style: const TextStyle(
                        color: Colors.redAccent,
                        fontSize: 10,
                        fontWeight: FontWeight.w600)),
              ),
            ]),
          ],

          // ── Detail list sender (expand) ──
          if (_showSenderDetail && !_isLoadingSenders) ...[
            const SizedBox(height: 10),
            const Divider(color: Colors.white12, height: 1),
            const SizedBox(height: 8),
            // Global list
            if (_globalSenders.isNotEmpty) ...[
              const Text('Global Senders:',
                  style: TextStyle(
                    color: Color(0xFF27AE60),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  )),
              const SizedBox(height: 4),
              ..._globalSenders.map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 2),
                    child: Row(children: [
                      const Icon(Icons.circle,
                          color: Color(0xFF27AE60), size: 6),
                      const SizedBox(width: 6),
                      Expanded(
                          child: Text(s,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 10))),
                    ]),
                  )),
              const SizedBox(height: 6),
            ],
            // Private list
            if (_privateSenders.isNotEmpty) ...[
              const Text('Private Senders:',
                  style: TextStyle(
                    color: Color(0xFF2196F3),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  )),
              const SizedBox(height: 4),
              ..._privateSenders.map((s) => Padding(
                    padding: const EdgeInsets.only(bottom: 2),
                    child: Row(children: [
                      const Icon(Icons.circle,
                          color: Color(0xFF2196F3), size: 6),
                      const SizedBox(width: 6),
                      Expanded(
                          child: Text(s,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 10))),
                    ]),
                  )),
            ],
            if (_globalSenders.isEmpty && _privateSenders.isEmpty)
              const Text('Tidak ada sender aktif',
                  style:
                      TextStyle(color: Colors.white38, fontSize: 10)),
          ],
        ]),
      ),
    );
  }

  Widget _buildSenderStatBox({
    required String label,
    required int count,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: 8),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label,
              style: TextStyle(
                color: color,
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              )),
          Text('$count sender',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w900,
              )),
        ]),
        const Spacer(),
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
          decoration: BoxDecoration(
            color: count > 0
                ? color.withOpacity(0.2)
                : Colors.red.withOpacity(0.15),
            borderRadius: BorderRadius.circular(5),
          ),
          child: Text(
            count > 0 ? 'READY' : 'NONE',
            style: TextStyle(
              color: count > 0 ? color : Colors.red,
              fontSize: 9,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ]),
    );
  }

  // ── Input nomor target ──────────────────────────────────────
  Widget _buildTargetInput() {
    return Row(children: [
      Expanded(
        child: Container(
          height: 46,
          decoration: BoxDecoration(
            border:
                Border.all(color: const Color(0xFF27AE60), width: 1.5),
            borderRadius: BorderRadius.circular(11),
          ),
          child: Row(children: [
            const SizedBox(width: 10),
            const Icon(Icons.phone_rounded,
                color: Color(0xFF27AE60), size: 17),
            const SizedBox(width: 6),
            Expanded(
              child: TextField(
                controller: _targetCtrl,
                keyboardType: TextInputType.phone,
                style: const TextStyle(
                  fontSize: 13,
                  color: Color(0xFF111111),
                  fontWeight: FontWeight.w600,
                ),
                decoration: const InputDecoration(
                  hintText: 'Nomor target (62xxx / 1x...)',
                  hintStyle:
                      TextStyle(color: Color(0xFFAAAAAA), fontSize: 11),
                  border: InputBorder.none,
                  isDense: true,
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ),
          ]),
        ),
      ),
      const SizedBox(width: 8),
      GestureDetector(
        onTap: () async {
          final p = await SharedPreferences.getInstance();
          await p.setString(
              'bubble_saved_target', _targetCtrl.text.trim());
          setState(() {
            _statusMessage = '✅ Nomor disimpan';
            _statusOk = true;
          });
        },
        child: Container(
          height: 46,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: const Color(0xFF27AE60),
            borderRadius: BorderRadius.circular(11),
          ),
          child: const Row(children: [
            Icon(Icons.check_circle_outline_rounded,
                color: Colors.white, size: 15),
            SizedBox(width: 5),
            Text('SAVE',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                  letterSpacing: 0.5,
                )),
          ]),
        ),
      ),
    ]);
  }

  Widget _buildLabel(String t) => Text(t,
      style: const TextStyle(
        fontWeight: FontWeight.w900,
        fontSize: 12,
        letterSpacing: 1,
        color: Color(0xFF222222),
      ));

  // ── Menu Bug ────────────────────────────────────────────────
  Widget _buildBugMenu() {
    final bugs = _listBug.isNotEmpty
        ? _listBug
        : const [
            {'bug_id': 'fc_android', 'bug_name': 'FC ANDROID ORI / BISNIS'},
            {'bug_id': 'fc_android_v2', 'bug_name': 'FC ANDROID V2'},
            {'bug_id': 'fc_ios', 'bug_name': 'FC IOS INVISIBLE'},
          ];
    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: bugs.map((bug) {
        final id = (bug['bug_id'] ?? '') as String;
        final nm = (bug['bug_name'] ?? id) as String;
        final sel = id == _selectedBugId;
        return GestureDetector(
          onTap: () => setState(() => _selectedBugId = id),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: sel
                  ? const Color(0xFFFFC107)
                  : const Color(0xFFF2F2F2),
              borderRadius: BorderRadius.circular(9),
              border: Border.all(
                color: sel
                    ? const Color(0xFFFF9800)
                    : const Color(0xFFDDDDDD),
                width: sel ? 2 : 1,
              ),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.bug_report_rounded,
                  size: 13,
                  color: sel
                      ? const Color(0xFF333333)
                      : const Color(0xFF888888)),
              const SizedBox(width: 5),
              Text(nm.toUpperCase(),
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 10,
                    letterSpacing: 0.3,
                    color: sel
                        ? const Color(0xFF333333)
                        : const Color(0xFF555555),
                  )),
            ]),
          ),
        );
      }).toList(),
    );
  }

  // ── Sender Pribadi / Global ─────────────────────────────────
  Widget _buildSenderRow() {
    return Row(children: [
      Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _senderType = 'private'),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: _senderType == 'private'
                  ? const Color(0xFFF0F0F0)
                  : Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: _senderType == 'private'
                    ? const Color(0xFF777777)
                    : const Color(0xFFDDDDDD),
                width: _senderType == 'private' ? 2 : 1,
              ),
            ),
            child: Column(children: [
              Icon(Icons.person_rounded,
                  size: 20,
                  color: _senderType == 'private'
                      ? const Color(0xFF333333)
                      : const Color(0xFF888888)),
              const SizedBox(height: 3),
              Text('PRIBADI',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 10,
                    color: _senderType == 'private'
                        ? const Color(0xFF111111)
                        : const Color(0xFF888888),
                  )),
              Text('$_privateSenderCount sender',
                  style: const TextStyle(
                      fontSize: 9, color: Color(0xFFAAAAAA))),
            ]),
          ),
        ),
      ),
      const SizedBox(width: 8),
      Expanded(
        child: GestureDetector(
          onTap: () {
            if (!_canGlobal) {
              setState(() {
                _statusMessage = '❌ Global hanya untuk Owner/Admin/VIP';
                _statusOk = false;
              });
              return;
            }
            setState(() => _senderType = 'global');
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: _senderType == 'global'
                  ? const Color(0xFF27AE60)
                  : const Color(0xFFF0FFF4),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: _senderType == 'global'
                    ? const Color(0xFF1E8A4A)
                    : const Color(0xFF27AE60),
                width: _senderType == 'global' ? 2 : 1,
              ),
            ),
            child: Column(children: [
              Icon(Icons.public_rounded,
                  size: 20,
                  color: _senderType == 'global'
                      ? Colors.white
                      : const Color(0xFF27AE60)),
              const SizedBox(height: 3),
              Text('GLOBAL',
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 10,
                    color: _senderType == 'global'
                        ? Colors.white
                        : const Color(0xFF27AE60),
                  )),
              Text('$_globalSenderCount sender online',
                  style: TextStyle(
                    fontSize: 9,
                    color: _senderType == 'global'
                        ? Colors.white70
                        : const Color(0xFF27AE60).withOpacity(0.7),
                  )),
            ]),
          ),
        ),
      ),
    ]);
  }

  Widget _buildQuotaInfo() {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFDE7),
        borderRadius: BorderRadius.circular(7),
        border:
            Border.all(color: const Color(0xFFFFCC00).withOpacity(0.5)),
      ),
      child: Row(children: [
        const Icon(Icons.info_outline_rounded,
            size: 13, color: Color(0xFFBB8800)),
        const SizedBox(width: 5),
        Text(
          'Global: $_globalSenderCount sender  •  Private: $_privateSenderCount sender',
          style: const TextStyle(
            fontSize: 10,
            color: Color(0xFF886600),
            fontWeight: FontWeight.w600,
          ),
        ),
      ]),
    );
  }

  Widget _buildStatus() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: _statusOk
            ? const Color(0xFFE8F5E9)
            : const Color(0xFFFFEBEE),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(
          color: _statusOk
              ? const Color(0xFF27AE60).withOpacity(0.35)
              : const Color(0xFFCC0000).withOpacity(0.35),
        ),
      ),
      child: Row(children: [
        Icon(
          _statusOk
              ? Icons.check_circle_rounded
              : Icons.error_outline_rounded,
          color:
              _statusOk ? const Color(0xFF27AE60) : const Color(0xFFCC0000),
          size: 16,
        ),
        const SizedBox(width: 7),
        Expanded(
          child: Text(
            _statusMessage!,
            style: TextStyle(
              fontSize: 11,
              color: _statusOk
                  ? const Color(0xFF1A6B3C)
                  : const Color(0xFF9B1111),
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ]),
    );
  }

  Widget _buildSendBtn() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
      child: SizedBox(
        width: double.infinity,
        height: 48,
        child: ElevatedButton(
          onPressed: _isSending ? null : _sendBug,
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFFCC0000),
            disabledBackgroundColor:
                const Color(0xFFCC0000).withOpacity(0.45),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(13)),
            elevation: 4,
            shadowColor: const Color(0xFFCC0000).withOpacity(0.4),
          ),
          child: _isSending
              ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2.5),
                )
              : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.send_rounded,
                        color: Colors.white, size: 16),
                    SizedBox(width: 8),
                    Text('KIRIM BUG SEKARANG',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                          letterSpacing: 0.8,
                        )),
                  ],
                ),
        ),
      ),
    );
  }
}
