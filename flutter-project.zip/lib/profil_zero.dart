import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'config.dart';

// Model akun APK yang benar-benar terdaftar di server (bukan data dummy)
class DiscoverUser {
  final String username;
  final String role;
  final String? avatarUrl;
  int followersCount;
  bool isFollowing;

  DiscoverUser({
    required this.username,
    required this.role,
    required this.avatarUrl,
    required this.followersCount,
    required this.isFollowing,
  });

  factory DiscoverUser.fromJson(Map<String, dynamic> json) {
    return DiscoverUser(
      username: (json['username'] ?? '').toString(),
      role: (json['role'] ?? 'member').toString(),
      avatarUrl: json['avatarUrl']?.toString(),
      followersCount: int.tryParse(json['followersCount'].toString()) ?? 0,
      isFollowing: json['isFollowing'] == true,
    );
  }
}

class ProfilZeroPage extends StatefulWidget {
  final String username;
  final String sessionKey;
  
  const ProfilZeroPage({
    Key? key,
    required this.username,
    required this.sessionKey,
  }) : super(key: key);

  @override
  State<ProfilZeroPage> createState() => _ProfilZeroPageState();
}

class _ProfilZeroPageState extends State<ProfilZeroPage> {
  File? _profileImage;
  int posts = 0;
  int followers = 0;
  int following = 0;
  List<dynamic> suggestedUsers = [];
  List<DiscoverUser> discoveredUsers = [];
  bool isLoadingDiscover = true;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadProfileData();
    _fetchFollowStats();
    _fetchDiscoverUsers();
  }

  Future<void> _loadProfileData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      posts = prefs.getInt('user_posts_${widget.username}') ?? 0;
      final imagePath = prefs.getString('profile_image_${widget.username}');
      if (imagePath != null && File(imagePath).existsSync()) {
        _profileImage = File(imagePath);
      }
    });
    // Sinkron dengan foto profil yang tersimpan di server. Kalau device ini
    // belum punya file lokalnya (misal habis login ulang / ganti HP), foto
    // akan otomatis diunduh & dipasang lagi tanpa perlu upload ulang.
    _syncProfileImageFromServer();
  }

  // Ambil jumlah followers/following yang sebenarnya dari server (bukan
  // angka statis 0/0/0 lagi).
  Future<void> _fetchFollowStats() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/api/users/stats?key=${widget.sessionKey}'),
      );
      if (response.statusCode != 200) return;
      final data = jsonDecode(response.body);
      if (data['status'] != true) return;
      if (mounted) {
        setState(() {
          followers = int.tryParse(data['followers'].toString()) ?? 0;
          following = int.tryParse(data['following'].toString()) ?? 0;
        });
      }
    } catch (e) {
      debugPrint('Gagal ambil statistik followers: $e');
    }
  }

  // Ambil daftar akun APK yang benar-benar terdaftar di server untuk
  // section "Temukan orang". Kalau tidak ada akun lain sama sekali,
  // discoveredUsers akan tetap kosong -> UI otomatis tidak menampilkan
  // apa-apa (tidak ada kartu dummy lagi).
  Future<void> _fetchDiscoverUsers() async {
    setState(() => isLoadingDiscover = true);
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/api/users/discover?key=${widget.sessionKey}'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          final list = ((data['users'] ?? []) as List)
              .map((e) => DiscoverUser.fromJson(e))
              .toList();
          if (mounted) {
            setState(() {
              discoveredUsers = list;
              isLoadingDiscover = false;
            });
          }
          return;
        }
      }
      if (mounted) setState(() => isLoadingDiscover = false);
    } catch (e) {
      debugPrint('Gagal ambil daftar akun: $e');
      if (mounted) setState(() => isLoadingDiscover = false);
    }
  }

  // Follow/unfollow akun beneran ke server, dengan update optimis di UI
  // supaya terasa instan (di-rollback kalau ternyata gagal).
  Future<void> _toggleFollow(DiscoverUser user) async {
    final previousFollowing = user.isFollowing;
    final previousCount = user.followersCount;
    setState(() {
      user.isFollowing = !user.isFollowing;
      user.followersCount += user.isFollowing ? 1 : -1;
    });

    try {
      final response = await http.post(
        Uri.parse('$apiBaseUrl/api/users/follow'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'targetUsername': user.username,
        }),
      );
      final data = response.statusCode == 200 ? jsonDecode(response.body) : null;

      if (data != null && data['status'] == true) {
        setState(() {
          user.isFollowing = data['isFollowing'] == true;
          user.followersCount =
              int.tryParse(data['followersCount'].toString()) ?? user.followersCount;
        });
        _fetchFollowStats(); // refresh angka "Mengikuti" di header profil
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                user.isFollowing
                    ? 'Mengikuti ${user.username}'
                    : 'Berhenti mengikuti ${user.username}',
              ),
            ),
          );
        }
      } else {
        setState(() {
          user.isFollowing = previousFollowing;
          user.followersCount = previousCount;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data?['message']?.toString() ?? 'Gagal follow user')),
          );
        }
      }
    } catch (e) {
      setState(() {
        user.isFollowing = previousFollowing;
        user.followersCount = previousCount;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal follow user')),
        );
      }
    }
  }

  Future<void> _syncProfileImageFromServer() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/api/profile/avatar?key=${widget.sessionKey}'),
      );
      if (response.statusCode != 200) return;

      final data = jsonDecode(response.body);
      if (data['status'] != true || data['avatarUrl'] == null) return;

      final avatarUrl = '$apiBaseUrl${data['avatarUrl']}';
      final mediaResponse = await http.get(Uri.parse(avatarUrl));
      if (mediaResponse.statusCode != 200) return;

      final dir = await getApplicationDocumentsDirectory();
      final ext = avatarUrl.split('.').last.split('?').first;
      final localPath = '${dir.path}/profile_${widget.username}.$ext';
      final file = File(localPath);
      await file.writeAsBytes(mediaResponse.bodyBytes);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('profile_image_${widget.username}', localPath);

      if (mounted) {
        setState(() {
          _profileImage = file;
        });
      }
    } catch (e) {
      debugPrint('Gagal sinkron foto profil dari server: $e');
    }
  }

  Future<void> _pickProfileImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    
    if (image != null) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('profile_image_${widget.username}', image.path);
      setState(() {
        _profileImage = File(image.path);
      });

      // Simpan juga ke server supaya foto profil tetap ada walau logout,
      // login ulang, atau ganti device.
      _uploadProfileImageToServer(File(image.path));
    }
  }

  Future<void> _uploadProfileImageToServer(File imageFile) async {
    try {
      final bytes = await imageFile.readAsBytes();
      final base64Image = base64Encode(bytes);
      final response = await http.post(
        Uri.parse('$apiBaseUrl/api/profile/avatar/upload'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'imageBase64': base64Image,
        }),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] != true && mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                data['message']?.toString() ?? 'Gagal menyimpan foto profil ke server',
              ),
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('Gagal upload foto profil ke server: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF000000),
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.username,
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w700,
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.more_vert_rounded, color: Colors.white),
            onPressed: _showSettingsMenu,
          ),
        ],
      ),
      body: Stack(
        children: [
          // Grid background
          Positioned.fill(
            child: CustomPaint(
              painter: _GridPainter(),
            ),
          ),
          // Content
          SingleChildScrollView(
            padding: EdgeInsets.only(top: kToolbarHeight + 50),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header dengan foto profil
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // Profile picture dengan tombol edit
                      Stack(
                        children: [
                          Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Color(0xFF7C3AED),
                                width: 3,
                              ),
                              image: _profileImage != null
                                  ? DecorationImage(
                                      image: FileImage(_profileImage!),
                                      fit: BoxFit.cover,
                                    )
                                  : null,
                            ),
                            child: _profileImage == null
                                ? Icon(Icons.person, size: 50, color: Colors.grey)
                                : null,
                          ),
                          // Edit button
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: GestureDetector(
                              onTap: _pickProfileImage,
                              child: Container(
                                width: 36,
                                height: 36,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xFF7C3AED),
                                  border: Border.all(
                                    color: Color(0xFF000000),
                                    width: 2,
                                  ),
                                ),
                                child: Icon(
                                  Icons.add,
                                  color: Colors.white,
                                  size: 20,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(width: 30),
                      // Stats
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                _StatColumn(
                                  count: posts.toString(),
                                  label: 'postingan',
                                ),
                                _StatColumn(
                                  count: followers.toString(),
                                  label: 'pengikut',
                                  onTap: _openFollowerActivity,
                                ),
                                _StatColumn(
                                  count: following.toString(),
                                  label: 'mengikuti',
                                  onTap: _openFollowingList,
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // Bio
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.username,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Zero Crash Member',
                        style: TextStyle(
                          color: Color(0xFF888888),
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20),

                // Action buttons
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    children: [
                      Expanded(
                        child: _ActionButton(
                          label: 'Edit profil',
                          onTap: _editProfile,
                        ),
                      ),
                      SizedBox(width: 12),
                      Expanded(
                        child: _ActionButton(
                          label: 'Bagikan profil',
                          onTap: _shareProfile,
                        ),
                      ),
                      SizedBox(width: 12),
                      GestureDetector(
                        onTap: _addFriend,
                        child: Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: Color(0xFF1F1F1F),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Color(0xFF2A2A2A),
                            ),
                          ),
                          child: Icon(
                            Icons.person_add,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // Find people section — hanya tampil kalau memang ada akun
                // lain yang terdaftar di server (atau masih dalam proses
                // memuat). Kalau tidak ada satupun, section ini benar-benar
                // hilang, tidak ada kartu kosong sama sekali.
                if (isLoadingDiscover || discoveredUsers.isNotEmpty) ...[
                  SizedBox(height: 16),
                  _SectionHeader(
                    title: 'Temukan orang',
                    actionText: 'Lihat semua',
                    onAction: _searchUsers,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20),
                    child: isLoadingDiscover
                        ? Padding(
                            padding: EdgeInsets.symmetric(vertical: 24),
                            child: Center(
                              child: SizedBox(
                                width: 22,
                                height: 22,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Color(0xFF7C3AED),
                                ),
                              ),
                            ),
                          )
                        // Pakai Wrap (bukan GridView) supaya tinggi area ini
                        // pas mengikuti isi kartu — tidak menyisakan ruang
                        // kosong besar seperti GridView shrinkWrap dulu.
                        : LayoutBuilder(
                            builder: (context, constraints) {
                              const crossAxisCount = 3;
                              const spacing = 12.0;
                              final cardWidth = (constraints.maxWidth -
                                      spacing * (crossAxisCount - 1)) /
                                  crossAxisCount;
                              return Wrap(
                                spacing: spacing,
                                runSpacing: spacing,
                                children: discoveredUsers.map((user) {
                                  return SizedBox(
                                    width: cardWidth,
                                    child: _UserCard(
                                      username: user.username,
                                      followers: user.followersCount,
                                      avatarUrl: user.avatarUrl != null
                                          ? '$apiBaseUrl${user.avatarUrl}'
                                          : null,
                                      isFollowing: user.isFollowing,
                                      onFollow: () => _toggleFollow(user),
                                      onTapProfile: () => _openOtherProfile(user.username),
                                    ),
                                  );
                                }).toList(),
                              );
                            },
                          ),
                  ),
                ],

                SizedBox(height: 30),

                // Thanks to section
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.favorite, color: Color(0xFF7C3AED), size: 20),
                          SizedBox(width: 8),
                          Text(
                            'Thanks To',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Container(
                        height: 200,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Color(0xFF2A2A2A),
                          ),
                        ),
                        child: Center(
                          child: Text(
                            'No data available',
                            style: TextStyle(
                              color: Color(0xFF888888),
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 40),

                // Post video button
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: GestureDetector(
                    onTap: _postVideo,
                    child: Container(
                      width: double.infinity,
                      height: 50,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF7C3AED), Color(0xFF5B21B6)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.video_camera_back_outlined, color: Colors.white, size: 20),
                          SizedBox(width: 8),
                          Text(
                            'Posting Video',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 16),

                // Aktivitas Pengikut — lihat siapa saja yang mengikuti akun
                // ini & follow-back langsung dari sini.
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: GestureDetector(
                    onTap: _openFollowerActivity,
                    child: Container(
                      width: double.infinity,
                      height: 50,
                      decoration: BoxDecoration(
                        color: Color(0xFF1F1F1F),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Color(0xFF2A2A2A)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.people_alt_outlined, color: Colors.white, size: 20),
                          SizedBox(width: 8),
                          Text(
                            'Aktivitas Pengikut',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

                SizedBox(height: 40),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _editProfile() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Edit profil coming soon')),
    );
  }

  void _shareProfile() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Share profil: ${widget.username}')),
    );
  }

  void _addFriend() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Tambah teman')),
    );
  }

  void _searchUsers() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _UserSearchPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
    // Sinkron ulang: kalau ada follow/unfollow yang terjadi di halaman
    // pencarian, angka & status di halaman profil ikut ter-update.
    _fetchDiscoverUsers();
    _fetchFollowStats();
  }

  void _openFollowerActivity() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _FollowerActivityPage(
          sessionKey: widget.sessionKey,
          myUsername: widget.username,
          mode: 'followers',
        ),
      ),
    );
    _fetchDiscoverUsers();
    _fetchFollowStats();
  }

  void _openFollowingList() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _FollowerActivityPage(
          sessionKey: widget.sessionKey,
          myUsername: widget.username,
          mode: 'following',
        ),
      ),
    );
    _fetchDiscoverUsers();
    _fetchFollowStats();
  }

  void _openOtherProfile(String targetUsername) async {
    if (targetUsername == widget.username) return; // sudah di profil sendiri
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _OtherProfilePage(
          viewedUsername: targetUsername,
          myUsername: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
    _fetchDiscoverUsers();
    _fetchFollowStats();
  }

  void _followUser(int index) {
    setState(() {
      following++;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Mengikuti user_${index + 1}')),
    );
  }

  void _postVideo() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Post video feature coming soon')),
    );
  }

  void _showSettingsMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Color(0xFF111111),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 12),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Color(0xFF2A2A2A),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 24),
            ListTile(
              leading: Icon(Icons.settings, color: Colors.white),
              title: Text('Pengaturan', style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: Icon(Icons.help, color: Colors.white),
              title: Text('Bantuan', style: TextStyle(color: Colors.white)),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: Icon(Icons.logout, color: Color(0xFFEF4444)),
              title: Text('Keluar', style: TextStyle(color: Color(0xFFEF4444))),
              onTap: () => Navigator.pop(context),
            ),
            SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _StatColumn extends StatelessWidget {
  final String count;
  final String label;
  final VoidCallback? onTap;

  const _StatColumn({
    required this.count,
    required this.label,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Text(
            count,
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.w700,
            ),
          ),
          SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: Color(0xFF888888),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _ActionButton({
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: Color(0xFF1F1F1F),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Color(0xFF2A2A2A),
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String actionText;
  final VoidCallback onAction;

  const _SectionHeader({
    required this.title,
    required this.actionText,
    required this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
          GestureDetector(
            onTap: onAction,
            child: Text(
              actionText,
              style: TextStyle(
                color: Color(0xFF7C3AED),
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _UserCard extends StatelessWidget {
  final String username;
  final int followers;
  final String? avatarUrl;
  final bool isFollowing;
  final VoidCallback onFollow;
  final VoidCallback onTapProfile;

  const _UserCard({
    required this.username,
    required this.followers,
    required this.avatarUrl,
    required this.isFollowing,
    required this.onFollow,
    required this.onTapProfile,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Color(0xFF111111),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Color(0xFF1F1F1F),
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: onTapProfile,
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Stack(
                children: [
                  Container(
                    width: 70,
                    height: 70,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xFF1F1F1F),
                      image: avatarUrl != null
                          ? DecorationImage(
                              image: NetworkImage(avatarUrl!),
                              fit: BoxFit.cover,
                            )
                          : null,
                    ),
                    child: avatarUrl == null
                        ? Center(
                            child: Text(
                              username.isNotEmpty ? username[0].toUpperCase() : '?',
                              style: TextStyle(
                                color: Color(0xFF888888),
                                fontSize: 26,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          )
                        : null,
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      width: 20,
                      height: 20,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF7C3AED),
                        border: Border.all(
                          color: Color(0xFF111111),
                          width: 2,
                        ),
                      ),
                      child: Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 12,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          GestureDetector(
            onTap: onTapProfile,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Column(
                children: [
                  Text(
                    username,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 2),
                  Text(
                    '$followers followers',
                    style: TextStyle(
                      color: Color(0xFF888888),
                      fontSize: 11,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.all(8),
            child: GestureDetector(
              onTap: onFollow,
              child: Container(
                width: double.infinity,
                height: 32,
                decoration: BoxDecoration(
                  color: isFollowing ? Color(0xFF1F1F1F) : Color(0xFF7C3AED),
                  borderRadius: BorderRadius.circular(8),
                  border: isFollowing
                      ? Border.all(color: Color(0xFF2A2A2A))
                      : null,
                ),
                child: Center(
                  child: Text(
                    isFollowing ? 'Mengikuti' : 'Ikuti',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _UserSearchPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const _UserSearchPage({required this.username, required this.sessionKey});

  @override
  State<_UserSearchPage> createState() => _UserSearchPageState();
}

class _UserSearchPageState extends State<_UserSearchPage> {
  final TextEditingController _searchController = TextEditingController();
  List<DiscoverUser> _searchResults = [];
  bool _isSearching = false;
  bool _hasSearchedOnce = false;
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    // Tampilkan semua akun terdaftar saat halaman pertama dibuka
    _performSearch('');
    _searchController.addListener(_onQueryChanged);
  }

  void _onQueryChanged() {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      _performSearch(_searchController.text.trim());
    });
  }

  Future<void> _performSearch(String query) async {
    setState(() => _isSearching = true);
    try {
      final response = await http.get(
        Uri.parse(
          '$apiBaseUrl/api/users/search?key=${widget.sessionKey}&q=${Uri.encodeQueryComponent(query)}',
        ),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          final list = ((data['users'] ?? []) as List)
              .map((e) => DiscoverUser.fromJson(e))
              .toList();
          if (mounted) {
            setState(() {
              _searchResults = list;
              _isSearching = false;
              _hasSearchedOnce = true;
            });
          }
          return;
        }
      }
      if (mounted) {
        setState(() {
          _isSearching = false;
          _hasSearchedOnce = true;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isSearching = false;
          _hasSearchedOnce = true;
        });
      }
    }
  }

  Future<void> _toggleFollow(DiscoverUser user) async {
    final previousFollowing = user.isFollowing;
    final previousCount = user.followersCount;
    setState(() {
      user.isFollowing = !user.isFollowing;
      user.followersCount += user.isFollowing ? 1 : -1;
    });

    try {
      final response = await http.post(
        Uri.parse('$apiBaseUrl/api/users/follow'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'targetUsername': user.username,
        }),
      );
      final data = response.statusCode == 200 ? jsonDecode(response.body) : null;
      if (data != null && data['status'] == true) {
        setState(() {
          user.isFollowing = data['isFollowing'] == true;
          user.followersCount =
              int.tryParse(data['followersCount'].toString()) ?? user.followersCount;
        });
      } else {
        setState(() {
          user.isFollowing = previousFollowing;
          user.followersCount = previousCount;
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data?['message']?.toString() ?? 'Gagal follow user')),
          );
        }
      }
    } catch (e) {
      setState(() {
        user.isFollowing = previousFollowing;
        user.followersCount = previousCount;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal follow user')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF000000),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Cari Pengguna',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: TextField(
              controller: _searchController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Cari pengguna...',
                hintStyle: TextStyle(color: Color(0xFF888888)),
                prefixIcon: Icon(Icons.search, color: Color(0xFF888888)),
                filled: true,
                fillColor: Color(0xFF1F1F1F),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Color(0xFF2A2A2A)),
                ),
              ),
            ),
          ),
          Expanded(
            child: _isSearching
                ? Center(
                    child: CircularProgressIndicator(color: Color(0xFF7C3AED)),
                  )
                : _searchResults.isEmpty
                    ? Center(
                        child: Text(
                          _hasSearchedOnce
                              ? 'Tidak ada akun ditemukan'
                              : 'Ketik nama pengguna',
                          style: TextStyle(
                            color: Color(0xFF888888),
                            fontSize: 14,
                          ),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _searchResults.length,
                        itemBuilder: (context, index) {
                          final user = _searchResults[index];
                          return _UserSearchResult(
                            username: user.username,
                            role: user.role,
                            avatarUrl: user.avatarUrl != null
                                ? '$apiBaseUrl${user.avatarUrl}'
                                : null,
                            isFollowing: user.isFollowing,
                            onFollow: () => _toggleFollow(user),
                            onTapProfile: () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => _OtherProfilePage(
                                    viewedUsername: user.username,
                                    myUsername: widget.username,
                                    sessionKey: widget.sessionKey,
                                  ),
                                ),
                              );
                              _performSearch(_searchController.text.trim());
                            },
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    super.dispose();
  }
}

class _UserSearchResult extends StatelessWidget {
  final String username;
  final String role;
  final String? avatarUrl;
  final bool isFollowing;
  final VoidCallback onFollow;
  final VoidCallback onTapProfile;

  const _UserSearchResult({
    required this.username,
    required this.role,
    required this.avatarUrl,
    required this.isFollowing,
    required this.onFollow,
    required this.onTapProfile,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        decoration: BoxDecoration(
          color: Color(0xFF111111),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Color(0xFF1F1F1F)),
        ),
        child: ListTile(
          onTap: onTapProfile,
          leading: CircleAvatar(
            backgroundColor: Color(0xFF1F1F1F),
            backgroundImage: avatarUrl != null ? NetworkImage(avatarUrl!) : null,
            child: avatarUrl == null
                ? Text(
                    username.isNotEmpty ? username[0].toUpperCase() : '?',
                    style: TextStyle(
                      color: Color(0xFF888888),
                      fontWeight: FontWeight.w800,
                    ),
                  )
                : null,
          ),
          title: Text(
            username,
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
          ),
          subtitle: Text(
            'Zero Crash Member',
            style: TextStyle(color: Color(0xFF888888), fontSize: 12),
          ),
          trailing: GestureDetector(
            onTap: onFollow,
            child: Container(
              height: 40,
              width: 80,
              decoration: BoxDecoration(
                color: isFollowing ? Color(0xFF1F1F1F) : Color(0xFF7C3AED),
                borderRadius: BorderRadius.circular(8),
                border: isFollowing ? Border.all(color: Color(0xFF2A2A2A)) : null,
              ),
              child: Center(
                child: Text(
                  isFollowing ? 'Mengikuti' : 'Ikuti',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const gridSize = 40.0;
    final paint = Paint()
      ..color = Color(0xFF1F1F1F).withOpacity(0.3)
      ..strokeWidth = 0.5;

    for (double i = 0; i < size.width; i += gridSize) {
      canvas.drawLine(Offset(i, 0), Offset(i, size.height), paint);
    }
    for (double i = 0; i < size.height; i += gridSize) {
      canvas.drawLine(Offset(0, i), Offset(size.width, i), paint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// Model satu entri di daftar "Aktivitas Pengikut"
class _FollowerEntry {
  final String username;
  final String? avatarUrl;
  bool isFollowingBack;

  _FollowerEntry({
    required this.username,
    required this.avatarUrl,
    required this.isFollowingBack,
  });

  factory _FollowerEntry.fromJson(Map<String, dynamic> json) {
    return _FollowerEntry(
      username: (json['username'] ?? '').toString(),
      avatarUrl: json['avatarUrl']?.toString(),
      isFollowingBack: json['isFollowingBack'] == true,
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// DAFTAR PENGIKUT / MENGIKUTI — dipakai untuk "Aktivitas Pengikut"
// (punya sendiri) maupun untuk melihat pengikut/mengikuti akun orang
// lain dari halaman profil mereka. Tap satu baris -> buka profil
// orang itu.
// ═══════════════════════════════════════════════════════════════
class _FollowerActivityPage extends StatefulWidget {
  final String sessionKey;
  final String myUsername;
  // Kalau null -> tampilkan punya diri sendiri ("Aktivitas Pengikut").
  // Kalau diisi -> tampilkan punya akun tersebut ("Pengikut <nama>").
  final String? viewedUsername;
  // 'followers' atau 'following'
  final String mode;

  const _FollowerActivityPage({
    required this.sessionKey,
    required this.myUsername,
    this.viewedUsername,
    this.mode = 'followers',
  });

  @override
  State<_FollowerActivityPage> createState() => _FollowerActivityPageState();
}

class _FollowerActivityPageState extends State<_FollowerActivityPage> {
  List<_FollowerEntry> entries = [];
  bool isLoading = true;
  String? errorMessage;

  bool get _isFollowingMode => widget.mode == 'following';
  bool get _isOwnList => widget.viewedUsername == null;

  @override
  void initState() {
    super.initState();
    _fetchEntries();
  }

  Future<void> _fetchEntries() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final endpoint = _isFollowingMode ? 'following-list' : 'followers-list';
      final usernameParam =
          widget.viewedUsername != null ? '&username=${widget.viewedUsername}' : '';
      final response = await http.get(
        Uri.parse('$apiBaseUrl/api/users/$endpoint?key=${widget.sessionKey}$usernameParam'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          final rawList = (data[_isFollowingMode ? 'following' : 'followers'] ?? []) as List;
          final list = rawList.map((e) => _FollowerEntry.fromJson(e)).toList();
          if (mounted) {
            setState(() {
              entries = list;
              isLoading = false;
            });
          }
          return;
        } else {
          setState(() {
            errorMessage = data['message']?.toString() ?? 'Gagal memuat data';
            isLoading = false;
          });
          return;
        }
      }
      setState(() {
        errorMessage = 'Gagal memuat data';
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = 'Gagal memuat data';
        isLoading = false;
      });
    }
  }

  Future<void> _toggleFollow(_FollowerEntry entry) async {
    if (entry.username == widget.myUsername) return; // tidak bisa follow diri sendiri
    final previous = entry.isFollowingBack;
    setState(() => entry.isFollowingBack = !entry.isFollowingBack);

    try {
      final response = await http.post(
        Uri.parse('$apiBaseUrl/api/users/follow'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'targetUsername': entry.username,
        }),
      );
      final data = response.statusCode == 200 ? jsonDecode(response.body) : null;
      if (data != null && data['status'] == true) {
        setState(() => entry.isFollowingBack = data['isFollowing'] == true);
      } else {
        setState(() => entry.isFollowingBack = previous);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data?['message']?.toString() ?? 'Gagal follow balik')),
          );
        }
      }
    } catch (e) {
      setState(() => entry.isFollowingBack = previous);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal follow balik')),
        );
      }
    }
  }

  void _openProfile(_FollowerEntry entry) async {
    if (entry.username == widget.myUsername) return; // sudah di profil sendiri
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _OtherProfilePage(
          viewedUsername: entry.username,
          myUsername: widget.myUsername,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
    _fetchEntries();
  }

  @override
  Widget build(BuildContext context) {
    final title = _isOwnList
        ? (_isFollowingMode ? 'Mengikuti' : 'Aktivitas Pengikut')
        : (_isFollowingMode
            ? 'Mengikuti ${widget.viewedUsername}'
            : 'Pengikut ${widget.viewedUsername}');
    final emptyText = _isFollowingMode
        ? (_isOwnList ? 'Anda belum mengikuti siapa pun' : 'Belum mengikuti siapa pun')
        : (_isOwnList ? 'Belum ada yang mengikuti akun ini' : 'Belum ada pengikut');

    return Scaffold(
      backgroundColor: Color(0xFF000000),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          title,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF7C3AED)))
          : errorMessage != null
              ? Center(
                  child: Text(
                    errorMessage!,
                    style: TextStyle(color: Color(0xFF888888)),
                  ),
                )
              : entries.isEmpty
                  ? Center(
                      child: Text(
                        emptyText,
                        style: TextStyle(color: Color(0xFF888888), fontSize: 14),
                      ),
                    )
                  : ListView.builder(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      itemCount: entries.length,
                      itemBuilder: (context, index) {
                        final entry = entries[index];
                        final fullAvatarUrl =
                            entry.avatarUrl != null ? '$apiBaseUrl${entry.avatarUrl}' : null;
                        final isSelf = entry.username == widget.myUsername;
                        return Padding(
                          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                          child: Container(
                            decoration: BoxDecoration(
                              color: Color(0xFF111111),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: Color(0xFF1F1F1F)),
                            ),
                            child: ListTile(
                              onTap: () => _openProfile(entry),
                              leading: CircleAvatar(
                                backgroundColor: Color(0xFF1F1F1F),
                                backgroundImage:
                                    fullAvatarUrl != null ? NetworkImage(fullAvatarUrl) : null,
                                child: fullAvatarUrl == null
                                    ? Text(
                                        entry.username.isNotEmpty
                                            ? entry.username[0].toUpperCase()
                                            : '?',
                                        style: TextStyle(
                                          color: Color(0xFF888888),
                                          fontWeight: FontWeight.w800,
                                        ),
                                      )
                                    : null,
                              ),
                              title: Text(
                                entry.username,
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
                              ),
                              subtitle: Text(
                                _isFollowingMode ? 'Diikuti' : 'Mengikuti Anda',
                                style: TextStyle(color: Color(0xFF888888), fontSize: 12),
                              ),
                              trailing: isSelf
                                  ? null
                                  : GestureDetector(
                                      onTap: () => _toggleFollow(entry),
                                      child: Container(
                                        height: 40,
                                        width: 90,
                                        decoration: BoxDecoration(
                                          color: entry.isFollowingBack
                                              ? Color(0xFF1F1F1F)
                                              : Color(0xFF7C3AED),
                                          borderRadius: BorderRadius.circular(8),
                                          border: entry.isFollowingBack
                                              ? Border.all(color: Color(0xFF2A2A2A))
                                              : null,
                                        ),
                                        child: Center(
                                          child: Text(
                                            entry.isFollowingBack ? 'Mengikuti' : 'Ikuti',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                            ),
                          ),
                        );
                      },
                    ),
    );
  }
}

// Model ringkasan profil akun lain (dari /api/users/profile)
class _ProfileSummary {
  final String username;
  final String role;
  final String? avatarUrl;
  final int followersCount;
  final int followingCount;
  bool isFollowing;

  _ProfileSummary({
    required this.username,
    required this.role,
    required this.avatarUrl,
    required this.followersCount,
    required this.followingCount,
    required this.isFollowing,
  });

  factory _ProfileSummary.fromJson(Map<String, dynamic> json) {
    return _ProfileSummary(
      username: (json['username'] ?? '').toString(),
      role: (json['role'] ?? 'member').toString(),
      avatarUrl: json['avatarUrl']?.toString(),
      followersCount: int.tryParse(json['followersCount'].toString()) ?? 0,
      followingCount: int.tryParse(json['followingCount'].toString()) ?? 0,
      isFollowing: json['isFollowing'] == true,
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// HALAMAN PROFIL AKUN ORANG LAIN — dibuka saat menekan lingkaran
// profil/nama seseorang di manapun (Temukan orang, Cari Pengguna,
// daftar pengikut/mengikuti). Mode lihat saja (tidak bisa edit),
// tapi bisa follow/unfollow dan melihat pengikut & mengikuti mereka.
// ═══════════════════════════════════════════════════════════════
class _OtherProfilePage extends StatefulWidget {
  final String viewedUsername;
  final String myUsername;
  final String sessionKey;

  const _OtherProfilePage({
    required this.viewedUsername,
    required this.myUsername,
    required this.sessionKey,
  });

  @override
  State<_OtherProfilePage> createState() => _OtherProfilePageState();
}

class _OtherProfilePageState extends State<_OtherProfilePage> {
  _ProfileSummary? profile;
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchProfile();
  }

  Future<void> _fetchProfile() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final response = await http.get(
        Uri.parse(
          '$apiBaseUrl/api/users/profile?key=${widget.sessionKey}&username=${widget.viewedUsername}',
        ),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          if (mounted) {
            setState(() {
              profile = _ProfileSummary.fromJson(data);
              isLoading = false;
            });
          }
          return;
        } else {
          setState(() {
            errorMessage = data['message']?.toString() ?? 'Gagal memuat profil';
            isLoading = false;
          });
          return;
        }
      }
      setState(() {
        errorMessage = 'Gagal memuat profil';
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = 'Gagal memuat profil';
        isLoading = false;
      });
    }
  }

  Future<void> _toggleFollow() async {
    final p = profile;
    if (p == null) return;
    final previousFollowing = p.isFollowing;

    setState(() => p.isFollowing = !p.isFollowing);

    try {
      final response = await http.post(
        Uri.parse('$apiBaseUrl/api/users/follow'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'targetUsername': p.username,
        }),
      );
      final data = response.statusCode == 200 ? jsonDecode(response.body) : null;
      if (data != null && data['status'] == true) {
        setState(() => p.isFollowing = data['isFollowing'] == true);
        _fetchProfile(); // refresh angka followers-nya dia
      } else {
        setState(() => p.isFollowing = previousFollowing);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data?['message']?.toString() ?? 'Gagal follow user')),
          );
        }
      }
    } catch (e) {
      setState(() => p.isFollowing = previousFollowing);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Gagal follow user')),
        );
      }
    }
  }

  void _openFollowersOfViewed() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _FollowerActivityPage(
          sessionKey: widget.sessionKey,
          myUsername: widget.myUsername,
          viewedUsername: widget.viewedUsername,
          mode: 'followers',
        ),
      ),
    );
    _fetchProfile();
  }

  void _openFollowingOfViewed() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _FollowerActivityPage(
          sessionKey: widget.sessionKey,
          myUsername: widget.myUsername,
          viewedUsername: widget.viewedUsername,
          mode: 'following',
        ),
      ),
    );
    _fetchProfile();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF000000),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.viewedUsername,
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        ),
      ),
      body: isLoading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF7C3AED)))
          : errorMessage != null
              ? Center(
                  child: Text(errorMessage!, style: TextStyle(color: Color(0xFF888888))),
                )
              : profile == null
                  ? SizedBox.shrink()
                  : _buildProfileBody(profile!),
    );
  }

  Widget _buildProfileBody(_ProfileSummary p) {
    final fullAvatarUrl = p.avatarUrl != null ? '$apiBaseUrl${p.avatarUrl}' : null;

    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xFF1F1F1F),
                    border: Border.all(color: Color(0xFF7C3AED), width: 2),
                    image: fullAvatarUrl != null
                        ? DecorationImage(image: NetworkImage(fullAvatarUrl), fit: BoxFit.cover)
                        : null,
                  ),
                  child: fullAvatarUrl == null
                      ? Center(
                          child: Text(
                            p.username.isNotEmpty ? p.username[0].toUpperCase() : '?',
                            style: TextStyle(
                              color: Color(0xFF888888),
                              fontSize: 32,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        )
                      : null,
                ),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _StatColumn(count: '0', label: 'postingan'),
                      _StatColumn(
                        count: p.followersCount.toString(),
                        label: 'pengikut',
                        onTap: _openFollowersOfViewed,
                      ),
                      _StatColumn(
                        count: p.followingCount.toString(),
                        label: 'mengikuti',
                        onTap: _openFollowingOfViewed,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Text(
              p.username,
              style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 4),
            Text(
              'Zero Crash Member',
              style: TextStyle(color: Color(0xFF888888), fontSize: 14),
            ),
            SizedBox(height: 20),
            GestureDetector(
              onTap: _toggleFollow,
              child: Container(
                width: double.infinity,
                height: 46,
                decoration: BoxDecoration(
                  color: p.isFollowing ? Color(0xFF1F1F1F) : Color(0xFF7C3AED),
                  borderRadius: BorderRadius.circular(10),
                  border: p.isFollowing ? Border.all(color: Color(0xFF2A2A2A)) : null,
                ),
                child: Center(
                  child: Text(
                    p.isFollowing ? 'Mengikuti' : 'Ikuti',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
