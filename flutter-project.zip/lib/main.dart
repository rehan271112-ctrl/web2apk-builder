// lib/main.dart
import 'package:flutter/material.dart';
import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';
import 'tes_server.dart';
import 'color_theme.dart';
import 'ghost_page.dart';
import 'build_manager.dart';

// ══════════════════════════════════════════════════════════════
//  PENTING: overlayMain sudah dideklarasikan di bubble_overlay.dart
//  dengan @pragma("vm:entry-point"). Jangan deklarasikan lagi di
//  sini karena akan menyebabkan konflik entry point!
//  Import bubble_overlay.dart agar entry point terdaftar.
// ══════════════════════════════════════════════════════════════
import 'bubble_overlay.dart'; // ← entry point overlayMain ada di sini

// ══════════════════════════════════════════════════════════════
//  APP ENTRY POINT
// ══════════════════════════════════════════════════════════════
void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load tema tersimpan
  await AppThemeController.instance.loadTheme();

  // Init notification service untuk Build APK feature
  await NotificationService.instance.init();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Zero Crash',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'fly',
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark().copyWith(
          secondary: Colors.purple,
        ),
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(
                builder: (_) => const TesServerPage());
          case '/landing':
            return MaterialPageRoute(builder: (_) => LandingPage());
          case '/login':
            return MaterialPageRoute(
                builder: (_) => const LoginPage());
          case '/dashboard':
            final args =
                settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                sessionKey: args['key'],
                expiredDate: args['expiredDate'],
                listBug: List<Map<String, dynamic>>.from(
                    args['listBug'] ?? []),
                listDoos: List<Map<String, dynamic>>.from(
                    args['listDoos'] ?? []),
                news: List<Map<String, dynamic>>.from(
                    args['news'] ?? []),
              ),
            );
          case '/home':
            final args =
                settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => HomePage(
                username: args['username'],
                password: args['password'],
                listBug: List<Map<String, dynamic>>.from(
                    args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
            );
          case '/seller':
            final args =
                settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (_) =>
                    SellerPage(keyToken: args['keyToken']));
          case '/admin':
            final args =
                settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (_) =>
                    AdminPage(sessionKey: args['sessionKey']));
          case '/owner':
            final args =
                settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (_) => OwnerPage(
                      sessionKey: args['sessionKey'],
                      username: args['username'],
                    ));
          case '/ghost':
            final args =
                settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (_) => GhostPage(
                      sessionKey: args['sessionKey'],
                      username: args['username'],
                    ));
          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(child: Text('404 - Not Found')),
              ),
            );
        }
      },
    );
  }
}
