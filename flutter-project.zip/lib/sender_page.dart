import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class SenderPage extends StatefulWidget {
  final String sessionKey;

  const SenderPage({super.key, required this.sessionKey});

  @override
  State<SenderPage> createState() => _SenderPageState();
}

class _SenderPageState extends State<SenderPage> with TickerProviderStateMixin {
  Map<String, dynamic> connections = {"private": [], "global": []};
  bool isLoading = false;
  String _currentFilter = "all";

  @override
  void initState() {
    super.initState();
    _fetchSenders();
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  // ==================== API FUNCTIONS ====================
  Future<void> _fetchSenders() async {
    if (isLoading) return;
    setState(() => isLoading = true);

    try {
      final res = await http.get(
        Uri.parse("$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}"),
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() {
            connections = data["connections"] ?? {"private": [], "global": []};
          });
        } else {
          _showErrorSnackBar(data['message'] ?? "Failed to fetch senders");
        }
      } else {
        _showErrorSnackBar("Failed to fetch senders");
      }
    } catch (e) {
      debugPrint("Error fetching senders: $e");
      _showErrorSnackBar("Failed to fetch senders. Please try again.");
    }

    setState(() => isLoading = false);
  }

  Future<void> _addSender(String number, bool isGlobal) async {
    if (number.isEmpty) {
      _showErrorSnackBar("Phone number cannot be empty");
      return;
    }

    try {
      final url = "$baseUrl/api/whatsapp/getPairing?key=${widget.sessionKey}&number=$number" + 
                   (isGlobal ? "&isGlobal=true" : "");
      
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final res = jsonDecode(response.body);
        if (res['valid'] == true) {
          _showPairingCodeDialog(number, res['pairingCode'], isGlobal);
          _fetchSenders();
        } else {
          _showErrorSnackBar("Failed: ${res['message'] ?? 'Unknown error'}");
        }
      } else {
        _showErrorSnackBar("Failed to get pairing code");
      }
    } catch (e) {
      debugPrint("Error adding sender: $e");
      _showErrorSnackBar("An error occurred. Please try again.");
    }
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: NeoBrutalismColors.white, fontFamily: 'Inter')),
        backgroundColor: NeoBrutalismColors.pink,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
      ),
    );
  }

  void _showSuccessSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: NeoBrutalismColors.black, fontFamily: 'Inter', fontWeight: FontWeight.w600)),
        backgroundColor: NeoBrutalismColors.yellow,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
      ),
    );
  }

  // ==================== PAIRING CODE DIALOG WITH TUTORIAL ====================
  void _showPairingCodeDialog(String number, String code, bool isGlobal) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // ===== HEADER =====
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.purple,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                    ),
                    child: const Icon(Icons.phonelink_lock, color: NeoBrutalismColors.white, size: 24),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "Pairing Code",
                    style: TextStyle(
                      color: NeoBrutalismColors.black,
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // ===== INFO =====
              _neoCard(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Text(
                          "Number: ",
                          style: TextStyle(
                            color: NeoBrutalismColors.darkGrey,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Inter',
                          ),
                        ),
                        Text(
                          number,
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 13,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: isGlobal ? NeoBrutalismColors.blue.withOpacity(0.15) : NeoBrutalismColors.grey,
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: isGlobal ? NeoBrutalismColors.blue : NeoBrutalismColors.darkGrey,
                          width: 2,
                        ),
                      ),
                      child: Text(
                        isGlobal ? "GLOBAL SENDER" : "PRIVATE SENDER",
                        style: TextStyle(
                          color: isGlobal ? NeoBrutalismColors.blue : NeoBrutalismColors.darkGrey,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    // ===== PAIRING CODE =====
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.grey,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                      ),
                      child: Text(
                        code,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 4,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ===== TUTORIAL =====
              _neoCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "📱 Cara Menghubungkan:",
                      style: TextStyle(
                        color: NeoBrutalismColors.black,
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        fontFamily: 'Inter',
                      ),
                    ),
                    const SizedBox(height: 8),
                    _tutorialStep("1", "Buka WhatsApp di HP Anda"),
                    _tutorialStep("2", "Tap titik 3 di pojok kanan atas"),
                    _tutorialStep("3", "Pilih 'Tautkan Perangkat'"),
                    _tutorialStep("4", "Masukkan kode di atas"),
                    _tutorialStep("5", "Bot akan otomatis terhubung 🟢"),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // ===== BUTTONS =====
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Clipboard.setData(ClipboardData(text: code));
                        _showSuccessSnackBar("Pairing code copied!");
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.grey,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                        ),
                        child: const Center(
                          child: Text(
                            "📋 Copy",
                            style: TextStyle(
                              color: NeoBrutalismColors.black,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.yellow,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(3, 3),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            "DONE",
                            style: TextStyle(
                              color: NeoBrutalismColors.black,
                              fontWeight: FontWeight.w800,
                              fontSize: 13,
                              fontFamily: 'Inter',
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tutorialStep(String step, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Container(
            width: 22,
            height: 22,
            decoration: BoxDecoration(
              color: NeoBrutalismColors.yellow,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
            ),
            child: Center(
              child: Text(
                step,
                style: const TextStyle(
                  color: NeoBrutalismColors.black,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                  fontFamily: 'Inter',
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: NeoBrutalismColors.black.withOpacity(0.8),
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showAddSenderDialog(bool isGlobal) {
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isGlobal ? NeoBrutalismColors.blue : NeoBrutalismColors.grey,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                    ),
                    child: Icon(
                      isGlobal ? Icons.public : Icons.lock,
                      color: NeoBrutalismColors.white,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isGlobal ? "Add Global Sender" : "Add Private Sender",
                        style: const TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                        ),
                      ),
                      Text(
                        isGlobal ? "Dapat digunakan semua orang" : "Hanya untuk pribadi",
                        style: TextStyle(
                          color: NeoBrutalismColors.darkGrey,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextField(
                controller: controller,
                keyboardType: TextInputType.phone,
                style: const TextStyle(
                  color: NeoBrutalismColors.black,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
                cursorColor: NeoBrutalismColors.black,
                decoration: InputDecoration(
                  hintText: "Enter phone number",
                  hintStyle: TextStyle(
                    color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                  filled: true,
                  fillColor: NeoBrutalismColors.grey,
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  prefixIcon: Icon(Icons.phone, color: NeoBrutalismColors.darkGrey),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      child: Text(
                        "Cancel",
                        style: TextStyle(
                          color: NeoBrutalismColors.darkGrey,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  GestureDetector(
                    onTap: () async {
                      Navigator.pop(context);
                      final number = controller.text.trim();
                      await _addSender(number, isGlobal);
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      decoration: BoxDecoration(
                        color: isGlobal ? NeoBrutalismColors.blue : NeoBrutalismColors.purple,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: NeoBrutalismColors.black.withOpacity(0.08),
                            offset: const Offset(3, 3),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: Text(
                        "Add Sender",
                        style: TextStyle(
                          color: NeoBrutalismColors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 13,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ==================== FILTER ====================
  List<dynamic> _getFilteredSenders() {
    switch (_currentFilter) {
      case "private":
        return connections["private"] ?? [];
      case "global":
        return connections["global"] ?? [];
      default:
        return [
          ...connections["private"] ?? [],
          ...connections["global"] ?? []
        ];
    }
  }

  int _getSenderCount() {
    switch (_currentFilter) {
      case "private":
        return connections["private"]?.length ?? 0;
      case "global":
        return connections["global"]?.length ?? 0;
      default:
        return (connections["private"]?.length ?? 0) + (connections["global"]?.length ?? 0);
    }
  }

  int _getTotalSenderCount() {
    return (connections["private"]?.length ?? 0) + (connections["global"]?.length ?? 0);
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    final totalSenders = _getTotalSenderCount();

    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Column(
              children: [
                // ===== HEADER (TANPA BACK BUTTON) =====
                _buildHeader(),
                // ===== ADD SENDER MENU =====
                _buildAddSenderMenu(),
                const SizedBox(height: 8),
                // ===== FILTER CHIPS =====
                _buildFilterChips(),
                // ===== SENDER LIST =====
                Expanded(
                  child: isLoading
                      ? const Center(child: CircularProgressIndicator(color: NeoBrutalismColors.purple))
                      : totalSenders == 0
                          ? _buildEmptyState()
                          : _buildSenderList(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Row(
        children: [
          // ===== TITLE (TANPA BACK BUTTON) =====
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: NeoBrutalismColors.purple,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
              boxShadow: [
                BoxShadow(
                  color: NeoBrutalismColors.black.withOpacity(0.08),
                  offset: const Offset(4, 4),
                  blurRadius: 0,
                ),
              ],
            ),
            child: const Icon(
              Icons.phone_android,
              color: NeoBrutalismColors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            "My Senders (${_getSenderCount()})",
            style: const TextStyle(
              color: NeoBrutalismColors.black,
              fontSize: 20,
              fontWeight: FontWeight.w900,
              fontFamily: 'Inter',
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: _fetchSenders,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: const Icon(
                Icons.refresh,
                color: NeoBrutalismColors.black,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddSenderMenu() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          // PRIVATE
          Expanded(
            child: GestureDetector(
              onTap: () => _showAddSenderDialog(false),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.black.withOpacity(0.08),
                      offset: const Offset(4, 4),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.grey,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                      ),
                      child: const Icon(Icons.lock_outline, color: NeoBrutalismColors.darkGrey, size: 22),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      "PRIVATE",
                      style: TextStyle(
                        color: NeoBrutalismColors.black,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Inter',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      "Pribadi",
                      style: TextStyle(
                        color: NeoBrutalismColors.darkGrey,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          // GLOBAL
          Expanded(
            child: GestureDetector(
              onTap: () => _showAddSenderDialog(true),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: NeoBrutalismColors.blue,
                    width: 3,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.blue.withOpacity(0.2),
                      offset: const Offset(4, 4),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.blue.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: NeoBrutalismColors.blue, width: 2),
                      ),
                      child: const Icon(Icons.public, color: NeoBrutalismColors.blue, size: 22),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      "GLOBAL",
                      style: TextStyle(
                        color: NeoBrutalismColors.blue,
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Inter',
                        letterSpacing: 1,
                      ),
                    ),
                    Text(
                      "Semua orang",
                      style: TextStyle(
                        color: NeoBrutalismColors.darkGrey,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChips() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _buildFilterChip("All", "all"),
            const SizedBox(width: 8),
            _buildFilterChip("Private", "private"),
            const SizedBox(width: 8),
            _buildFilterChip("Global", "global"),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, String filter) {
    final isSelected = _currentFilter == filter;

    return GestureDetector(
      onTap: () {
        setState(() {
          _currentFilter = filter;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? NeoBrutalismColors.yellow : NeoBrutalismColors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? NeoBrutalismColors.borderColor : NeoBrutalismColors.darkGrey,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected ? [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.08),
              offset: const Offset(3, 3),
              blurRadius: 0,
            ),
          ] : null,
        ),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
            fontSize: 12,
            fontFamily: 'Inter',
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: NeoBrutalismColors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
            ),
            child: const Icon(
              Icons.phone_disabled,
              color: NeoBrutalismColors.darkGrey,
              size: 50,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            "No senders found",
            style: TextStyle(
              color: NeoBrutalismColors.black,
              fontSize: 18,
              fontFamily: 'Inter',
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Add a sender to get started",
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 13,
              fontWeight: FontWeight.w600,
              fontFamily: 'Inter',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderList() {
    final filteredSenders = _getFilteredSenders();

    if (filteredSenders.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.filter_list_off,
              color: NeoBrutalismColors.darkGrey.withOpacity(0.5),
              size: 40,
            ),
            const SizedBox(height: 12),
            Text(
              "No senders in '${_currentFilter.toUpperCase()}'",
              style: TextStyle(
                color: NeoBrutalismColors.darkGrey,
                fontSize: 14,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _fetchSenders,
      color: NeoBrutalismColors.black,
      backgroundColor: NeoBrutalismColors.white,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: filteredSenders.length,
        itemBuilder: (context, index) {
          final sender = filteredSenders[index];
          final isGlobal = sender['dev'] == "global" || sender['role'] == "high admin";

          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _neoCard(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: isGlobal ? NeoBrutalismColors.blue.withOpacity(0.15) : NeoBrutalismColors.grey,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: isGlobal ? NeoBrutalismColors.blue : NeoBrutalismColors.darkGrey,
                        width: 2,
                      ),
                    ),
                    child: Icon(
                      Icons.phone,
                      color: isGlobal ? NeoBrutalismColors.blue : NeoBrutalismColors.darkGrey,
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          sender['sessionName'] ?? 'Unknown',
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          "Type: ${sender['type'] ?? 'N/A'}",
                          style: TextStyle(
                            color: NeoBrutalismColors.darkGrey,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isGlobal)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.blue.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: NeoBrutalismColors.blue, width: 2),
                      ),
                      child: const Text(
                        "VIP",
                        style: TextStyle(
                          color: NeoBrutalismColors.blue,
                          fontSize: 9,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Inter',
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.green.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: NeoBrutalismColors.green, width: 2),
                    ),
                    child: const Text(
                      "Active",
                      style: TextStyle(
                        color: NeoBrutalismColors.green,
                        fontSize: 9,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}