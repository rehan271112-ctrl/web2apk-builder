import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';
import 'color_theme.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  // ── Theme color getters ──
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;

  late VideoPlayerController _videoController;
  late AnimationController _fadeController;
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late AnimationController _scaleController;

  bool _fadeOutStarted = false;
  bool _navigated = false;

  // --- TEMA WARNA UNGU ---

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);

    // Fade Controller untuk transisi keluar
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    // Pulse Controller untuk efek berdenyut pada teks
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    // Glow Controller untuk efek cahaya bergerak
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat();

    // Scale Controller untuk efek zoom-in
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..forward();

    _videoController = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController.setLooping(false);
        _videoController.play();

        _videoController.addListener(() {
          final position = _videoController.value.position;
          final duration = _videoController.value.duration;

          if (duration != null &&
              position >= duration - const Duration(seconds: 1) &&
              !_fadeOutStarted) {
            _fadeOutStarted = true;
            _fadeController.forward();
          }

          if (position >= duration) {
            _navigateToDashboard();
          }
        });
      });
  }

  void _navigateToDashboard() {
    if (_navigated) return;
    _navigated = true;
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
          news: widget.news,
        ),
      ),
    );
  }

  void _skip() {
    _videoController.pause();
    _navigateToDashboard();
  }

  void _onThemeChanged() => mounted ? setState(() {}) : null;

  @override
  void dispose() {
    _videoController.dispose();
    _fadeController.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    _scaleController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // --- VIDEO BACKGROUND FULL SCREEN ---
          if (_videoController.value.isInitialized)
            Positioned.fill(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(color: Colors.black),

          // --- OVERLAY GRADIENT ---
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  stops: const [0.0, 0.4, 0.6, 1.0],
                  colors: [
                    Colors.black.withOpacity(0.2),
                    Colors.transparent,
                    Colors.black.withOpacity(0.5),
                    Colors.black.withOpacity(0.85),
                  ],
                ),
              ),
            ),
          ),

          // --- TOMBOL SKIP (POJOK KANAN ATAS) ---
          Positioned(
            top: 16,
            right: 16,
            child: SafeArea(
              child: GestureDetector(
                onTap: _skip,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.45),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: Colors.white.withOpacity(0.15)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        "Skip",
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 4),
                      Icon(Icons.skip_next_rounded,
                          color: accentPurple, size: 18),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // --- TEKS UTAMA DI TENGAH ---
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // --- TEKS "VOLTARA NIGHT" SATU BARIS DI TENGAH ---
                AnimatedBuilder(
                  animation: _glowController,
                  builder: (context, _) {
                    final double t = _glowController.value;
                    return ShaderMask(
                      blendMode: BlendMode.srcIn,
                      shaderCallback: (bounds) {
                        return LinearGradient(
                          begin: Alignment(-2.0 + 4.0 * t, -0.3),
                          end: Alignment(-1.0 + 4.0 * t, 0.3),
                          colors: [
                            primaryPurple,
                            accentPurple,
                            Colors.white,
                            Colors.white,
                            accentPurple,
                            primaryPurple,
                          ],
                          stops: const [0.0, 0.2, 0.4, 0.6, 0.8, 1.0],
                        ).createShader(bounds);
                      },
                      child: AnimatedBuilder(
                        animation: _pulseController,
                        builder: (context, _) {
                          final double pulseValue = _pulseController.value;
                          return Transform.scale(
                            scale: 1.0 + 0.02 * pulseValue,
                            child: Text(
                              "𝙕𝙚𝙧𝙤 𝘾𝙧𝙖𝙨𝙝",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontFamily: 'Orbitron',
                                fontSize: 58,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                letterSpacing: 3,
                                shadows: [
                                  Shadow(
                                    color: primaryPurple.withOpacity(
                                      0.3 + 0.2 * pulseValue,
                                    ),
                                    blurRadius: 25 + 10 * pulseValue,
                                  ),
                                  Shadow(
                                    color: accentPurple.withOpacity(
                                      0.2 + 0.15 * pulseValue,
                                    ),
                                    blurRadius: 15 + 5 * pulseValue,
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    );
                  },
                ),

                const SizedBox(height: 12),

                // --- SUBTITLE ---
                AnimatedBuilder(
                  animation: _scaleController,
                  builder: (context, child) {
                    return Opacity(
                      opacity: _scaleController.value * 0.8,
                      child: Text(
                        "Alergi Apk Ampas",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: 'Orbitron',
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 19,
                          letterSpacing: 2,
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(height: 8),

                // --- DIVIDER ---
                AnimatedBuilder(
                  animation: _scaleController,
                  builder: (context, child) {
                    return Container(
                      width: 80 * _scaleController.value,
                      height: 2,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [primaryPurple, accentPurple.withOpacity(0.3)],
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),

          // --- LOADING INDICATOR (BAWAH) ---
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Column(
              children: [
                AnimatedBuilder(
                  animation: _pulseController,
                  builder: (context, _) {
                    final double pulseValue = _pulseController.value;
                    return SizedBox(
                      width: 24 + 4 * pulseValue,
                      height: 24 + 4 * pulseValue,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          Color.lerp(
                            primaryPurple,
                            accentPurple,
                            pulseValue,
                          )!,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 12),
                Text(
                  "Loading Brader",
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 12,
                    letterSpacing: 1,
                  ),
                ),
              ],
                ),
              ),
            ),
          ),

          // --- FADE OUT OVERLAY ---
          if (_fadeOutStarted)
            FadeTransition(
              opacity: _fadeController.drive(Tween(begin: 1.0, end: 0.0)),
              child: Container(color: Colors.black),
            ),
        ],
      ),
    );
  }
}