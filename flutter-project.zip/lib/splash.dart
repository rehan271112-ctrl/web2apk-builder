import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// Import DashboardPage dari loader_page.dart
import 'loader_page.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

class SplashPage extends StatefulWidget {
  // Menerima data user dari rute (arguments)
  final Map<String, dynamic> data;

  const SplashPage({super.key, required this.data});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with TickerProviderStateMixin {
  // Animasi logo membesar
  late AnimationController _logoScaleController;
  late Animation<double> _logoScaleAnimation;
  
  // Animasi loading bar & persentase
  late AnimationController _loadingController;
  late Animation<double> _loadingAnimation;

  Timer? _navigationTimer;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    
    // Sembunyikan status bar
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersive);
    
    // Mulai animasi dan timer 10 detik
    _startAnimations();
  }

  void _initializeAnimations() {
    // Animasi logo: kecil (0.5) ke besar (1.0) dalam 10 detik
    _logoScaleController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    );
    _logoScaleAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _logoScaleController, curve: Curves.easeOutCubic),
    );

    // Animasi loading bar 0 -> 1 dalam 10 detik
    _loadingController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    );
    _loadingAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _loadingController, curve: Curves.easeInOut),
    );
  }

  void _startAnimations() {
    _logoScaleController.forward();
    _loadingController.forward();

    // Timer 10 detik untuk pindah halaman
    _navigationTimer = Timer(const Duration(seconds: 10), () {
      _navigateToDashboard();
    });
  }

  void _navigateToDashboard() {
    _logoScaleController.stop();
    _loadingController.stop();
    _navigationTimer?.cancel();

    // Kembalikan UI Mode ke normal
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => DashboardPage(
            username: widget.data['username'] ?? '',
            password: widget.data['password'] ?? '',
            role: widget.data['role'] ?? 'user',
            expiredDate: widget.data['expiredDate'] ?? '-',
            sessionKey: widget.data['key'] ?? '', 
            listBug: List<Map<String, dynamic>>.from(widget.data['listBug'] ?? []),
            listPayload: List<Map<String, dynamic>>.from(widget.data['listPayload'] ?? []),
            listDDoS: List<Map<String, dynamic>>.from(widget.data['listDDoS'] ?? []),
            news: List<Map<String, dynamic>>.from(widget.data['news'] ?? []),
          ),
        ), 
      );
    }
  }

  // Fungsi helper untuk mendapatkan persentase loading
  String _getPercentage(double value) {
    // Tahapan: 1% -> 30% -> 50% -> 80% -> 100%
    if (value < 0.30) return "${(value / 0.30 * 1).toInt()}%";
    if (value < 0.50) return "30%";
    if (value < 0.80) return "50%";
    if (value < 1.0) return "80%";
    return "100%";
  }

  // ==================== NEOBRUTALISM UI HELPERS ====================
  
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  @override
  void dispose() {
    _logoScaleController.dispose();
    _loadingController.dispose();
    _navigationTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ===== BACKGROUND DENGAN POLA KOTAK =====
          _buildBackgroundGrid(),

          // ===== KONTEN UTAMA =====
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // ===== LOGO DENGAN BORDER TEBAL =====
                ScaleTransition(
                  scale: _logoScaleAnimation,
                  child: Container(
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.purple,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 4),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.12),
                          offset: const Offset(6, 6),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.asset(
                        'assets/images/splash.jpg',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                // ===== NAMA APP =====
                const Text(
                  "R z y n",
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    color: NeoBrutalismColors.black,
                    letterSpacing: 4,
                  ),
                ),

                const SizedBox(height: 10),

                // ===== BADGE POWERED BY =====
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.yellow,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: NeoBrutalismColors.black.withOpacity(0.08),
                        offset: const Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: const Text(
                    "Powered by @Rizzisreal01",
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: NeoBrutalismColors.black,
                      letterSpacing: 1,
                    ),
                  ),
                ),
                
                const SizedBox(height: 60),

                // ===== LOADING BAR CARD =====
                _neoCard(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  child: AnimatedBuilder(
                    animation: _loadingAnimation,
                    builder: (context, child) {
                      final progress = _loadingAnimation.value;
                      final percentage = _getPercentage(progress);
                      
                      return Column(
                        children: [
                          // ===== DUA TITIK =====
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: NeoBrutalismColors.purple,
                                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                  shape: BoxShape.circle,
                                ),
                              ),
                              const SizedBox(width: 10),
                              Container(
                                width: 8,
                                height: 8,
                                decoration: BoxDecoration(
                                  color: NeoBrutalismColors.yellow,
                                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          
                          // ===== PROGRESS BAR =====
                          Container(
                            width: 280,
                            height: 6,
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.grey,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                            ),
                            child: FractionallySizedBox(
                              alignment: Alignment.centerLeft,
                              widthFactor: progress,
                              child: Container(
                                decoration: BoxDecoration(
                                  color: NeoBrutalismColors.purple,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 14),
                          
                          // ===== PERSENTASE + STATUS =====
                          Text(
                            "$percentage   Initializing...",
                            style: TextStyle(
                              fontFamily: 'Inter',
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                              color: NeoBrutalismColors.darkGrey,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ],
            ),
          ),

          // ===== SKIP BUTTON =====
          Positioned(
            top: 50,
            right: 25,
            child: GestureDetector(
              onTap: _navigateToDashboard,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.white,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.black.withOpacity(0.08),
                      offset: const Offset(3, 3),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Text(
                      "SKIP",
                      style: TextStyle(
                        color: NeoBrutalismColors.black,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                        letterSpacing: 1.5,
                        fontFamily: 'Inter',
                      ),
                    ),
                    SizedBox(width: 6),
                    Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: NeoBrutalismColors.black,
                      size: 12,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ===== BACKGROUND GRID =====
  Widget _buildBackgroundGrid() {
    return CustomPaint(
      painter: GridPainter(),
    );
  }
}

// ===== CUSTOM PAINTER UNTUK GRID =====
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;

    // Garis vertikal
    const double spacing = 40.0;
    for (double x = spacing; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    // Garis horizontal
    for (double y = spacing; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}