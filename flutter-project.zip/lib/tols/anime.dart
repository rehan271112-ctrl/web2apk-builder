import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ==================== NEOBRUTALISM HELPERS ====================
Widget neoCard({
  required Widget child,
  Color bg = NeoBrutalismColors.white,
  double radius = 12,
  double shadowOffset = 5,
  EdgeInsets padding = const EdgeInsets.all(16),
  double? height,
}) {
  return Container(
    height: height,
    padding: padding,
    decoration: BoxDecoration(
      color: bg,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
      boxShadow: [
        BoxShadow(
          color: NeoBrutalismColors.black.withOpacity(0.08),
          offset: Offset(shadowOffset, shadowOffset),
          blurRadius: 0,
        ),
      ],
    ),
    child: child,
  );
}

Widget neoButton({
  required String label,
  required VoidCallback onTap,
  Color bg = NeoBrutalismColors.yellow,
  Color textColor = NeoBrutalismColors.black,
  double fontSize = 13,
  bool isLoading = false,
}) {
  return GestureDetector(
    onTap: isLoading ? null : onTap,
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: const Offset(3, 3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Center(
        child: isLoading
            ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: textColor,
                  strokeWidth: 2,
                ),
              )
            : Text(
                label,
                style: TextStyle(
                  fontSize: fontSize,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 1.5,
                  color: textColor,
                  fontFamily: 'Inter',
                ),
              ),
      ),
    ),
  );
}

// ==================== MAIN PAGE ====================
class HomeAnimePage extends StatefulWidget {
  const HomeAnimePage({super.key});

  @override
  State<HomeAnimePage> createState() => _HomeAnimePageState();
}

class _HomeAnimePageState extends State<HomeAnimePage> {
  Map<String, dynamic>? animeData;
  bool isLoading = true;
  bool isSearching = false;
  List<dynamic> searchResults = [];
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  List<Map<String, dynamic>> _watchHistory = [];
  bool _isHistoryLoading = true;

  // ===== API ENDPOINT =====
  final String baseApi = 'https://api.jikan.moe/v4';

  @override
  void initState() {
    super.initState();
    fetchAnimeData();
    _loadWatchHistory();
  }

  void refreshHistory() {
    _loadWatchHistory();
  }

  Future<void> _loadWatchHistory() async {
    setState(() => _isHistoryLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyJson = prefs.getStringList('watch_history') ?? [];
      setState(() {
        _watchHistory = historyJson
            .map((item) => Map<String, dynamic>.from(json.decode(item)))
            .toList();
        _isHistoryLoading = false;
      });
    } catch (e) {
      setState(() => _isHistoryLoading = false);
    }
  }

  Future<void> fetchAnimeData() async {
    try {
      final response = await http.get(
        Uri.parse('$baseApi/seasons/now'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          animeData = jsonData;
          isLoading = false;
        });
      } else {
        throw Exception('Gagal memuat data anime');
      }
    } catch (e) {
      debugPrint('Error: $e');
      setState(() => isLoading = false);
    }
  }

  Future<void> searchAnime(String query) async {
    if (query.isEmpty) {
      setState(() {
        isSearching = false;
        searchResults.clear();
      });
      return;
    }

    setState(() => isSearching = true);

    try {
      final response = await http.get(
        Uri.parse('$baseApi/anime?q=$query&limit=20'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          searchResults = jsonData['data'] ?? [];
        });
      } else {
        setState(() => searchResults = []);
      }
    } catch (e) {
      debugPrint('Search Error: $e');
      setState(() => searchResults = []);
    }
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      isSearching = false;
      searchResults.clear();
    });
    _searchFocusNode.unfocus();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          Container(
            color: NeoBrutalismColors.grey,
            child: CustomPaint(
              painter: GridPainter(),
              size: Size.infinite,
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                // ===== HEADER =====
                Container(
                  margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: NeoBrutalismColors.black.withOpacity(0.15),
                        offset: const Offset(4, 4),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.purple,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                        ),
                        child: const Icon(
                          Icons.animation,
                          color: NeoBrutalismColors.white,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Text(
                        'Tempat Wibu',
                        style: TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.pink.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: NeoBrutalismColors.pink, width: 2),
                        ),
                        child: const Text(
                          'ANIME',
                          style: TextStyle(
                            color: NeoBrutalismColors.pink,
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                // ===== SEARCH BAR =====
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: neoCard(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: TextField(
                      controller: _searchController,
                      focusNode: _searchFocusNode,
                      style: const TextStyle(
                        color: NeoBrutalismColors.black,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                      decoration: InputDecoration(
                        hintText: "Cari anime...",
                        hintStyle: TextStyle(
                          color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w600,
                        ),
                        prefixIcon: const Icon(
                          Icons.search,
                          color: NeoBrutalismColors.darkGrey,
                        ),
                        suffixIcon: _searchController.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear, color: NeoBrutalismColors.darkGrey),
                                onPressed: _clearSearch,
                              )
                            : null,
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      onChanged: (value) {
                        if (value.isNotEmpty) {
                          searchAnime(value);
                        } else {
                          setState(() {
                            isSearching = false;
                            searchResults.clear();
                          });
                        }
                      },
                    ),
                  ),
                ),

                // ===== CONTENT =====
                Expanded(
                  child: isLoading
                      ? _buildLoadingShimmer()
                      : isSearching
                          ? _buildSearchResults()
                          : animeData == null
                              ? _buildErrorWidget()
                              : _buildHomeContent(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHomeContent() {
    final data = animeData!['data'] ?? [];
    
    return RefreshIndicator(
      onRefresh: () async {
        await Future.wait([fetchAnimeData(), _loadWatchHistory()]);
      },
      color: NeoBrutalismColors.black,
      backgroundColor: NeoBrutalismColors.white,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ===== WATCH HISTORY =====
            _buildSectionHeader(Icons.history, "Riwayat Tontonan"),
            const SizedBox(height: 10),
            if (_isHistoryLoading)
              SizedBox(
                height: 180,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: 5,
                  itemBuilder: (context, index) {
                    return Container(
                      width: 120,
                      margin: const EdgeInsets.only(right: 12),
                      child: Shimmer.fromColors(
                        baseColor: NeoBrutalismColors.grey,
                        highlightColor: NeoBrutalismColors.white,
                        child: Container(
                          height: 160,
                          decoration: BoxDecoration(
                            color: NeoBrutalismColors.grey,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              )
            else if (_watchHistory.isEmpty)
              neoCard(
                height: 100,
                child: const Center(
                  child: Text(
                    "Belum ada riwayat tontonan",
                    style: TextStyle(
                      color: NeoBrutalismColors.darkGrey,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter',
                    ),
                  ),
                ),
              )
            else
              SizedBox(
                height: 200,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _watchHistory.length,
                  itemBuilder: (context, index) {
                    final anime = _watchHistory[index];
                    return _buildHistoryCard(anime);
                  },
                ),
              ),
            const SizedBox(height: 16),

            // ===== QUICK ACCESS =====
            _buildSectionHeader(Icons.dashboard, "Akses Cepat"),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _buildQuickAccessCard(
                    "Genre",
                    Icons.category,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const AnimeGenreListPage(),
                        ),
                      ).then((_) => refreshHistory());
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildQuickAccessCard(
                    "Jadwal",
                    Icons.schedule,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const AnimeSchedulePage(),
                        ),
                      ).then((_) => refreshHistory());
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // ===== ONGOING ANIME =====
            _buildSectionHeader(Icons.live_tv, "Tayang Sekarang"),
            const SizedBox(height: 10),
            _buildAnimeGrid(data),
            const SizedBox(height: 16),

            // ===== POPULAR ANIME =====
            _buildSectionHeader(Icons.trending_up, "Populer"),
            const SizedBox(height: 10),
            _buildPopularAnime(),
          ],
        ),
      ),
    );
  }

  Widget _buildPopularAnime() {
    return FutureBuilder(
      future: http.get(Uri.parse('${baseApi}anime?order_by=popularity&limit=10')),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return _buildLoadingShimmer();
        }
        if (snapshot.hasError || !snapshot.hasData) {
          return const SizedBox.shrink();
        }
        try {
          final data = json.decode(snapshot.data!.body);
          final list = data['data'] ?? [];
          return _buildAnimeGrid(list);
        } catch (e) {
          return const SizedBox.shrink();
        }
      },
    );
  }

  Widget _buildSectionHeader(IconData icon, String title) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: NeoBrutalismColors.purple.withOpacity(0.15),
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: NeoBrutalismColors.purple, width: 2),
          ),
          child: Icon(icon, color: NeoBrutalismColors.purple, size: 16),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w800,
            color: NeoBrutalismColors.black,
            fontFamily: 'Inter',
          ),
        ),
      ],
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> anime) {
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 12),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AnimeDetailPage(
                animeId: anime['mal_id'] ?? 0,
                onHistoryUpdate: refreshHistory,
              ),
            ),
          ).then((_) => refreshHistory());
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                boxShadow: [
                  BoxShadow(
                    color: NeoBrutalismColors.black.withOpacity(0.1),
                    offset: const Offset(4, 4),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: Image.network(
                  anime['poster'] ?? '',
                  height: 160,
                  width: 120,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 160,
                    width: 120,
                    color: NeoBrutalismColors.grey,
                    alignment: Alignment.center,
                    child: const Icon(
                      Icons.image_not_supported,
                      color: NeoBrutalismColors.darkGrey,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              anime['title'] ?? 'Unknown',
              style: const TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 11,
                fontWeight: FontWeight.w700,
                fontFamily: 'Inter',
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAccessCard(String title, IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: neoCard(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.purple.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.purple, width: 2),
              ),
              child: Icon(icon, color: NeoBrutalismColors.purple, size: 28),
            ),
            const SizedBox(height: 8),
            Text(
              title,
              style: const TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 13,
                fontWeight: FontWeight.w700,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimeGrid(List<dynamic> list) {
    if (list.isEmpty) {
      return neoCard(
        height: 100,
        child: const Center(
          child: Text(
            "Tidak ada anime",
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 13,
              fontWeight: FontWeight.w600,
              fontFamily: 'Inter',
            ),
          ),
        ),
      );
    }

    return GridView.builder(
      itemCount: list.length > 6 ? 6 : list.length,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisExtent: 240,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemBuilder: (context, index) {
        final anime = list[index];
        final title = anime['title'] ?? 'Unknown';
        final poster = anime['images']?['jpg']?['image_url'] ?? anime['poster'] ?? '';
        final episodes = anime['episodes']?.toString() ?? '?';
        final malId = anime['mal_id'] ?? 0;

        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AnimeDetailPage(
                  animeId: malId,
                  onHistoryUpdate: refreshHistory,
                ),
              ),
            ).then((_) => refreshHistory());
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.black.withOpacity(0.1),
                      offset: const Offset(4, 4),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: Image.network(
                    poster,
                    height: 160,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 160,
                      color: NeoBrutalismColors.grey,
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.image_not_supported,
                        color: NeoBrutalismColors.darkGrey,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: NeoBrutalismColors.black,
                  fontFamily: 'Inter',
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              Text(
                "$episodes Episode",
                style: TextStyle(
                  fontSize: 10,
                  color: NeoBrutalismColors.darkGrey,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSearchResults() {
    if (searchResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.search_off,
              color: NeoBrutalismColors.darkGrey,
              size: 64,
            ),
            const SizedBox(height: 16),
            const Text(
              "Tidak ada hasil",
              style: TextStyle(
                color: NeoBrutalismColors.darkGrey,
                fontSize: 16,
                fontWeight: FontWeight.w700,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Coba dengan kata kunci lain",
              style: TextStyle(
                color: NeoBrutalismColors.darkGrey,
                fontSize: 13,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: searchResults.length,
      itemBuilder: (context, index) {
        final anime = searchResults[index];
        return _buildSearchResultCard(anime);
      },
    );
  }

  Widget _buildSearchResultCard(Map<String, dynamic> anime) {
    final title = anime['title'] ?? 'Unknown';
    final poster = anime['images']?['jpg']?['image_url'] ?? '';
    final score = anime['score']?.toString() ?? '-';
    final episodes = anime['episodes']?.toString() ?? '?';
    final malId = anime['mal_id'] ?? 0;
    final synopsis = anime['synopsis'] ?? '';
    final genres = anime['genres'] ?? [];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.1),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AnimeDetailPage(
                animeId: malId,
                onHistoryUpdate: refreshHistory,
              ),
            ),
          ).then((_) => refreshHistory());
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: Image.network(
                    poster,
                    width: 80,
                    height: 110,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 80,
                      height: 110,
                      color: NeoBrutalismColors.grey,
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.image_not_supported,
                        color: NeoBrutalismColors.darkGrey,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: NeoBrutalismColors.black,
                        fontFamily: 'Inter',
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.star, color: NeoBrutalismColors.yellow, size: 14),
                        const SizedBox(width: 4),
                        Text(
                          score,
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Inter',
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          "$episodes Ep",
                          style: TextStyle(
                            color: NeoBrutalismColors.darkGrey,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    if (genres.isNotEmpty)
                      Wrap(
                        spacing: 4,
                        runSpacing: 4,
                        children: genres.take(3).map<Widget>((genre) {
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.purple.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: NeoBrutalismColors.purple, width: 1),
                            ),
                            child: Text(
                              genre['name'] ?? '',
                              style: TextStyle(
                                color: NeoBrutalismColors.purple,
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                                fontFamily: 'Inter',
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    if (synopsis.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        synopsis,
                        style: TextStyle(
                          color: NeoBrutalismColors.darkGrey,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter',
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 6,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisExtent: 240,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: NeoBrutalismColors.grey,
        highlightColor: NeoBrutalismColors.white,
        child: Container(
          decoration: BoxDecoration(
            color: NeoBrutalismColors.grey,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.error_outline,
            color: NeoBrutalismColors.darkGrey,
            size: 64,
          ),
          const SizedBox(height: 16),
          const Text(
            "Gagal memuat data",
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              fontFamily: 'Inter',
            ),
          ),
          const SizedBox(height: 16),
          neoButton(
            label: "COBA LAGI",
            onTap: () async {
              await Future.wait([fetchAnimeData(), _loadWatchHistory()]);
            },
            bg: NeoBrutalismColors.yellow,
            textColor: NeoBrutalismColors.black,
          ),
        ],
      ),
    );
  }
}

// ==================== ANIME DETAIL PAGE ====================
class AnimeDetailPage extends StatefulWidget {
  final int animeId;
  final Function()? onHistoryUpdate;

  const AnimeDetailPage({
    super.key,
    required this.animeId,
    this.onHistoryUpdate,
  });

  @override
  State<AnimeDetailPage> createState() => _AnimeDetailPageState();
}

class _AnimeDetailPageState extends State<AnimeDetailPage> {
  Map<String, dynamic>? animeDetail;
  bool isLoading = true;
  bool isError = false;

  final String baseApi = 'https://api.jikan.moe/v4';

  @override
  void initState() {
    super.initState();
    fetchAnimeDetail();
  }

  Future<void> fetchAnimeDetail() async {
    try {
      final response = await http.get(
        Uri.parse('$baseApi/anime/${widget.animeId}/full'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          animeDetail = jsonData['data'];
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      debugPrint('Error: $e');
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  Future<void> _addToWatchHistory() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyJson = prefs.getStringList('watch_history') ?? [];
      List<Map<String, dynamic>> watchHistory = historyJson
          .map((item) => Map<String, dynamic>.from(json.decode(item)))
          .toList();

      final historyItem = {
        'mal_id': widget.animeId,
        'title': animeDetail?['title'] ?? 'Unknown',
        'poster': animeDetail?['images']?['jpg']?['image_url'] ?? '',
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      };

      watchHistory.removeWhere((item) => item['mal_id'] == widget.animeId);
      watchHistory.insert(0, historyItem);

      if (watchHistory.length > 20) {
        watchHistory = watchHistory.sublist(0, 20);
      }

      final newHistoryJson = watchHistory.map((item) => json.encode(item)).toList();
      await prefs.setStringList('watch_history', newHistoryJson);

      if (widget.onHistoryUpdate != null) {
        widget.onHistoryUpdate!();
      }
    } catch (e) {
      debugPrint('Error saving to watch history: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          Container(
            color: NeoBrutalismColors.grey,
            child: CustomPaint(
              painter: GridPainter(),
              size: Size.infinite,
            ),
          ),
          SafeArea(
            child: isLoading
                ? _buildLoadingShimmer()
                : isError || animeDetail == null
                    ? _buildErrorWidget()
                    : _buildAnimeDetail(),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Shimmer.fromColors(
            baseColor: NeoBrutalismColors.grey,
            highlightColor: NeoBrutalismColors.white,
            child: Container(
              height: 200,
              width: double.infinity,
              decoration: BoxDecoration(
                color: NeoBrutalismColors.grey,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Shimmer.fromColors(
            baseColor: NeoBrutalismColors.grey,
            highlightColor: NeoBrutalismColors.white,
            child: Container(
              height: 24,
              width: 200,
              decoration: BoxDecoration(
                color: NeoBrutalismColors.grey,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.error_outline,
            color: NeoBrutalismColors.darkGrey,
            size: 64,
          ),
          const SizedBox(height: 16),
          const Text(
            "Gagal memuat detail anime",
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              fontFamily: 'Inter',
            ),
          ),
          const SizedBox(height: 16),
          neoButton(
            label: "COBA LAGI",
            onTap: fetchAnimeDetail,
            bg: NeoBrutalismColors.yellow,
          ),
        ],
      ),
    );
  }

  Widget _buildAnimeDetail() {
    final anime = animeDetail!;
    final poster = anime['images']?['jpg']?['image_url'] ?? '';
    final title = anime['title'] ?? 'Unknown';
    final titleJapanese = anime['title_japanese'] ?? '';
    final synopsis = anime['synopsis'] ?? 'Tidak ada sinopsis';
    final score = anime['score']?.toString() ?? '-';
    final episodes = anime['episodes']?.toString() ?? '?';
    final status = anime['status'] ?? 'Unknown';
    final duration = anime['duration'] ?? '-';
    final genres = anime['genres'] ?? [];
    final studios = anime['studios'] ?? [];
    final year = anime['year']?.toString() ?? '-';

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ===== BACK BUTTON =====
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: NeoBrutalismColors.black.withOpacity(0.08),
                    offset: const Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: const Icon(
                Icons.arrow_back_ios_new_rounded,
                color: NeoBrutalismColors.black,
                size: 18,
              ),
            ),
          ),
          const SizedBox(height: 16),

          // ===== HEADER =====
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 120,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                  boxShadow: [
                    BoxShadow(
                      color: NeoBrutalismColors.black.withOpacity(0.12),
                      offset: const Offset(6, 6),
                      blurRadius: 0,
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    poster,
                    height: 170,
                    width: 120,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 170,
                      width: 120,
                      color: NeoBrutalismColors.grey,
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.image_not_supported,
                        color: NeoBrutalismColors.darkGrey,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: NeoBrutalismColors.black,
                        fontFamily: 'Inter',
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (titleJapanese.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        titleJapanese,
                        style: TextStyle(
                          fontSize: 12,
                          color: NeoBrutalismColors.darkGrey,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.star, color: NeoBrutalismColors.yellow, size: 16),
                        const SizedBox(width: 4),
                        Text(
                          score,
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      children: [
                        _buildInfoChip("📺 $episodes Ep"),
                        _buildInfoChip("📅 $year"),
                        _buildInfoChip("⏱ $duration"),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: status.toLowerCase().contains('airing')
                            ? NeoBrutalismColors.green.withOpacity(0.15)
                            : NeoBrutalismColors.blue.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(
                          color: status.toLowerCase().contains('airing')
                              ? NeoBrutalismColors.green
                              : NeoBrutalismColors.blue,
                          width: 2,
                        ),
                      ),
                      child: Text(
                        status,
                        style: TextStyle(
                          color: status.toLowerCase().contains('airing')
                              ? NeoBrutalismColors.green
                              : NeoBrutalismColors.blue,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // ===== GENRES =====
          if (genres.isNotEmpty) ...[
            const Text(
              "Genre",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: NeoBrutalismColors.black,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: genres.map<Widget>((genre) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.purple.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: NeoBrutalismColors.purple, width: 2),
                  ),
                  child: Text(
                    genre['name'] ?? '',
                    style: TextStyle(
                      color: NeoBrutalismColors.purple,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Inter',
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
          ],

          // ===== STUDIOS =====
          if (studios.isNotEmpty) ...[
            const Text(
              "Studio",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: NeoBrutalismColors.black,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: studios.map<Widget>((studio) {
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.blue.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: NeoBrutalismColors.blue, width: 2),
                  ),
                  child: Text(
                    studio['name'] ?? '',
                    style: TextStyle(
                      color: NeoBrutalismColors.blue,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Inter',
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 12),
          ],

          // ===== SYNOPSIS =====
          const Text(
            "Sinopsis",
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: NeoBrutalismColors.black,
              fontFamily: 'Inter',
            ),
          ),
          const SizedBox(height: 6),
          neoCard(
            padding: const EdgeInsets.all(14),
            child: Text(
              synopsis,
              style: TextStyle(
                color: NeoBrutalismColors.black.withOpacity(0.7),
                fontSize: 13,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
                height: 1.5,
              ),
              textAlign: TextAlign.justify,
            ),
          ),
          const SizedBox(height: 12),

          // ===== TRAILER =====
          if (anime['trailer']?['embed_url'] != null) ...[
            const Text(
              "Trailer",
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: NeoBrutalismColors.black,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(height: 6),
            neoButton(
              label: "▶ TONTON TRAILER",
              onTap: () {
                final url = anime['trailer']['embed_url'];
                if (url != null) {
                  launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
                }
              },
              bg: NeoBrutalismColors.pink,
              textColor: NeoBrutalismColors.white,
            ),
          ],
          const SizedBox(height: 16),

          // ===== ADD TO HISTORY =====
          neoButton(
            label: "📚 TAMBAHKAN KE RIWAYAT",
            onTap: () {
              _addToWatchHistory();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text("Ditambahkan ke riwayat tontonan"),
                  backgroundColor: NeoBrutalismColors.green,
                ),
              );
            },
            bg: NeoBrutalismColors.purple,
            textColor: NeoBrutalismColors.white,
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.grey,
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: NeoBrutalismColors.black,
          fontSize: 9,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter',
        ),
      ),
    );
  }
}

// ==================== GENRE LIST PAGE ====================
class AnimeGenreListPage extends StatefulWidget {
  const AnimeGenreListPage({super.key});

  @override
  State<AnimeGenreListPage> createState() => _AnimeGenreListPageState();
}

class _AnimeGenreListPageState extends State<AnimeGenreListPage> {
  List<dynamic> genreList = [];
  bool isLoading = true;
  bool isError = false;
  final String baseApi = 'https://api.jikan.moe/v4';

  @override
  void initState() {
    super.initState();
    fetchGenreList();
  }

  Future<void> fetchGenreList() async {
    try {
      final response = await http.get(Uri.parse('$baseApi/genres/anime'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          genreList = jsonData['data'] ?? [];
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          Container(
            color: NeoBrutalismColors.grey,
            child: CustomPaint(
              painter: GridPainter(),
              size: Size.infinite,
            ),
          ),
          SafeArea(
            child: isLoading
                ? _buildLoadingShimmer()
                : isError
                    ? _buildErrorWidget()
                    : _buildGenreGrid(),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 20,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 3.0,
      ),
      itemBuilder: (context, index) {
        return Shimmer.fromColors(
          baseColor: NeoBrutalismColors.grey,
          highlightColor: NeoBrutalismColors.white,
          child: Container(
            decoration: BoxDecoration(
              color: NeoBrutalismColors.grey,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
            ),
          ),
        );
      },
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, color: NeoBrutalismColors.darkGrey, size: 64),
          const SizedBox(height: 16),
          const Text(
            "Gagal memuat genre",
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              fontFamily: 'Inter',
            ),
          ),
          const SizedBox(height: 16),
          neoButton(
            label: "COBA LAGI",
            onTap: fetchGenreList,
            bg: NeoBrutalismColors.yellow,
          ),
        ],
      ),
    );
  }

  Widget _buildGenreGrid() {
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: NeoBrutalismColors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
            boxShadow: [
              BoxShadow(
                color: NeoBrutalismColors.black.withOpacity(0.08),
                offset: const Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.purple,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                ),
                child: const Icon(Icons.category, color: NeoBrutalismColors.white, size: 20),
              ),
              const SizedBox(width: 10),
              const Text(
                "Genre Anime",
                style: TextStyle(
                  color: NeoBrutalismColors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Inter',
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: GridView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: genreList.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 3.0,
            ),
            itemBuilder: (context, index) {
              final genre = genreList[index];
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AnimeGenrePage(
                        genreId: genre['mal_id'] ?? 0,
                        genreName: genre['name'] ?? 'Unknown',
                      ),
                    ),
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: NeoBrutalismColors.black.withOpacity(0.08),
                        offset: const Offset(3, 3),
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: Center(
                    child: Text(
                      genre['name'] ?? 'Unknown',
                      style: const TextStyle(
                        color: NeoBrutalismColors.black,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Inter',
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

// ==================== GENRE PAGE ====================
class AnimeGenrePage extends StatefulWidget {
  final int genreId;
  final String genreName;

  const AnimeGenrePage({
    super.key,
    required this.genreId,
    required this.genreName,
  });

  @override
  State<AnimeGenrePage> createState() => _AnimeGenrePageState();
}

class _AnimeGenrePageState extends State<AnimeGenrePage> {
  List<dynamic> animeList = [];
  bool isLoading = true;
  bool isError = false;
  int currentPage = 1;
  bool hasMore = true;
  final String baseApi = 'https://api.jikan.moe/v4';

  @override
  void initState() {
    super.initState();
    fetchGenreAnime();
  }

  Future<void> fetchGenreAnime({int page = 1}) async {
    try {
      final response = await http.get(
        Uri.parse('$baseApi/anime?genres=${widget.genreId}&page=$page&limit=20'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final data = jsonData['data'] ?? [];
        setState(() {
          if (page == 1) {
            animeList = data;
          } else {
            animeList.addAll(data);
          }
          isLoading = false;
          currentPage = page;
          hasMore = data.isNotEmpty;
        });
      } else {
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  void _loadMore() {
    if (!hasMore || isLoading) return;
    fetchGenreAnime(page: currentPage + 1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          Container(
            color: NeoBrutalismColors.grey,
            child: CustomPaint(
              painter: GridPainter(),
              size: Size.infinite,
            ),
          ),
          SafeArea(
            child: isLoading && animeList.isEmpty
                ? _buildLoadingShimmer()
                : isError
                    ? _buildErrorWidget()
                    : _buildGenreContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 10,
      itemBuilder: (context, index) {
        return Shimmer.fromColors(
          baseColor: NeoBrutalismColors.grey,
          highlightColor: NeoBrutalismColors.white,
          child: Container(
            height: 120,
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: NeoBrutalismColors.grey,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
            ),
          ),
        );
      },
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, color: NeoBrutalismColors.darkGrey, size: 64),
          const SizedBox(height: 16),
          const Text(
            "Gagal memuat anime genre ini",
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              fontFamily: 'Inter',
            ),
          ),
          const SizedBox(height: 16),
          neoButton(
            label: "COBA LAGI",
            onTap: () => fetchGenreAnime(),
            bg: NeoBrutalismColors.yellow,
          ),
        ],
      ),
    );
  }

  Widget _buildGenreContent() {
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: NeoBrutalismColors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
            boxShadow: [
              BoxShadow(
                color: NeoBrutalismColors.black.withOpacity(0.08),
                offset: const Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.purple,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                ),
                child: const Icon(Icons.category, color: NeoBrutalismColors.white, size: 20),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  "Genre: ${widget.genreName}",
                  style: const TextStyle(
                    color: NeoBrutalismColors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Inter',
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.purple,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                ),
                child: Text(
                  "${animeList.length} Anime",
                  style: const TextStyle(
                    color: NeoBrutalismColors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'Inter',
                  ),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: animeList.isEmpty
              ? const Center(
                  child: Text(
                    "Tidak ada anime di genre ini",
                    style: TextStyle(
                      color: NeoBrutalismColors.darkGrey,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter',
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: animeList.length + (hasMore ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == animeList.length) {
                      return Center(
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: _buildLoadMoreButton(),
                        ),
                      );
                    }
                    final anime = animeList[index];
                    return _buildAnimeCard(anime);
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildLoadMoreButton() {
    return neoButton(
      label: "MUAT LAGI",
      onTap: _loadMore,
      bg: NeoBrutalismColors.yellow,
      textColor: NeoBrutalismColors.black,
      isLoading: isLoading,
    );
  }

  Widget _buildAnimeCard(Map<String, dynamic> anime) {
    final title = anime['title'] ?? 'Unknown';
    final poster = anime['images']?['jpg']?['image_url'] ?? '';
    final score = anime['score']?.toString() ?? '-';
    final episodes = anime['episodes']?.toString() ?? '?';
    final malId = anime['mal_id'] ?? 0;
    final synopsis = anime['synopsis'] ?? '';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.1),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AnimeDetailPage(animeId: malId),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: Image.network(
                    poster,
                    width: 70,
                    height: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      width: 70,
                      height: 100,
                      color: NeoBrutalismColors.grey,
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.image_not_supported,
                        color: NeoBrutalismColors.darkGrey,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: NeoBrutalismColors.black,
                        fontFamily: 'Inter',
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.star, color: NeoBrutalismColors.yellow, size: 12),
                        const SizedBox(width: 4),
                        Text(
                          score,
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Inter',
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          "$episodes Ep",
                          style: TextStyle(
                            color: NeoBrutalismColors.darkGrey,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                    if (synopsis.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        synopsis,
                        style: TextStyle(
                          color: NeoBrutalismColors.darkGrey,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter',
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== SCHEDULE PAGE ====================
class AnimeSchedulePage extends StatefulWidget {
  const AnimeSchedulePage({super.key});

  @override
  State<AnimeSchedulePage> createState() => _AnimeSchedulePageState();
}

class _AnimeSchedulePageState extends State<AnimeSchedulePage> {
  List<dynamic> scheduleData = [];
  bool isLoading = true;
  bool isError = false;
  final String baseApi = 'https://api.jikan.moe/v4';

  @override
  void initState() {
    super.initState();
    fetchSchedule();
  }

  Future<void> fetchSchedule() async {
    try {
      final response = await http.get(Uri.parse('$baseApi/schedules'));
      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        setState(() {
          scheduleData = jsonData['data'] ?? [];
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
          isError = true;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        isError = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          Container(
            color: NeoBrutalismColors.grey,
            child: CustomPaint(
              painter: GridPainter(),
              size: Size.infinite,
            ),
          ),
          SafeArea(
            child: isLoading
                ? _buildLoadingShimmer()
                : isError
                    ? _buildErrorWidget()
                    : _buildScheduleContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingShimmer() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: 7,
      itemBuilder: (context, index) {
        return Shimmer.fromColors(
          baseColor: NeoBrutalismColors.grey,
          highlightColor: NeoBrutalismColors.white,
          child: Container(
            height: 160,
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: NeoBrutalismColors.grey,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
            ),
          ),
        );
      },
    );
  }

  Widget _buildErrorWidget() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, color: NeoBrutalismColors.darkGrey, size: 64),
          const SizedBox(height: 16),
          const Text(
            "Gagal memuat jadwal",
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              fontFamily: 'Inter',
            ),
          ),
          const SizedBox(height: 16),
          neoButton(
            label: "COBA LAGI",
            onTap: fetchSchedule,
            bg: NeoBrutalismColors.yellow,
          ),
        ],
      ),
    );
  }

  Widget _buildScheduleContent() {
    return Column(
      children: [
        Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: NeoBrutalismColors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
            boxShadow: [
              BoxShadow(
                color: NeoBrutalismColors.black.withOpacity(0.08),
                offset: const Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: NeoBrutalismColors.pink,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                ),
                child: const Icon(Icons.schedule, color: NeoBrutalismColors.white, size: 20),
              ),
              const SizedBox(width: 10),
              const Text(
                "Jadwal Tayang Anime",
                style: TextStyle(
                  color: NeoBrutalismColors.black,
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Inter',
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: scheduleData.isEmpty
              ? const Center(
                  child: Text(
                    "Tidak ada jadwal",
                    style: TextStyle(
                      color: NeoBrutalismColors.darkGrey,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter',
                    ),
                  ),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: scheduleData.length,
                  itemBuilder: (context, index) {
                    final anime = scheduleData[index];
                    final title = anime['title'] ?? 'Unknown';
                    final poster = anime['images']?['jpg']?['image_url'] ?? '';
                    final episodes = anime['episodes']?.toString() ?? '?';
                    final malId = anime['mal_id'] ?? 0;
                    final broadcast = anime['broadcast']?['string'] ?? 'Unknown';

                    return Container(
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: NeoBrutalismColors.black.withOpacity(0.1),
                            offset: const Offset(4, 4),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: InkWell(
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => AnimeDetailPage(animeId: malId),
                            ),
                          );
                        },
                        borderRadius: BorderRadius.circular(12),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(4),
                                  child: Image.network(
                                    poster,
                                    width: 60,
                                    height: 85,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => Container(
                                      width: 60,
                                      height: 85,
                                      color: NeoBrutalismColors.grey,
                                      alignment: Alignment.center,
                                      child: const Icon(
                                        Icons.image_not_supported,
                                        color: NeoBrutalismColors.darkGrey,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      title,
                                      style: const TextStyle(
                                        fontSize: 13,
                                        fontWeight: FontWeight.w800,
                                        color: NeoBrutalismColors.black,
                                        fontFamily: 'Inter',
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      "$episodes Episode",
                                      style: TextStyle(
                                        color: NeoBrutalismColors.darkGrey,
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'Inter',
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: NeoBrutalismColors.green.withOpacity(0.15),
                                        borderRadius: BorderRadius.circular(4),
                                        border: Border.all(color: NeoBrutalismColors.green, width: 1),
                                      ),
                                      child: Text(
                                        broadcast,
                                        style: TextStyle(
                                          color: NeoBrutalismColors.green,
                                          fontSize: 9,
                                          fontWeight: FontWeight.w700,
                                          fontFamily: 'Inter',
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}