import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ReportWaPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ReportWaPage({
    super.key, 
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ReportWaPage> createState() => _ReportWaPageState();
}

class _ReportWaPageState extends State<ReportWaPage> {
  // ==================== CONTROLLERS ====================
  final TextEditingController _targetController = TextEditingController();
  final TextEditingController _amountController = TextEditingController(text: "5");
  final ScrollController _logScrollController = ScrollController();

  // ==================== STATE ====================
  bool _isAttacking = false;
  bool _isLoadingSenders = false;
  List<dynamic> _privateSenders = [];
  List<dynamic> _globalSenders = [];
  String _selectedSenderType = "global";
  List<String> _logs = [];
  int _successCount = 0;
  int _failCount = 0;

  // ==================== TEKS & GAMBAR SPAM ====================
  final String _spamText = "MAKLO AMPAS MAKLO AMPAS YATIM TOLOL BEGO REDUP AJA LU ANJ MATI AJA ANAK BABI🤪😹😹🤪🖕🖕";
  final String _spamImage = "https://cdn.phototourl.com/free/2026-07-21-1f2b70c7-3163-4291-ad0e-f09c90c7ceec.jpg";

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _neoButton({
    required String label,
    required VoidCallback onTap,
    Color bg = NeoBrutalismColors.yellow,
    Color textColor = NeoBrutalismColors.black,
    double fontSize = 14,
    bool isDanger = false,
  }) {
    final buttonColor = isDanger ? NeoBrutalismColors.pink : bg;
    final buttonTextColor = isDanger ? NeoBrutalismColors.white : textColor;
    
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: buttonColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
          boxShadow: [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.1),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.w800,
              letterSpacing: 2,
              color: buttonTextColor,
              fontFamily: 'Inter',
            ),
          ),
        ),
      ),
    );
  }

  Widget _neoInput({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool isNumber = false,
    double flex = 1,
  }) {
    return Expanded(
      flex: flex.toInt(),
      child: TextField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.phone,
        style: const TextStyle(
          color: NeoBrutalismColors.black,
          fontSize: 14,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter',
        ),
        cursorColor: NeoBrutalismColors.black,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(
            color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
            fontFamily: 'Inter',
            fontWeight: FontWeight.w600,
          ),
          prefixIcon: Icon(icon, color: NeoBrutalismColors.darkGrey, size: 18),
          filled: true,
          fillColor: NeoBrutalismColors.grey,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchSenders();
  }

  @override
  void dispose() {
    _targetController.dispose();
    _amountController.dispose();
    _logScrollController.dispose();
    super.dispose();
  }

  // ==================== FETCH SENDERS ====================
  Future<void> _fetchSenders() async {
    setState(() => _isLoadingSenders = true);
    _addLog("[SYSTEM] Authenticating as ${widget.username}...");
    
    try {
      final uri = Uri.parse("$baseUrl/api/whatsapp/mySender?key=${widget.sessionKey}");
      final response = await http.get(uri);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          final connections = data['connections'];
          
          setState(() {
            _privateSenders = connections['private'] ?? [];
            _globalSenders = connections['global'] ?? [];
          });
          
          final total = _privateSenders.length + _globalSenders.length;
          _addLog("[ACCESS GRANTED] $total Agents Loaded.");
          _addLog("  └─ Global: ${_globalSenders.length} Agents");
          _addLog("  └─ Private: ${_privateSenders.length} Agents");
        } else {
          _addLog("[ERROR] Session Expired / Invalid Key.");
        }
      } else {
        _addLog("[ERROR] Server Offline (Status: ${response.statusCode})");
      }
    } catch (e) {
      _addLog("[FATAL] Connection Failed: $e");
    } finally {
      setState(() => _isLoadingSenders = false);
    }
  }

  // ==================== EKSEKUSI SPAM ====================
  Future<void> _executeSpam() async {
    final List<dynamic> selectedSenders = _selectedSenderType == "global" 
        ? _globalSenders 
        : _privateSenders;

    if (selectedSenders.isEmpty) {
      _showSnack("No ${_selectedSenderType.toUpperCase()} senders available!", NeoBrutalismColors.pink);
      return;
    }

    if (_targetController.text.isEmpty) {
      _showSnack("Target number is required!", NeoBrutalismColors.pink);
      return;
    }

    int totalAmount = int.tryParse(_amountController.text) ?? 5;
    if (totalAmount < 1) totalAmount = 1;
    if (totalAmount > 50) totalAmount = 50;

    setState(() {
      _isAttacking = true;
      _successCount = 0;
      _failCount = 0;
      _logs.clear();
      _addLog("[SYSTEM] 🚀 STARTING SPAM ATTACK");
      _addLog("[TARGET] ${_targetController.text}");
      _addLog("[AMOUNT] $totalAmount Messages");
      _addLog("[SENDER TYPE] ${_selectedSenderType.toUpperCase()}");
      _addLog("[AGENTS] ${selectedSenders.length} Active");
      _addLog("─" * 30);
    });

    for (int i = 0; i < totalAmount; i++) {
      if (!_isAttacking) break;

      var sender = selectedSenders[i % selectedSenders.length];
      String senderNum = sender['owner'] ?? 'Unknown';

      try {
        // ===== 1. KIRIM TEKS =====
        final textResponse = await http.post(
          Uri.parse("$baseUrl/api/whatsapp/spamText"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "key": widget.sessionKey,
            "target": _targetController.text,
            "sender_number": senderNum,
            "message": _spamText,
          }),
        );

        if (textResponse.statusCode == 200) {
          final textData = jsonDecode(textResponse.body);
          if (textData['success'] == true) {
            _addLog("[${i+1}] 📝 TEXT SENT via $senderNum");
            setState(() => _successCount++);
          } else {
            _addLog("[${i+1}] ❌ TEXT FAILED: ${textData['message'] ?? 'Unknown error'}");
            setState(() => _failCount++);
            continue;
          }
        } else {
          _addLog("[${i+1}] ❌ TEXT FAILED (HTTP ${textResponse.statusCode})");
          setState(() => _failCount++);
          continue;
        }

        await Future.delayed(const Duration(milliseconds: 500));

        // ===== 2. KIRIM GAMBAR =====
        final imageResponse = await http.post(
          Uri.parse("$baseUrl/api/whatsapp/spamImage"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "key": widget.sessionKey,
            "target": _targetController.text,
            "sender_number": senderNum,
            "image_url": _spamImage,
            "caption": "MAKLO AMPAS! 🤪🖕",
          }),
        );

        if (imageResponse.statusCode == 200) {
          final imageData = jsonDecode(imageResponse.body);
          if (imageData['success'] == true) {
            _addLog("[${i+1}] 🖼️ IMAGE SENT via $senderNum");
            setState(() => _successCount++);
          } else {
            _addLog("[${i+1}] ❌ IMAGE FAILED: ${imageData['message'] ?? 'Unknown error'}");
            setState(() => _failCount++);
          }
        } else {
          _addLog("[${i+1}] ❌ IMAGE FAILED (HTTP ${imageResponse.statusCode})");
          setState(() => _failCount++);
        }

        await Future.delayed(const Duration(milliseconds: 300));
        
      } catch (e) {
        _addLog("[${i+1}] 💀 ERROR: $e");
        setState(() => _failCount++);
      }
    }

    setState(() {
      _isAttacking = false;
      _addLog("─" * 30);
      _addLog("[SYSTEM] ✅ SPAM COMPLETED");
      _addLog("  └─ Success: $_successCount");
      _addLog("  └─ Failed: $_failCount");
      _addLog("  └─ Total: ${_successCount + _failCount}");
    });
  }

  void _addLog(String log) {
    if (!mounted) return;
    setState(() {
      _logs.add(log);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_logScrollController.hasClients) {
          _logScrollController.animateTo(
            _logScrollController.position.maxScrollExtent,
            duration: const Duration(milliseconds: 300),
            curve: Curves.easeOut,
          );
        }
      });
    });
  }

  void _showSnack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(
        color: NeoBrutalismColors.white,
        fontFamily: 'Inter',
        fontWeight: FontWeight.w600,
      )),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
      ),
    ));
  }

  // ==================== SENDER TYPE SELECTOR ====================
  Widget _buildSenderTypeSelector() {
    final int globalCount = _globalSenders.length;
    final int privateCount = _privateSenders.length;

    return _neoCard(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedSenderType = "global"),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: _selectedSenderType == "global" 
                      ? NeoBrutalismColors.blue.withOpacity(0.15) 
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _selectedSenderType == "global" 
                        ? NeoBrutalismColors.blue 
                        : NeoBrutalismColors.darkGrey.withOpacity(0.3),
                    width: _selectedSenderType == "global" ? 2 : 1,
                  ),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(FontAwesomeIcons.globe, 
                            color: _selectedSenderType == "global" 
                                ? NeoBrutalismColors.blue 
                                : NeoBrutalismColors.darkGrey, 
                            size: 16),
                        const SizedBox(width: 6),
                        Text(
                          "GLOBAL",
                          style: TextStyle(
                            color: _selectedSenderType == "global" 
                                ? NeoBrutalismColors.blue 
                                : NeoBrutalismColors.darkGrey,
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            fontFamily: 'Inter',
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                      decoration: BoxDecoration(
                        color: _selectedSenderType == "global" 
                            ? NeoBrutalismColors.blue.withOpacity(0.15) 
                            : NeoBrutalismColors.grey,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: _selectedSenderType == "global" 
                              ? NeoBrutalismColors.blue 
                              : NeoBrutalismColors.darkGrey.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: Text(
                        "$globalCount AGENTS",
                        style: TextStyle(
                          color: _selectedSenderType == "global" 
                              ? NeoBrutalismColors.blue 
                              : NeoBrutalismColors.darkGrey,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => _selectedSenderType = "private"),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: _selectedSenderType == "private" 
                      ? NeoBrutalismColors.purple.withOpacity(0.15) 
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _selectedSenderType == "private" 
                        ? NeoBrutalismColors.purple 
                        : NeoBrutalismColors.darkGrey.withOpacity(0.3),
                    width: _selectedSenderType == "private" ? 2 : 1,
                  ),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.lock_outline, 
                            color: _selectedSenderType == "private" 
                                ? NeoBrutalismColors.purple 
                                : NeoBrutalismColors.darkGrey, 
                            size: 16),
                        const SizedBox(width: 6),
                        Text(
                          "PRIVATE",
                          style: TextStyle(
                            color: _selectedSenderType == "private" 
                                ? NeoBrutalismColors.purple 
                                : NeoBrutalismColors.darkGrey,
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                            fontFamily: 'Inter',
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                      decoration: BoxDecoration(
                        color: _selectedSenderType == "private" 
                            ? NeoBrutalismColors.purple.withOpacity(0.15) 
                            : NeoBrutalismColors.grey,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: _selectedSenderType == "private" 
                              ? NeoBrutalismColors.purple 
                              : NeoBrutalismColors.darkGrey.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: Text(
                        "$privateCount AGENTS",
                        style: TextStyle(
                          color: _selectedSenderType == "private" 
                              ? NeoBrutalismColors.purple 
                              : NeoBrutalismColors.darkGrey,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== LOGS ====================
  Widget _buildLogs() {
    return Container(
      height: 200,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: const Offset(4, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Icon(Icons.terminal, color: NeoBrutalismColors.purple, size: 16),
                  const SizedBox(width: 8),
                  Text(
                    "> SYSTEM LOGS",
                    style: TextStyle(
                      color: NeoBrutalismColors.purple,
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                      fontFamily: 'Inter',
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
              if (_isAttacking)
                const SizedBox(
                  height: 14,
                  width: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: NeoBrutalismColors.green,
                  ),
                )
              else if (_logs.isNotEmpty)
                GestureDetector(
                  onTap: () => setState(() => _logs.clear()),
                  child: Text(
                    "Clear",
                    style: TextStyle(
                      color: NeoBrutalismColors.pink,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Inter',
                    ),
                  ),
                ),
            ],
          ),
          const Divider(height: 12, color: NeoBrutalismColors.borderColor),
          Expanded(
            child: ListView.builder(
              controller: _logScrollController,
              itemCount: _logs.length,
              itemBuilder: (context, index) {
                final log = _logs[index];
                Color textColor;
                if (log.contains("ERROR") || log.contains("FAILED") || log.contains("❌") || log.contains("FATAL")) {
                  textColor = NeoBrutalismColors.pink;
                } else if (log.contains("SUCCESS") || log.contains("SENT") || log.contains("✅")) {
                  textColor = NeoBrutalismColors.green;
                } else if (log.contains("🚀") || log.contains("STARTING") || log.contains("COMPLETED")) {
                  textColor = NeoBrutalismColors.blue;
                } else if (log.contains("─")) {
                  textColor = NeoBrutalismColors.darkGrey.withOpacity(0.3);
                } else {
                  textColor = NeoBrutalismColors.darkGrey;
                }
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 1),
                  child: Text(
                    log,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 10,
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    final totalSenders = _privateSenders.length + _globalSenders.length;

    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ===== HEADER (TANPA BACK BUTTON) =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.pink,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(4, 4),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.shield,
                          color: NeoBrutalismColors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "Spam Panel",
                        style: TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                      const Spacer(),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.blue.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: NeoBrutalismColors.blue, width: 2),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.circle, color: NeoBrutalismColors.green, size: 6),
                                const SizedBox(width: 4),
                                Text(
                                  "$totalSenders AGENTS",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.blue,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          GestureDetector(
                            onTap: _fetchSenders,
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: NeoBrutalismColors.white,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                              ),
                              child: const Icon(
                                Icons.refresh,
                                color: NeoBrutalismColors.black,
                                size: 18,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.only(left: 4),
                    child: Text(
                      "WhatsApp Spam with Text & Image",
                      style: TextStyle(
                        color: NeoBrutalismColors.darkGrey,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // ===== USER CARD =====
                  _neoCard(
                    padding: const EdgeInsets.all(14),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: NeoBrutalismColors.purple,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.asset(
                              'assets/images/icon.jpg',
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => const Icon(
                                Icons.person,
                                color: NeoBrutalismColors.white,
                                size: 24,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.username,
                                style: const TextStyle(
                                  color: NeoBrutalismColors.black,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Inter',
                                  fontSize: 14,
                                ),
                              ),
                              Text(
                                "ROLE: ${widget.role.toUpperCase()}",
                                style: TextStyle(
                                  color: NeoBrutalismColors.darkGrey,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Inter',
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== SENDER TYPE SELECTOR =====
                  _buildSenderTypeSelector(),
                  const SizedBox(height: 12),

                  // ===== INPUT ROW =====
                  _neoCard(
                    padding: const EdgeInsets.all(12),
                    child: Row(
                      children: [
                        _neoInput(
                          controller: _targetController,
                          hint: "Target (e.g. 628xx)",
                          icon: Icons.phone,
                          flex: 3,
                        ),
                        const SizedBox(width: 10),
                        _neoInput(
                          controller: _amountController,
                          hint: "Qty",
                          icon: Icons.numbers,
                          isNumber: true,
                          flex: 1,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // ===== LAUNCH BUTTON =====
                  _neoButton(
                    label: _isAttacking ? "🛑 STOP SPAM" : "🚀 LAUNCH SPAM",
                    onTap: _isAttacking ? () => setState(() => _isAttacking = false) : _executeSpam,
                    bg: _isAttacking ? NeoBrutalismColors.pink : NeoBrutalismColors.yellow,
                    textColor: _isAttacking ? NeoBrutalismColors.white : NeoBrutalismColors.black,
                    fontSize: 14,
                    isDanger: _isAttacking,
                  ),
                  const SizedBox(height: 12),

                  // ===== LOGS =====
                  Expanded(child: _buildLogs()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}