// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'color_theme.dart';
import 'config.dart';

// ═══════════════════════════════════════════════════════════════
// MODEL
// ═══════════════════════════════════════════════════════════════
class BuildHistoryItem {
  final String sessionId;
  final String fileName;
  final String status;
  final int progress;
  final String currentStep;
  final String? apkFileName;
  final String? error;
  final int? createdAt;
  final int? completedAt;

  BuildHistoryItem({
    required this.sessionId,
    required this.fileName,
    required this.status,
    required this.progress,
    required this.currentStep,
    this.apkFileName,
    this.error,
    this.createdAt,
    this.completedAt,
  });

  factory BuildHistoryItem.fromJson(Map<String, dynamic> j) => BuildHistoryItem(
        sessionId:   j['sessionId'] as String? ?? '',
        fileName:    j['fileName']  as String? ?? 'unknown.zip',
        status:      j['status']    as String? ?? 'unknown',
        progress:    (j['progress'] as num?)?.toInt() ?? 0,
        currentStep: j['currentStep'] as String? ?? '',
        apkFileName: j['apkFileName'] as String?,
        error:       j['error']       as String?,
        createdAt:   (j['createdAt']  as num?)?.toInt(),
        completedAt: (j['completedAt'] as num?)?.toInt(),
      );

  bool get isCompleted => status == 'completed';
  bool get isFailed    => status == 'failed';
  bool get isRunning   => ['uploading', 'queued', 'building', 'extracting', 'pubget', 'cleaning'].contains(status);
}

// ═══════════════════════════════════════════════════════════════
// PAGE
// ═══════════════════════════════════════════════════════════════
class RiwayatBuildPage extends StatefulWidget {
  final String sessionKey;
  final String username;

  const RiwayatBuildPage({
    super.key,
    required this.sessionKey,
    required this.username,
  });

  @override
  State<RiwayatBuildPage> createState() => _RiwayatBuildPageState();
}

class _RiwayatBuildPageState extends State<RiwayatBuildPage>
    with TickerProviderStateMixin {
  // ── Theme shorthand ──
  Color get bgDark        => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple  => AppThemeController.instance.theme.accentPurple;
  Color get cardSolid     => AppThemeController.instance.theme.cardSolid;
  Color get borderGlass   => AppThemeController.instance.theme.borderGlass;
  Color get cardGlass     => AppThemeController.instance.theme.cardGlass;
  Color get accentGrey    => AppThemeController.instance.theme.accentGrey;

  late AnimationController _glowCtrl;
  late AnimationController _pulseCtrl;

  List<BuildHistoryItem> _sessions = [];
  bool  _isLoading  = true;
  String? _error;

  // Download state per sessionId
  final Map<String, double>  _dlProgress  = {};
  final Map<String, bool>    _dlLoading   = {};
  final Map<String, String>  _localPaths  = {};
  final Map<String, bool>    _delLoading  = {};

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onTheme);
    _glowCtrl  = AnimationController(duration: const Duration(seconds: 3), vsync: this)..repeat();
    _pulseCtrl = AnimationController(duration: const Duration(milliseconds: 800), vsync: this)..repeat(reverse: true);
    _load();
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    _pulseCtrl.dispose();
    AppThemeController.instance.removeListener(_onTheme);
    super.dispose();
  }

  void _onTheme() => mounted ? setState(() {}) : null;

  // ──────────────────────────────────────────────
  // FETCH HISTORY
  // ──────────────────────────────────────────────
  Future<void> _load() async {
    if (!mounted) return;
    setState(() { _isLoading = true; _error = null; });
    
    try {
      debugPrint('[RiwayatBuild] Fetching from: $apiBaseUrl/api/buildSessions');
      
      final resp = await http.get(
        Uri.parse('$apiBaseUrl/api/buildSessions'),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 15));

      debugPrint('[RiwayatBuild] Response status: ${resp.statusCode}');
      debugPrint('[RiwayatBuild] Response body: ${resp.body}');

      if (resp.statusCode != 200) {
        throw Exception('HTTP ${resp.statusCode}: ${resp.body}');
      }

      final data = jsonDecode(resp.body) as Map<String, dynamic>;
      debugPrint('[RiwayatBuild] Parsed JSON success: ${data['success']}');

      if (data['success'] != true) {
        throw Exception(data['message'] ?? 'API returned success: false');
      }

      final sessionsRaw = data['sessions'] as List<dynamic>? ?? [];
      debugPrint('[RiwayatBuild] Sessions count from API: ${sessionsRaw.length}');

      final list = sessionsRaw
          .map((e) {
            debugPrint('[RiwayatBuild] Parsing session: $e');
            return BuildHistoryItem.fromJson(e as Map<String, dynamic>);
          })
          .toList();

      // Sort: terbaru di atas
      list.sort((a, b) => (b.createdAt ?? 0).compareTo(a.createdAt ?? 0));

      debugPrint('[RiwayatBuild] Final list count: ${list.length}');
      
      if (!mounted) return;
      setState(() { 
        _sessions = list; 
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('[RiwayatBuild] ERROR: $e');
      if (!mounted) return;
      setState(() { 
        _error = e.toString(); 
        _isLoading = false; 
      });
    }
  }

  // ──────────────────────────────────────────────
  // DOWNLOAD & INSTALL
  // ──────────────────────────────────────────────
  Future<void> _downloadAndInstall(BuildHistoryItem item) async {
    if (_dlLoading[item.sessionId] == true) return;
    if (item.apkFileName == null) return;

    // Jika sudah ada lokal
    final local = _localPaths[item.sessionId];
    if (local != null && File(local).existsSync()) {
      final r = await OpenFile.open(local);
      if (r.type != ResultType.done) _snack('⚠️ ${r.message}');
      return;
    }

    if (Platform.isAndroid) {
      final st = await Permission.requestInstallPackages.request();
      if (!st.isGranted) {
        _snack('❌ Izin install dari sumber tidak dikenal diperlukan.');
        await openAppSettings();
        return;
      }
    }

    if (!mounted) return;
    setState(() { _dlLoading[item.sessionId] = true; _dlProgress[item.sessionId] = 0; });

    try {
      final url    = '$apiBaseUrl/download-apk/${item.apkFileName}';
      final client = http.Client();
      final req    = http.Request('GET', Uri.parse(url));
      req.headers['x-session-key'] = widget.sessionKey;
      final response = await client.send(req);
      final total    = response.contentLength ?? 0;
      final bytes    = <int>[];
      int downloaded = 0;

      await for (final chunk in response.stream) {
        bytes.addAll(chunk);
        downloaded += chunk.length;
        if (total > 0 && mounted) {
          setState(() => _dlProgress[item.sessionId] = downloaded / total);
        }
      }
      client.close();

      final dir     = await getTemporaryDirectory();
      final apkFile = File('${dir.path}/${item.apkFileName}');
      await apkFile.writeAsBytes(bytes);

      if (!mounted) return;
      setState(() {
        _dlLoading[item.sessionId]  = false;
        _dlProgress[item.sessionId] = 1.0;
        _localPaths[item.sessionId] = apkFile.path;
      });

      _snack('✅ APK tersimpan! Membuka installer...');
      final r = await OpenFile.open(apkFile.path);
      if (r.type != ResultType.done) _snack('⚠️ ${r.message}');
    } catch (e) {
      if (mounted) {
        setState(() { _dlLoading[item.sessionId] = false; _dlProgress[item.sessionId] = 0; });
      }
      _snack('❌ Download gagal: $e');
    }
  }

  // ──────────────────────────────────────────────
  // SHARE APK — download silent, lalu share
  // ──────────────────────────────────────────────
  Future<void> _shareApk(BuildHistoryItem item) async {
    if (item.apkFileName == null) return;
    final local = _localPaths[item.sessionId];

    // Sudah ada di lokal → langsung share
    if (local != null && File(local).existsSync()) {
      await Share.shareXFiles(
        [XFile(local)],
        text: '📱 APK dari Zero Crash Builder\n📦 ${item.apkFileName}',
        subject: 'Zero Crash APK',
      );
      return;
    }

    // Download dulu TANPA buka installer, baru share
    _snack('⬇️ Mendownload APK untuk dibagikan...');
    final path = await _downloadOnly(item);
    if (path != null) {
      await Share.shareXFiles(
        [XFile(path)],
        text: '📱 APK dari Zero Crash Builder\n📦 ${item.apkFileName}',
        subject: 'Zero Crash APK',
      );
    }
  }

  // Download APK ke temp folder, TIDAK buka installer — return path atau null
  Future<String?> _downloadOnly(BuildHistoryItem item) async {
    if (item.apkFileName == null) return null;
    if (_dlLoading[item.sessionId] == true) return null;

    if (!mounted) return null;
    setState(() { _dlLoading[item.sessionId] = true; _dlProgress[item.sessionId] = 0; });

    try {
      final url    = '$apiBaseUrl/download-apk/${item.apkFileName}';
      final client = http.Client();
      final req    = http.Request('GET', Uri.parse(url));
      req.headers['x-session-key'] = widget.sessionKey;
      final response = await client.send(req);
      final total    = response.contentLength ?? 0;
      final bytes    = <int>[];
      int downloaded = 0;

      await for (final chunk in response.stream) {
        bytes.addAll(chunk);
        downloaded += chunk.length;
        if (total > 0 && mounted) {
          setState(() => _dlProgress[item.sessionId] = downloaded / total);
        }
      }
      client.close();

      final dir     = await getTemporaryDirectory();
      final apkFile = File('${dir.path}/${item.apkFileName}');
      await apkFile.writeAsBytes(bytes);

      if (!mounted) return null;
      setState(() {
        _dlLoading[item.sessionId]  = false;
        _dlProgress[item.sessionId] = 1.0;
        _localPaths[item.sessionId] = apkFile.path;
      });
      return apkFile.path;
    } catch (e) {
      if (mounted) {
        setState(() { _dlLoading[item.sessionId] = false; _dlProgress[item.sessionId] = 0; });
      }
      _snack('❌ Download gagal: $e');
      return null;
    }
  }

  // ──────────────────────────────────────────────
  // DELETE SESSION
  // ──────────────────────────────────────────────
  Future<void> _deleteSession(BuildHistoryItem item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardSolid,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text('Hapus Riwayat?',
            style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
        content: Text(
          'Session "${item.apkFileName ?? item.fileName}" akan dihapus permanen dari server.',
          style: TextStyle(color: accentGrey, fontFamily: 'ShareTechMono', fontSize: 12),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Batal', style: TextStyle(color: accentGrey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Hapus', style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 11)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    if (!mounted) return;
    setState(() => _delLoading[item.sessionId] = true);
    try {
      final resp = await http.delete(
        Uri.parse('$apiBaseUrl/api/buildSession/${item.sessionId}'),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(resp.body);
      if (!mounted) return;
      
      if (data['success'] == true) {
        setState(() { _sessions.removeWhere((s) => s.sessionId == item.sessionId); });
        _snack('🗑️ Session dihapus.');
      } else {
        _snack('❌ Gagal hapus: ${data['message']}');
      }
    } catch (e) {
      _snack('❌ Error: $e');
    } finally {
      if (mounted) setState(() => _delLoading.remove(item.sessionId));
    }
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'ShareTechMono')),
      backgroundColor: primaryPurple.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(12),
    ));
  }

  // ──────────────────────────────────────────────
  // HELPERS
  // ──────────────────────────────────────────────
  String _formatDate(int? ms) {
    if (ms == null) return '-';
    try {
      final dt = DateTime.fromMillisecondsSinceEpoch(ms);
      // Fallback ke en jika id_ID tidak tersedia
      try {
        return DateFormat('dd MMM yyyy  HH:mm', 'id_ID').format(dt);
      } catch (_) {
        return DateFormat('dd MMM yyyy  HH:mm').format(dt);
      }
    } catch (e) {
      return 'Invalid date';
    }
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'completed':  return '✅ Build Selesai';
      case 'failed':     return '❌ Build Gagal';
      case 'uploading':  return '📤 Uploading...';
      case 'queued':     return '⏳ Antrian';
      case 'building':   return '🔨 Compiling...';
      case 'extracting': return '📂 Extracting...';
      case 'pubget':     return '📦 Pub Get...';
      case 'cleaning':   return '🧹 Cleaning...';
      default:           return '❓ $status';
    }
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'completed': return Colors.greenAccent;
      case 'failed':    return Colors.redAccent.shade200;
      default:          return Colors.orangeAccent;
    }
  }

  // ══════════════════════════════════════════════
  // BUILD UI
  // ══════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      appBar: _appBar(),
      body: _isLoading
          ? _loadingState()
          : _error != null
              ? _errorState()
              : _sessions.isEmpty
                  ? _emptyState()
                  : _listView(),
    );
  }

  // ── AppBar ──
  AppBar _appBar() => AppBar(
    backgroundColor: bgDark,
    elevation: 0,
    leading: IconButton(
      icon: Icon(Icons.arrow_back_ios_new_rounded, color: accentPurple, size: 20),
      onPressed: () => Navigator.pop(context),
    ),
    titleSpacing: 0,
    title: Row(children: [
      AnimatedBuilder(
        animation: _glowCtrl,
        builder: (_, __) => Container(
          padding: const EdgeInsets.all(7),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [primaryPurple, accentPurple]),
            borderRadius: BorderRadius.circular(10),
            boxShadow: [BoxShadow(
              color: primaryPurple.withOpacity(0.3 + 0.2 * _glowCtrl.value),
              blurRadius: 12,
            )],
          ),
          child: const Icon(Icons.history_rounded, color: Colors.white, size: 16),
        ),
      ),
      const SizedBox(width: 10),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('RIWAYAT BUILD', style: TextStyle(
          color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800,
          fontFamily: 'Orbitron', letterSpacing: 1,
        )),
        Text('Semua APK yang pernah di-build', style: TextStyle(
          color: accentGrey, fontSize: 9, fontFamily: 'ShareTechMono',
        )),
      ]),
      const Spacer(),
      // Refresh button
      IconButton(
        icon: Icon(Icons.refresh_rounded, color: accentPurple, size: 22),
        onPressed: _isLoading ? null : _load,
        tooltip: 'Refresh',
      ),
    ]),
    bottom: PreferredSize(
      preferredSize: const Size.fromHeight(1),
      child: Container(height: 1, decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Colors.transparent, primaryPurple, Colors.transparent]),
      )),
    ),
  );

  // ── Loading ──
  Widget _loadingState() => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      SizedBox(
        width: 42, height: 42,
        child: CircularProgressIndicator(color: accentPurple, strokeWidth: 2.5),
      ),
      const SizedBox(height: 16),
      Text('Memuat riwayat build...', style: TextStyle(
        color: accentGrey, fontFamily: 'ShareTechMono', fontSize: 13,
      )),
    ]),
  );

  // ── Error ──
  Widget _errorState() => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.error_outline_rounded, color: Colors.redAccent.shade200, size: 48),
        const SizedBox(height: 16),
        Text('Gagal memuat riwayat', style: TextStyle(
          color: Colors.white, fontFamily: 'Orbitron', fontSize: 14,
        )),
        const SizedBox(height: 8),
        Text(_error ?? '', style: TextStyle(color: accentGrey, fontFamily: 'ShareTechMono', fontSize: 11),
            textAlign: TextAlign.center),
        const SizedBox(height: 24),
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: primaryPurple,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          ),
          onPressed: _load,
          icon: const Icon(Icons.refresh_rounded, color: Colors.white),
          label: const Text('Coba Lagi', style: TextStyle(
            color: Colors.white, fontFamily: 'Orbitron', fontSize: 12,
          )),
        ),
      ]),
    ),
  );

  // ── Empty ──
  Widget _emptyState() => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.inbox_rounded, color: accentGrey.withOpacity(0.3), size: 64),
      const SizedBox(height: 16),
      Text('Belum Ada Riwayat Build', style: TextStyle(
        color: Colors.white, fontFamily: 'Orbitron', fontSize: 14,
      )),
      const SizedBox(height: 8),
      Text('Build APK pertamamu dan\nriwayatnya akan muncul di sini.',
          style: TextStyle(color: accentGrey, fontFamily: 'ShareTechMono', fontSize: 12, height: 1.6),
          textAlign: TextAlign.center),
    ]),
  );

  // ── List View ──
  Widget _listView() => RefreshIndicator(
    onRefresh: _load,
    color: accentPurple,
    backgroundColor: cardSolid,
    child: ListView(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 32),
      children: [
        // Summary bar
        _summaryBar(),
        const SizedBox(height: 14),
        // Items
        ..._sessions.map((item) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: _buildCard(item),
        )),
      ],
    ),
  );

  // ── Summary bar ──
  Widget _summaryBar() {
    final total    = _sessions.length;
    final success  = _sessions.where((s) => s.isCompleted).length;
    final failed   = _sessions.where((s) => s.isFailed).length;
    final running  = _sessions.where((s) => s.isRunning).length;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: cardSolid,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _statChip('TOTAL', total.toString(), accentGrey),
          _divider(),
          _statChip('SUKSES', success.toString(), Colors.greenAccent),
          _divider(),
          _statChip('GAGAL', failed.toString(), Colors.redAccent.shade200),
          _divider(),
          _statChip('PROSES', running.toString(), Colors.orangeAccent),
        ],
      ),
    );
  }

  Widget _statChip(String label, String value, Color color) => Column(
    children: [
      Text(value, style: TextStyle(
        color: color, fontSize: 20, fontWeight: FontWeight.w900, fontFamily: 'Orbitron',
      )),
      const SizedBox(height: 2),
      Text(label, style: TextStyle(
        color: accentGrey, fontSize: 9, fontFamily: 'ShareTechMono', letterSpacing: 0.5,
      )),
    ],
  );

  Widget _divider() => Container(
    width: 1, height: 32,
    color: borderGlass,
  );

  // ── Build Card ──
  Widget _buildCard(BuildHistoryItem item) {
    final isSuccess  = item.isCompleted;
    final isFailed   = item.isFailed;
    final isRunning  = item.isRunning;
    final statusColor = _statusColor(item.status);
    final hasLocal   = _localPaths[item.sessionId] != null &&
        File(_localPaths[item.sessionId]!).existsSync();
    final dlLoad    = _dlLoading[item.sessionId] == true;
    final dlProg    = _dlProgress[item.sessionId] ?? 0.0;
    final delLoad   = _delLoading[item.sessionId] == true;

    return AnimatedBuilder(
      animation: _glowCtrl,
      builder: (_, __) => Container(
        decoration: BoxDecoration(
          color: cardSolid,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSuccess
                ? Colors.greenAccent.withOpacity(0.25 + 0.1 * _glowCtrl.value)
                : isFailed
                    ? Colors.redAccent.withOpacity(0.2)
                    : borderGlass,
            width: isSuccess ? 1.5 : 1,
          ),
          boxShadow: isSuccess
              ? [BoxShadow(color: Colors.greenAccent.withOpacity(0.04 + 0.03 * _glowCtrl.value), blurRadius: 16)]
              : [],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          // ─── Header ───
          Container(
            padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
            decoration: BoxDecoration(
              color: isSuccess
                  ? Colors.greenAccent.withOpacity(0.05)
                  : isFailed
                      ? Colors.redAccent.withOpacity(0.04)
                      : cardGlass,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              border: Border(bottom: BorderSide(color: borderGlass)),
            ),
            child: Row(children: [
              // Icon status
              Container(
                padding: const EdgeInsets.all(9),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: statusColor.withOpacity(0.3)),
                ),
                child: Icon(
                  isSuccess ? Icons.check_circle_rounded
                      : isFailed ? Icons.error_rounded
                          : Icons.pending_rounded,
                  color: statusColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(
                  item.apkFileName ?? item.fileName.replaceAll('.zip', '.apk'),
                  style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700,
                    fontFamily: 'ShareTechMono', fontSize: 12,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 3),
                Text(
                  _statusLabel(item.status),
                  style: TextStyle(color: statusColor, fontSize: 11, fontFamily: 'ShareTechMono'),
                ),
              ])),
              // Delete button
              if (!isRunning)
                delLoad
                    ? SizedBox(
                        width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.redAccent.shade200),
                      )
                    : GestureDetector(
                        onTap: () => _deleteSession(item),
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: Colors.redAccent.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.redAccent.withOpacity(0.25)),
                          ),
                          child: Icon(Icons.delete_outline_rounded, color: Colors.redAccent.shade200, size: 16),
                        ),
                      ),
            ]),
          ),

          // ─── Info Row ───
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
            child: Row(children: [
              Icon(Icons.calendar_today_rounded, color: accentGrey, size: 11),
              const SizedBox(width: 5),
              Text(_formatDate(item.createdAt),
                  style: TextStyle(color: accentGrey, fontSize: 10, fontFamily: 'ShareTechMono')),
              if (item.completedAt != null) ...[
                const SizedBox(width: 12),
                Icon(Icons.access_time_rounded, color: accentGrey, size: 11),
                const SizedBox(width: 4),
                Text(
                  _buildDuration(item.createdAt, item.completedAt),
                  style: TextStyle(color: accentGrey, fontSize: 10, fontFamily: 'ShareTechMono'),
                ),
              ],
            ]),
          ),

          // ─── Progress bar (running) ───
          if (isRunning) ...[
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text(item.currentStep, style: TextStyle(color: accentGrey, fontSize: 10, fontFamily: 'ShareTechMono')),
                  Text('${item.progress}%', style: TextStyle(color: accentPurple, fontSize: 10, fontFamily: 'ShareTechMono', fontWeight: FontWeight.w700)),
                ]),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: item.progress / 100,
                    backgroundColor: accentPurple.withOpacity(0.1),
                    valueColor: AlwaysStoppedAnimation(accentPurple),
                    minHeight: 5,
                  ),
                ),
              ]),
            ),
          ],

          // ─── Error message ───
          if (isFailed && item.error != null) ...[
            const SizedBox(height: 10),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.redAccent.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.redAccent.withOpacity(0.2)),
                ),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Icon(Icons.warning_amber_rounded, color: Colors.redAccent.shade200, size: 13),
                  const SizedBox(width: 7),
                  Expanded(child: Text(
                    item.error!,
                    style: TextStyle(color: Colors.redAccent.shade200, fontSize: 10, fontFamily: 'ShareTechMono', height: 1.5),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  )),
                ]),
              ),
            ),
          ],

          // ─── Download section (only for completed) ───
          if (isSuccess) ...[
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 0),
              child: Column(children: [
                // Download progress
                if (dlLoad) ...[
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('⬇️ Mendownload...', style: TextStyle(color: Colors.greenAccent, fontSize: 11, fontFamily: 'ShareTechMono')),
                    Text('${(dlProg * 100).toInt()}%', style: const TextStyle(color: Colors.greenAccent, fontWeight: FontWeight.w700, fontFamily: 'ShareTechMono')),
                  ]),
                  const SizedBox(height: 6),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: LinearProgressIndicator(
                      value: dlProg,
                      backgroundColor: Colors.greenAccent.withOpacity(0.1),
                      valueColor: const AlwaysStoppedAnimation(Colors.greenAccent),
                      minHeight: 6,
                    ),
                  ),
                  const SizedBox(height: 10),
                ],
                // APK Ready badge
                Row(children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.greenAccent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.greenAccent.withOpacity(0.3)),
                    ),
                    child: const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('APK SIAP DIDOWNLOAD!', style: TextStyle(
                      color: Colors.greenAccent, fontWeight: FontWeight.w900,
                      fontFamily: 'Orbitron', fontSize: 10,
                    )),
                    Text(item.apkFileName ?? 'app.apk', style: const TextStyle(
                      color: Colors.white60, fontSize: 9, fontFamily: 'ShareTechMono',
                    ), overflow: TextOverflow.ellipsis),
                  ])),
                  if (hasLocal)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.greenAccent.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text('✓ Di HP', style: TextStyle(
                        color: Colors.greenAccent, fontSize: 9, fontFamily: 'ShareTechMono',
                      )),
                    ),
                ]),
                const SizedBox(height: 10),
                // Download & Install button
                GestureDetector(
                  onTap: dlLoad ? null : () => _downloadAndInstall(item),
                  child: Container(
                    height: 46,
                    decoration: BoxDecoration(
                      gradient: dlLoad
                          ? LinearGradient(colors: [Colors.grey.shade700, Colors.grey.shade600])
                          : const LinearGradient(colors: [Color(0xFF00C853), Color(0xFF00BFA5)]),
                      borderRadius: BorderRadius.circular(13),
                      boxShadow: dlLoad ? [] : [
                        BoxShadow(color: Colors.greenAccent.withOpacity(0.28), blurRadius: 14, offset: const Offset(0, 4)),
                      ],
                    ),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      if (dlLoad)
                        const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      else
                        const Icon(Icons.download_rounded, color: Colors.white, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        dlLoad ? 'DOWNLOADING...' : hasLocal ? 'INSTALL ULANG APK' : 'DOWNLOAD & INSTALL APK',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontFamily: 'Orbitron', fontSize: 11, letterSpacing: 0.8),
                      ),
                    ]),
                  ),
                ),
                const SizedBox(height: 8),
                // Share button
                GestureDetector(
                  onTap: dlLoad ? null : () => _shareApk(item),
                  child: Container(
                    height: 46,
                    decoration: BoxDecoration(
                      color: cardSolid,
                      borderRadius: BorderRadius.circular(13),
                      border: Border.all(color: Colors.greenAccent.withOpacity(0.5), width: 1.5),
                    ),
                    child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(Icons.share_rounded, color: Colors.greenAccent, size: 20),
                      SizedBox(width: 8),
                      Text('BAGIKAN APK', style: TextStyle(
                        color: Colors.greenAccent, fontWeight: FontWeight.w900,
                        fontFamily: 'Orbitron', fontSize: 12, letterSpacing: 1,
                      )),
                    ]),
                  ),
                ),
              ]),
            ),
          ],

          const SizedBox(height: 14),
        ]),
      ),
    );
  }

  String _buildDuration(int? start, int? end) {
    if (start == null || end == null) return '';
    final diff = Duration(milliseconds: end - start);
    if (diff.inMinutes >= 1) return '${diff.inMinutes}m ${diff.inSeconds % 60}s';
    return '${diff.inSeconds}s';
  }
}
