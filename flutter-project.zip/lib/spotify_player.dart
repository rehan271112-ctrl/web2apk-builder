// spotify_player.dart
// Global Spotify-like music player dengan mini player yang persist di semua halaman
// dan full-screen player dengan background/tema yang sinkron

import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'app_theme.dart';
import 'background_notifier.dart';
import 'background_widget.dart';

// ─── MODEL LAGU ───────────────────────────────────────────────────────────────
class SpotifyTrack {
  final String id;
  final String title;
  final String artist;
  final String album;
  final String? artworkUrl;
  final String? previewUrl;  // URL preview MP3
  final Duration duration;
  final Color? accentColor;

  const SpotifyTrack({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    this.artworkUrl,
    this.previewUrl,
    this.duration = const Duration(seconds: 30),
    this.accentColor,
  });

  // Factory: buat dari JSON yang dikirim API
  factory SpotifyTrack.fromJson(Map<String, dynamic> json) {
    final durationMs = (json['durationMs'] as int?) ?? 30000;
    return SpotifyTrack(
      id:         json['id']         as String? ?? '',
      title:      json['title']      as String? ?? 'Unknown',
      artist:     json['artist']     as String? ?? 'Unknown',
      album:      json['album']      as String? ?? '',
      artworkUrl: json['artworkUrl'] as String?,
      previewUrl: json['previewUrl'] as String?,
      duration:   Duration(milliseconds: durationMs),
    );
  }
}

// ─── PLAYLIST NOTIFIER (Global State) ────────────────────────────────────────
class SpotifyNotifier extends ChangeNotifier {
  static final SpotifyNotifier _instance = SpotifyNotifier._internal();
  factory SpotifyNotifier() => _instance;
  SpotifyNotifier._internal() {
    _player.onPlayerStateChanged.listen(_onStateChanged);
    _player.onPositionChanged.listen(_onPositionChanged);
    _player.onDurationChanged.listen(_onDurationChanged);
    _player.onPlayerComplete.listen((_) => skipNext());
  }

  final AudioPlayer _player = AudioPlayer();

  // ── State ─────────────────────────────────────────────────────────────────
  List<SpotifyTrack> _playlist = kDefaultPlaylist;
  int _currentIndex = 0;
  bool _isPlaying = false;
  bool _isLoading = false;
  bool _isLoadingPlaylist = false;
  String? _playlistError;
  Duration _position = Duration.zero;
  Duration _duration = const Duration(seconds: 30);
  bool _shuffle = false;
  bool _repeat = false;
  bool _isMiniVisible = true;

  // ── Getters ───────────────────────────────────────────────────────────────
  List<SpotifyTrack> get playlist          => _playlist;
  int          get currentIndex            => _currentIndex;
  SpotifyTrack get currentTrack            => _playlist[_currentIndex];
  bool         get isPlaying               => _isPlaying;
  bool         get isLoading               => _isLoading;
  bool         get isLoadingPlaylist       => _isLoadingPlaylist;
  String?      get playlistError           => _playlistError;
  Duration     get position                => _position;
  Duration     get duration                => _duration;
  bool         get shuffle                 => _shuffle;
  bool         get repeat                  => _repeat;
  bool         get isMiniVisible           => _isMiniVisible;
  double       get progress                => _duration.inMilliseconds > 0
      ? (_position.inMilliseconds / _duration.inMilliseconds).clamp(0.0, 1.0)
      : 0.0;

  // ── Event Handlers ────────────────────────────────────────────────────────
  void _onStateChanged(PlayerState state) {
    _isPlaying = state == PlayerState.playing;
    _isLoading = false;
    notifyListeners();
  }

  void _onPositionChanged(Duration pos) {
    _position = pos;
    notifyListeners();
  }

  void _onDurationChanged(Duration dur) {
    _duration = dur;
    notifyListeners();
  }

  // ── Controls ──────────────────────────────────────────────────────────────
  Future<void> play([int? index]) async {
    if (index != null) _currentIndex = index.clamp(0, _playlist.length - 1);
    final track = currentTrack;
    if (track.previewUrl == null || track.previewUrl!.isEmpty) return;

    _isLoading = true;
    notifyListeners();

    try {
      await _player.stop();
      await _player.play(UrlSource(track.previewUrl!));
      _position = Duration.zero;
    } catch (e) {
      _isLoading = false;
      debugPrint('SpotifyPlayer: error playing ${track.title}: $e');
    }
    notifyListeners();
  }

  Future<void> pause() async {
    await _player.pause();
  }

  Future<void> resume() async {
    await _player.resume();
  }

  Future<void> togglePlay() async {
    if (_isPlaying) {
      await pause();
    } else if (_position > Duration.zero) {
      await resume();
    } else {
      await play();
    }
  }

  Future<void> skipNext() async {
    if (_shuffle) {
      final rng = Random();
      int next;
      do { next = rng.nextInt(_playlist.length); } while (next == _currentIndex && _playlist.length > 1);
      await play(next);
    } else if (_currentIndex < _playlist.length - 1) {
      await play(_currentIndex + 1);
    } else if (_repeat) {
      await play(0);
    }
  }

  Future<void> skipPrev() async {
    if (_position.inSeconds > 3) {
      await _player.seek(Duration.zero);
    } else if (_currentIndex > 0) {
      await play(_currentIndex - 1);
    } else {
      await _player.seek(Duration.zero);
    }
  }

  Future<void> seekTo(double progress) async {
    final ms = (_duration.inMilliseconds * progress).toInt();
    await _player.seek(Duration(milliseconds: ms));
  }

  void toggleShuffle() {
    _shuffle = !_shuffle;
    notifyListeners();
  }

  void toggleRepeat() {
    _repeat = !_repeat;
    _player.setReleaseMode(_repeat ? ReleaseMode.loop : ReleaseMode.release);
    notifyListeners();
  }

  void hideMini() {
    _isMiniVisible = false;
    notifyListeners();
  }

  void showMini() {
    _isMiniVisible = true;
    notifyListeners();
  }

  void setPlaylist(List<SpotifyTrack> tracks, [int startIndex = 0]) {
    _playlist = tracks;
    play(startIndex);
  }

  // ── Load Playlist dari API Spotify ────────────────────────────────────────
  /// Panggil method ini setelah login untuk load lagu dari server.
  /// Secara otomatis ambil key & baseUrl dari SharedPreferences.
  Future<void> loadTrendingFromApi() async {
    if (_isLoadingPlaylist) return;
    _isLoadingPlaylist = true;
    _playlistError = null;
    notifyListeners();

    try {
      final prefs   = await SharedPreferences.getInstance();
      final key     = prefs.getString('key') ?? '';
      const baseUrl = 'http://alanwinter.alannxd.my.id:3298';

      if (key.isEmpty) {
        _playlistError = 'Belum login';
        _isLoadingPlaylist = false;
        notifyListeners();
        return;
      }

      final uri  = Uri.parse('$baseUrl/api/spotify/trending?key=$key&limit=25');
      final resp = await http.get(uri).timeout(const Duration(seconds: 15));

      if (resp.statusCode == 200) {
        final body  = jsonDecode(resp.body) as Map<String, dynamic>;
        final list  = (body['tracks'] as List<dynamic>?) ?? [];
        final tracks = list
            .map((e) => SpotifyTrack.fromJson(e as Map<String, dynamic>))
            .where((t) => t.previewUrl != null && t.previewUrl!.isNotEmpty)
            .toList();

        if (tracks.isNotEmpty) {
          _playlist     = tracks;
          _currentIndex = 0;
          debugPrint('[🎵 Spotify] Loaded ${tracks.length} lagu dari API');
        } else {
          _playlistError = 'Tidak ada lagu dengan preview. Cek CLIENT_ID Spotify.';
          debugPrint('[⚠️ Spotify] Tidak ada preview_url – pastikan Spotify credentials sudah diset di server');
        }
      } else if (resp.statusCode == 503) {
        _playlistError = 'Spotify credentials belum diset di server (CLIENT_ID/SECRET)';
        debugPrint('[❌ Spotify] 503 - ${resp.body}');
      } else {
        _playlistError = 'Server error: ${resp.statusCode}';
        debugPrint('[❌ Spotify] ${resp.statusCode} - ${resp.body}');
      }
    } catch (e) {
      _playlistError = 'Koneksi gagal: $e';
      debugPrint('[❌ Spotify] Exception: $e');
    }

    _isLoadingPlaylist = false;
    notifyListeners();
  }

  /// Cari lagu berdasarkan keyword, hasilnya langsung jadi playlist
  Future<void> searchAndPlay(String query) async {
    if (query.trim().isEmpty) return;
    _isLoadingPlaylist = true;
    _playlistError = null;
    notifyListeners();

    try {
      final prefs   = await SharedPreferences.getInstance();
      final key     = prefs.getString('key') ?? '';
      const baseUrl = 'http://alanwinter.alannxd.my.id:3298';

      final uri  = Uri.parse('$baseUrl/api/spotify/search?key=$key&q=${Uri.encodeComponent(query)}&limit=20');
      final resp = await http.get(uri).timeout(const Duration(seconds: 15));

      if (resp.statusCode == 200) {
        final body   = jsonDecode(resp.body) as Map<String, dynamic>;
        final list   = (body['tracks'] as List<dynamic>?) ?? [];
        final tracks = list
            .map((e) => SpotifyTrack.fromJson(e as Map<String, dynamic>))
            .where((t) => t.previewUrl != null && t.previewUrl!.isNotEmpty)
            .toList();

        if (tracks.isNotEmpty) {
          _playlist     = tracks;
          _currentIndex = 0;
          await play(0);
        } else {
          _playlistError = 'Tidak ada hasil untuk "$query"';
        }
      } else {
        _playlistError = 'Pencarian gagal: ${resp.statusCode}';
      }
    } catch (e) {
      _playlistError = 'Koneksi gagal: $e';
    }

    _isLoadingPlaylist = false;
    notifyListeners();
  }

  void dispose() {
    _player.dispose();
  }
}

// ─── DEFAULT PLAYLIST (Preview URLs Spotify) ─────────────────────────────────
// Menggunakan Deezer 30-detik preview yang bebas diakses publik
const List<SpotifyTrack> kDefaultPlaylist = [
  SpotifyTrack(
    id: '1',
    title: 'Blinding Lights',
    artist: 'The Weeknd',
    album: 'After Hours',
    artworkUrl: 'https://cdn-images.dzcdn.net/images/cover/48c8f0b7dab00e0b34af7bf97ef8b370/264x264.jpg',
    previewUrl: 'https://cdns-preview-d.dzcdn.net/stream/c-d4b96aa9e5f68b0bce5a1a8fc0c70af7-7.mp3',
    duration: Duration(seconds: 30),
    accentColor: Color(0xFFFF0080),
  ),
  SpotifyTrack(
    id: '2',
    title: 'Levitating',
    artist: 'Dua Lipa',
    album: 'Future Nostalgia',
    artworkUrl: 'https://cdn-images.dzcdn.net/images/cover/d99e8fba11f1c2fe3e7b13af7ee56498/264x264.jpg',
    previewUrl: 'https://cdns-preview-8.dzcdn.net/stream/c-87e36808b1b2219afcc7f08d9cde7c66-7.mp3',
    duration: Duration(seconds: 30),
    accentColor: Color(0xFF8B5CF6),
  ),
  SpotifyTrack(
    id: '3',
    title: 'Stay',
    artist: 'The Kid LAROI, Justin Bieber',
    album: 'F*CK LOVE 3',
    artworkUrl: 'https://cdn-images.dzcdn.net/images/cover/f63d9d099ebe5d6b3c01b5e9b9ce2041/264x264.jpg',
    previewUrl: 'https://cdns-preview-4.dzcdn.net/stream/c-4de1b0cab4a47d1a7a5be26ee8b1ae43-5.mp3',
    duration: Duration(seconds: 30),
    accentColor: Color(0xFF06B6D4),
  ),
  SpotifyTrack(
    id: '4',
    title: 'As It Was',
    artist: 'Harry Styles',
    album: "Harry's House",
    artworkUrl: 'https://cdn-images.dzcdn.net/images/cover/70c3d5d32f5cb62e59b0ad54e81e2c13/264x264.jpg',
    previewUrl: 'https://cdns-preview-c.dzcdn.net/stream/c-c37c985b3b45a44f32a37fbc3d3a5e36-4.mp3',
    duration: Duration(seconds: 30),
    accentColor: Color(0xFFF59E0B),
  ),
  SpotifyTrack(
    id: '5',
    title: 'Heat Waves',
    artist: 'Glass Animals',
    album: 'Dreamland',
    artworkUrl: 'https://cdn-images.dzcdn.net/images/cover/fb0fb2c3b97dff4dd8e57e63b5dd72f5/264x264.jpg',
    previewUrl: 'https://cdns-preview-b.dzcdn.net/stream/c-b06aa2dc1eef56a45d6dcedf5cf7be33-7.mp3',
    duration: Duration(seconds: 30),
    accentColor: Color(0xFF10B981),
  ),
  SpotifyTrack(
    id: '6',
    title: 'Dynamite',
    artist: 'BTS',
    album: 'Dynamite (DayTime Version)',
    artworkUrl: 'https://cdn-images.dzcdn.net/images/cover/48dfe4f19a68e08c15b434bdcc73fe8a/264x264.jpg',
    previewUrl: 'https://cdns-preview-0.dzcdn.net/stream/c-0a5aa3a75ea0b4c46c9f6aa76e50f3e6-7.mp3',
    duration: Duration(seconds: 30),
    accentColor: Color(0xFFEF4444),
  ),
  SpotifyTrack(
    id: '7',
    title: 'Peaches',
    artist: 'Justin Bieber',
    album: 'Justice',
    artworkUrl: 'https://cdn-images.dzcdn.net/images/cover/28fee40e58c1eb6cc8e9e7d7cc2b7cbb/264x264.jpg',
    previewUrl: 'https://cdns-preview-1.dzcdn.net/stream/c-14e5e15c5ac4e9d7e0900ead82c94cdd-7.mp3',
    duration: Duration(seconds: 30),
    accentColor: Color(0xFFFF8C00),
  ),
];

// ─── SPOTIFY SCOPE (Provider) ─────────────────────────────────────────────────
class SpotifyScope extends InheritedNotifier<SpotifyNotifier> {
  const SpotifyScope({
    super.key,
    required SpotifyNotifier notifier,
    required super.child,
  }) : super(notifier: notifier);

  static SpotifyNotifier of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<SpotifyScope>()!.notifier!;
  }
}

// ─── MINI PLAYER ──────────────────────────────────────────────────────────────
// Muncul di bawah layar semua halaman saat musik sedang berjalan
class SpotifyMiniPlayer extends StatelessWidget {
  const SpotifyMiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final sp = SpotifyScope.of(context);

    if (!sp.isPlaying && sp.position == Duration.zero) return const SizedBox.shrink();
    if (!sp.isMiniVisible) return const SizedBox.shrink();

    final track = sp.currentTrack;
    final accent = track.accentColor ?? AppColors.accent1;

    return GestureDetector(
      onTap: () => _openFullPlayer(context),
      child: AnimatedBuilder(
        animation: sp,
        builder: (ctx, _) => Container(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.85),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: accent.withOpacity(0.4), width: 1),
            boxShadow: [
              BoxShadow(color: accent.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 4)),
              const BoxShadow(color: Colors.black54, blurRadius: 8, offset: Offset(0, 2)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Progress bar tipis di atas
              ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                child: LinearProgressIndicator(
                  value: sp.progress,
                  backgroundColor: Colors.white12,
                  valueColor: AlwaysStoppedAnimation<Color>(accent),
                  minHeight: 2,
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  children: [
                    // Artwork
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        color: Colors.black38,
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: track.artworkUrl != null
                            ? Image.network(
                                track.artworkUrl!,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => Icon(
                                  FontAwesomeIcons.music,
                                  color: accent,
                                  size: 16,
                                ),
                              )
                            : Icon(FontAwesomeIcons.music, color: accent, size: 16),
                      ),
                    ),
                    const SizedBox(width: 10),
                    // Title + Artist
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            track.title,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            track.artist,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.6),
                              fontSize: 10,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    // Controls
                    Row(
                      children: [
                        IconButton(
                          onPressed: sp.skipPrev,
                          icon: const Icon(Icons.skip_previous_rounded, color: Colors.white, size: 22),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                        ),
                        GestureDetector(
                          onTap: sp.togglePlay,
                          child: Container(
                            width: 34,
                            height: 34,
                            decoration: BoxDecoration(
                              color: accent,
                              shape: BoxShape.circle,
                              boxShadow: [BoxShadow(color: accent.withOpacity(0.4), blurRadius: 8)],
                            ),
                            child: sp.isLoading
                                ? const Padding(
                                    padding: EdgeInsets.all(8),
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                    ),
                                  )
                                : Icon(
                                    sp.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                                    color: Colors.white,
                                    size: 20,
                                  ),
                          ),
                        ),
                        IconButton(
                          onPressed: sp.skipNext,
                          icon: const Icon(Icons.skip_next_rounded, color: Colors.white, size: 22),
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openFullPlayer(BuildContext context) {
    Navigator.of(context).push(
      PageRouteBuilder(
        opaque: false,
        pageBuilder: (_, __, ___) => const SpotifyFullPlayerPage(),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween(begin: const Offset(0, 1), end: Offset.zero).animate(
            CurvedAnimation(parent: anim, curve: Curves.easeOutCubic),
          ),
          child: child,
        ),
      ),
    );
  }
}

// ─── HALAMAN HEADSET / SPOTIFY FULL PLAYER ───────────────────────────────────
class SpotifyFullPlayerPage extends StatefulWidget {
  const SpotifyFullPlayerPage({super.key});

  @override
  State<SpotifyFullPlayerPage> createState() => _SpotifyFullPlayerPageState();
}

class _SpotifyFullPlayerPageState extends State<SpotifyFullPlayerPage>
    with TickerProviderStateMixin {
  late AnimationController _rotationCtrl;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _rotationCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _pulseAnim = Tween(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _rotationCtrl.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }

  String _fmtDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    return BackgroundWrapper(
      child: AnimatedBuilder(
        animation: SpotifyScope.of(context),
        builder: (ctx, _) {
          final sp = SpotifyScope.of(ctx);
          final track = sp.currentTrack;
          final accent = track.accentColor ?? AppColors.accent1;

          // Sync rotasi dengan status play
          if (sp.isPlaying) {
            if (!_rotationCtrl.isAnimating) _rotationCtrl.repeat();
            if (!_pulseCtrl.isAnimating) _pulseCtrl.repeat(reverse: true);
          } else {
            _rotationCtrl.stop();
            _pulseCtrl.stop();
          }

          return Scaffold(
            backgroundColor: Colors.transparent,
            body: SafeArea(
              child: Column(
                children: [
                  // ── Header ───────────────────────────────────────────────
                  _buildHeader(context, accent),
                  // ── Body ─────────────────────────────────────────────────
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Column(
                          children: [
                            const SizedBox(height: 20),
                            // Artwork
                            _buildArtwork(sp, track, accent),
                            const SizedBox(height: 28),
                            // Track Info
                            _buildTrackInfo(track, accent),
                            const SizedBox(height: 24),
                            // Progress Bar
                            _buildProgressBar(ctx, sp, accent),
                            const SizedBox(height: 20),
                            // Controls
                            _buildControls(sp, accent),
                            const SizedBox(height: 24),
                            // Extra controls
                            _buildExtraControls(sp, accent),
                            const SizedBox(height: 28),
                            // Playlist
                            _buildPlaylist(ctx, sp, accent),
                            const SizedBox(height: 24),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildHeader(BuildContext context, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        border: Border(
          bottom: BorderSide(color: accent.withOpacity(0.2), width: 0.5),
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white24),
              ),
              child: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white, size: 22),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(FontAwesomeIcons.headphones, color: accent, size: 14),
                    const SizedBox(width: 8),
                    const Text(
                      'MUSIC PLAYER',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 2,
                      ),
                    ),
                  ],
                ),
                Text(
                  'Powered by Spotify',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.5),
                    fontSize: 10,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
          // Spotify logo badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xFF1DB954).withOpacity(0.2),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF1DB954).withOpacity(0.5)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Color(0xFF1DB954),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                const Text(
                  'Spotify',
                  style: TextStyle(
                    color: Color(0xFF1DB954),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildArtwork(SpotifyNotifier sp, SpotifyTrack track, Color accent) {
    return Center(
      child: AnimatedBuilder(
        animation: _pulseAnim,
        builder: (_, __) => ScaleTransition(
          scale: sp.isPlaying ? _pulseAnim : const AlwaysStoppedAnimation(1.0),
          child: AnimatedBuilder(
            animation: _rotationCtrl,
            builder: (_, child) => Transform.rotate(
              angle: sp.isPlaying ? _rotationCtrl.value * 2 * pi : 0,
              child: child,
            ),
            child: Container(
              width: 220,
              height: 220,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(color: accent.withOpacity(0.5), blurRadius: 40, spreadRadius: 5),
                  BoxShadow(color: accent.withOpacity(0.2), blurRadius: 80, spreadRadius: 20),
                  const BoxShadow(color: Colors.black54, blurRadius: 20),
                ],
                border: Border.all(color: accent.withOpacity(0.4), width: 2),
              ),
              child: ClipOval(
                child: track.artworkUrl != null
                    ? Image.network(
                        track.artworkUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _artworkFallback(accent),
                      )
                    : _artworkFallback(accent),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _artworkFallback(Color accent) {
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          colors: [accent.withOpacity(0.6), Colors.black87],
        ),
      ),
      child: Icon(FontAwesomeIcons.music, color: accent, size: 60),
    );
  }

  Widget _buildTrackInfo(SpotifyTrack track, Color accent) {
    return Column(
      children: [
        Text(
          track.title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 6),
        Text(
          track.artist,
          style: TextStyle(
            color: accent,
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 4),
        Text(
          track.album,
          style: TextStyle(
            color: Colors.white.withOpacity(0.4),
            fontSize: 12,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildProgressBar(BuildContext context, SpotifyNotifier sp, Color accent) {
    return Column(
      children: [
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 3,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
            activeTrackColor: accent,
            inactiveTrackColor: Colors.white24,
            thumbColor: Colors.white,
            overlayColor: accent.withOpacity(0.2),
          ),
          child: Slider(
            value: sp.progress,
            onChanged: (v) => sp.seekTo(v),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                _fmtDuration(sp.position),
                style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
              ),
              Text(
                _fmtDuration(sp.duration),
                style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildControls(SpotifyNotifier sp, Color accent) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // Shuffle
        GestureDetector(
          onTap: sp.toggleShuffle,
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: sp.shuffle ? accent.withOpacity(0.2) : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              Icons.shuffle_rounded,
              color: sp.shuffle ? accent : Colors.white54,
              size: 20,
            ),
          ),
        ),
        const SizedBox(width: 12),
        // Prev
        GestureDetector(
          onTap: sp.skipPrev,
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(50),
            ),
            child: const Icon(Icons.skip_previous_rounded, color: Colors.white, size: 28),
          ),
        ),
        const SizedBox(width: 16),
        // Play/Pause
        GestureDetector(
          onTap: sp.togglePlay,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              gradient: RadialGradient(
                colors: [accent.withOpacity(0.9), accent],
              ),
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(color: accent.withOpacity(0.6), blurRadius: 20, spreadRadius: 2),
                BoxShadow(color: accent.withOpacity(0.3), blurRadius: 40),
              ],
            ),
            child: sp.isLoading
                ? const Padding(
                    padding: EdgeInsets.all(16),
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Icon(
                    sp.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: Colors.white,
                    size: 32,
                  ),
          ),
        ),
        const SizedBox(width: 16),
        // Next
        GestureDetector(
          onTap: sp.skipNext,
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.08),
              borderRadius: BorderRadius.circular(50),
            ),
            child: const Icon(Icons.skip_next_rounded, color: Colors.white, size: 28),
          ),
        ),
        const SizedBox(width: 12),
        // Repeat
        GestureDetector(
          onTap: sp.toggleRepeat,
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: sp.repeat ? accent.withOpacity(0.2) : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              Icons.repeat_rounded,
              color: sp.repeat ? accent : Colors.white54,
              size: 20,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildExtraControls(SpotifyNotifier sp, Color accent) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _extraBtn(
          icon: FontAwesomeIcons.spotify,
          label: 'Buka Spotify',
          color: const Color(0xFF1DB954),
          onTap: () {},
        ),
        const SizedBox(width: 16),
        _extraBtn(
          icon: Icons.playlist_play_rounded,
          label: 'Playlist',
          color: accent,
          onTap: () {},
        ),
        const SizedBox(width: 16),
        _extraBtn(
          icon: Icons.share_rounded,
          label: 'Bagikan',
          color: Colors.white60,
          onTap: () {},
        ),
      ],
    );
  }

  Widget _extraBtn({required IconData icon, required String label, required Color color, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.3)),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: color, fontSize: 9)),
        ],
      ),
    );
  }

  Widget _buildPlaylist(BuildContext context, SpotifyNotifier sp, Color accent) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Row(
            children: [
              Icon(Icons.queue_music_rounded, color: accent, size: 16),
              const SizedBox(width: 8),
              Text(
                'PLAYLIST',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.8),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${sp.playlist.length} lagu',
                  style: TextStyle(color: accent, fontSize: 9, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
        ...sp.playlist.asMap().entries.map((e) => _buildPlaylistItem(context, sp, e.key, e.value, accent)),
      ],
    );
  }

  Widget _buildPlaylistItem(BuildContext context, SpotifyNotifier sp, int index, SpotifyTrack track, Color accent) {
    final isActive = index == sp.currentIndex;
    final itemAccent = track.accentColor ?? accent;

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        sp.play(index);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: isActive
              ? itemAccent.withOpacity(0.15)
              : Colors.black.withOpacity(0.3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isActive ? itemAccent.withOpacity(0.5) : Colors.white12,
            width: isActive ? 1 : 0.5,
          ),
        ),
        child: Row(
          children: [
            // Nomor / playing indicator
            SizedBox(
              width: 24,
              child: isActive
                  ? _PlayingBars(color: itemAccent, isPlaying: sp.isPlaying)
                  : Text(
                      '${index + 1}',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 12,
                      ),
                      textAlign: TextAlign.center,
                    ),
            ),
            const SizedBox(width: 8),
            // Artwork kecil
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6),
                color: Colors.black38,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: track.artworkUrl != null
                    ? Image.network(
                        track.artworkUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Icon(
                          FontAwesomeIcons.music,
                          color: itemAccent,
                          size: 14,
                        ),
                      )
                    : Icon(FontAwesomeIcons.music, color: itemAccent, size: 14),
              ),
            ),
            const SizedBox(width: 10),
            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    track.title,
                    style: TextStyle(
                      color: isActive ? itemAccent : Colors.white,
                      fontSize: 12,
                      fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    track.artist,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.4),
                      fontSize: 10,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            // Duration
            Text(
              '0:30',
              style: TextStyle(
                color: Colors.white.withOpacity(0.3),
                fontSize: 10,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── PLAYING BARS ANIMATION ───────────────────────────────────────────────────
class _PlayingBars extends StatefulWidget {
  final Color color;
  final bool isPlaying;

  const _PlayingBars({required this.color, required this.isPlaying});

  @override
  State<_PlayingBars> createState() => _PlayingBarsState();
}

class _PlayingBarsState extends State<_PlayingBars> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    if (widget.isPlaying) _ctrl.repeat(reverse: true);
  }

  @override
  void didUpdateWidget(_PlayingBars old) {
    super.didUpdateWidget(old);
    if (widget.isPlaying && !_ctrl.isAnimating) {
      _ctrl.repeat(reverse: true);
    } else if (!widget.isPlaying) {
      _ctrl.stop();
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, __) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          _bar(0.4 + _ctrl.value * 0.6),
          const SizedBox(width: 1),
          _bar(0.8 - _ctrl.value * 0.4),
          const SizedBox(width: 1),
          _bar(0.5 + _ctrl.value * 0.5),
        ],
      ),
    );
  }

  Widget _bar(double heightFactor) {
    return Container(
      width: 3,
      height: 16 * heightFactor,
      decoration: BoxDecoration(
        color: widget.color,
        borderRadius: BorderRadius.circular(2),
      ),
    );
  }
}

// ─── HEADSET ICON BUTTON (di AppBar dashboard) ───────────────────────────────
// Ganti icon ? → headset, buka SpotifyFullPlayerPage
class SpotifyHeadsetButton extends StatelessWidget {
  const SpotifyHeadsetButton({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: SpotifyScope.of(context),
      builder: (ctx, _) {
        final sp = SpotifyScope.of(ctx);
        final isActive = sp.isPlaying;
        final accent = isActive ? (sp.currentTrack.accentColor ?? AppColors.accent1) : AppColors.silver2;

        return GestureDetector(
          onTap: () {
            HapticFeedback.lightImpact();
            Navigator.of(context).push(
              PageRouteBuilder(
                opaque: false,
                pageBuilder: (_, __, ___) => const SpotifyFullPlayerPage(),
                transitionsBuilder: (_, anim, __, child) => SlideTransition(
                  position: Tween(
                    begin: const Offset(0, 1),
                    end: Offset.zero,
                  ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
                  child: child,
                ),
              ),
            );
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: isActive ? accent.withOpacity(0.15) : AppColors.surface2,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isActive ? accent.withOpacity(0.5) : AppColors.silver2.withOpacity(0.2),
                width: isActive ? 1 : 0.5,
              ),
              boxShadow: isActive
                  ? [BoxShadow(color: accent.withOpacity(0.3), blurRadius: 8)]
                  : null,
            ),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(FontAwesomeIcons.headphones, color: accent, size: 15),
                // Dot indikator kalau sedang main
                if (isActive)
                  Positioned(
                    top: -4,
                    right: -4,
                    child: Container(
                      width: 7,
                      height: 7,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1DB954),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(color: const Color(0xFF1DB954).withOpacity(0.6), blurRadius: 4),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
