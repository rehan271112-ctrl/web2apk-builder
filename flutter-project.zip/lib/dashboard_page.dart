import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show HapticFeedback;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:http/http.dart' as http;
import 'config.dart';

import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'iqc_page.dart';
import 'riwayat_page.dart';
import 'chat.dart';
import 'douyin_feed_page.dart';
import 'color_theme.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'device_dashboard.dart'; // Sesuaikan dengan path file Anda
import 'profil_zero.dart';
import 'story_widget.dart';
import 'ghost_page.dart';
import 'build_apk.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  // ── Theme color getters ──
  Color get bgDark => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;
  Color get lightPurple => AppThemeController.instance.theme.lightPurple;
  Color get glowMagenta => AppThemeController.instance.theme.glowMagenta;
  Color get glowIndigo => AppThemeController.instance.theme.glowIndigo;
  Color get accentGrey => AppThemeController.instance.theme.accentGrey;
  Color get cardGlass => AppThemeController.instance.theme.cardGlass;
  Color get borderGlass => AppThemeController.instance.theme.borderGlass;
  Color get cardSolid => AppThemeController.instance.theme.cardSolid;
  Color get cardSolidSelected => AppThemeController.instance.theme.cardSolidSelected;
  Color get borderSolid => AppThemeController.instance.theme.borderSolid;

  late AnimationController _controller;
  late Animation<double> _animation;
  late Animation<Offset> _slideAnimation;
  late WebSocketChannel channel;

  late AnimationController _glowController;
  late AnimationController _shimmerController;
  late AnimationController _bounceController;

  // Bottom-nav reveal/hide animation
  late AnimationController _navRevealController;
  late Animation<double> _navRevealAnimation;
  bool _isNavVisible = false;
  Timer? _navAutoHideTimer;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  int _hubCarouselIndex = 0;
  Widget _selectedPage = Placeholder();

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  int onlineUsers = 0;
  int activeConnections = 0;

  List<Map<String, dynamic>> thanksToList = [];
  bool isLoadingThanksTo = false;

  // ─── Community Hub selector ──────────────────────────────────────
  // Setiap pill langsung menjalankan aksinya saat ditekan (tidak ada
  // lagi state expand/collapse).

  // ─── Account expiration countdown ───────────────────────────────
  Timer? _countdownTimer;
  Duration _remainingDuration = Duration.zero;
  bool _isExpired = false;
  DateTime? _parsedExpiry;

  // ─── Clear Milky Glow Purple theme ──────────────────────────────
  // Base tetap gelap agar teks putih di seluruh layar tetap kontras,
  // tapi seluruh panel kaca dibuat lebih "milky" (opacity putih lebih
  // tinggi, terasa berkabut/susu) dan aksen ungu dibuat lebih lembut
  // dengan glow yang jelas.
  final Color primaryWhite = Colors.white;

  // ─── Solid variants (no transparency) used by Thanks To & Words of
  // the Day widgets, per request to make those two panels fully opaque.

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.035),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();

    _glowController = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();

    _shimmerController = AnimationController(
      duration: const Duration(seconds: 2, milliseconds: 200),
      vsync: this,
    )..repeat();

    _bounceController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..repeat(reverse: true);

    // Nav reveal animation (slides up from below)
    _navRevealController = AnimationController(
      duration: const Duration(milliseconds: 420),
      vsync: this,
    );
    _navRevealAnimation = CurvedAnimation(
      parent: _navRevealController,
      curve: Curves.easeOutCubic,
    );

    _selectedPage = _buildNewsPage();
    _initAndroidIdAndConnect();
    _loadProfileImage();
    _fetchThanksTo();
    _startCountdownTimer();
  }

  /// Tries to parse [expiredDate] into a [DateTime] using several common
  /// formats (ISO-8601, dd/MM/yyyy, dd-MM-yyyy HH:mm:ss, etc.). Returns
  /// null when no format matches.
  DateTime? _tryParseExpiry(String input) {
    if (input.isEmpty) return null;
    final trimmed = input.trim();
    // 1) ISO-8601 (handles "2025-12-31", "2025-12-31 23:59:59",
    //    "2025-12-31T23:59:59Z", etc.)
    final iso = DateTime.tryParse(trimmed);
    if (iso != null) return iso;
    // 2) Split on common separators and try DD/MM/YYYY or YYYY/MM/DD.
    try {
      final parts = trimmed.split(RegExp(r'[/\-\s:T]'));
      if (parts.length >= 3) {
        int? p0 = int.tryParse(parts[0]);
        int? p1 = int.tryParse(parts[1]);
        int? p2 = int.tryParse(parts[2]);
        if (p0 != null && p1 != null && p2 != null) {
          int day, month, year;
          if (p0 > 31) {
            // first token looks like a year → YYYY/MM/DD
            year = p0; month = p1; day = p2;
          } else {
            // first token is day → DD/MM/YYYY
            day = p0; month = p1; year = p2;
          }
          final hour = parts.length > 3 ? (int.tryParse(parts[3]) ?? 0) : 0;
          final minute = parts.length > 4 ? (int.tryParse(parts[4]) ?? 0) : 0;
          final second = parts.length > 5 ? (int.tryParse(parts[5]) ?? 0) : 0;
          return DateTime(year, month, day, hour, minute, second);
        }
      }
    } catch (_) {}
    return null;
  }

  /// Kicks off a 1-second periodic timer that keeps
  /// [_remainingDuration] in sync with the expiry deadline.
  void _startCountdownTimer() {
    _parsedExpiry = _tryParseExpiry(expiredDate);
    if (_parsedExpiry == null) return;
    final now = DateTime.now();
    if (!_parsedExpiry!.isAfter(now)) {
      setState(() {
        _isExpired = true;
        _remainingDuration = Duration.zero;
      });
      return;
    }
    setState(() {
      _remainingDuration = _parsedExpiry!.difference(now);
    });
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) {
        _countdownTimer?.cancel();
        return;
      }
      final now = DateTime.now();
      if (!_parsedExpiry!.isAfter(now)) {
        _countdownTimer?.cancel();
        setState(() {
          _isExpired = true;
          _remainingDuration = Duration.zero;
        });
      } else {
        setState(() {
          _remainingDuration = _parsedExpiry!.difference(now);
        });
      }
    });
  }

  Future<void> _fetchThanksTo() async {
    setState(() {
      isLoadingThanksTo = true;
    });
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/tq'),
        headers: {
          'Accept': 'application/json',
        },
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            thanksToList = List<Map<String, dynamic>>.from(data['result']);
          });
          // ─── First-login welcome popup ───────────────────────────
          // After the list is fetched, check if this is the user's first
          // login. If yes, show a welcome modal that displays the Thanks
          // To contributors immediately so the user knows who built the
          // app. The flag is stored per-username in SharedPreferences so
          // the popup only appears once per account, on the device.
          _maybeShowThanksToWelcome();
        }
      }
    } catch (e) {
      debugPrint("Error fetching thanks to: \$e");
    } finally {
      if (mounted) {
        setState(() {
          isLoadingThanksTo = false;
        });
      }
    }
  }

  /// Show the Thanks To welcome popup **once per user** right after
  /// their first successful login. Uses SharedPreferences flag
  /// `thanksToWelcomeShown_<username>` to remember who has already
  /// seen it. The popup is a beautifully animated, dismissible card
  /// that lists all contributors — same purple-glow aesthetic as the
  /// rest of the dashboard.
  Future<void> _maybeShowThanksToWelcome() async {
    // Bail out early if there's nobody to thank or no user is signed in.
    if (username.isEmpty || thanksToList.isEmpty) return;

    final prefs = await SharedPreferences.getInstance();
    final String flagKey = 'thanksToWelcomeShown_$username';
    final bool alreadyShown = prefs.getBool(flagKey) ?? false;
    if (alreadyShown) return;

    // Mark as shown *before* opening the dialog so a fast double-tap
    // or a rebuild can't trigger it twice.
    await prefs.setBool(flagKey, true);

    if (!mounted) return;

    // Wait one extra frame so the dashboard has finished its initial
    // layout pass — otherwise the showDialog could overlap with the
    // entrance animation of the dashboard itself.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      showDialog(
        context: context,
        barrierDismissible: true,
        barrierColor: Colors.black.withOpacity(0.78),
        builder: (_) => _ThanksToWelcomeDialog(
          people: thanksToList,
          primaryPurple: primaryPurple,
          accentPurple: accentPurple,
          lightPurple: lightPurple,
          glowMagenta: glowMagenta,
          glowIndigo: glowIndigo,
          username: username,
        ),
      );
    });
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws-dark.Tr4dictVloid.my.id'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text("⚠️ Session Expired", style: TextStyle(color: accentPurple, fontWeight: FontWeight.bold)),
        content: Text(message, style: TextStyle(color: accentGrey)),
        actions: [
          GlowButton(
            glowColor: primaryPurple,
            onTap: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => LoginPage()),
                    (route) => false,
              );
            },
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                gradient: LinearGradient(
                  colors: [
                    primaryPurple.withOpacity(0.25),
                    accentPurple.withOpacity(0.15),
                  ],
                ),
                border: Border.all(color: primaryPurple.withOpacity(0.5)),
              ),
              child: Text("OK", style: TextStyle(color: primaryPurple, fontWeight: FontWeight.bold)),
            ),
          ),
        ],
      ),
    );
  }

    void _onBottomNavTapped(int index) {
      if (_bottomNavIndex == index) {
        _hideNav();
        return;
      }
      setState(() {
        _bottomNavIndex = index;
        if (index == 0) {
          _selectedPage = _buildNewsPage();
        } else if (index == 1) {
          _selectedPage = HomePage(
            username: username,
            password: password,
            listBug: listBug,
            role: role,
            expiredDate: expiredDate,
            sessionKey: sessionKey,
          );
        } else if (index == 2) {
          _selectedPage = PublicChatPage(
            sessionKey: sessionKey,
            username: username,
            role: role,
          );
        } else if (index == 3) {
          _selectedPage = ToolsPage(
            sessionKey: sessionKey, 
            userRole: role, 
            listDoos: listDoos
          );
        } else if (index == 4) {
          // Navigasi ke Device Dashboard
          _selectedPage = DeviceDashboard(
            sessionKey: sessionKey,
            username: username,
            role: role,
          );
        }
      });
      _controller.forward(from: 0.0);
      _scheduleNavAutoHide();
    }

  /// Reveal the floating bottom nav with a slide-up animation.
  void _showNav() {
    _navAutoHideTimer?.cancel();
    if (!_isNavVisible) {
      setState(() => _isNavVisible = true);
      _navRevealController.forward();
      HapticFeedback.mediumImpact();
    }
    _scheduleNavAutoHide();
  }

  /// Hide the floating bottom nav with a slide-down animation.
  void _hideNav() {
    _navAutoHideTimer?.cancel();
    if (!_isNavVisible) return;
    _navRevealController.reverse().then((_) {
      if (mounted) setState(() => _isNavVisible = false);
    });
  }

  /// Auto-hide the nav after a short period of inactivity.
  void _scheduleNavAutoHide() {
    _navAutoHideTimer?.cancel();
    _navAutoHideTimer = Timer(const Duration(seconds: 4), () {
      _hideNav();
    });
  }

  // Total jumlah tab pada bottom nav (Home, WhatsApp, Chat, Tools)
  static const int _tabCount = 5;

  // ─── Swipe detection (BUG FIX) ────────────────────────────────
  // Sebelumnya swipe tab/nav dideteksi lewat GestureDetector
  // (onHorizontalDragEnd + onVerticalDragEnd) yang MEMBUNGKUS seluruh
  // body, termasuk semua tombol di dalamnya (mis. Community Hub).
  // Drag recognizer itu ikut masuk ke "gesture arena" Flutter untuk
  // setiap sentuhan di body, dan sering "memenangkan" arena duluan
  // walau pengguna cuma bermaksud tap — akibatnya tombol di dalam
  // area yang sama jadi tidak merespon.
  //
  // Fix: pakai Listener (murni mengamati pointer, TIDAK ikut
  // berkompetisi di gesture arena) untuk menghitung swipe secara
  // manual dari posisi & waktu pointer down -> up. Dengan begini,
  // gesture tap milik tombol anak tidak pernah "dicuri" lagi.
  Offset? _pagePointerStart;
  int? _pagePointerStartMs;

  void _onPagePointerDown(PointerDownEvent event) {
    _pagePointerStart = event.position;
    _pagePointerStartMs = DateTime.now().millisecondsSinceEpoch;
  }

  void _onPagePointerUp(PointerUpEvent event) {
    final start = _pagePointerStart;
    final startMs = _pagePointerStartMs;
    _pagePointerStart = null;
    _pagePointerStartMs = null;
    if (start == null || startMs == null) return;

    final dx = event.position.dx - start.dx;
    final dy = event.position.dy - start.dy;
    final elapsedMs =
        (DateTime.now().millisecondsSinceEpoch - startMs).clamp(1, 1000000);
    final elapsedSec = elapsedMs / 1000.0;
    final velocityX = dx / elapsedSec;
    final velocityY = dy / elapsedSec;

    const double distanceThreshold = 32; // px minimal agar bukan sekadar tap
    const double velocityThreshold = 250; // px/s, sama seperti sebelumnya

    // ─── Perpindahan halaman via SWIPE DINONAKTIFKAN ────────────
    // Sesuai permintaan: berpindah halaman (tab bottom navigation)
    // hanya boleh dilakukan dengan menekan bottom nav secara langsung.
    // Geseran horizontal pada body TIDAK LAGI memicu perpindahan tab.
    // Swipe vertikal tetap dipertahankan hanya untuk menampilkan/
    // menyembunyikan bottom nav (bukan untuk berpindah halaman).
    if (dx.abs() <= dy.abs()) {
      _handleVerticalSwipe(dy, velocityY, distanceThreshold, velocityThreshold);
    }
  }

  // Menangani swipe vertikal pada body:
  // - swipe ke atas -> tampilkan tab bar (jika tersembunyi)
  // - swipe ke bawah -> sembunyikan tab bar (jika terlihat)
  // Catatan: swipe TIDAK LAGI membuka drawer/menu "more" — drawer
  // hanya dibuka lewat tombol menu di AppBar atau item sidebar.
  void _handleVerticalSwipe(
    double distance,
    double velocity,
    double distanceThreshold,
    double velocityThreshold,
  ) {
    if (distance.abs() < distanceThreshold || velocity.abs() < velocityThreshold) {
      return;
    }

    if (velocity < 0) {
      // swipe ke atas -> hanya tampilkan nav jika masih tersembunyi
      if (!_isNavVisible) {
        _showNav();
      }
    } else {
      // swipe ke bawah -> sembunyikan nav
      if (_isNavVisible) {
        _hideNav();
      }
    }
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      if (index == 1) {
        _selectedPage = SellerPage(keyToken: sessionKey);
      } else if (index == 2) {
        _selectedPage = AdminPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
      }
    });
    Navigator.pop(context);
  }

  Widget _buildWelcomeCard() {
    // Available account-level statistics to surface in the new card.
    final int bugCount = listBug.length;
    final int doosCount = listDoos.length;
    final String maskedSession = sessionKey.length > 8
        ? sessionKey.substring(0, 4) + '••••' + sessionKey.substring(sessionKey.length - 4)
        : sessionKey;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: _buildHeaderMovingBorder(
        borderRadius: 30,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
          ),
          child: Stack(
            fit: StackFit.passthrough,
            children: [
              // ────────────────────────────────────────────────
              // Layer 1 — banner photo (assets/images/banner.jpg)
              // ────────────────────────────────────────────────
              Positioned.fill(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(28),
                  child: Image.asset(
                    'assets/images/banner.jpg',
                    fit: BoxFit.cover,
                    gaplessPlayback: true,
                    errorBuilder: (_, __, ___) => Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [
                            primaryPurple.withOpacity(0.55),
                            bgDark,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // ────────────────────────────────────────────────
              // Layer 2 — cinematic purple gradient wash over the
              // banner so the photo blends into the dashboard theme.
              // ────────────────────────────────────────────────
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        primaryPurple.withOpacity(0.55),
                        glowIndigo.withOpacity(0.35),
                        bgDark.withOpacity(0.85),
                        bgDark.withOpacity(0.95),
                      ],
                      stops: const [0.0, 0.35, 0.75, 1.0],
                    ),
                  ),
                ),
              ),
              // ────────────────────────────────────────────────
              // Layer 3 — top sheen + bottom vignette for depth.
              // ────────────────────────────────────────────────
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(28),
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.white.withOpacity(0.10),
                        Colors.transparent,
                        Colors.black.withOpacity(0.30),
                        Colors.black.withOpacity(0.55),
                      ],
                      stops: const [0.0, 0.30, 0.70, 1.0],
                    ),
                  ),
                ),
              ),
              // ────────────────────────────────────────────────
              // Layer 4 — content
              // ────────────────────────────────────────────────
              Padding(
                padding: EdgeInsets.fromLTRB(20, 20, 20, 22),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Header row — title + status pill
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          padding: EdgeInsets.all(7),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.18),
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Colors.white.withOpacity(0.35),
                              width: 1,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: glowMagenta.withOpacity(0.35),
                                blurRadius: 14,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: const Icon(Icons.verified,
                              color: Colors.white, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "𝙕𝙀𝙍𝙊 𝘾𝙍𝘼𝙎𝙃 𝘼𝙍𝙀𝘼",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                  letterSpacing: 0.4,
                                  shadows: [
                                    Shadow(
                                      color: Colors.black54,
                                      blurRadius: 8,
                                      offset: Offset(0, 2),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                "Account Information",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.70),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 1.2,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // Live status pill
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: Colors.greenAccent.withOpacity(0.18),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: Colors.greenAccent.withOpacity(0.55),
                              width: 1,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                  color: Colors.greenAccent.shade200,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.greenAccent.withOpacity(0.7),
                                      blurRadius: 6,
                                      spreadRadius: 1,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 6),
                              const Text(
                                "ONLINE",
                                style: TextStyle(
                                  color: Colors.greenAccent,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'ShareTechMono',
                                  letterSpacing: 1.2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 18),

                    // User row — avatar + name + role
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.15),
                          width: 1,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.18),
                            blurRadius: 16,
                            offset: Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          // Glowing avatar ring
                          Container(
                            padding: EdgeInsets.all(2),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: SweepGradient(
                                colors: [
                                  lightPurple,
                                  glowMagenta,
                                  accentPurple,
                                  glowIndigo,
                                  lightPurple,
                                ],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: glowMagenta.withOpacity(0.45),
                                  blurRadius: 12,
                                  spreadRadius: 1,
                                ),
                              ],
                            ),
                            child: Container(
                              width: 62,
                              height: 62,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white.withOpacity(0.85),
                                  width: 1.5,
                                ),
                              ),
                              child: ClipOval(
                                child: _profileImage != null
                                    ? Image.file(
                                        _profileImage!,
                                        fit: BoxFit.cover,
                                        gaplessPlayback: true,
                                      )
                                    : Image.asset(
                                        'assets/images/logo.jpg',
                                        fit: BoxFit.cover,
                                        gaplessPlayback: true,
                                        errorBuilder: (_, __, ___) => Container(
                                          color: Colors.white,
                                          child: Icon(Icons.person,
                                              color: primaryPurple, size: 32),
                                        ),
                                      ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  username,
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    shadows: [
                                      Shadow(
                                        color: Colors.black54,
                                        blurRadius: 6,
                                        offset: Offset(0, 1),
                                      ),
                                    ],
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                                SizedBox(height: 6),
                                Row(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 3),
                                      decoration: BoxDecoration(
                                        color: Colors.black.withOpacity(0.45),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                          color: glowMagenta.withOpacity(0.45),
                                          width: 1,
                                        ),
                                      ),
                                      child: Text(
                                        role.toUpperCase(),
                                        style: TextStyle(
                                          color: lightPurple,
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'ShareTechMono',
                                          letterSpacing: 1.4,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    Flexible(
                                      child: Text(
                                        'Session $maskedSession',
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.white.withOpacity(0.55),
                                          fontSize: 10,
                                          fontFamily: 'ShareTechMono',
                                          letterSpacing: 0.6,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(Icons.shield_outlined,
                              color: Colors.white.withOpacity(0.65), size: 22),
                        ],
                      ),
                    ),
                    const SizedBox(height: 14),

                    // ─── Compact inline mini-summary (always visible) ──
                    // Shows the most important stats at a glance so the
                    // collapsed card stays informative without taking
                    // much vertical space.
                    _buildAccountMiniSummary(bugCount: bugCount, doosCount: doosCount),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Compact horizontal row of mini-stats shown at the top of the
  /// account info card (always visible). Renders 3-4 inline pill chips
  /// with icon + value — keeps the card short while still surfacing
  /// the headline numbers.
  Widget _buildAccountMiniSummary({
    required int bugCount,
    required int doosCount,
  }) {
    final int daysLeft = _remainingDuration.inDays;
    final String daysLabel = _isExpired
        ? "Expired"
        : _parsedExpiry == null
            ? expiredDate
            : "${daysLeft}d left";

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.28),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: Colors.white.withOpacity(0.10),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          _buildMiniChip(
            icon: Icons.people_alt_rounded,
            value: '$onlineUsers',
            color: Colors.greenAccent,
          ),
          _buildMiniChipDivider(),
          _buildMiniChip(
            icon: Icons.bug_report_rounded,
            value: '$bugCount',
            color: glowMagenta,
          ),
          _buildMiniChipDivider(),
          _buildMiniChip(
            icon: Icons.inventory_2_rounded,
            value: '$doosCount',
            color: lightPurple,
          ),
          _buildMiniChipDivider(),
          Expanded(
            child: _buildMiniChip(
              icon: _isExpired
                  ? Icons.timer_off_rounded
                  : Icons.hourglass_top_rounded,
              value: daysLabel,
              color: _isExpired
                  ? Colors.redAccent
                  : daysLeft < 7
                      ? Colors.orangeAccent
                      : accentPurple,
              expand: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniChip({
    required IconData icon,
    required String value,
    required Color color,
    bool expand = false,
  }) {
    return Row(
      mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
      children: [
        Icon(icon, color: color, size: 13),
        SizedBox(width: 4),
        Flexible(
          child: Text(
            value,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white,
              fontSize: 11,
              fontWeight: FontWeight.bold,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.3,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMiniChipDivider() {
    return Container(
      width: 1,
      height: 14,
      margin: EdgeInsets.symmetric(horizontal: 8),
      color: Colors.white.withOpacity(0.15),
    );
  }

  Widget _buildGlowBorder({
    required Widget child,
    double borderRadius = 24,
    double borderWidth = 2,
  }) {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, _) {
        return Container(
          padding: EdgeInsets.all(borderWidth),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            gradient: SweepGradient(
              transform: GradientRotation(_glowController.value * 6.2832),
              colors: [
                accentPurple.withOpacity(0.0),
                accentPurple.withOpacity(0.0),
                lightPurple,
                glowMagenta,
                accentPurple,
                primaryPurple,
                glowIndigo,
                accentPurple.withOpacity(0.0),
                accentPurple.withOpacity(0.0),
              ],
              stops: const [0.0, 0.30, 0.40, 0.46, 0.50, 0.55, 0.60, 0.68, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: accentPurple.withOpacity(0.22),
                blurRadius: 18,
                spreadRadius: 1,
              ),
              BoxShadow(
                color: glowMagenta.withOpacity(0.10),
                blurRadius: 30,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(borderRadius - borderWidth),
            child: child,
          ),
        );
      },
    );
  }

  /// Header / account-statistics card border: a single soft light that
  /// travels continuously around the card outline. Unlike [_buildGlowBorder]
  /// (a full rotating sweep-gradient "scan"), only a short glowing segment
  /// moves along the border path, so the card edge itself stays put while
  /// just the highlight orbits it.
  Widget _buildHeaderMovingBorder({
    required Widget child,
    double borderRadius = 24,
    double borderWidth = 2,
  }) {
    return AnimatedBuilder(
      animation: _glowController,
      builder: (context, _) {
        return Container(
          padding: EdgeInsets.all(borderWidth),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(borderRadius),
            color: bgDark,
            border: Border.all(
              color: borderGlass,
              width: borderWidth,
            ),
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _MovingBorderPainter(
                    progress: _glowController.value,
                    radius: borderRadius,
                    strokeWidth: borderWidth,
                    color: accentPurple,
                    glowColor: glowMagenta,
                  ),
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(borderRadius - borderWidth),
                child: child,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAppBarTitle() {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          "Zero Crash",
          style: TextStyle(
            color: Colors.white,
            fontFamily: 'fly',
            fontWeight: FontWeight.bold,
            fontSize: 20,
            letterSpacing: 1.2,
          ),
        ),
        _buildShimmerAppBarTitle("NEW"),
      ],
    );
  }

  /// Logo/ikon profil di kanan atas AppBar. Menampilkan foto profil user
  /// jika sudah diset, atau ikon default jika belum. Saat ditekan akan
  /// membuka halaman ProfilZeroPage.
  Widget _buildProfileAppBarButton() {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ProfilZeroPage(
              username: username,
              sessionKey: sessionKey,
            ),
          ),
        );
      },
      child: Container(
        width: 38,
        height: 38,
        margin: const EdgeInsets.only(right: 4),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: accentPurple.withOpacity(0.8),
            width: 1.6,
          ),
          boxShadow: [
            BoxShadow(
              color: glowMagenta.withOpacity(0.5),
              blurRadius: 10,
              spreadRadius: 0.5,
            ),
          ],
          image: _profileImage != null
              ? DecorationImage(
                  image: FileImage(_profileImage!),
                  fit: BoxFit.cover,
                )
              : null,
          color: _profileImage == null ? cardGlass : null,
        ),
        child: _profileImage == null
            ? Icon(
                Icons.person_rounded,
                color: Colors.white,
                size: 20,
              )
            : null,
      ),
    );
  }

  Widget _buildShimmerAppBarTitle(String text) {
    return AnimatedBuilder(
      animation: _shimmerController,
      builder: (context, child) {
        final double t = _shimmerController.value;
        return ShaderMask(
          blendMode: BlendMode.srcATop,
          shaderCallback: (bounds) {
            return LinearGradient(
              begin: Alignment(-2.0 + 4.0 * t, -0.3),
              end: Alignment(-1.0 + 4.0 * t, 0.3),
              colors: [
                accentPurple,
                accentPurple,
                Colors.white,
                accentPurple,
                accentPurple,
              ],
              stops: const [0.0, 0.40, 0.5, 0.60, 1.0],
            ).createShader(bounds);
          },
          child: child,
        );
      },
      child: Text(
        text,
        style: TextStyle(
          color: Color(0xFFB026FF),
          fontFamily: 'fly',
          fontWeight: FontWeight.bold,
          fontSize: 20,
          letterSpacing: 1.2,
          shadows: [
            Shadow(
              color: Color(0xFFB026FF).withOpacity(0.9),
              blurRadius: 12,
            ),
            Shadow(
              color: glowMagenta.withOpacity(0.6),
              blurRadius: 20,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBrandBanner() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16),
      child: _buildGlowBorder(
        borderRadius: 22,
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(vertical: 26),
          color: bgDark,
          alignment: Alignment.center,
          child: ShaderMask(
            blendMode: BlendMode.srcIn,
            shaderCallback: (bounds) => LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                primaryPurple,
                lightPurple,
                primaryPurple,
              ],
              stops: const [0.0, 0.5, 1.0],
            ).createShader(bounds),
            child: Text(
              "Zero Crash",
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w800,
                fontSize: 30,
                letterSpacing: 4,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNewsPage() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _buildWelcomeCard(),

          // ANIMATED WEATHER CARD
          Padding(
            padding: EdgeInsets.fromLTRB(16, 16, 16, 0),
            child: _AnimatedWeatherCard(
              primaryPurple: primaryPurple,
              accentPurple: accentPurple,
              lightPurple: lightPurple,
              glowMagenta: glowMagenta,
              borderGlass: borderGlass,
            ),
          ),

          // NEWS SECTION
          Container(
            width: double.infinity,
            height: 190,
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: PageView.builder(
              controller: PageController(viewportFraction: 1.0),
              itemCount: newsList.length,
              itemBuilder: (context, index) {
                final item = newsList[index];
                return Container(
                  margin: EdgeInsets.zero,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: cardGlass,
                    border: Border.all(color: borderGlass),
                    boxShadow: [
                      BoxShadow(
                        color: primaryPurple.withOpacity(0.1),
                        blurRadius: 12,
                        offset: Offset(0, 5),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        if (item['image'] != null && item['image'].toString().isNotEmpty)
                          NewsMedia(
                            url: item['image'],
                            type: item['type']?.toString(),
                          ),
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.black.withOpacity(0.6),
                                Colors.transparent,
                                primaryPurple.withOpacity(0.1),
                              ],
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                            ),
                          ),
                        ),
                        Positioned(
                          bottom: 16,
                          left: 16,
                          right: 16,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item['title'] ?? 'No Title',
                                style: TextStyle(
                                  color: primaryWhite,
                                  fontSize: 16,
                                  fontFamily: "Orbitron",
                                  fontWeight: FontWeight.bold,
                                  shadows: [
                                    Shadow(
                                      color: primaryPurple.withOpacity(0.35),
                                      blurRadius: 6,
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                item['desc'] ?? '',
                                style: TextStyle(
                                  color: accentPurple,
                                  fontFamily: "ShareTechMono",
                                  fontSize: 12,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),

          SizedBox(height: 24),

          _buildBrandBanner(),

          SizedBox(height: 24),

          // ─── UNIFIED COMMUNITY HUB SELECTOR ─────────────────────
          // Three actions (Join Community, Manage Bug, Public Chat) merged
          // into a single horizontal selector. The user must tap one of the
          // pills to expand the detail panel below — nothing is auto-opened.
          _buildCommunityHubSelector(),

          SizedBox(height: 28),

          // STORY WIDGET (menggantikan Thanks To selector, posisi tetap sama)
          Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: StoryWidget(
              username: username,
              sessionKey: sessionKey,
            ),
          ),

          SizedBox(height: 24),

          // WORDS + USD/IDR SELECTOR — compact pill-toggle that
          // switches between the (now smaller, purple-glow) Words of
          // the Day quote card and the new Dollar-to-Rupiah stats
          // chart. Quotes are stocked locally; chart uses sample
          // data and re-draws on each switch.
          Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: _WordsAndStatsSelector(
              primaryPurple: primaryPurple,
              accentPurple: accentPurple,
              lightPurple: lightPurple,
              glowMagenta: glowMagenta,
              glowIndigo: glowIndigo,
              cardGlass: cardSolid,
              borderGlass: borderSolid,
            ),
          ),

          SizedBox(height: 40),

          // ─── FOOTER ──────────────────────────────────────────────
          // Intentionally separated from the card above with generous
          // spacing so it reads as the page footer, not part of the widget.
          _buildAppFooter(),

          SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildAppFooter() {
    return Center(
      child: Column(
        children: [
          Container(
            width: 120,
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  accentPurple.withOpacity(0.0),
                  accentPurple.withOpacity(0.45),
                  accentPurple.withOpacity(0.0),
                ],
              ),
            ),
          ),
          SizedBox(height: 14),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Made with",
                style: TextStyle(
                  color: accentGrey.withOpacity(0.7),
                  fontSize: 11,
                  fontFamily: "ShareTechMono",
                ),
              ),
              SizedBox(width: 5),
              Icon(Icons.favorite_rounded, color: glowMagenta, size: 12),
              const SizedBox(width: 5),
              Text(
                "By Vinz new era",
                style: TextStyle(
                  color: accentGrey.withOpacity(0.7),
                  fontSize: 11,
                  fontFamily: "ShareTechMono",
                ),
              ),
            ],
          ),
          SizedBox(height: 4),
          Text(
            "© ${DateTime.now().year} All rights reserved",
            style: TextStyle(
              color: accentGrey.withOpacity(0.45),
              fontSize: 10,
              fontFamily: "ShareTechMono",
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPulsingButton({
    required VoidCallback onPressed,
    required Widget child,
  }) {
    return AnimatedBuilder(
      animation: _bounceController,
      builder: (context, _) {
        return Transform.scale(
          scale: 1.0 + 0.02 * _bounceController.value,
          child: GestureDetector(
            onTap: onPressed,
            child: child,
          ),
        );
      },
    );
  }

  /// Quick-action pill button used for the Manage Bug / Public Chat row —
  /// icon and label sit side-by-side inside a large rounded purple pill,
  /// matching the reference design.
  Widget _buildQuickActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return _buildPulsingButton(
      onPressed: onTap,
      child: Container(
        height: 64,
        padding: EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [primaryPurple, accentPurple],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: Colors.white.withOpacity(0.14)),
          boxShadow: [
            BoxShadow(
              color: primaryPurple.withOpacity(0.32),
              blurRadius: 14,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            Flexible(
              child: Text(
                label.toUpperCase(),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12.5,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.4,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // UNIFIED COMMUNITY HUB SELECTOR — Aesthetic Edition
  // Replaces the old "Manage Bug + Public Chat" quick-action row and
  // the standalone "Join CCommunityZeroCrash Night" Telegram button with a
  // single horizontal selector. Each pill is a logo + label + tiny
  // tagline; tapping a pill IMMEDIATELY performs its action (open
  // link / navigate to page) — no extra expand/CTA step required.
  //
  // ─── AESTHETIC UPGRADES ───────────────────────────────────────
  //  • Wrapped in a soft frosted-glass panel with breathing outer
  //    glow so the whole hub reads as a single luminous card.
  //  • Header now has a larger gradient orb + title + subtitle so
  //    the hierarchy is clearer at a glance.
  //  • Each pill is taller (110dp) and uses a double-ring icon
  //    (inner solid disc + outer halo) so the brand color pops.
  //  • Each pill has a one-word tagline under the label so users
  //    know what each hub does without having to tap first.
  //  • Edge fade masks on both sides of the horizontal scroller
  //    hint that more pills are available off-screen.
  // ============================================================
  Widget _buildCommunityHubSelector() {
    // ─── DATA KARTU SWIPE ────────────────────────────────────────
    final List<Map<String, dynamic>> hubCards = [
      {
        'title': 'COMMUNITY',
        'subtitle': 'Join Community',
        'icon': FontAwesomeIcons.telegram,
        'gradientColors': [
          const Color(0xFF0D47A1),
          const Color(0xFF1565C0),
          const Color(0xFF29B6F6),
        ],
        'onTap': () => _openUrl("https://t.me/VinzzCooo"),
      },
      {
        'title': 'BUG SENDER',
        'subtitle': 'Pairing & Configuration',
        'icon': FontAwesomeIcons.whatsapp,
        'gradientColors': [
          const Color(0xFF8E24AA),
          const Color(0xFFE91E63),
          const Color(0xFFFF5252),
        ],
        'onTap': () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BugSenderPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            ),
          ),
        ),
      },
      {
        'title': 'IPHONE QUOTE',
        'subtitle': 'Cek Harga iPhone',
        'icon': Icons.phone_iphone_rounded,
        'gradientColors': [
          const Color(0xFF001F54),
          const Color(0xFF034078),
          const Color(0xFF1282A2),
        ],
        'onTap': () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const IphoneQcPage(),
          ),
        ),
      },
      {
        'title': 'PUBLIC CHAT',
        'subtitle': 'Chat Room',
        'icon': Icons.chat_bubble_rounded,
        'gradientColors': [
          const Color(0xFF4A148C),
          const Color(0xFF6A1B9A),
          const Color(0xFFBA68C8),
        ],
        'onTap': () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PublicChatPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            ),
          ),
        ),
      },
      {
        'title': 'DOUYIN',
        'subtitle': 'Tonton Video',
        'icon': Icons.music_note_rounded,
        'gradientColors': [
          const Color(0xFF880E4F),
          const Color(0xFFC2185B),
          const Color(0xFFFE2C55),
        ],
        'onTap': () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const DouyinFeedPage(),
          ),
        ),
      },
      {
        'title': 'ZERO BUILDER',
        'subtitle': 'Build Flutter → APK',
        'icon': Icons.build_circle_rounded,
        'gradientColors': [
          const Color(0xFF0D1B2A),
          const Color(0xFF1B3A4B),
          const Color(0xFF00B4D8),
        ],
        'onTap': () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BuildApkPage(
              sessionKey: sessionKey,
              username: username,
            ),
          ),
        ),
      },
    ];

    // ─── LAYOUT BEBAS TANPA KOTAK — SISTEM OTAX ──────────────────
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ─── HEADER ────────────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [Color(0xFF6A1B9A), Color(0xFF8E24AA)],
                  ),
                ),
                child: const Icon(Icons.hub_rounded, color: Colors.white, size: 18),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text(
                      "𝙁𝙄𝙏𝙐𝙍 𝙕𝙀𝙍𝙊 𝘾𝙍𝘼𝙎𝙃",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 0.8,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "Terhubung dengan ekosistem Zero Crash",
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.70),
                        fontSize: 10.5,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ),
              // Swipe hint chip
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.07),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.12),
                    width: 0.8,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.swipe_rounded,
                        color: Colors.white.withOpacity(0.85), size: 11),
                    const SizedBox(width: 4),
                    Text(
                      'swipe',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.85),
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.6,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 16),

        // ─── CAROUSEL — SETTING SAMA PERSIS DENGAN OTAX ─────────────
        CarouselSlider.builder(
          options: CarouselOptions(
            height: 190,
            aspectRatio: 16 / 9,
            viewportFraction: 0.78,
            initialPage: 0,
            enableInfiniteScroll: true,
            reverse: false,
            autoPlay: true,
            autoPlayInterval: const Duration(seconds: 5),
            autoPlayAnimationDuration: const Duration(milliseconds: 800),
            autoPlayCurve: Curves.fastOutSlowIn,
            enlargeCenterPage: true,
            enlargeFactor: 0.22,
            scrollDirection: Axis.horizontal,
            onPageChanged: (index, reason) {
              setState(() => _hubCarouselIndex = index);
            },
          ),
          itemCount: hubCards.length,
          itemBuilder: (context, index, realIndex) {
            return _buildHubSwipeCard(hubCards[index], index);
          },
        ),

        const SizedBox(height: 14),

        // ─── DOT INDICATORS ────────────────────────────────────────
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(hubCards.length, (i) {
            final bool active = i == _hubCarouselIndex;
            final Color dotColor =
                (hubCards[i]['gradientColors'] as List<Color>)[2];
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: active ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                color: active
                    ? dotColor
                    : Colors.white.withOpacity(0.25),
                borderRadius: BorderRadius.circular(4),
                boxShadow: active
                    ? [
                        BoxShadow(
                          color: dotColor.withOpacity(0.6),
                          blurRadius: 8,
                          spreadRadius: 1,
                        )
                      ]
                    : [],
              ),
            );
          }),
        ),
      ],
    );
  }

  /// Build satu kartu swipe — 100% sistem dari Carousel Premium
  Widget _buildHubSwipeCard(Map<String, dynamic> card, int index) {
    final gradientColors = card['gradientColors'] as List<Color>;

    return Animate(
      effects: [
        ScaleEffect(
          duration: 400.ms,
          curve: Curves.easeOutBack,
          delay: (100 * index).ms,
        ),
        FadeEffect(duration: 400.ms),
      ],
      child: _buildHubSwipeCardContent(card, gradientColors),
    );
  }

  /// Content builder untuk swipe card — SAMA PERSIS seperti sistem
  /// _ModernActionCard di dashboard Otax: icon, chip "Tap →", title, dan
  /// subtitle saja. Tidak ada badge, deskripsi, atau feature chip tambahan.
  Widget _buildHubSwipeCardContent(
    Map<String, dynamic> card,
    List<Color> gradientColors,
  ) {
    final gradient = LinearGradient(
      colors: gradientColors,
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    );

    return GestureDetector(
      onTap: card['onTap'] as VoidCallback,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: gradientColors.first.withOpacity(0.4),
              blurRadius: 20,
              spreadRadius: 2,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              top: -20,
              right: -20,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          card['icon'] as IconData,
                          color: Colors.white,
                          size: 28,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.white.withOpacity(0.3),
                          ),
                        ),
                        child: const Text(
                          "Tap →",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        card['title'] as String,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        card['subtitle'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.white.withOpacity(0.1),
                      Colors.transparent,
                      Colors.black.withOpacity(0.05),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAccessButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Container(
      height: 50,
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentPurple.withOpacity(0.4)),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: accentPurple, size: 20),
              SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner":
        return accentPurple;
      case "vip":
        return primaryPurple;
      case "reseller":
        return Colors.lightGreenAccent;
      case "premium":
        return Colors.orangeAccent;
      default:
        return lightPurple;
    }
  }

  Widget _buildCompactInfoItem({
    required IconData icon,
    required String label,
    required String value,
    Color valueColor = Colors.white,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderGlass),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: accentPurple, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: accentGrey,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: valueColor,
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCustomDrawer() {
    // ─── REDESIGNED DRAWER (static — no pulsing) ─────────────────
    // The whole panel now sizes itself to its content (mainAxisSize.min)
    // instead of being force-stretched to the full screen height. This
    // makes the drawer noticeably shorter/more compact, and — combined
    // with the SingleChildScrollView fallback below — guarantees every
    // menu item is always fully visible and tappable, never clipped.
    //
    // Animations layered on top of the existing structure:
    //  1. Static multi-stop gradient background (no hue shift, no pulse).
    //  2. (removed floating particle field — was a continuous pulse)
    //  3. Static banner image (no Ken-Burns zoom breathing).
    //  4. Static conic-gradient ring around the avatar.
    //  5. Staggered slide-in + fade for each menu item — each item
    //     waits its turn then slides in from the left with a soft
    //     bounce, instead of all appearing at once. (one-shot only)
    //  6. Each item has an animated sheen that sweeps across on tap.
    //     (one-shot only)
    //  7. Bottom: a static soft glow orb as a "footer" anchor.
    final List<Widget> menuItems = [
      _buildDrawerMenuItem(
        icon: FontAwesomeIcons.ghost,
        label: "Ghost Page",
        index: 0,
        onTap: () {
          Navigator.pop(context);
          // ✅ Cek role: hanya GHOST yang boleh akses
          if (role?.toLowerCase() != 'ghost') {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text("❌ Hanya role GHOST yang dapat mengakses Ghost Page!"),
                backgroundColor: Colors.red,
                duration: Duration(seconds: 2),
              ),
            );
            return;
          }
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => GhostPage(
                sessionKey: sessionKey,
                username: username,
              ),
            ),
          );
        },
      ),
      _buildDrawerMenuItem(
        icon: Icons.chat_bubble_outline,
        label: "Public Chat",
        index: 1,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => PublicChatPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        },
      ),
      _buildDrawerMenuItem(
        icon: Icons.history_rounded,
        label: "Riwayat Aktivitas",
        index: 2,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => RiwayatPage(
                sessionKey: sessionKey,
                role: role,
              ),
            ),
          );
        },
      ),
      // ─── COLOR THEME PICKER ───────────────────────────────
      SizedBox(height: 6),
      ColorThemePicker(username: username, sessionKey: sessionKey),
      SizedBox(height: 10),
      Padding(
        padding: EdgeInsets.symmetric(horizontal: 20),
        child: Divider(
          color: borderGlass,
          height: 1,
          thickness: 0.6,
        ),
      ),
      SizedBox(height: 6),
      _buildDrawerMenuItem(
        icon: Icons.logout,
        label: "Log Out",
        index: 3,
        isLogout: true,
        onTap: () async {
          Navigator.pop(context);
          final prefs = await SharedPreferences.getInstance();
          await prefs.clear();
          if (!mounted) return;
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => LoginPage()),
                (route) => false,
          );
        },
      ),
    ];

    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.82,
      elevation: 0,
      child: SafeArea(
        bottom: false,
        child: SizedBox(
          height: double.infinity,
          child: Container(
            decoration: BoxDecoration(
              color: bgDark,
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(26),
                bottomRight: Radius.circular(26),
              ),
              border: Border.all(color: borderGlass),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.45),
                  blurRadius: 24,
                  offset: Offset(0, 10),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(26),
                bottomRight: Radius.circular(26),
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // ─── Layer 1: Static gradient background (no pulse) ───
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: AppThemeController.instance.theme.drawerGradient,
                        stops: const [0.0, 0.55, 1.0],
                      ),
                    ),
                  ),

                  // ─── Layer 2: (removed — was floating particle field) ─

                  // ─── Layer 3: Main column (header + menu) ─────────
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      // Compact header with banner + glow ring around avatar
                      SizedBox(
                        height: 180,
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            // Banner — static (no Ken-Burns breathing)
                            Positioned.fill(
                              child: Container(
                                color: Colors.black,
                                child: Image.asset(
                                  'assets/images/banner.png',
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          primaryPurple,
                                          bgDark
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            // Multi-stop darkening gradient for legibility
                            Positioned.fill(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors.black.withOpacity(0.25),
                                      bgDark.withOpacity(0.6),
                                      bgDark.withOpacity(0.95),
                                    ],
                                    stops: const [0.0, 0.55, 1.0],
                                  ),
                                ),
                              ),
                            ),
                            // Top sheen — static hairline accent (no sweep)
                            Positioned(
                              top: 0,
                              left: 0,
                              right: 0,
                              height: 2,
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.topRight,
                                    colors: [
                                      Colors.transparent,
                                      accentPurple.withOpacity(0.55),
                                      glowMagenta.withOpacity(0.55),
                                      Colors.transparent,
                                    ],
                                    stops: const [0.0, 0.45, 0.55, 1.0],
                                  ),
                                ),
                              ),
                            ),
                            Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  // Avatar with static conic ring (no rotation)
                                  Container(
                                    width: 84,
                                    height: 84,
                                    padding: EdgeInsets.all(3),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      gradient: SweepGradient(
                                        colors: AppThemeController.instance.theme.sweepGradientColors,
                                        stops: const [0.0, 0.30, 0.50, 0.70, 0.95],
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: primaryPurple
                                              .withOpacity(0.55),
                                          blurRadius: 18,
                                          spreadRadius: 2,
                                        ),
                                        BoxShadow(
                                          color: glowMagenta
                                              .withOpacity(0.30),
                                          blurRadius: 24,
                                          spreadRadius: 1,
                                        ),
                                      ],
                                    ),
                                    child: ClipOval(
                                      child: _profileImage != null
                                          ? Image.file(
                                              _profileImage!,
                                              fit: BoxFit.cover,
                                            )
                                          : Container(
                                              color: bgDark,
                                              child: Icon(
                                                FontAwesomeIcons
                                                    .userAstronaut,
                                                size: 36,
                                                color: Colors.white
                                                    .withOpacity(0.85),
                                              ),
                                            ),
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  // Username with subtle reveal animation (one-shot)
                                  TweenAnimationBuilder<double>(
                                    tween: Tween<double>(begin: 0.0, end: 1.0),
                                    duration: const Duration(milliseconds: 600),
                                    curve: Curves.easeOutCubic,
                                    builder: (context, value, child) {
                                      return Opacity(
                                        opacity: value.clamp(0.0, 1.0),
                                        child: Transform.translate(
                                          offset:
                                              Offset(0, 8 * (1 - value)),
                                          child: child,
                                        ),
                                      );
                                    },
                                    child: Text(
                                      username,
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Orbitron',
                                        shadows: [
                                          Shadow(
                                            color: Colors.black54,
                                            blurRadius: 6,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 6),
                                  // Role badge — static (no breathing glow)
                                  Container(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 12, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: accentPurple.withOpacity(0.22),
                                      borderRadius:
                                          BorderRadius.circular(12),
                                      border: Border.all(
                                        color: accentPurple.withOpacity(0.6),
                                        width: 1,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: accentPurple
                                              .withOpacity(0.18),
                                          blurRadius: 8,
                                          spreadRadius: 0,
                                        ),
                                      ],
                                    ),
                                    child: Text(
                                      role.toUpperCase(),
                                      style: TextStyle(
                                        color: accentPurple,
                                        fontSize: 11,
                                        letterSpacing: 2,
                                        fontWeight: FontWeight.w700,
                                        fontFamily: 'ShareTechMono',
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.transparent,
                                Color(0xFF0A0418).withOpacity(0.65),
                              ],
                            ),
                          ),
                          child: SingleChildScrollView(
                            child: Padding(
                              padding: EdgeInsets.symmetric(vertical: 12),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: menuItems,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  // ─── Layer 4: Bottom soft glow orb (static, no pulse) ─
                  Positioned(
                    bottom: -30,
                    right: -30,
                    child: Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(
                          colors: [
                            glowMagenta.withOpacity(0.22),
                            glowIndigo.withOpacity(0.10),
                            Colors.transparent,
                          ],
                          stops: const [0.0, 0.5, 1.0],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawerMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required int index,
    bool isLogout = false,
  }) {
    // Staggered slide-in: each item starts ~80ms after the previous one,
    // giving the menu a "card-deal" reveal feel as the drawer opens.
    return _StaggeredDrawerItem(
      index: index,
      child: _DrawerMenuItemBody(
        icon: icon,
        label: label,
        onTap: onTap,
        isLogout: isLogout,
        primaryPurple: primaryPurple,
        accentPurple: accentPurple,
        lightPurple: lightPurple,
        glowMagenta: glowMagenta,
        borderGlass: borderGlass,
        bgDark: bgDark,
      ),
    );
  }

  void _onThemeChanged() => mounted ? setState(() {}) : null;
  @override
  Widget build(BuildContext context) {
    final double bottomPadding = MediaQuery.of(context).padding.bottom;
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: bgDark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: _buildAppBarTitle(),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          _buildProfileAppBarButton(),
          const SizedBox(width: 8),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Listener(
        behavior: HitTestBehavior.translucent,
        onPointerDown: _onPagePointerDown,
        onPointerUp: _onPagePointerUp,
        child: Container(
          color: bgDark,
          child: Stack(
            children: [
              Positioned.fill(
                child: CustomPaint(
                  painter: _GridPainter(lineColor: borderGlass),
                ),
              ),
              SafeArea(
                bottom: false,
                child: Padding(
                  padding: EdgeInsets.only(
                    bottom: 48 + bottomPadding,
                  ),
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: FadeTransition(
                      opacity: _animation,
                      // ✅ FIX: _bottomNavIndex==0 (Home/News) dibuild ulang
                      // langsung di sini agar Profile Card ikut rebuild 
                      // saat tema berubah. Halaman lain tetap pakai _selectedPage.
                      child: _bottomNavIndex == 0
                          ? _buildNewsPage()
                          : _selectedPage,
                    ),
                  ),
                ),
              ),
              // Persistent swipe-up pill handle at the bottom edge
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: _SwipeUpHandle(
                  onTap: _showNav,
                  accentPurple: accentPurple,
                  lightPurple: lightPurple,
                  bottomPadding: bottomPadding,
                ),
              ),
              // Floating bottom nav — revealed on swipe up, slides in from below
              if (_isNavVisible)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: AnimatedBuilder(
                    animation: _navRevealAnimation,
                    builder: (context, child) {
                      final double t = _navRevealAnimation.value;
                      return Opacity(
                        opacity: t.clamp(0.0, 1.0),
                        child: Transform.translate(
                          offset: Offset(0, (1 - t) * 140),
                          child: child,
                        ),
                      );
                    },
                    child: _FloatingBottomNav(
                      currentIndex: _bottomNavIndex,
                      onTap: _onBottomNavTapped,
                      onHide: _hideNav,
                      bgDark: bgDark,
                      primaryPurple: primaryPurple,
                      accentPurple: accentPurple,
                      lightPurple: lightPurple,
                      glowMagenta: glowMagenta,
                      glowIndigo: glowIndigo,
                      cardGlass: cardGlass,
                      borderGlass: borderGlass,
                      accentGrey: accentGrey,
                      bottomPadding: bottomPadding,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _navAutoHideTimer?.cancel();
    _navRevealController.dispose();
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _glowController.dispose();
    _shimmerController.dispose();
    _bounceController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }
}

// ============================================================
// MOVING BORDER PAINTER — draws a single glowing segment that travels
// continuously along a rounded-rect outline (a "chasing light" border),
// with no full-ring rotating wash / scan behaviour.
// ============================================================
class _MovingBorderPainter extends CustomPainter {
  final double progress; // 0..1, position of the light along the perimeter
  final double radius;
  final double strokeWidth;
  final Color color;
  final Color glowColor;

  _MovingBorderPainter({
    required this.progress,
    required this.radius,
    required this.strokeWidth,
    required this.color,
    required this.glowColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final double inset = strokeWidth / 2;
    final RRect rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        inset,
        inset,
        size.width - strokeWidth,
        size.height - strokeWidth,
      ),
      Radius.circular((radius - inset).clamp(0, radius)),
    );

    final Path path = Path()..addRRect(rrect);
    final List<PathMetric> metrics = path.computeMetrics().toList();
    if (metrics.isEmpty) return;
    final PathMetric metric = metrics.first;
    final double total = metric.length;
    if (total <= 0) return;

    final double segmentLength = total * 0.22;
    final double start = (progress * total) % total;
    final double end = start + segmentLength;

    Path segment;
    if (end <= total) {
      segment = metric.extractPath(start, end);
    } else {
      segment = Path()
        ..addPath(metric.extractPath(start, total), Offset.zero)
        ..addPath(metric.extractPath(0, end - total), Offset.zero);
    }

    final Paint glowPaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth + 4
      ..strokeCap = StrokeCap.round
      ..color = glowColor.withOpacity(0.45)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6);
    canvas.drawPath(segment, glowPaint);

    final Paint linePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round
      ..color = color;
    canvas.drawPath(segment, linePaint);
  }

  @override
  bool shouldRepaint(covariant _MovingBorderPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.color != color ||
      oldDelegate.glowColor != glowColor;
}

class _GridPainter extends CustomPainter {
  final Color lineColor;
  final double cellSize;

  _GridPainter({required this.lineColor, this.cellSize = 28});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = lineColor
      ..strokeWidth = 1;

    for (double x = 0; x <= size.width; x += cellSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y <= size.height; y += cellSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _GridPainter oldDelegate) =>
      oldDelegate.lineColor != lineColor || oldDelegate.cellSize != cellSize;
}

class NewsMedia extends StatefulWidget {
  final String url;
  final String? type;
  const NewsMedia({super.key, required this.url, this.type});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (!mounted) return;
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    if (widget.type != null) {
      return widget.type!.toLowerCase() == "video";
    }
    final cleanUrl = url.split('?').first.split('#').first.toLowerCase();
    const videoExt = [".mp4", ".webm", ".mov", ".mkv", ".m4v", ".3gp"];
    return videoExt.any((ext) => cleanUrl.endsWith(ext));
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _controller?.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return const Center(
          child: CircularProgressIndicator(
            color: Color(0xFFFF5252),
          ),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(
          color: Colors.grey.shade800,
          child: const Icon(Icons.error, color: Color(0xFFFF5252)),
        ),
      );
    }
  }
}

// ============================================================
// DRAWER HELPERS — staggered slide-in, animated item body, and
// floating particle field used by the redesigned custom drawer.
// ============================================================

/// Wraps a drawer menu item so it slides in from the left + fades
/// in with a per-index delay. The staggered reveal gives the
/// drawer a card-deal / hand-of-cards feel as it opens.
class _StaggeredDrawerItem extends StatefulWidget {
  final int index;
  final Widget child;
  const _StaggeredDrawerItem({required this.index, required this.child});

  @override
  State<_StaggeredDrawerItem> createState() => _StaggeredDrawerItemState();
}

class _StaggeredDrawerItemState extends State<_StaggeredDrawerItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 520),
    );
    // Each item waits ~90ms × index before starting, with a hard
    // cap so the last items don't feel sluggish.
    final delay = (widget.index * 90).clamp(0, 360);
    Future.delayed(Duration(milliseconds: 180 + delay), () {
      if (mounted) _controller.forward();
    });

    _fade = CurvedAnimation(
      parent: _controller,
      curve: Interval(0.0, 0.7, curve: Curves.easeOut),
    );
    // Slide in from the left with a slight overshoot bounce.
    _slide = Tween<Offset>(
      begin: Offset(-0.45, 0),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutBack,
    ));
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _controller.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: widget.child,
      ),
    );
  }
}

/// Animated drawer menu item body — gradient pill with hover glow,
/// icon disc with breathing sheen, label, and an arrow that nudges
/// to the right while pressed. On tap, a horizontal sheen sweeps
/// across the pill once.
class _DrawerMenuItemBody extends StatefulWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isLogout;
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color borderGlass;
  final Color bgDark;

  const _DrawerMenuItemBody({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.isLogout,
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.borderGlass,
    required this.bgDark,
  });

  @override
  State<_DrawerMenuItemBody> createState() => _DrawerMenuItemBodyState();
}

class _DrawerMenuItemBodyState extends State<_DrawerMenuItemBody>
    with TickerProviderStateMixin {
  late final AnimationController _sheen;
  late final AnimationController _press;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _sheen = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 650),
    );
    _press = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 120),
    );
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _sheen.dispose();
    _press.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _handleTap() {
    HapticFeedback.lightImpact();
    // Sweep the sheen across once, then fire the callback at the
    // sheen's peak so the visual feedback aligns with navigation.
    _sheen
      ..reset()
      ..forward();
    Future.delayed(Duration(milliseconds: 180), widget.onTap);
  }

  @override
  Widget build(BuildContext context) {
    final baseColor = widget.isLogout
        ? Colors.red.shade900
        : AppThemeController.instance.primaryPurple;
    final accentColor = widget.isLogout
        ? Colors.red
        : AppThemeController.instance.accentPurple;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      child: MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: GestureDetector(
          onTapDown: (_) => _press.forward(),
          onTapCancel: () => _press.reverse(),
          onTapUp: (_) {
            _press.reverse();
            _handleTap();
          },
          child: AnimatedBuilder(
            animation: Listenable.merge([_sheen, _press]),
            builder: (context, _) {
              final pressScale = 1.0 - 0.025 * _press.value;
              return Transform.scale(
                scale: pressScale,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color.lerp(
                            baseColor,
                            baseColor.withRed((baseColor.red + 30).clamp(0, 255)),
                            _isHovered ? 1.0 : 0.0)!,
                        Color.lerp(
                            baseColor,
                            Colors.black.withOpacity(0.25),
                            _isHovered ? 0.4 : 0.0)!,
                      ],
                    ),
                    border: Border.all(
                      color: _isHovered
                          ? accentColor.withOpacity(0.95)
                          : accentColor.withOpacity(0.55),
                      width: _isHovered ? 1.4 : 1.0,
                    ),
                    boxShadow: [
                      if (_isHovered)
                        BoxShadow(
                          color: accentColor.withOpacity(0.35),
                          blurRadius: 18,
                          spreadRadius: 0,
                          offset: const Offset(0, 4),
                        ),
                      BoxShadow(
                        color: Colors.black.withOpacity(0.18),
                        blurRadius: 6,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Stack(
                      children: [
                        // ─── Sheen sweep (one-shot on tap) ────────────
                        if (_sheen.value > 0.0 && _sheen.value < 1.0)
                          Positioned.fill(
                            child: IgnorePointer(
                              child: ShaderMask(
                                shaderCallback: (rect) {
                                  final t = _sheen.value;
                                  return LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.topRight,
                                    colors: [
                                      Colors.transparent,
                                      Colors.white.withOpacity(0.0),
                                      Colors.white.withOpacity(0.45),
                                      Colors.white.withOpacity(0.0),
                                      Colors.transparent,
                                    ],
                                    stops: [
                                      0.0,
                                      (t - 0.20).clamp(0.0, 1.0),
                                      t.clamp(0.0, 1.0),
                                      (t + 0.20).clamp(0.0, 1.0),
                                      1.0,
                                    ],
                                  ).createShader(rect);
                                },
                                blendMode: BlendMode.srcOver,
                                child: Container(color: Colors.white),
                              ),
                            ),
                          ),
                        // ─── Content ──────────────────────────────────
                        ListTile(
                          contentPadding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 2),
                          horizontalTitleGap: 10,
                          minLeadingWidth: 0,
                          leading: Container(
                            width: 38,
                            height: 38,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Colors.white.withOpacity(_isHovered ? 0.28 : 0.16),
                                  Colors.white.withOpacity(_isHovered ? 0.10 : 0.04),
                                ],
                              ),
                              border: Border.all(
                                color: Colors.white.withOpacity(_isHovered ? 0.35 : 0.12),
                                width: 0.8,
                              ),
                              boxShadow: _isHovered
                                  ? [
                                      BoxShadow(
                                        color: accentColor.withOpacity(0.30),
                                        blurRadius: 8,
                                        spreadRadius: 0,
                                      ),
                                    ]
                                  : null,
                            ),
                            child: Icon(
                              widget.icon,
                              color: Colors.white,
                              size: 17,
                            ),
                          ),
                          title: Text(
                            widget.label,
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                              letterSpacing: 0.2,
                              shadows: _isHovered
                                  ? [
                                      Shadow(
                                        color: accentColor.withOpacity(0.55),
                                        blurRadius: 8,
                                      ),
                                    ]
                                  : null,
                            ),
                          ),
                          trailing: Transform.translate(
                            offset: Offset(_isHovered ? 3 : 0, 0),
                            child: Icon(
                              Icons.arrow_forward_ios,
                              color: Colors.white.withOpacity(_isHovered ? 0.9 : 0.6),
                              size: 13,
                            ),
                          ),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16)),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

/// Floating particle field for the drawer background — small soft
/// dots that drift slowly upward, like dust motes in a sunbeam.
/// Repeats seamlessly by wrapping the vertical position modulo 1.
class _DrawerParticlePainter extends CustomPainter {
  final double progress;
  final Color color;
  _DrawerParticlePainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final rng = math.Random(7);
    final count = 22;
    final w = size.width;
    final h = size.height;

    for (int i = 0; i < count; i++) {
      // Stable per-particle parameters
      final baseX = rng.nextDouble() * w;
      final baseY = rng.nextDouble() * h;
      final drift = 0.3 + rng.nextDouble() * 0.7; // upward speed factor
      final radius = 0.6 + rng.nextDouble() * 1.6;
      final opacity = 0.10 + rng.nextDouble() * 0.30;

      // Each particle moves upward continuously and wraps around.
      final y =
          (baseY - progress * h * drift) % h;
      final wrappedY = (y + h) % h;

      // Slight horizontal sway for organic motion.
      final sway = math.sin((progress * 2 * math.pi) + i) * 4;
      final x = (baseX + sway).clamp(0.0, w);

      canvas.drawCircle(
        Offset(x, wrappedY),
        radius,
        Paint()..color = color.withOpacity(opacity),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _DrawerParticlePainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.color != color;
}

// ============================================================
// ANIMATED WEATHER CARD — smooth color-shifting sky, glowing
// rotating sun, and drifting parallax clouds.
// ============================================================
class _AnimatedWeatherCard extends StatefulWidget {
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color borderGlass;
  final String city;
  final String apiKey;

  const _AnimatedWeatherCard({
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.borderGlass,
    this.city = 'Jakarta',
    this.apiKey = '0dfe03d03f7f610cfcf6a1c5695e3609',
  });

  @override
  State<_AnimatedWeatherCard> createState() => _AnimatedWeatherCardState();
}

class _AnimatedWeatherCardState extends State<_AnimatedWeatherCard>
    with TickerProviderStateMixin {
  late final AnimationController _skyController;
  late final AnimationController _sunController;
  late final AnimationController _cloudA;
  late final AnimationController _cloudB;
  late final AnimationController _cloudC;
  late final AnimationController _rainController;
  late final AnimationController _lightningController;
  late final AnimationController _snowController;
  late final AnimationController _starController;
  late final AnimationController _windController;

  // Weather data state
  bool _isLoading = true;
  String _temperature = '';
  String _feelsLike = '';
  String _description = '';
  String _cityName = '';
  String _humidity = '';
  String _windSpeed = '';
  int _weatherCode = 800;
  bool _isNight = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _skyController =
        AnimationController(vsync: this, duration: const Duration(seconds: 8))
          ..repeat(reverse: true);
    _sunController =
        AnimationController(vsync: this, duration: const Duration(seconds: 7))
          ..repeat();
    _cloudA = AnimationController(
        vsync: this, duration: const Duration(seconds: 20))
      ..repeat();
    _cloudB = AnimationController(
        vsync: this, duration: const Duration(seconds: 28))
      ..repeat();
    _cloudC = AnimationController(
        vsync: this, duration: const Duration(seconds: 24))
      ..repeat();
    _rainController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700))
      ..repeat();
    // Lightning flash controller — bursts of bright flashes for storms.
    _lightningController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat();
    // Snowfall controller — slow drifting flakes.
    _snowController = AnimationController(
        vsync: this, duration: const Duration(seconds: 5))
      ..repeat();
    // Star twinkle controller for night skies.
    _starController = AnimationController(
        vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
    // Wind streak controller — sweeps across for atmosphere (mist/wind).
    _windController = AnimationController(
        vsync: this, duration: const Duration(seconds: 4))
      ..repeat();
    _fetchWeather();
  }

  // ============================================================
  // OpenWeatherMap API integration
  // Endpoint: https://api.openweathermap.org/data/2.5/weather
  // Docs: https://openweathermap.org/api
  // ============================================================
  Future<void> _fetchWeather() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    try {
      final client = HttpClient()
        ..connectionTimeout = const Duration(seconds: 10);
      final uri = Uri.parse(
        'https://api.openweathermap.org/data/2.5/weather'
        '?q=${Uri.encodeComponent(widget.city)}'
        '&appid=${widget.apiKey}'
        '&units=metric'
        '&lang=id',
      );
      final request = await client.getUrl(uri);
      final response = await request.close();
      final body = await response.transform(utf8.decoder).join();
      final data = jsonDecode(body) as Map<String, dynamic>;

      if (data['cod'] == 200) {
        final weather =
            (data['weather'] as List).first as Map<String, dynamic>;
        final main = data['main'] as Map<String, dynamic>;
        final wind = data['wind'] as Map<String, dynamic>;
        final sys = data['sys'] as Map<String, dynamic>;
        final dt = (data['dt'] as num).toInt();
        final sunrise = (sys['sunrise'] as num).toInt();
        final sunset = (sys['sunset'] as num).toInt();

        String desc = (weather['description'] as String?) ?? '';
        if (desc.isNotEmpty) {
          desc = desc[0].toUpperCase() + desc.substring(1);
        }

        setState(() {
          _temperature = '${(main['temp'] as num).round()}°C';
          _feelsLike = '${(main['feels_like'] as num).round()}°C';
          _description = desc;
          _cityName = (data['name'] as String?) ?? widget.city;
          _humidity = '${main['humidity']}%';
          _windSpeed = '${(wind['speed'] as num).round()} m/s';
          _weatherCode = (weather['id'] as num).toInt();
          _isNight = dt < sunrise || dt > sunset;
          _isLoading = false;
          _errorMessage = '';
        });
      } else {
        setState(() {
          _errorMessage =
              (data['message'] as String?) ?? 'Gagal memuat cuaca';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Gagal terhubung ke server cuaca';
        _isLoading = false;
      });
    }
  }

  // OpenWeather condition code categories:
  // 2xx Thunderstorm | 3xx Drizzle | 5xx Rain | 6xx Snow
  // 7xx Atmosphere (mist/fog/smoke) | 800 Clear | 80x Clouds
  String _weatherCategory() {
    if (_weatherCode >= 200 && _weatherCode < 300) return 'thunderstorm';
    if (_weatherCode >= 300 && _weatherCode < 400) return 'drizzle';
    if (_weatherCode >= 500 && _weatherCode < 600) return 'rain';
    if (_weatherCode >= 600 && _weatherCode < 700) return 'snow';
    if (_weatherCode >= 700 && _weatherCode < 800) return 'atmosphere';
    if (_weatherCode == 800) return 'clear';
    if (_weatherCode > 800) return 'clouds';
    return 'clear';
  }

  // Adaptive sky gradient based on weather condition and time of day.
  // Each palette now carries a real "zenith -> horizon" progression
  // (deep tone at the top, warmer/lighter glow near the ground) so the
  // card reads like an actual sky rather than a flat color wash, while
  // keeping the app's purple/neon identity in the shadows and glows.
  //
  // ─── DAYTIME REALISM UPDATE ────────────────────────────────────
  // For daytime "clear" and "clouds" cases we now return 5 colors
  // instead of 3, allowing a proper atmospheric-scattering gradient:
  // deep zenith → cobalt → sky-blue → hazy lavender → warm horizon
  // peach. `_sky()` detects the longer list and renders 5 stops.
  // Other cases still return 3 colors and behave exactly as before.
  List<Color> _skyColors() {
    final cat = _weatherCategory();
    if (_isNight) {
      switch (cat) {
        case 'clouds':
          return [
            const Color(0xFF06061A),
            const Color(0xFF15123A),
            const Color(0xFF352A5E),
          ];
        case 'rain':
        case 'drizzle':
        case 'thunderstorm':
          return [
            const Color(0xFF05050F),
            const Color(0xFF14141F),
            const Color(0xFF23202E),
          ];
        default:
          // Clear night: near-black zenith fading into a faint
          // indigo horizon glow, like real night-sky light pollution.
          return [
            const Color(0xFF03030D),
            const Color(0xFF120B32),
            const Color(0xFF2D1854),
          ];
      }
    }
    switch (cat) {
      case 'thunderstorm':
        return [
          const Color(0xFF16151F),
          const Color(0xFF2B2A3B),
          const Color(0xFF4A4658),
        ];
      case 'rain':
      case 'drizzle':
        return [
          const Color(0xFF3E4657),
          const Color(0xFF66707F),
          const Color(0xFF97A2AD),
        ];
      case 'snow':
        return [
          const Color(0xFFA9C3DB),
          const Color(0xFFCDE0EC),
          const Color(0xFFF1F6FA),
        ];
      case 'atmosphere':
        return [
          const Color(0xFF7C8288),
          const Color(0xFF9CA1A6),
          const Color(0xFFC2C6C9),
        ];
      case 'clouds':
        // Daytime cloudy — 5-stop realistic overcast progression:
        // slate-blue zenith → muted denim → soft periwinkle →
        // warm grey-lavender → pale luminous horizon.
        return [
          const Color(0xFF2B3654),
          const Color(0xFF4F6086),
          const Color(0xFF7E8AA8),
          const Color(0xFFB6B7CC),
          const Color(0xFFE5DCC6),
        ];
      case 'clear':
      default:
        // Daytime clear — 5-stop realistic atmospheric scattering:
        // deep cobalt zenith → royal blue → sky blue → hazy warm
        // lavender → golden-peach horizon (Rayleigh scattering).
        return [
          const Color(0xFF0A2A6B), // deep cobalt zenith
          const Color(0xFF2563B5), // royal blue upper-mid
          const Color(0xFF6BA4DD), // sky blue mid
          const Color(0xFFC9B7DA), // hazy lavender lower-mid
          const Color(0xFFFFD9A0), // warm peach horizon
        ];
    }
  }

  bool _showSun() {
    final cat = _weatherCategory();
    return (cat == 'clear' || cat == 'clouds') && !_isNight;
  }

  bool _showMoon() {
    return _isNight && (_weatherCategory() == 'clear' ||
        _weatherCategory() == 'clouds');
  }

  int _cloudCount() {
    switch (_weatherCategory()) {
      case 'clear':
        return 1;
      case 'clouds':
      case 'rain':
      case 'thunderstorm':
      case 'snow':
        return 3;
      case 'drizzle':
      case 'atmosphere':
        return 2;
      default:
        return 1;
    }
  }

  bool _showRain() {
    final cat = _weatherCategory();
    return cat == 'rain' || cat == 'drizzle' || cat == 'thunderstorm';
  }

  bool _showSnow() {
    final cat = _weatherCategory();
    return cat == 'snow';
  }

  bool _showLightning() {
    final cat = _weatherCategory();
    return cat == 'thunderstorm';
  }

  bool _showStars() {
    return _isNight;
  }

  bool _showWindStreaks() {
    final cat = _weatherCategory();
    return cat == 'atmosphere' || cat == 'drizzle';
  }

  /// Picks an icon glyph that best matches the current condition.
  IconData _weatherIcon() {
    if (_isLoading) return Icons.cloud_outlined;
    switch (_weatherCategory()) {
      case 'thunderstorm':
        return Icons.thunderstorm_rounded;
      case 'drizzle':
        return Icons.grain_rounded;
      case 'rain':
        return Icons.water_drop_rounded;
      case 'snow':
        return Icons.ac_unit_rounded;
      case 'atmosphere':
        return Icons.blur_on_rounded;
      case 'clouds':
        return Icons.cloud_rounded;
      case 'clear':
      default:
        return _isNight ? Icons.nightlight_rounded : Icons.wb_sunny_rounded;
    }
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _skyController.dispose();
    _sunController.dispose();
    _cloudA.dispose();
    _cloudB.dispose();
    _cloudC.dispose();
    _rainController.dispose();
    _lightningController.dispose();
    _snowController.dispose();
    _starController.dispose();
    _windController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  Widget _sky() {
    final colors = _skyColors();
    return AnimatedBuilder(
      animation: _skyController,
      builder: (context, _) {
        final t = _skyController.value;
        // For the 5-color realistic daytime gradient we use a
        // proper top-to-bottom atmospheric progression with subtle
        // horizontal drift so the sky breathes like a real one.
        // For 3-color legacy palettes we keep the original
        // diagonal 3-stop lerp behaviour.
        if (colors.length >= 5) {
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color.lerp(colors[0], colors[1], t * 0.5)!,
                  Color.lerp(colors[1], colors[2], t * 0.4)!,
                  colors[2],
                  Color.lerp(colors[2], colors[3], 0.4 + t * 0.3)!,
                  Color.lerp(colors[3], colors[4], 0.6 + t * 0.4)!,
                ],
                stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
              ),
            ),
          );
        }
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color.lerp(colors[0], colors[1], t)!,
                Color.lerp(colors[1], colors[2], t)!,
                Color.lerp(colors[2], colors[0], t)!,
              ],
              stops: const [0.0, 0.55, 1.0],
            ),
          ),
        );
      },
    );
  }

  Widget _sunGlow() {
    if (!_showSun()) return const SizedBox.shrink();
    // ─── SIMPLIFIED SOFT SUN HALO ────────────────────────────────
    // One single soft warm halo (warm-white core → soft amber →
    // transparent). The classic realist look: not a stack of
    // overlapping rings, just one painterly bloom that breathes
    // slowly. Sits behind the disc; the disc itself handles the
    // hard edge.
    return AnimatedBuilder(
      animation: _sunController,
      builder: (context, _) {
        final t = _sunController.value;
        final pulse =
            0.5 + 0.5 * math.sin(t * 2 * math.pi);
        return Positioned(
          top: -70,
          right: -70,
          child: Container(
            width: 260,
            height: 260,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [
                  Colors.white.withOpacity(0.35 + 0.15 * pulse),
                  const Color(0xFFFFE8B0).withOpacity(0.30 + 0.10 * pulse),
                  Colors.orange.withOpacity(0.12 + 0.06 * pulse),
                  Colors.transparent,
                ],
                stops: const [0.0, 0.30, 0.60, 1.0],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Warm atmospheric horizon band — brightens the lower ~30% of
  /// the card with a soft warm glow, mimicking the way real skies
  /// scatter more light low down near the horizon. Kept subtle so
  /// the sky reads as classic-realistic, not over-processed.
  Widget _atmosphericHorizon() {
    // Only show during daytime — night skies already have their
    // own glow handling.
    if (_isNight) return const SizedBox.shrink();
    return Positioned.fill(
      child: IgnorePointer(
        child: DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [
                const Color(0xFFFFD9A0).withOpacity(0.16),
                const Color(0xFFFFE8C8).withOpacity(0.06),
                Colors.transparent,
              ],
              stops: const [0.0, 0.30, 0.65],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sun() {
    if (_showSun()) {
      // ─── CLASSIC REALISTIC SUN ─────────────────────────────────
      // Clean layered render: a single rotating ray set (long & short
      // alternating) + a smooth radial disc that goes white-hot core
      // → cream → yellow → soft orange → transparent. A subtle
      // "breathing" pulse decoupled from the rotation makes the
      // disc feel alive without being busy.
      return AnimatedBuilder(
        animation: _sunController,
        builder: (context, _) {
          final t = _sunController.value;
          final glow = 0.55 +
              0.20 * (0.5 + 0.5 * math.sin(t * 2 * math.pi));
          final corePulse = 0.88 +
              0.12 * (0.5 + 0.5 * math.sin(t * 2 * math.pi + 0.8));
          return Positioned(
            top: 22,
            right: 26,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Rotating rays — long & short alternating
                Transform.rotate(
                  angle: t * 2 * math.pi,
                  child: SizedBox(
                    width: 100,
                    height: 100,
                    child: CustomPaint(
                      painter: _SunRaysPainter(
                        color:
                            Colors.yellowAccent.withOpacity(0.50 * glow),
                        rayCount: 10,
                        longExtra: 18,
                        shortExtra: 10,
                        strokeWidth: 1.6,
                      ),
                    ),
                  ),
                ),
                // The solar disc — soft 5-stop radial gradient
                Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        Colors.white.withOpacity(corePulse),
                        const Color(0xFFFFF4C8),
                        Colors.yellowAccent,
                        const Color(0xFFFFB94A),
                        const Color(0x00FFA726),
                      ],
                      stops: const [0.0, 0.22, 0.50, 0.78, 1.0],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.orangeAccent.withOpacity(glow * 0.85),
                        blurRadius: 22,
                        spreadRadius: 4,
                      ),
                      BoxShadow(
                        color: Colors.yellow.withOpacity(glow * 0.6),
                        blurRadius: 14,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
                // Tiny hot-core highlight (offset for "lit from above")
                Transform.translate(
                  offset: const Offset(-3, -3),
                  child: Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          Colors.white.withOpacity(0.85 * corePulse),
                          Colors.white.withOpacity(0.0),
                        ],
                        stops: const [0.0, 1.0],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      );
    }
    if (_showMoon()) {
      return Positioned(
        top: 22,
        right: 26,
        child: Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const RadialGradient(
              colors: [
                Colors.white,
                Color(0xFFE8E8E8),
                Color(0xFFB8B8C8),
              ],
              stops: [0.0, 0.55, 1.0],
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.white.withOpacity(0.5),
                blurRadius: 22,
                spreadRadius: 5,
              ),
              BoxShadow(
                color: Colors.indigoAccent.withOpacity(0.3),
                blurRadius: 14,
                spreadRadius: 1,
              ),
            ],
          ),
          child: CustomPaint(
            painter: _MoonCraterPainter(),
          ),
        ),
      );
    }
    return const SizedBox.shrink();
  }

  /// Twinkling starfield for night skies.
  Widget _starsLayer() {
    if (!_showStars()) return const SizedBox.shrink();
    return AnimatedBuilder(
      animation: _starController,
      builder: (context, _) {
        return Positioned.fill(
          child: CustomPaint(
            painter: _StarsPainter(
              progress: _starController.value,
            ),
          ),
        );
      },
    );
  }

  /// Lightning bolts + screen-flash for thunderstorms.
  Widget _lightningLayer() {
    if (!_showLightning()) return const SizedBox.shrink();
    return AnimatedBuilder(
      animation: _lightningController,
      builder: (context, _) {
        final t = _lightningController.value;
        // Two short, intense flashes within one cycle.
        double flash = 0.0;
        if (t < 0.05) {
          flash = (t / 0.05).clamp(0.0, 1.0);
        } else if (t < 0.10) {
          flash = 1.0 - ((t - 0.05) / 0.05);
        } else if (t > 0.55 && t < 0.60) {
          flash = ((t - 0.55) / 0.05).clamp(0.0, 1.0) * 0.7;
        } else if (t > 0.60 && t < 0.65) {
          flash = (1.0 - ((t - 0.60) / 0.05)) * 0.7;
        }
        return Stack(
          fit: StackFit.expand,
          children: [
            // Whole-card brightening
            if (flash > 0.0)
              Positioned.fill(
                child: Container(
                  color: Colors.white.withOpacity(flash * 0.35),
                ),
              ),
            // Bolt stroke (only at peak)
            if (flash > 0.6)
              Positioned.fill(
                child: CustomPaint(
                  painter: _LightningPainter(seed: (t * 100).toInt()),
                ),
              ),
          ],
        );
      },
    );
  }

  /// Drifting snowflakes for snow conditions.
  Widget _snowLayer() {
    if (!_showSnow()) return const SizedBox.shrink();
    return AnimatedBuilder(
      animation: _snowController,
      builder: (context, _) {
        return Positioned.fill(
          child: CustomPaint(
            painter: _SnowPainter(
              progress: _snowController.value,
            ),
          ),
        );
      },
    );
  }

  /// Wind streaks for mist / atmosphere / drizzle conditions.
  Widget _windLayer() {
    if (!_showWindStreaks()) return const SizedBox.shrink();
    return AnimatedBuilder(
      animation: _windController,
      builder: (context, _) {
        return Positioned.fill(
          child: CustomPaint(
            painter: _WindStreakPainter(
              progress: _windController.value,
            ),
          ),
        );
      },
    );
  }

  Widget _cloudLayer(
    AnimationController controller, {
    required double top,
    required double size,
    required double opacity,
    required bool reverse,
  }) {
    return AnimatedBuilder(
      animation: controller,
      builder: (context, _) {
        final width = MediaQuery.of(context).size.width - 32;
        final t = reverse ? (1 - controller.value) : controller.value;
        final dx = -size * 1.8 + (width + size * 3.6) * t;
        return Positioned(
          top: top,
          left: dx,
          child: Opacity(
            opacity: opacity,
            child: _CloudShape(size: size),
          ),
        );
      },
    );
  }

  Widget _rainLayer() {
    if (!_showRain()) return SizedBox.shrink();
    return AnimatedBuilder(
      animation: _rainController,
      builder: (context, _) {
        return Positioned.fill(
          child: CustomPaint(
            painter: _RainPainter(
              progress: _rainController.value,
              color: Colors.white.withOpacity(0.55),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _isLoading ? null : _fetchWeather,
      child: Container(
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: AppThemeController.instance.borderGlass, width: 1),
          boxShadow: [
            BoxShadow(
              color: AppThemeController.instance.primaryPurple.withOpacity(0.22),
              blurRadius: 28,
              spreadRadius: 1,
              offset: Offset(0, 12),
            ),
            BoxShadow(
              color: AppThemeController.instance.glowMagenta.withOpacity(0.10),
              blurRadius: 36,
              spreadRadius: 2,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // Photographic backdrop (assets/images/weather.jpg)
              // gives the sky real depth; the animated sun/clouds/
              // rain layers still render on top of it.
              Image.asset(
                'assets/images/weather.jpg',
                fit: BoxFit.cover,
                gaplessPlayback: true,
                errorBuilder: (_, __, ___) => const SizedBox.shrink(),
              ),
              // Soft photographic wash so the picture blends with
              // the animated sky gradient instead of competing.
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.10),
                      Colors.black.withOpacity(0.25),
                      Colors.black.withOpacity(0.55),
                    ],
                    stops: const [0.0, 0.55, 1.0],
                  ),
                ),
              ),
              _sky(),
              // Warm atmospheric horizon band — daytime realism
              // boost: brightens the lower portion of the sky like
              // real atmospheric scattering near the horizon.
              _atmosphericHorizon(),
              // Subtle atmospheric haze near the horizon — real skies
              // scatter more light low down, giving a soft brightening
              // band instead of a hard gradient stop.
              Positioned.fill(
                child: IgnorePointer(
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          Colors.white.withOpacity(_isNight ? 0.02 : 0.07),
                        ],
                        stops: const [0.55, 1.0],
                      ),
                    ),
                  ),
                ),
              ),
              // Stars first (behind everything) for night skies
              _starsLayer(),
              if (_showSun()) _sunGlow(),
              // Sun / Moon
              _sun(),
              // Clouds layered with parallax depth
              if (_cloudCount() >= 1)
                _cloudLayer(_cloudA, top: 40, size: 70, opacity: 0.92, reverse: false),
              if (_cloudCount() >= 2)
                _cloudLayer(_cloudB, top: 92, size: 52, opacity: 0.62, reverse: true),
              if (_cloudCount() >= 3)
                _cloudLayer(_cloudC, top: 138, size: 42, opacity: 0.42, reverse: false),
              // Precipitation & atmosphere overlays
              _rainLayer(),
              _snowLayer(),
              _windLayer(),
              // Lightning flash + bolt (on top of clouds/rain)
              _lightningLayer(),
              // Bottom vignette for legibility
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      Colors.black.withOpacity(0.55),
                      Colors.black.withOpacity(0.15),
                      Colors.transparent,
                    ],
                    stops: const [0.0, 0.55, 1.0],
                  ),
                ),
              ),
              // Loading overlay
              if (_isLoading)
                Container(
                  color: Colors.black.withOpacity(0.35),
                  alignment: Alignment.center,
                  child: const SizedBox(
                    width: 28,
                    height: 28,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2.4,
                    ),
                  ),
                ),
              // Top-left location chip + weather icon
              if (!_isLoading && _errorMessage.isEmpty)
                Positioned(
                  top: 12,
                  left: 14,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.32),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.18),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.location_on,
                          color: Colors.white.withOpacity(0.85),
                          size: 11,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          _cityName,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.92),
                            fontSize: 10.5,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              // Top-right weather-icon badge
              if (!_isLoading && _errorMessage.isEmpty)
                Positioned(
                  top: 10,
                  right: 12,
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.32),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withOpacity(0.22),
                      ),
                    ),
                    child: Icon(
                      _weatherIcon(),
                      color: Colors.white.withOpacity(0.95),
                      size: 16,
                    ),
                  ),
                ),
              // Bottom content
              Positioned(
                left: 18,
                bottom: 14,
                right: 18,
                child: _buildBottomContent(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBottomContent() {
    if (_isLoading) {
      return SizedBox.shrink();
    }
    if (_errorMessage.isNotEmpty) {
      return Row(
        children: [
          Expanded(
            child: Text(
              _errorMessage,
              style: TextStyle(
                color: Colors.white.withOpacity(0.9),
                fontSize: 13,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
          LiquidButton(
            onTap: _isLoading ? null : _fetchWeather,
            borderRadius: BorderRadius.circular(8),
            liquidColors: [
              AppThemeController.instance.primaryPurple.withOpacity(0.55),
              AppThemeController.instance.accentPurple.withOpacity(0.35),
              AppThemeController.instance.glowMagenta.withOpacity(0.45),
            ],
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.white.withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.refresh, color: Colors.white, size: 14),
                  SizedBox(width: 4),
                  Text(
                    'Coba Lagi',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        // Big temperature + description
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              _temperature,
              style: TextStyle(
                color: Colors.white,
                fontSize: 34,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                height: 1.0,
                shadows: [
                  Shadow(
                    color: AppThemeController.instance.primaryPurple.withOpacity(0.7),
                    blurRadius: 16,
                  ),
                  Shadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                _description,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.95),
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.3,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        // Stat chips: feels-like, humidity, wind
        Wrap(
          spacing: 6,
          runSpacing: 4,
          children: [
            _weatherStatChip(
              icon: Icons.device_thermostat_rounded,
              label: 'Terasa',
              value: _feelsLike,
            ),
            _weatherStatChip(
              icon: Icons.water_drop_rounded,
              label: 'Lembab',
              value: _humidity,
            ),
            _weatherStatChip(
              icon: Icons.air_rounded,
              label: 'Angin',
              value: _windSpeed,
            ),
          ],
        ),
      ],
    );
  }

  /// Compact frosted chip used for secondary weather stats.
  Widget _weatherStatChip({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.32),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white.withOpacity(0.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white.withOpacity(0.85), size: 11),
          const SizedBox(width: 4),
          Text(
            '$label ',
            style: TextStyle(
              color: Colors.white.withOpacity(0.6),
              fontSize: 9.5,
              fontFamily: 'ShareTechMono',
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: Colors.white.withOpacity(0.95),
              fontSize: 9.5,
              fontFamily: 'ShareTechMono',
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}

class _SunRaysPainter extends CustomPainter {
  final Color color;
  final int rayCount;
  final double longExtra;
  final double shortExtra;
  final double strokeWidth;
  _SunRaysPainter({
    required this.color,
    this.rayCount = 8,
    this.longExtra = 14.0,
    this.shortExtra = 8.0,
    this.strokeWidth = 2.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    for (int i = 0; i < rayCount; i++) {
      final angle = (i * 360 / rayCount) * math.pi / 180;
      // Alternate long / short rays for a more dynamic sun
      final isLong = i.isEven;
      final extra = isLong ? longExtra : shortExtra;
      final start = Offset(
        center.dx + (radius + 3) * math.cos(angle),
        center.dy + (radius + 3) * math.sin(angle),
      );
      final end = Offset(
        center.dx + (radius + extra) * math.cos(angle),
        center.dy + (radius + extra) * math.sin(angle),
      );
      canvas.drawLine(start, end, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _SunRaysPainter oldDelegate) =>
      oldDelegate.color != color ||
      oldDelegate.rayCount != rayCount ||
      oldDelegate.longExtra != longExtra ||
      oldDelegate.shortExtra != shortExtra ||
      oldDelegate.strokeWidth != strokeWidth;
}

class _CloudShape extends StatelessWidget {
  final double size;
  const _CloudShape({required this.size});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size * 1.8,
      height: size * 0.95,
      child: CustomPaint(painter: _CloudPainter()),
    );
  }
}

class _CloudPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Soft shadow under the cloud for depth
    final shadowPaint = Paint()
      ..color = Colors.black.withOpacity(0.18)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0);
    final shadowPath = Path()
      ..addOval(Rect.fromCircle(center: Offset(w * 0.50, h * 0.85), radius: h * 0.55));
    canvas.drawPath(shadowPath, shadowPaint);

    // Main cloud body — vertical gradient for a "puffy" 3D feel
    final bodyPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.white,
          Colors.white.withOpacity(0.92),
          Colors.white.withOpacity(0.74),
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        stops: const [0.0, 0.55, 1.0],
      ).createShader(Rect.fromLTWH(0, 0, w, h))
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1.6);

    final path = Path()
      ..addOval(Rect.fromCircle(center: Offset(w * 0.30, h * 0.65), radius: h * 0.45))
      ..addOval(Rect.fromCircle(center: Offset(w * 0.52, h * 0.40), radius: h * 0.55))
      ..addOval(Rect.fromCircle(center: Offset(w * 0.74, h * 0.58), radius: h * 0.42))
      ..addOval(Rect.fromCircle(center: Offset(w * 0.18, h * 0.76), radius: h * 0.30))
      ..addOval(Rect.fromCircle(center: Offset(w * 0.88, h * 0.76), radius: h * 0.28));
    canvas.drawPath(path, bodyPaint);

    // Top highlight to give a sunlit rim
    final highlightPaint = Paint()
      ..shader = LinearGradient(
        colors: [
          Colors.white.withOpacity(0.6),
          Colors.transparent,
        ],
        begin: Alignment.topCenter,
        end: Alignment.center,
      ).createShader(Rect.fromLTWH(0, 0, w, h))
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2.0);
    final highlightPath = Path()
      ..addOval(Rect.fromCircle(center: Offset(w * 0.52, h * 0.28), radius: h * 0.32));
    canvas.drawPath(highlightPath, highlightPaint);
  }

  @override
  bool shouldRepaint(covariant _CloudPainter oldDelegate) => false;
}

// ============================================================
// RAIN PAINTER — animated rain drops for rainy / drizzle / storm
// conditions. Drops fall vertically with slight slant.
// ============================================================
class _RainPainter extends CustomPainter {
  final double progress;
  final Color color;

  _RainPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    // 32 drops split across three depth "planes" so the shower reads
    // as real rain with parallax: far drops are thin, faint and slow;
    // near drops are thicker, brighter and fall faster with a longer
    // wind-driven slant.
    const dropCount = 32;
    final totalHeight = size.height + 24.0;

    for (int i = 0; i < dropCount; i++) {
      final seedX = ((i * 137) % 1000) / 1000.0;
      final depth = ((i * 73) % 100) / 100.0; // 0 = far, 1 = near
      final speed = 0.55 + depth * 0.85;
      final length = 8.0 + depth * 12.0;
      final slant = 1.5 + depth * 3.0;
      final strokeW = 0.9 + depth * 1.1;
      final opacity = 0.28 + depth * 0.5;

      final x = seedX * size.width;
      final baseOffset = (i * 47.0) % totalHeight;
      final y = (baseOffset + progress * totalHeight * speed) % totalHeight;

      final paint = Paint()
        ..color = color.withOpacity((color.opacity * opacity).clamp(0.0, 1.0))
        ..strokeWidth = strokeW
        ..strokeCap = StrokeCap.round;

      canvas.drawLine(
        Offset(x, y - length),
        Offset(x - slant, y),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _RainPainter oldDelegate) =>
      oldDelegate.progress != progress || oldDelegate.color != color;
}

// ============================================================
// MOON CRATER PAINTER — subtle craters on the night moon.
// ============================================================
class _MoonCraterPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.grey.withOpacity(0.25);

    // Three small craters
    canvas.drawCircle(
      Offset(size.width * 0.35, size.height * 0.40),
      size.width * 0.08,
      paint,
    );
    canvas.drawCircle(
      Offset(size.width * 0.60, size.height * 0.55),
      size.width * 0.06,
      paint,
    );
    canvas.drawCircle(
      Offset(size.width * 0.45, size.height * 0.70),
      size.width * 0.05,
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _MoonCraterPainter oldDelegate) => false;
}

// ============================================================
// STARS PAINTER — twinkling starfield for night skies.
// Each star has its own phase so the field shimmers organically.
// ============================================================
class _StarsPainter extends CustomPainter {
  final double progress;
  _StarsPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    // Deterministic pseudo-random star positions
    const starCount = 22;
    for (int i = 0; i < starCount; i++) {
      final seedX = ((i * 9301 + 49297) % 233280) / 233280.0;
      final seedY = ((i * 49297 + 9301) % 233280) / 233280.0;
      final x = seedX * size.width;
      final y = seedY * (size.height * 0.7); // keep stars in upper region
      final phase = (i * 0.37) % 1.0;
      final double t = (progress + phase) % 1.0;
      // Twinkle: peak at t=0.5
      final double twinkle = math.sin(t * math.pi);
      final double opacity = 0.25 + 0.65 * twinkle;
      final double radius = 0.6 + 0.9 * twinkle;

      final paint = Paint()
        ..color = Colors.white.withOpacity(opacity.clamp(0.0, 1.0));
      canvas.drawCircle(Offset(x, y), radius, paint);

      // Optional cross sparkle for the brightest stars
      if (twinkle > 0.85) {
        final sparkPaint = Paint()
          ..color = Colors.white.withOpacity(opacity * 0.6)
          ..strokeWidth = 0.6
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(
          Offset(x - radius * 2.5, y),
          Offset(x + radius * 2.5, y),
          sparkPaint,
        );
        canvas.drawLine(
          Offset(x, y - radius * 2.5),
          Offset(x, y + radius * 2.5),
          sparkPaint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _StarsPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ============================================================
// LIGHTNING PAINTER — jagged bolt drawn from top to mid-card.
// Uses a seeded pseudo-random path so each flash looks different.
// ============================================================
class _LightningPainter extends CustomPainter {
  final int seed;
  _LightningPainter({required this.seed});

  @override
  void paint(Canvas canvas, Size size) {
    final math.Random rng = math.Random(seed);
    // Bolt origin slightly off-center
    final double startX = size.width * (0.35 + rng.nextDouble() * 0.3);
    final double startY = 0;

    final path = Path();
    double x = startX;
    double y = startY;
    path.moveTo(x, y);

    // Zig-zag down to roughly 60% of card height
    final double targetY = size.height * 0.6;
    while (y < targetY) {
      x += (rng.nextDouble() - 0.5) * 28;
      y += 14 + rng.nextDouble() * 16;
      path.lineTo(x, y);
    }

    // Two branches at the end
    final double branchX1 = x + (rng.nextDouble() - 0.5) * 30;
    final double branchY1 = y + 20 + rng.nextDouble() * 15;
    final double branchX2 = x + (rng.nextDouble() - 0.5) * 30;
    final double branchY2 = y + 20 + rng.nextDouble() * 15;
    path.moveTo(x, y);
    path.lineTo(branchX1, branchY1);
    path.moveTo(x, y);
    path.lineTo(branchX2, branchY2);

    // Outer glow stroke
    final glowPaint = Paint()
      ..color = Colors.white.withOpacity(0.55)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0);
    canvas.drawPath(path, glowPaint);

    // Bright core
    final corePaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(path, corePaint);
  }

  @override
  bool shouldRepaint(covariant _LightningPainter oldDelegate) =>
      oldDelegate.seed != seed;
}

// ============================================================
// SNOW PAINTER — slow drifting snowflakes with slight sway.
// ============================================================
class _SnowPainter extends CustomPainter {
  final double progress;
  _SnowPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    const flakeCount = 24;
    final totalHeight = size.height + 8.0;

    for (int i = 0; i < flakeCount; i++) {
      final seedX = ((i * 137) % 1000) / 1000.0;
      final seedSway = (((i * 73) % 100) / 100.0);
      final seedSize = (((i * 53) % 100) / 100.0);
      final baseX = seedX * size.width;
      final baseOffset = (i * 31.0) % totalHeight;
      final y = (baseOffset + progress * totalHeight) % totalHeight;
      // Horizontal sway via sine wave
      final double sway = math.sin((progress * 2 * math.pi) + i) * 6 * seedSway;
      final x = baseX + sway;
      final radius = 1.4 + seedSize * 1.6;

      final paint = Paint()
        ..color = Colors.white.withOpacity(0.65 + 0.25 * seedSize);
      canvas.drawCircle(Offset(x, y), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _SnowPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ============================================================
// WIND STREAK PAINTER — horizontal translucent streaks that
// sweep across the card for mist / atmosphere conditions.
// ============================================================
class _WindStreakPainter extends CustomPainter {
  final double progress;
  _WindStreakPainter({required this.progress});

  @override
  void paint(Canvas canvas, Size size) {
    const streakCount = 7;
    final totalWidth = size.width + 80.0;

    for (int i = 0; i < streakCount; i++) {
      final seedY = ((i * 211) % 1000) / 1000.0;
      final seedSpeed = (((i * 67) % 100) / 100.0) + 0.5;
      final seedLen = (((i * 41) % 100) / 100.0);
      final y = seedY * size.height;
      final len = 40 + seedLen * 50;
      final offset = (i * 23.0) % totalWidth;
      final x = ((offset + progress * totalWidth * seedSpeed) % totalWidth) - 40;

      final paint = Paint()
        ..color = Colors.white.withOpacity(0.10 + 0.08 * seedSpeed)
        ..strokeWidth = 1.2
        ..strokeCap = StrokeCap.round
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, 1.2);
      canvas.drawLine(
        Offset(x, y),
        Offset(x + len, y),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _WindStreakPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ============================================================
// THANKS TO — horizontal credit selector for 3 contributors
// ============================================================
class _ThanksToSelector extends StatefulWidget {
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color cardGlass;
  final Color cardSelected;
  final Color borderGlass;
  final List<Map<String, dynamic>> people;
  final bool isLoading;

  const _ThanksToSelector({
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.cardGlass,
    required this.cardSelected,
    required this.borderGlass,
    required this.people,
    required this.isLoading,
  });

  @override
  State<_ThanksToSelector> createState() => _ThanksToSelectorState();
}

class _ThanksToSelectorState extends State<_ThanksToSelector>
    with SingleTickerProviderStateMixin {
  late final AnimationController _glow;
  late final PageController _pageController;
  int _selected = 0;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _glow = AnimationController(vsync: this, duration: Duration(seconds: 3))
      ..repeat();
    _pageController = PageController(viewportFraction: 1.0);
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _glow.dispose();
    _pageController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final people = widget.people;
    if (_selected >= people.length) _selected = 0;

    return Padding(
      padding: EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.auto_awesome, color: AppThemeController.instance.accentPurple, size: 16),
              SizedBox(width: 6),
              Text(
                "Thanks To",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
              Spacer(),
              if (!widget.isLoading && people.length > 1)
                Text(
                  "Geser untuk lihat lainnya",
                  style: TextStyle(
                    color: AppThemeController.instance.lightPurple.withOpacity(0.5),
                    fontSize: 10,
                    fontStyle: FontStyle.italic,
                  ),
                ),
            ],
          ),
          SizedBox(height: 10),
          SizedBox(
            height: 96,
            child: widget.isLoading
                ? Center(
                    child: SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.2,
                        color: AppThemeController.instance.accentPurple,
                      ),
                    ),
                  )
                : people.isEmpty
                    ? Center(
                        child: Text(
                          "No data available",
                          style: TextStyle(
                            color: AppThemeController.instance.lightPurple.withOpacity(0.6),
                            fontSize: 12,
                          ),
                        ),
                      )
                    : PageView.builder(
                        controller: _pageController,
                        itemCount: people.length,
                        onPageChanged: (index) {
                          setState(() => _selected = index);
                        },
                        itemBuilder: (context, index) {
                          final person = people[index];
                          final String name =
                              (person['name'] ?? 'Unknown').toString();
                          final String role =
                              (person['role'] ?? person['status'] ?? '')
                                  .toString();
                          final String? ppUrl = person['ppUrl']?.toString();
                          return Padding(
                            padding: EdgeInsets.symmetric(horizontal: 2),
                            child: AnimatedBuilder(
                              animation: _glow,
                              builder: (context, _) {
                                final glowValue =
                                    0.5 + 0.5 * math.sin(_glow.value * 2 * math.pi);
                                return Container(
                                  width: double.infinity,
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 14),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(18),
                                    color: widget.cardSelected,
                                    border: Border.all(
                                      color: AppThemeController.instance.accentPurple,
                                      width: 1.4,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color: AppThemeController.instance.accentPurple
                                            .withOpacity(0.22 + 0.18 * glowValue),
                                        blurRadius: 20,
                                        spreadRadius: 1,
                                      ),
                                      BoxShadow(
                                        color: AppThemeController.instance.glowMagenta
                                            .withOpacity(0.10),
                                        blurRadius: 26,
                                        spreadRadius: 1,
                                      ),
                                    ],
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 44,
                                        height: 44,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          gradient: LinearGradient(
                                            colors: [
                                              AppThemeController.instance.primaryPurple,
                                              AppThemeController.instance.accentPurple
                                            ],
                                          ),
                                          boxShadow: [
                                            BoxShadow(
                                              color: AppThemeController.instance.accentPurple
                                                  .withOpacity(
                                                      0.35 + 0.25 * glowValue),
                                              blurRadius: 14,
                                              spreadRadius: 0.5,
                                            ),
                                          ],
                                        ),
                                        child: ClipOval(
                                          child: ppUrl != null && ppUrl.isNotEmpty
                                              ? Image.network(
                                                  ppUrl,
                                                  fit: BoxFit.cover,
                                                  errorBuilder:
                                                      (_, __, ___) => const Icon(
                                                          Icons.favorite_rounded,
                                                          color: Colors.white,
                                                          size: 20),
                                                )
                                              : const Icon(
                                                  Icons.favorite_rounded,
                                                  color: Colors.white,
                                                  size: 20),
                                        ),
                                      ),
                                      SizedBox(width: 14),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              name,
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 15,
                                                fontWeight: FontWeight.bold,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                            SizedBox(height: 3),
                                            Text(
                                              role.isEmpty
                                                  ? "Contributor"
                                                  : role,
                                              style: TextStyle(
                                                color: AppThemeController.instance.lightPurple,
                                                fontSize: 11,
                                                fontWeight: FontWeight.w600,
                                                letterSpacing: 0.5,
                                              ),
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ],
                                        ),
                                      ),
                                      Icon(
                                        Icons.swipe_rounded,
                                        color: AppThemeController.instance.lightPurple
                                            .withOpacity(0.35),
                                        size: 16,
                                      ),
                                    ],
                                  ),
                                );
                              },
                            ),
                          );
                        },
                      ),
          ),
          if (!widget.isLoading && people.length > 1) ...[
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(people.length, (index) {
                final bool isActive = index == _selected;
                return AnimatedContainer(
                  duration: Duration(milliseconds: 250),
                  margin: EdgeInsets.symmetric(horizontal: 3),
                  width: isActive ? 18 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(3),
                    color: isActive
                        ? AppThemeController.instance.accentPurple
                        : AppThemeController.instance.borderGlass,
                  ),
                );
              }),
            ),
          ],
        ],
      ),
    );
  }
}

// ============================================================
// THANKS TO WELCOME DIALOG — Auto-popup shown once per user,
// right after their first successful login. Displays all
// contributors in a beautifully animated purple-glow card so
// the user immediately sees who built the app.
//
// Behaviour:
//  - Tapping anywhere outside the card dismisses it.
//  - The "Lanjutkan" button also dismisses it.
//  - Once dismissed (or auto-shown once), it never appears
//    again for the same username on the same device — the
//    flag lives in SharedPreferences under
//    `thanksToWelcomeShown_<username>`.
// ============================================================
class _ThanksToWelcomeDialog extends StatefulWidget {
  final List<Map<String, dynamic>> people;
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color glowIndigo;
  final String username;

  const _ThanksToWelcomeDialog({
    required this.people,
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.glowIndigo,
    required this.username,
  });

  @override
  State<_ThanksToWelcomeDialog> createState() =>
      _ThanksToWelcomeDialogState();
}

class _ThanksToWelcomeDialogState extends State<_ThanksToWelcomeDialog>
    with SingleTickerProviderStateMixin {
  late final AnimationController _enter;
  late final Animation<double> _enterFade;
  late final Animation<Offset> _enterSlide;
  late final AnimationController _glow;
  late final PageController _pageController;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _enter = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 420),
    );
    _enterFade = CurvedAnimation(
      parent: _enter,
      curve: Curves.easeOutCubic,
    );
    _enterSlide = Tween<Offset>(
      begin: Offset(0, 0.08),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _enter,
      curve: Curves.easeOutCubic,
    ));
    _enter.forward();

    _glow = AnimationController(
      vsync: this,
      duration: Duration(seconds: 3),
    )..repeat();

    _pageController = PageController(viewportFraction: 1.0);
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _enter.dispose();
    _glow.dispose();
    _pageController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _close() {
    Navigator.of(context).maybePop();
  }

  @override
  Widget build(BuildContext context) {
    final people = widget.people;
    if (_page >= people.length) _page = 0;

    return Center(
      child: FadeTransition(
        opacity: _enterFade,
        child: SlideTransition(
          position: _enterSlide,
          child: Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: EdgeInsets.symmetric(
              horizontal: 24,
              vertical: 24,
            ),
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.fromLTRB(20, 22, 20, 18),
              decoration: BoxDecoration(
                color: Color(0xFF1A0E30),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                  color: AppThemeController.instance.accentPurple.withOpacity(0.55),
                  width: 1.4,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppThemeController.instance.primaryPurple.withOpacity(0.45),
                    blurRadius: 32,
                    spreadRadius: 2,
                  ),
                  BoxShadow(
                    color: AppThemeController.instance.glowMagenta.withOpacity(0.25),
                    blurRadius: 48,
                    spreadRadius: 4,
                  ),
                ],
              ),
              child: AnimatedBuilder(
                animation: _glow,
                builder: (context, _) {
                  final glowValue =
                      0.5 + 0.5 * math.sin(_glow.value * 2 * math.pi);
                  return Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      // === Top ornamental badge ===
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          gradient: LinearGradient(
                            colors: [
                              AppThemeController.instance.primaryPurple,
                              AppThemeController.instance.accentPurple,
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppThemeController.instance.accentPurple
                                  .withOpacity(0.45 + 0.20 * glowValue),
                              blurRadius: 14,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: const [
                            Icon(Icons.auto_awesome,
                                color: Colors.white, size: 14),
                            SizedBox(width: 6),
                            Text(
                              'THANKS TO',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 2,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 14),

                      // === Welcome heading ===
                      Text(
                        'Selamat datang, ${widget.username}!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 0.4,
                        ),
                      ),
                      SizedBox(height: 6),
                      Text(
                        'Aplikasi ini ada berkat kontribusi dari:',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: AppThemeController.instance.lightPurple.withOpacity(0.78),
                          fontSize: 12,
                          height: 1.45,
                        ),
                      ),
                      SizedBox(height: 18),

                      // === Contributor page-view ===
                      SizedBox(
                        height: 110,
                        child: people.isEmpty
                            ? Center(
                                child: Text(
                                  'No data available',
                                  style: TextStyle(
                                    color:
                                        AppThemeController.instance.lightPurple.withOpacity(0.6),
                                    fontSize: 12,
                                  ),
                                ),
                              )
                            : PageView.builder(
                                controller: _pageController,
                                itemCount: people.length,
                                onPageChanged: (i) =>
                                    setState(() => _page = i),
                                itemBuilder: (context, i) {
                                  final p = people[i];
                                  final String pName =
                                      (p['name'] ?? 'Unknown').toString();
                                  final String pRole =
                                      (p['role'] ??
                                              p['status'] ??
                                              'Contributor')
                                          .toString();
                                  final String? pPp =
                                      p['ppUrl']?.toString();
                                  return Container(
                                    margin: EdgeInsets.symmetric(
                                        horizontal: 4),
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 14, vertical: 14),
                                    decoration: BoxDecoration(
                                      borderRadius:
                                          BorderRadius.circular(18),
                                      color: AppThemeController.instance.cardSolidSelected,
                                      border: Border.all(
                                        color: AppThemeController.instance.accentPurple
                                            .withOpacity(0.55),
                                        width: 1.2,
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: AppThemeController.instance.accentPurple
                                              .withOpacity(
                                                  0.22 + 0.18 * glowValue),
                                          blurRadius: 16,
                                          spreadRadius: 1,
                                        ),
                                      ],
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 52,
                                          height: 52,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            gradient: LinearGradient(
                                              colors: [
                                                AppThemeController.instance.primaryPurple,
                                                AppThemeController.instance.accentPurple,
                                              ],
                                            ),
                                            boxShadow: [
                                              BoxShadow(
                                                color: AppThemeController.instance.accentPurple
                                                    .withOpacity(
                                                        0.35 +
                                                            0.25 *
                                                                glowValue),
                                                blurRadius: 14,
                                                spreadRadius: 0.5,
                                              ),
                                            ],
                                          ),
                                          child: ClipOval(
                                            child: (pPp != null &&
                                                    pPp.isNotEmpty)
                                                ? Image.network(
                                                    pPp,
                                                    fit: BoxFit.cover,
                                                    errorBuilder:
                                                        (_, __, ___) =>
                                                            const Icon(
                                                      Icons.favorite_rounded,
                                                      color: Colors.white,
                                                      size: 24,
                                                    ),
                                                  )
                                                : const Icon(
                                                    Icons.favorite_rounded,
                                                    color: Colors.white,
                                                    size: 24,
                                                  ),
                                          ),
                                        ),
                                        SizedBox(width: 14),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Text(
                                                pName,
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                                maxLines: 1,
                                                overflow:
                                                    TextOverflow.ellipsis,
                                              ),
                                              SizedBox(height: 4),
                                              Text(
                                                pRole,
                                                style: TextStyle(
                                                  color: AppThemeController.instance.lightPurple,
                                                  fontSize: 11,
                                                  fontWeight: FontWeight.w600,
                                                  letterSpacing: 0.4,
                                                ),
                                                maxLines: 1,
                                                overflow:
                                                    TextOverflow.ellipsis,
                                              ),
                                            ],
                                          ),
                                        ),
                                        Icon(
                                          Icons.swipe_rounded,
                                          color: AppThemeController.instance.lightPurple
                                              .withOpacity(0.35),
                                          size: 16,
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                      ),

                      // === Page indicators ===
                      if (people.length > 1) ...[
                        SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(people.length, (i) {
                            final active = i == _page;
                            return AnimatedContainer(
                              duration:
                                  Duration(milliseconds: 250),
                              margin: EdgeInsets.symmetric(
                                  horizontal: 3),
                              width: active ? 18 : 6,
                              height: 6,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(3),
                                color: active
                                    ? AppThemeController.instance.accentPurple
                                    : AppThemeController.instance.lightPurple.withOpacity(0.25),
                              ),
                            );
                          }),
                        ),
                      ],

                      SizedBox(height: 20),

                      // === Continue button ===
                      GestureDetector(
                        onTap: _close,
                        child: Container(
                          width: double.infinity,
                          padding: EdgeInsets.symmetric(vertical: 13),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            gradient: LinearGradient(
                              colors: [
                                AppThemeController.instance.primaryPurple,
                                AppThemeController.instance.accentPurple,
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: AppThemeController.instance.accentPurple
                                    .withOpacity(0.40 + 0.20 * glowValue),
                                blurRadius: 16,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: Center(
                            child: Text(
                              'Lanjutkan',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 1.2,
                              ),
                            ),
                          ),
                        ),
                      ),

                      SizedBox(height: 8),
                      Text(
                        'Tap di luar untuk menutup',
                        style: TextStyle(
                          color: AppThemeController.instance.lightPurple.withOpacity(0.35),
                          fontSize: 10,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// WORDS OF THE DAY — daily motivational quote card. Quotes are
// stocked directly in this file (no server call involved), rotating
// automatically by date and reshuffle-able via the refresh button.
//
// ─── REDESIGNED: Clear Blue Glow Edition ──────────────────────
// A crystal-clear, glassy blue card — like a sapphire geode
// caught in moonlight. The panel is mostly translucent with a
// soft radial blue bloom that breathes slowly, an inner
// hairline ring that catches the light, a top sheen, and a
// breathing outer halo made of two layered blue glows. Quote
// text uses a deep blue-ink on the bright crystal surface for
// maximum readability — clean, calm, aesthetic, and luminous.
// ============================================================
class _WordsOfTheDayCard extends StatefulWidget {
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color glowIndigo;
  final Color cardGlass;
  final Color borderGlass;

  const _WordsOfTheDayCard({
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.glowIndigo,
    required this.cardGlass,
    required this.borderGlass,
  });

  @override
  State<_WordsOfTheDayCard> createState() => _WordsOfTheDayCardState();
}

class _WordsOfTheDayCardState extends State<_WordsOfTheDayCard>
    with TickerProviderStateMixin {
  // Gentle ambient animations only.
  late final AnimationController _breathe;     // outer halo + inner highlight breathing
  late final AnimationController _refreshSpin; // one-shot 360° rotation on shuffle
  late final AnimationController _fade;        // cross-fade between quotes
  late final Animation<double> _fadeAnim;
  late int _index;

  // ─── Local quote stock — edit/add freely, no server needed ──────
  static const List<Map<String, String>> _quotes = [
    {
      "quote": "Kegagalan hanyalah kesempatan untuk memulai lagi dengan lebih cerdas.",
      "author": "Vinz",
    },
    {
      "quote": "Jangan tunggu momentum yang tepat, ciptakan momentum itu sendiri.",
      "author": "Vinz",
    },
    {
      "quote": "Konsistensi kecil setiap hari mengalahkan usaha besar yang jarang.",
      "author": "Vinz",
    },
    {
      "quote": "Fokus pada progress, bukan kesempurnaan.",
      "author": "Vinz",
    },
    {
      "quote": "Kesuksesan adalah hasil dari kerja keras yang tak terlihat orang lain.",
      "author": "Vinz",
    },
    {
      "quote": "Langkah kecil yang konsisten mengalahkan lompatan besar yang tak pernah dimulai.",
      "author": "Vinz",
    },
    {
      "quote": "Disiplin adalah jembatan antara tujuan dan pencapaian.",
      "author": "Vinz",
    },
  ];

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _breathe = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 6),
    )..repeat(reverse: true);
    _refreshSpin = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _fade = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 480),
    );
    _fadeAnim = CurvedAnimation(parent: _fade, curve: Curves.easeOutCubic);
    _fade.value = 1.0;

    // Pick today's quote deterministically so it stays the same all day
    // and changes automatically tomorrow — all computed on-device.
    final now = DateTime.now();
    final dayOfYear = now.difference(DateTime(now.year, 1, 1)).inDays;
    _index = dayOfYear % _quotes.length;
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _breathe.dispose();
    _refreshSpin.dispose();
    _fade.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _shuffleQuote() {
    HapticFeedback.selectionClick();
    int next;
    do {
      next = math.Random().nextInt(_quotes.length);
    } while (next == _index && _quotes.length > 1);

    // Cross-fade: fade current out, swap, fade new in.
    _fade.reverse().then((_) {
      if (!mounted) return;
      setState(() => _index = next);
      _fade.forward();
    });

    // Spin the refresh icon for tactile feedback.
    _refreshSpin
      ..reset()
      ..forward();
  }

  /// Map a DateTime to a short classic "MMM DD" label (e.g. "JUL 05").
  String get _dateLabel {
    const months = [
      'JAN', 'FEB', 'MAR', 'APR', 'MEI', 'JUN',
      'JUL', 'AGU', 'SEP', 'OKT', 'NOV', 'DES',
    ];
    final now = DateTime.now();
    final m = months[now.month - 1];
    final d = now.day.toString().padLeft(2, '0');
    return '$m $d';
  }

  @override
  Widget build(BuildContext context) {
    final current = _quotes[_index];

    // ─── Purple Gradient Palette (mini compact) ───────────────────
    // Rich multi-stop purple gradient — magenta → indigo → deep violet.
    // Quote text uses a soft lilac-white ink on the deep violet
    // gradient surface for max readability & aesthetic pop.
    final Color blueCrystal = AppThemeController.instance.lightPurple; // compat
    Color blueAqua    = Color(0xFFE0CBF6); // (unused — kept for compat)
    Color blueMist    = Color(0xFFC9A6EE); // (unused — kept for compat)
    final Color blueDeep    = AppThemeController.instance.glowIndigo; // glowIndigo (deep violet)
    final Color blueAccent  = AppThemeController.instance.primaryPurple; // primaryPurple accent
    final Color blueInk     = AppThemeController.instance.lightPurple; // lightPurple — quote text on dark gradient
    final Color blueInkSoft = AppThemeController.instance.accentPurple.withOpacity(0.85);
    final Color glowCore      = AppThemeController.instance.glowMagenta; // glowMagenta core

    return AnimatedBuilder(
      animation: _breathe,
      builder: (context, _) {
        // 0..1..0 triangle — used to pulse halo and inner glow.
        final b = _breathe.value;
        final breath = 0.5 + 0.5 * b;

        return Container(
          // ─── Outer halo — breathing purple glow (ultra-compact) ──
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: blueAccent.withOpacity(0.34 + 0.16 * breath),
                blurRadius: 14 + 5 * breath,
                spreadRadius: 1,
                offset: Offset(0, 4),
              ),
              BoxShadow(
                color: blueDeep.withOpacity(0.26 + 0.14 * breath),
                blurRadius: 22 + 8 * breath,
                spreadRadius: 2,
              ),
              BoxShadow(
                color: glowCore.withOpacity(0.22),
                blurRadius: 10,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Container(
            // ─── Border — multi-stop purple gradient hairline ──────
            padding: EdgeInsets.all(1.0),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  glowCore.withOpacity(0.85),
                  AppThemeController.instance.accentPurple.withOpacity(0.70), // accentPurple
                  blueAccent.withOpacity(0.55),
                  blueDeep.withOpacity(0.70),
                  glowCore.withOpacity(0.85),
                ],
                stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
              ),
            ),
            child: Container(
              width: double.infinity,
              // ─── Smaller padding for ultra-compact card ──────────
              padding: EdgeInsets.fromLTRB(12, 9, 12, 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(13),
                // ─── Inner panel — rich multi-stop purple gradient ──
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    blueDeep.withOpacity(0.96),
                    blueAccent.withOpacity(0.92),
                    blueDeep.withOpacity(0.96),
                    AppThemeController.instance.glowIndigo.withOpacity(0.98), // deep plum → theme
                  ],
                  stops: const [0.0, 0.35, 0.65, 1.0],
                ),
                border: Border.all(
                  color: glowCore.withOpacity(0.55),
                  width: 0.7,
                ),
              ),
              child: Stack(
                children: [
                  // ─── Inner radial bloom (top-left highlight) ───────
                  Positioned.fill(
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(13),
                          gradient: RadialGradient(
                            center: Alignment(
                                -0.5 + 0.15 * breath,
                                -0.7 + 0.15 * breath),
                            radius: 1.1,
                            colors: [
                              glowCore.withOpacity(0.30 + 0.10 * breath),
                              AppThemeController.instance.accentPurple.withOpacity(0.10),
                              Colors.transparent,
                            ],
                            stops: const [0.0, 0.45, 1.0],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // ─── Inner hairline ring (compact) ──
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Padding(
                        padding: const EdgeInsets.all(3),
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.18),
                              width: 0.5,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // ─── Top sheen (light from above) ──────────────────
                  Positioned(
                    top: 0,
                    left: 10,
                    right: 10,
                    height: 1.2,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              Colors.white.withOpacity(0.55),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // ─── Content (ultra-compact) ───────────────────────
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Top ornamental flourish — smaller
                      _OrnamentDivider(
                        color: glowCore.withOpacity(0.70),
                        width: 56,
                      ),
                      SizedBox(height: 5),

                      // Date + label row — compact masthead
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _dateLabel,
                            style: TextStyle(
                              color: glowCore,
                              fontSize: 7.5,
                              letterSpacing: 2.2,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                          SizedBox(width: 6),
                          Container(
                            width: 3,
                            height: 3,
                            decoration: BoxDecoration(
                              color: glowCore,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: glowCore.withOpacity(0.60),
                                  blurRadius: 3,
                                  spreadRadius: 0,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(width: 6),
                          Text(
                            'WORDS OF THE DAY',
                            style: TextStyle(
                              color: AppThemeController.instance.accentPurple, // accentPurple
                              fontSize: 7.5,
                              letterSpacing: 2.2,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),

                      // ─── Quote with cross-fade ───────────────────────
                      AnimatedBuilder(
                        animation: _fadeAnim,
                        builder: (context, child) {
                          return Opacity(
                            opacity: _fadeAnim.value.clamp(0.0, 1.0),
                            child: Transform.translate(
                              offset: Offset(0, 4 * (1 - _fadeAnim.value)),
                              child: child,
                            ),
                          );
                        },
                        child: Column(
                          children: [
                            // Decorative opening quotation mark (smaller)
                            Padding(
                              padding: EdgeInsets.only(bottom: 1),
                              child: Text(
                                '\u275D',
                                style: TextStyle(
                                  color: glowCore.withOpacity(0.55),
                                  fontSize: 22,
                                  height: 0.6,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: 'serif',
                                ),
                              ),
                            ),
                            // The quote itself — light lilac ink serif italic
                            Text(
                              current['quote'] ?? '',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: blueInk,
                                fontSize: 11.5,
                                height: 1.42,
                                fontStyle: FontStyle.italic,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'serif',
                                letterSpacing: 0.15,
                                shadows: [
                                  Shadow(
                                    color: Color(0x66000000),
                                    blurRadius: 3,
                                    offset: Offset(0, 1),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 1),
                            Text(
                              '\u275E',
                              style: TextStyle(
                                color: glowCore.withOpacity(0.55),
                                fontSize: 14,
                                height: 0.6,
                                fontWeight: FontWeight.w400,
                                fontFamily: 'serif',
                              ),
                            ),
                          ],
                        ),
                      ),

                      SizedBox(height: 7),

                      // Author — small caps with em-dash
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width: 10,
                            height: 0.7,
                            color: glowCore.withOpacity(0.60),
                          ),
                          SizedBox(width: 5),
                          Text(
                            '\u2014 ${current['author'] ?? 'Unknown'} \u2014',
                            style: TextStyle(
                              color: blueInkSoft,
                              fontSize: 8.0,
                              letterSpacing: 1.6,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                          SizedBox(width: 5),
                          Container(
                            width: 10,
                            height: 0.7,
                            color: glowCore.withOpacity(0.60),
                          ),
                        ],
                      ),

                      SizedBox(height: 7),

                      // Bottom ornament + refresh button (ultra-compact)
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          _OrnamentDivider(
                            color: AppThemeController.instance.accentPurple.withOpacity(0.55),
                            width: 34,
                          ),
                          // Refresh button — smaller crystal disc
                          GestureDetector(
                            onTap: _shuffleQuote,
                            child: Container(
                              width: 20,
                              height: 20,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                gradient: RadialGradient(
                                  center: Alignment(-0.3, -0.4),
                                  colors: [
                                    Colors.white.withOpacity(0.95),
                                    glowCore.withOpacity(0.85),
                                    blueAccent.withOpacity(0.75),
                                  ],
                                  stops: const [0.0, 0.55, 1.0],
                                ),
                                border: Border.all(
                                  color: glowCore.withOpacity(0.70),
                                  width: 0.8,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: glowCore.withOpacity(
                                        0.30 + 0.10 * breath),
                                    blurRadius: 5,
                                    spreadRadius: 0,
                                  ),
                                  BoxShadow(
                                    color: Colors.white.withOpacity(0.35),
                                    blurRadius: 2,
                                    spreadRadius: 0,
                                  ),
                                ],
                              ),
                              child: AnimatedBuilder(
                                animation: _refreshSpin,
                                builder: (context, child) {
                                  return Transform.rotate(
                                    angle:
                                        _refreshSpin.value * 2 * math.pi,
                                    child: child,
                                  );
                                },
                                child: Icon(
                                  Icons.autorenew_rounded,
                                  color: blueDeep,
                                  size: 11,
                                ),
                              ),
                            ),
                          ),
                          Transform(
                            alignment: Alignment.center,
                            transform:
                                Matrix4.identity()..scale(-1.0, 1.0),
                            child: _OrnamentDivider(
                              color: AppThemeController.instance.accentPurple.withOpacity(0.55),
                              width: 34,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Thin centered ornamental flourish used as classic card decoration.
/// Renders as a horizontal hairline with a small diamond center and
/// two tiny dots on each side — a Victorian/Art-Deco inspired motif.
class _OrnamentDivider extends StatelessWidget {
  final Color color;
  final double width;
  const _OrnamentDivider({required this.color, required this.width});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: 8,
      child: CustomPaint(painter: _OrnamentPainter(color: color)),
    );
  }
}

class _OrnamentPainter extends CustomPainter {
  final Color color;
  _OrnamentPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;
    final cy = h / 2;
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    // Center diamond
    final diamond = Path()
      ..moveTo(w / 2, cy - 3)
      ..lineTo(w / 2 + 3, cy)
      ..lineTo(w / 2, cy + 3)
      ..lineTo(w / 2 - 3, cy)
      ..close();
    canvas.drawPath(diamond, paint);

    // Side hairlines
    final linePaint = Paint()
      ..color = color
      ..strokeWidth = 0.7;
    canvas.drawLine(Offset(8, cy), Offset(w / 2 - 6, cy), linePaint);
    canvas.drawLine(Offset(w / 2 + 6, cy), Offset(w - 8, cy), linePaint);

    // Tiny end dots
    canvas.drawCircle(Offset(4, cy), 1.0, paint);
    canvas.drawCircle(Offset(w - 4, cy), 1.0, paint);
  }

  @override
  bool shouldRepaint(covariant _OrnamentPainter oldDelegate) =>
      oldDelegate.color != color;
}

/// Subtle paper-grain texture painter — scatters faint lighter
/// specks across the panel to evoke a printed / engraved surface
/// rather than a flat digital fill.
class _PaperGrainPainter extends CustomPainter {
  final Color baseColor;
  final double opacity;
  _PaperGrainPainter({required this.baseColor, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = baseColor.withOpacity(opacity)
      ..style = PaintingStyle.fill;

    // Deterministic pseudo-random speckle — same dot positions on every
    // repaint so the texture doesn't shimmer.
    final rng = math.Random(42);
    final count = (size.width * size.height / 220).round();
    for (int i = 0; i < count; i++) {
      final x = rng.nextDouble() * size.width;
      final y = rng.nextDouble() * size.height;
      final r = 0.4 + rng.nextDouble() * 0.9;
      canvas.drawCircle(Offset(x, y), r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _PaperGrainPainter oldDelegate) => false;
}

// ============================================================
// WORDS + USD/IDR SELECTOR — Compact pill-toggle that switches
// between two child widgets: the Words of the Day quote card and
// the Dollar-to-Rupiah statistics chart. Both share the same
// purple-glow aesthetic, the same outer dimensions, and the same
// selector header so they read as a single composite widget.
// ============================================================
class _WordsAndStatsSelector extends StatefulWidget {
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color glowIndigo;
  final Color cardGlass;
  final Color borderGlass;

  const _WordsAndStatsSelector({
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.glowIndigo,
    required this.cardGlass,
    required this.borderGlass,
  });

  @override
  State<_WordsAndStatsSelector> createState() => _WordsAndStatsSelectorState();
}

class _WordsAndStatsSelectorState extends State<_WordsAndStatsSelector>
    with SingleTickerProviderStateMixin {
  // 0 = Words of the Day, 1 = USD/IDR chart
  int _selected = 0;
  late final AnimationController _switchController;
  late final Animation<double> _switchAnim;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _switchController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 360),
    );
    _switchAnim = CurvedAnimation(
      parent: _switchController,
      curve: Curves.easeOutCubic,
    );
    _switchController.value = 1.0;
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _switchController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _select(int index) {
    if (index == _selected) return;
    HapticFeedback.selectionClick();
    setState(() => _selected = index);
    _switchController
      ..reset()
      ..forward();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // ─── Selector header — two pill toggles ───────────────────
        _buildSelectorHeader(),
        SizedBox(height: 12),
        // ─── Animated body — switches between the two child widgets
        AnimatedBuilder(
          animation: _switchAnim,
          builder: (context, _) {
            return Opacity(
              opacity: _switchAnim.value.clamp(0.0, 1.0),
              child: Transform.translate(
                offset: Offset(0, 8 * (1 - _switchAnim.value)),
                child: _buildChild(),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildSelectorHeader() {
    return Container(
      padding: EdgeInsets.all(4),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppThemeController.instance.cardGlass,
            AppThemeController.instance.primaryPurple.withOpacity(0.10),
          ],
        ),
        border: Border.all(color: AppThemeController.instance.borderGlass, width: 1),
        boxShadow: [
          BoxShadow(
            color: AppThemeController.instance.primaryPurple.withOpacity(0.16),
            blurRadius: 14,
            spreadRadius: 0,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: _SelectorPill(
              label: 'WORDS',
              icon: Icons.format_quote_rounded,
              selected: _selected == 0,
              onTap: () => _select(0),
              primaryPurple: AppThemeController.instance.primaryPurple,
              accentPurple: AppThemeController.instance.accentPurple,
              lightPurple: AppThemeController.instance.lightPurple,
              glowMagenta: AppThemeController.instance.glowMagenta,
              borderGlass: AppThemeController.instance.borderGlass,
            ),
          ),
          SizedBox(width: 4),
          Expanded(
            child: _SelectorPill(
              label: 'USD / IDR',
              icon: Icons.show_chart_rounded,
              selected: _selected == 1,
              onTap: () => _select(1),
              primaryPurple: AppThemeController.instance.primaryPurple,
              accentPurple: AppThemeController.instance.accentPurple,
              lightPurple: AppThemeController.instance.lightPurple,
              glowMagenta: AppThemeController.instance.glowMagenta,
              borderGlass: AppThemeController.instance.borderGlass,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChild() {
    switch (_selected) {
      case 1:
        return _DollarToRupiahChart(
          primaryPurple: AppThemeController.instance.primaryPurple,
          accentPurple: AppThemeController.instance.accentPurple,
          lightPurple: AppThemeController.instance.lightPurple,
          glowMagenta: AppThemeController.instance.glowMagenta,
          glowIndigo: AppThemeController.instance.glowIndigo,
          cardGlass: AppThemeController.instance.cardGlass,
          borderGlass: AppThemeController.instance.borderGlass,
        );
      case 0:
      default:
        return _WordsOfTheDayCard(
          primaryPurple: AppThemeController.instance.primaryPurple,
          accentPurple: AppThemeController.instance.accentPurple,
          lightPurple: AppThemeController.instance.lightPurple,
          glowMagenta: AppThemeController.instance.glowMagenta,
          glowIndigo: AppThemeController.instance.glowIndigo,
          cardGlass: AppThemeController.instance.cardGlass,
          borderGlass: AppThemeController.instance.borderGlass,
        );
    }
  }
}

/// Single pill toggle inside the selector header.
class _SelectorPill extends StatefulWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color borderGlass;

  const _SelectorPill({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.borderGlass,
  });

  @override
  State<_SelectorPill> createState() => _SelectorPillState();
}

class _SelectorPillState extends State<_SelectorPill> {
  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
  }

  void _onThemeChanged() => mounted ? setState(() {}) : null;

  @override
  void dispose() {
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          gradient: widget.selected
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    AppThemeController.instance.glowIndigo, // glowIndigo (deep violet)
                    AppThemeController.instance.primaryPurple, // primaryPurple
                    AppThemeController.instance.accentPurple, // accentPurple
                  ],
                  stops: [0.0, 0.55, 1.0],
                )
              : null,
          color: widget.selected ? null : Colors.transparent,
          border: Border.all(
            color: widget.selected
                ? AppThemeController.instance.glowMagenta.withOpacity(0.7) // glowMagenta
                : AppThemeController.instance.borderGlass,
            width: widget.selected ? 1.0 : 0.7,
          ),
          boxShadow: widget.selected
              ? [
                  BoxShadow(
                    color: AppThemeController.instance.primaryPurple.withOpacity(0.45), // primaryPurple
                    blurRadius: 12,
                    spreadRadius: 0,
                    offset: Offset(0, 4),
                  ),
                  BoxShadow(
                    color: AppThemeController.instance.glowMagenta.withOpacity(0.30), // glowMagenta
                    blurRadius: 16,
                    spreadRadius: 0,
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              widget.icon,
              size: 13,
              color: widget.selected
                  ? Colors.white
                  : AppThemeController.instance.lightPurple.withOpacity(0.7),
            ),
            SizedBox(width: 6),
            Text(
              widget.label,
              style: TextStyle(
                color: widget.selected
                    ? Colors.white
                    : AppThemeController.instance.lightPurple.withOpacity(0.75),
                fontSize: 10,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1.8,
                shadows: widget.selected
                    ? [
                        Shadow(
                          color: AppThemeController.instance.glowMagenta.withOpacity(0.7), // glowMagenta
                          blurRadius: 6,
                        ),
                      ]
                    : null,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// DOLLAR TO RUPIAH CHART — Compact statistics card showing the
// current USD→IDR exchange rate with a 14-day sparkline trend,
// delta indicator, and high/low stats. Pure CustomPaint so it
// works without any external chart library. Blue-glow aesthetic
// matches the Words of the Day card so the two feel like siblings.
//
// ─── REAL-TIME DATA SOURCE ─────────────────────────────────────
// Rates are fetched live from Frankfurter.app (free, no API key,
// based on European Central Bank reference rates). The widget
// hits two endpoints on mount and every 5 minutes thereafter:
//   1. /timeseries  → last 21 calendar days (we keep last ~14
//      trading-day points; ECB doesn't publish on weekends/EU
//      holidays so the window is wider than 14 to compensate).
//   2. /latest      → the most recent published rate, appended
//      if it differs from the timeseries' last entry.
// All data shown is real. No hardcoded / fake rates anywhere.
// ============================================================
class _DollarToRupiahChart extends StatefulWidget {
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color glowIndigo;
  final Color cardGlass;
  final Color borderGlass;

  const _DollarToRupiahChart({
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.glowIndigo,
    required this.cardGlass,
    required this.borderGlass,
  });

  @override
  State<_DollarToRupiahChart> createState() => _DollarToRupiahChartState();
}

class _DollarToRupiahChartState extends State<_DollarToRupiahChart>
    with TickerProviderStateMixin {
  late final AnimationController _breathe;
  late final AnimationController _draw;

  // ─── Real-time data state (no hardcoded rates) ────────────────
  List<double> _rates = [];           // historical, oldest → newest
  bool _isLoading = true;             // true only on first load
  String _errorMessage = '';
  DateTime? _lastUpdated;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _breathe = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat(reverse: true);
    _draw = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );
    // Kick off the first fetch — draw animation will fire once data
    // arrives, not before.
    _fetchRates();
    // Refresh every 5 minutes while the widget is mounted. The
    // ECB only updates once per business day (~16:00 CET), but
    // polling every 5 min keeps the "last updated" timestamp fresh
    // and picks up new rates quickly when they publish.
    _refreshTimer =
        Timer.periodic(const Duration(minutes: 5), (_) => _fetchRates());
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _refreshTimer?.cancel();
    _breathe.dispose();
    _draw.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  // ============================================================
  // Frankfurter API integration
  //   Endpoint: https://api.frankfurter.app
  //   Docs:     https://www.frankfurter.app/docs/
  //   Free, no API key, no rate limit (fair use).
  //   Source: European Central Bank reference rates.
  // ============================================================
  Future<void> _fetchRates() async {
    // Only show the full-card loading spinner on the very first
    // fetch. Subsequent background refreshes keep showing the
    // previous data so the UI doesn't blink.
    final bool firstLoad = _rates.isEmpty;
    if (firstLoad) {
      setState(() {
        _isLoading = true;
        _errorMessage = '';
      });
    }
    try {
      final client = HttpClient()
        ..connectionTimeout = const Duration(seconds: 10);

      // ─── 1. Timeseries — last 21 calendar days ────────────────
      //    We ask for a wider window than 14 because the ECB
      //    doesn't publish on weekends/EU holidays. From the
      //    returned points we keep only the last 14.
      final now = DateTime.now();
      final start = now.subtract(const Duration(days: 21));
      final histUri = Uri.parse(
        'https://api.frankfurter.app'
        '/${_fmtDate(start)}..${_fmtDate(now)}?from=USD&to=IDR',
      );
      final histReq = await client.getUrl(histUri);
      final histResp = await histReq.close();
      final histBody = await histResp.transform(utf8.decoder).join();
      if (histResp.statusCode != 200) {
        throw Exception('HTTP ${histResp.statusCode}');
      }
      final histData =
          jsonDecode(histBody) as Map<String, dynamic>;
      final histRatesMap =
          (histData['rates'] ?? {}) as Map<String, dynamic>;

      // Parse + sort by date (keys are "YYYY-MM-DD")
      final sortedDates = histRatesMap.keys.toList()..sort();
      final List<double> parsed = [];
      for (final d in sortedDates) {
        final dayData = histRatesMap[d];
        if (dayData is Map<String, dynamic>) {
          final rate = dayData['IDR'];
          if (rate is num) parsed.add(rate.toDouble());
        }
      }

      // ─── 2. Latest — most recent published rate ───────────────
      //    Frankfurter's /latest always returns the most recent
      //    available rate. We append it if it differs from the
      //    timeseries' last entry (so intraday updates show up).
      final latestUri = Uri.parse(
        'https://api.frankfurter.app/latest?from=USD&to=IDR',
      );
      final latestReq = await client.getUrl(latestUri);
      final latestResp = await latestReq.close();
      final latestBody = await latestResp.transform(utf8.decoder).join();
      if (latestResp.statusCode != 200) {
        throw Exception('HTTP ${latestResp.statusCode}');
      }
      final latestData =
          jsonDecode(latestBody) as Map<String, dynamic>;
      final latestRates =
          (latestData['rates'] ?? {}) as Map<String, dynamic>;
      final latestRate = (latestRates['IDR'] as num?)?.toDouble();

      if (latestRate != null) {
        if (parsed.isEmpty ||
            (parsed.last - latestRate).abs() > 0.01) {
          parsed.add(latestRate);
        }
      }

      // Keep only the last 14 entries (sparkline width)
      while (parsed.length > 14) {
        parsed.removeAt(0);
      }

      if (parsed.isEmpty) {
        throw Exception('No rate data returned');
      }

      if (!mounted) return;
      setState(() {
        _rates = parsed;
        _isLoading = false;
        _errorMessage = '';
        _lastUpdated = DateTime.now();
      });

      // Re-trigger the draw-in animation on each successful fetch
      _draw
        ..reset()
        ..forward();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Gagal memuat data kurs';
        _isLoading = false;
      });
    }
  }

  /// Format a DateTime as YYYY-MM-DD for Frankfurter URLs.
  String _fmtDate(DateTime d) {
    final y = d.year.toString();
    final m = d.month.toString().padLeft(2, '0');
    final day = d.day.toString().padLeft(2, '0');
    return '$y-$m-$day';
  }

  double get _current => _rates.isNotEmpty ? _rates.last : 0;
  double get _prev =>
      _rates.length > 1 ? _rates[_rates.length - 2] : _current;
  double get _delta => _current - _prev;
  double get _deltaPct => _prev > 0 ? (_delta / _prev) * 100 : 0;
  double get _high => _rates.isNotEmpty ? _rates.reduce(math.max) : 0;
  double get _low => _rates.isNotEmpty ? _rates.reduce(math.min) : 0;

  /// Format an integer IDR value with thousand separators.
  String _fmtIdr(double v) {
    final s = v.round().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  /// Short "HH:MM" label for the last-successful fetch.
  String get _lastUpdatedLabel {
    if (_lastUpdated == null) return '';
    final h = _lastUpdated!.hour.toString().padLeft(2, '0');
    final m = _lastUpdated!.minute.toString().padLeft(2, '0');
    return 'UPDATE $h:$m';
  }

  @override
  Widget build(BuildContext context) {
    // ─── Compact blue-glow palette (sibling of Words of the Day) ──
    Color blueCrystal = Color(0xFFE3EEFB);
    Color blueAqua = Color(0xFFD1E0F4);
    Color blueMist = Color(0xFFB6CCE6);
    Color blueDeep = Color(0xFF5F8FD0);
    Color blueAccent = Color(0xFF2F6ABF);
    Color blueInk = Color(0xFF0F1E45);
    Color blueInkSoft = Color(0xFF28406F);
    Color glowCore = Color(0xFFFFFFFF);

    final bool isUp = _delta >= 0;
    final bool hasData = _rates.isNotEmpty;

    return AnimatedBuilder(
      animation: _breathe,
      builder: (context, _) {
        final breath = 0.5 + 0.5 * _breathe.value;
        return Container(
          // ─── Outer halo — breathing blue glow ─────────────────
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: blueAccent.withOpacity(0.28 + 0.14 * breath),
                blurRadius: 18 + 6 * breath,
                spreadRadius: 1,
                offset: Offset(0, 6),
              ),
              BoxShadow(
                color: blueDeep.withOpacity(0.22 + 0.12 * breath),
                blurRadius: 30 + 10 * breath,
                spreadRadius: 2,
              ),
              BoxShadow(
                color: blueMist.withOpacity(0.22),
                blurRadius: 12,
                spreadRadius: 0,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.18),
                blurRadius: 8,
                spreadRadius: 0,
              ),
            ],
          ),
          child: Container(
            // ─── Border — clear purple glass gradient ─────────────
            padding: const EdgeInsets.all(1.2),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.white.withOpacity(0.88),
                  blueCrystal.withOpacity(0.72),
                  blueAqua.withOpacity(0.62),
                  blueCrystal.withOpacity(0.72),
                  Colors.white.withOpacity(0.88),
                ],
                stops: const [0.0, 0.25, 0.5, 0.75, 1.0],
              ),
            ),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.fromLTRB(16, 14, 16, 14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(17),
                gradient: RadialGradient(
                  center: Alignment(-0.5 + 0.15 * breath,
                      -0.7 + 0.15 * breath),
                  radius: 1.25,
                  colors: [
                    glowCore.withOpacity(0.92),
                    blueCrystal.withOpacity(0.95),
                    blueAqua.withOpacity(0.88),
                    blueMist.withOpacity(0.70),
                  ],
                  stops: const [0.0, 0.40, 0.75, 1.0],
                ),
                border: Border.all(
                  color: Colors.white.withOpacity(0.70),
                  width: 0.8,
                ),
              ),
              child: Stack(
                children: [
                  // ─── Inner hairline ring ──────────────────────────
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Padding(
                        padding: const EdgeInsets.all(5),
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.50),
                              width: 0.5,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  // ─── Top sheen ────────────────────────────────────
                  Positioned(
                    top: 0,
                    left: 12,
                    right: 12,
                    height: 1.4,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              Colors.white.withOpacity(0.90),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // ─── Bottom edge highlight ────────────────────────
                  Positioned(
                    bottom: 0,
                    left: 20,
                    right: 20,
                    height: 1,
                    child: IgnorePointer(
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              blueDeep.withOpacity(0.32),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  // ─── Content (with loading / error / loaded states) ─
                  _isLoading
                      ? _buildLoadingBody(blueInk, blueInkSoft, blueAccent)
                      : _errorMessage.isNotEmpty && !hasData
                          ? _buildErrorBody(
                              blueInk, blueInkSoft, blueAccent, blueDeep)
                          : _buildLoadedBody(
                              blueInk,
                              blueInkSoft,
                              blueAccent,
                              blueDeep,
                              blueMist,
                              isUp,
                              hasData,
                            ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ============================================================
  // BODY BUILDERS — loading / error / loaded states
  // Each returns the inner Column that sits inside the crystal
  // panel. Header (icon + "USD → IDR" + "14 HARI" chip) is shared
  // across all three via _buildHeader().
  // ============================================================

  Widget _buildHeader(Color ink, Color accent, Color deep) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Container(
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [accent, deep],
                ),
                boxShadow: [
                  BoxShadow(
                    color: accent.withOpacity(0.45),
                    blurRadius: 6,
                    spreadRadius: 0,
                  ),
                ],
              ),
              child: const Icon(
                Icons.attach_money_rounded,
                color: Colors.white,
                size: 13,
              ),
            ),
            const SizedBox(width: 7),
            Text(
              'USD → IDR',
              style: TextStyle(
                color: ink,
                fontSize: 11,
                fontWeight: FontWeight.w800,
                fontFamily: 'Orbitron',
                letterSpacing: 0.6,
              ),
            ),
          ],
        ),
        Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
          decoration: BoxDecoration(
            color: deep.withOpacity(0.18),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: deep.withOpacity(0.45),
              width: 0.6,
            ),
          ),
          child: Text(
            '14 HARI',
            style: TextStyle(
              color: deep,
              fontSize: 8.5,
              fontWeight: FontWeight.w700,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1.2,
            ),
          ),
        ),
      ],
    );
  }

  /// Loading state — show header + a soft shimmer block in place
  /// of the chart area + placeholder stat chips.
  Widget _buildLoadingBody(Color ink, Color inkSoft, Color accent) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildHeader(ink, accent, accent),
        const SizedBox(height: 10),
        Text(
          'Memuat kurs live…',
          style: TextStyle(
            color: inkSoft,
            fontSize: 10.5,
            fontWeight: FontWeight.w600,
            fontFamily: 'ShareTechMono',
            letterSpacing: 0.5,
          ),
        ),
        const SizedBox(height: 12),
        // Shimmer placeholder for the chart
        Container(
          height: 78,
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                accent.withOpacity(0.08),
                accent.withOpacity(0.18),
                accent.withOpacity(0.08),
              ],
              stops: const [0.0, 0.5, 1.0],
            ),
          ),
          child: Center(
            child: SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(
                  accent.withOpacity(0.7),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 14),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 14,
              height: 0.8,
              color: accent.withOpacity(0.55),
            ),
            const SizedBox(width: 6),
            Text(
              'SUMBER: ECB · FRANKFURTER.APP',
              style: TextStyle(
                color: inkSoft.withOpacity(0.85),
                fontSize: 8.5,
                letterSpacing: 1.8,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(width: 6),
            Container(
              width: 14,
              height: 0.8,
              color: accent.withOpacity(0.55),
            ),
          ],
        ),
      ],
    );
  }

  /// Error state (no data yet) — show header + error message +
  /// a retry button.
  Widget _buildErrorBody(
      Color ink, Color inkSoft, Color accent, Color deep) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildHeader(ink, accent, deep),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: Colors.red.withOpacity(0.10),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: Colors.red.withOpacity(0.35),
              width: 0.7,
            ),
          ),
          child: Row(
            children: [
              Icon(
                Icons.error_outline_rounded,
                color: Colors.red.shade700,
                size: 14,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  _errorMessage,
                  style: TextStyle(
                    color: Colors.red.shade800,
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            GestureDetector(
              onTap: _fetchRates,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: LinearGradient(
                    colors: [accent, deep],
                  ),
                  border: Border.all(
                    color: accent.withOpacity(0.6),
                    width: 0.9,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: accent.withOpacity(0.35),
                      blurRadius: 8,
                      spreadRadius: 0,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.refresh_rounded,
                      color: Colors.white,
                      size: 13,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      'COBA LAGI',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 14,
              height: 0.8,
              color: accent.withOpacity(0.55),
            ),
            const SizedBox(width: 6),
            Text(
              'SUMBER: ECB · FRANKFURTER.APP',
              style: TextStyle(
                color: inkSoft.withOpacity(0.85),
                fontSize: 8.5,
                letterSpacing: 1.8,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(width: 6),
            Container(
              width: 14,
              height: 0.8,
              color: accent.withOpacity(0.55),
            ),
          ],
        ),
      ],
    );
  }

  /// Loaded state — show header, big rate + delta, sparkline,
  /// stats row, and a footer with last-updated time + source.
  Widget _buildLoadedBody(
    Color ink,
    Color inkSoft,
    Color accent,
    Color deep,
    Color mist,
    bool isUp,
    bool hasData,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildHeader(ink, accent, deep),
        const SizedBox(height: 10),

        // ─── Big rate + delta row ──────────────────────────────
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              'Rp ${_fmtIdr(_current)}',
              style: TextStyle(
                color: ink,
                fontSize: 19,
                fontWeight: FontWeight.w800,
                fontFamily: 'Orbitron',
                height: 1.0,
                letterSpacing: 0.3,
                shadows: const [
                  Shadow(
                    color: Color(0x22FFFFFF),
                    blurRadius: 3,
                    offset: Offset(0, 1),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Padding(
              padding: const EdgeInsets.only(bottom: 2),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 6, vertical: 2.5),
                decoration: BoxDecoration(
                  color: (isUp ? Colors.green : Colors.red)
                      .withOpacity(0.16),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color:
                        (isUp ? Colors.green : Colors.red)
                            .withOpacity(0.55),
                    width: 0.7,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isUp
                          ? Icons.arrow_drop_up_rounded
                          : Icons.arrow_drop_down_rounded,
                      color: isUp
                          ? Colors.green.shade700
                          : Colors.red.shade700,
                      size: 13,
                    ),
                    Text(
                      '${isUp ? '+' : ''}${_delta.toStringAsFixed(0)}  (${_deltaPct.toStringAsFixed(2)}%)',
                      style: TextStyle(
                        color: isUp
                            ? Colors.green.shade800
                            : Colors.red.shade800,
                        fontSize: 9.5,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'ShareTechMono',
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        // ─── Sparkline chart ───────────────────────────────────
        AnimatedBuilder(
          animation: _draw,
          builder: (context, _) {
            return SizedBox(
              height: 78,
              width: double.infinity,
              child: CustomPaint(
                painter: _UsdIdrChartPainter(
                  rates: _rates,
                  progress: _draw.value,
                  lineColor: accent,
                  glowColor: mist,
                  fillColor: accent,
                  gridColor: deep.withOpacity(0.18),
                  dotColor: accent,
                  dotGlow: mist,
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 10),

        // ─── Stats row: high / low / avg ───────────────────────
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildStatChip(
              label: 'TINGGI',
              value: 'Rp ${_fmtIdr(_high)}',
              chipColor: Colors.green.withOpacity(0.14),
              textColor: Colors.green.shade800,
              borderColor: Colors.green.withOpacity(0.45),
            ),
            _buildStatChip(
              label: 'RENDAH',
              value: 'Rp ${_fmtIdr(_low)}',
              chipColor: Colors.red.withOpacity(0.14),
              textColor: Colors.red.shade800,
              borderColor: Colors.red.withOpacity(0.45),
            ),
            _buildStatChip(
              label: 'RATA-RATA',
              value:
                  'Rp ${_fmtIdr(_rates.reduce((a, b) => a + b) / _rates.length)}',
              chipColor: deep.withOpacity(0.14),
              textColor: inkSoft,
              borderColor: deep.withOpacity(0.45),
            ),
          ],
        ),
        const SizedBox(height: 10),

        // ─── Footer: live source + last-updated timestamp ─────
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 14,
              height: 0.8,
              color: accent.withOpacity(0.55),
            ),
            const SizedBox(width: 6),
            // Live dot — pulses softly using the existing _breathe
            // controller to signal that data is real-time.
            AnimatedBuilder(
              animation: _breathe,
              builder: (context, _) {
                final v = 0.5 + 0.5 * _breathe.value;
                return Container(
                  width: 5,
                  height: 5,
                  margin: const EdgeInsets.symmetric(horizontal: 2),
                  decoration: BoxDecoration(
                    color: Colors.greenAccent.withOpacity(v),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color:
                            Colors.greenAccent.withOpacity(v * 0.6),
                        blurRadius: 4,
                        spreadRadius: 0,
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(width: 4),
            Text(
              _lastUpdatedLabel.isNotEmpty
                  ? '${_lastUpdatedLabel} · ECB LIVE'
                  : 'SUMBER: ECB · FRANKFURTER.APP',
              style: TextStyle(
                color: inkSoft.withOpacity(0.85),
                fontSize: 8.5,
                letterSpacing: 1.6,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(width: 6),
            Container(
              width: 14,
              height: 0.8,
              color: accent.withOpacity(0.55),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildStatChip({
    required String label,
    required String value,
    required Color chipColor,
    required Color textColor,
    required Color borderColor,
  }) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 2),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
        decoration: BoxDecoration(
          color: chipColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: borderColor, width: 0.6),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                color: textColor.withOpacity(0.75),
                fontSize: 7.5,
                fontWeight: FontWeight.w700,
                fontFamily: 'ShareTechMono',
                letterSpacing: 1.0,
              ),
            ),
            const SizedBox(height: 1),
            Text(
              value,
              style: TextStyle(
                color: textColor,
                fontSize: 9.5,
                fontWeight: FontWeight.w800,
                fontFamily: 'Orbitron',
                letterSpacing: 0.2,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

/// Sparkline painter for the USD→IDR chart. Draws:
///  - subtle horizontal grid lines
///  - smooth bezier curve through the rate points
///  - gradient fill under the curve
///  - a pulsing dot at the latest point
///  - subtle outer glow around the line
class _UsdIdrChartPainter extends CustomPainter {
  final List<double> rates;
  final double progress; // 0..1 — animated draw-in
  final Color lineColor;
  final Color glowColor;
  final Color fillColor;
  final Color gridColor;
  final Color dotColor;
  final Color dotGlow;

  _UsdIdrChartPainter({
    required this.rates,
    required this.progress,
    required this.lineColor,
    required this.glowColor,
    required this.fillColor,
    required this.gridColor,
    required this.dotColor,
    required this.dotGlow,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (rates.length < 2) return;
    final w = size.width;
    final h = size.height;
    final padTop = 6.0;
    final padBottom = 6.0;
    final padLeft = 4.0;
    final padRight = 4.0;
    final chartW = w - padLeft - padRight;
    final chartH = h - padTop - padBottom;

    // Find min/max with a little padding so the line doesn't touch edges.
    final minV = rates.reduce(math.min);
    final maxV = rates.reduce(math.max);
    final range = (maxV - minV).clamp(1.0, double.infinity);
    final paddedMin = minV - range * 0.12;
    final paddedMax = maxV + range * 0.12;
    final paddedRange = paddedMax - paddedMin;

    // Map each rate to (x, y).
    final points = <Offset>[];
    for (int i = 0; i < rates.length; i++) {
      final x = padLeft + (chartW * i) / (rates.length - 1);
      final y = padTop +
          chartH *
              (1 - (rates[i] - paddedMin) / paddedRange);
      points.add(Offset(x, y));
    }

    // ─── Subtle horizontal grid lines (3 lines) ────────────────
    final gridPaint = Paint()
      ..color = gridColor
      ..strokeWidth = 0.5;
    for (int i = 0; i <= 2; i++) {
      final y = padTop + chartH * (i / 2);
      canvas.drawLine(
        Offset(padLeft, y),
        Offset(w - padRight, y),
        gridPaint,
      );
    }

    // ─── Build a smooth path (Catmull-Rom-ish bezier) ──────────
    // The path is truncated by `progress` so the line "draws in".
    final visibleCount =
        (rates.length * progress).ceil().clamp(2, rates.length);
    final path = Path()..moveTo(points[0].dx, points[0].dy);
    for (int i = 1; i < visibleCount; i++) {
      final p0 = points[i - 1];
      final p1 = points[i];
      // Mid-point smoothing: control points are mid-segments.
      final midX = (p0.dx + p1.dx) / 2;
      path.cubicTo(
        midX,
        p0.dy,
        midX,
        p1.dy,
        p1.dx,
        p1.dy,
      );
    }

    // ─── Fill under the curve ──────────────────────────────────
    final fillPath = Path()
      ..moveTo(points[0].dx, h - padBottom)
      ..addPath(path, Offset.zero)
      ..lineTo(points[visibleCount - 1].dx, h - padBottom)
      ..close();
    final fillPaint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          fillColor.withOpacity(0.42),
          fillColor.withOpacity(0.10),
          fillColor.withOpacity(0.0),
        ],
        stops: const [0.0, 0.6, 1.0],
      ).createShader(Rect.fromLTWH(0, 0, w, h));
    canvas.drawPath(fillPath, fillPaint);

    // ─── Outer glow under the line ─────────────────────────────
    final glowPaint = Paint()
      ..color = glowColor.withOpacity(0.40)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5.0
      ..strokeCap = StrokeCap.round
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0);
    canvas.drawPath(path, glowPaint);

    // ─── The line itself ───────────────────────────────────────
    final linePaint = Paint()
      ..color = lineColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(path, linePaint);

    // ─── Latest-point pulsing dot ──────────────────────────────
    if (progress >= 0.95) {
      final last = points.last;
      // Soft glow ring
      final ringPaint = Paint()
        ..color = dotGlow.withOpacity(0.45)
        ..style = PaintingStyle.fill
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4.0);
      canvas.drawCircle(last, 7, ringPaint);
      // Solid dot
      final dotPaint = Paint()
        ..color = dotColor
        ..style = PaintingStyle.fill;
      canvas.drawCircle(last, 3.2, dotPaint);
      // White inner highlight
      final hiPaint = Paint()
        ..color = Colors.white.withOpacity(0.85)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(last.translate(-0.7, -0.7), 1.0, hiPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _UsdIdrChartPainter oldDelegate) =>
      oldDelegate.progress != progress ||
      oldDelegate.lineColor != lineColor;
}

// ============================================================
// FLOATING BOTTOM NAV — glass-panel navigation bar with a
// glowing capsule indicator that morphs across menu items.
// Refined: tighter proportions, smoother glow, frosted top
// highlight, and a built-in dismiss button.
// ============================================================
class _NavItemData {
  final IconData icon;
  final String label;
  const _NavItemData(this.icon, this.label);
}

class _FloatingBottomNav extends StatefulWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;
  final VoidCallback onHide;
  final Color bgDark;
  final Color primaryPurple;
  final Color accentPurple;
  final Color lightPurple;
  final Color glowMagenta;
  final Color glowIndigo;
  final Color cardGlass;
  final Color borderGlass;
  final Color accentGrey;
  final double bottomPadding;

  const _FloatingBottomNav({
    required this.currentIndex,
    required this.onTap,
    required this.onHide,
    required this.bgDark,
    required this.primaryPurple,
    required this.accentPurple,
    required this.lightPurple,
    required this.glowMagenta,
    required this.glowIndigo,
    required this.cardGlass,
    required this.borderGlass,
    required this.accentGrey,
    required this.bottomPadding,
  });

  @override
  State<_FloatingBottomNav> createState() => _FloatingBottomNavState();
}

class _FloatingBottomNavState extends State<_FloatingBottomNav>
    with TickerProviderStateMixin {
  // Pulse controller dipertahankan agar indikator kapsul tetap hidup,
  // tapi amplitudonya diperkecil agar TIDAK terlihat seperti glow
  // berlebihan. Shimmer controller dihapus — efek sapuan cahaya
  // sebelumnya membuat bar terlihat "rame" dan kurang rapi.
  late final AnimationController _pulseController;
  int? _pressedIndex;

    static const List<_NavItemData> _items = [
      _NavItemData(Icons.home_rounded, "Home"),
      _NavItemData(FontAwesomeIcons.whatsapp, "WhatsApp"),
      _NavItemData(Icons.chat_bubble_rounded, "Chat"),
      _NavItemData(Icons.handyman_rounded, "Tools"),
    ];

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: Duration(seconds: 3),
    )..repeat(reverse: true);
    AppThemeController.instance.addListener(_onThemeChanged);
  }

  void _onThemeChanged() => mounted ? setState(() {}) : null;

  @override
  void dispose() {
    AppThemeController.instance.removeListener(_onThemeChanged);
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(14, 0, 14, 8 + widget.bottomPadding),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Grabber + close row
            _buildGrabber(),
            SizedBox(height: 8),
            Container(
              height: 62,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(26),
                // Solid dark gradient, tidak transparan agar terlihat rapi
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFF150A2E),
                    Color(0xFF0E0720),
                  ],
                ),
                border: Border.all(
                    color: AppThemeController.instance.borderGlass.withOpacity(0.85), width: 1.0),
                // Shadow netral tipis, BUKAN glow ungu tebal
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x55000000),
                    blurRadius: 18,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(26),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      // Top edge highlight tipis, agar terlihat seperti
                      // inset ring — bukan glow.
                      Positioned(
                        top: 0,
                        left: 12,
                        right: 12,
                        height: 1,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.transparent,
                                Colors.white.withOpacity(0.10),
                                Colors.transparent,
                              ],
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(5),
                        child: LayoutBuilder(
                          builder: (context, constraints) {
                            final double itemWidth =
                                constraints.maxWidth / _items.length;
                            return Stack(
                              children: [
                                // Active capsule that slides between items
                                AnimatedPositioned(
                                  duration: const Duration(milliseconds: 320),
                                  curve: Curves.easeOutCubic,
                                  left: itemWidth * widget.currentIndex,
                                  top: 0,
                                  bottom: 0,
                                  width: itemWidth,
                                  child: AnimatedBuilder(
                                    animation: _pulseController,
                                    builder: (context, _) {
                                      // Pulse halus: 0.85..1.0 saja, bukan
                                      // glow besar yang berkedip.
                                      final double pulse = 0.85 +
                                          0.15 *
                                              (0.5 +
                                                  0.5 *
                                                      math.sin(
                                                          _pulseController
                                                              .value *
                                                              2 *
                                                              math.pi));
                                      return Container(
                                        margin: EdgeInsets.symmetric(
                                            horizontal: 4),
                                        decoration: BoxDecoration(
                                          borderRadius:
                                              BorderRadius.circular(20),
                                          // Solid purple gradient (smooth),
                                          // bukan denganOpacity glow.
                                          gradient: LinearGradient(
                                            begin: Alignment.topLeft,
                                            end: Alignment.bottomRight,
                                            colors: [
                                              AppThemeController.instance.primaryPurple,
                                              AppThemeController.instance.glowIndigo,
                                            ],
                                          ),
                                          border: Border.all(
                                            color: AppThemeController.instance.accentPurple
                                                .withOpacity(0.55),
                                            width: 1.0,
                                          ),
                                          // Shadow purple halus, opacity rendah
                                          // (bukan glow tebal magenta+indigo).
                                          boxShadow: [
                                            BoxShadow(
                                              color: AppThemeController.instance.accentPurple
                                                  .withOpacity(
                                                      0.20 * pulse),
                                              blurRadius: 12,
                                              spreadRadius: 0,
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                // Nav items
                                Row(
                                  children: List.generate(
                                    _items.length,
                                    (index) =>
                                        Expanded(child: _buildItem(index)),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Small grabber pill + close button. Versi rapi: tidak ada pulsing
  // opacity yang membuat grabber "berkedip". Cukup statis dengan warna
  // solid ringan.
  Widget _buildGrabber() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: widget.onHide,
          child: Container(
            width: 38,
            height: 4,
            decoration: BoxDecoration(
              color: AppThemeController.instance.lightPurple.withOpacity(0.55),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildItem(int index) {
    final bool isSelected = widget.currentIndex == index;
    final bool isPressed = _pressedIndex == index;
    final item = _items[index];

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _pressedIndex = index),
      onTapCancel: () => setState(() => _pressedIndex = null),
      onTapUp: (_) => setState(() => _pressedIndex = null),
      onTap: () {
        HapticFeedback.selectionClick();
        widget.onTap(index);
      },
      child: AnimatedScale(
        scale: isPressed ? 0.90 : (isSelected ? 1.05 : 1.0),
        duration: const Duration(milliseconds: 140),
        curve: Curves.easeOut,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            AnimatedSwitcher(
              duration: Duration(milliseconds: 220),
              transitionBuilder: (child, anim) {
                return ScaleTransition(scale: anim, child: child);
              },
              child: Icon(
                item.icon,
                key: ValueKey<bool>(isSelected),
                size: isSelected ? 21 : 18,
                color: isSelected ? Colors.white : AppThemeController.instance.accentGrey,
                // Icon glow dihapus — sebelumnya punya shadow putih
                // ber-pulse yang membuat icon "menyala". Sekarang
                // bersih, hanya warna putih solid.
              ),
            ),
            SizedBox(height: 3),
            AnimatedDefaultTextStyle(
              duration: Duration(milliseconds: 260),
              style: TextStyle(
                color: isSelected ? Colors.white : AppThemeController.instance.accentGrey,
                fontSize: isSelected ? 10.5 : 9.5,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                letterSpacing: 0.2,
              ),
              child: Text(item.label),
            ),
          ],
        ),
      ),
    );
  }
}

// ============================================================
// SWIPE UP HANDLE — persistent, slim pill anchored to the
// bottom edge. Tapping or swiping up on it reveals the nav.
// ============================================================
class _SwipeUpHandle extends StatefulWidget {
  final VoidCallback onTap;
  final Color accentPurple;
  final Color lightPurple;
  final double bottomPadding;

  const _SwipeUpHandle({
    required this.onTap,
    required this.accentPurple,
    required this.lightPurple,
    required this.bottomPadding,
  });

  @override
  State<_SwipeUpHandle> createState() => _SwipeUpHandleState();
}

class _SwipeUpHandleState extends State<_SwipeUpHandle>
    with SingleTickerProviderStateMixin {
  // Animation dipertahankan hanya untuk bob vertikal halus (agar
  // pengguna tahu ini interaktif). Pulsing glow dihilangkan agar
  // handle tidak terlihat seperti lampu berkedip.
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _controller.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          final t = _controller.value;
          // Bob vertikal halus (-2..0 px) — sinyal interaktif minimal.
          final double offsetY = -2 * (0.5 + 0.5 * math.sin(t * 2 * math.pi));
          return Padding(
            padding: EdgeInsets.only(bottom: 6 + widget.bottomPadding),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Transform.translate(
                  offset: Offset(0, offsetY),
                  child: Icon(
                    Icons.keyboard_arrow_up_rounded,
                    color: AppThemeController.instance.lightPurple.withOpacity(0.75),
                    size: 16,
                  ),
                ),
                SizedBox(height: 2),
                Container(
                  width: 44,
                  height: 4,
                  decoration: BoxDecoration(
                    // Solid light purple, TANPA boxShadow glow.
                    color: AppThemeController.instance.lightPurple.withOpacity(0.70),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

// ============================================================
// _HubItem — value type used by the unified Community Hub selector.
// Each entry bundles a logo icon, label, expanded title/description,
// CTA button label, the accent / glow colors for the light-glow
// treatment, and the callback to run when the CTA is tapped.
// ============================================================
class _HubItem {
  final IconData icon;
  final String label;
  final String title;
  final String description;
  final String actionLabel;
  final Color iconColor;
  final Color glowColor;
  final VoidCallback onTap;

  const _HubItem({
    required this.icon,
    required this.label,
    required this.title,
    required this.description,
    required this.actionLabel,
    required this.iconColor,
    required this.glowColor,
    required this.onTap,
  });
}

// ============================================================
// CLEAR MILKY GLOW PURPLE — BUTTON KIT
// Empat tipe tombol reusable yang membungkus widget apa pun (icon,
// label, container, dsb) dan menambahkan animasi interaksinya
// sendiri saat ditekan, tanpa mengubah tampilan konten di dalamnya.
// ============================================================

/// 3D BUTTON — memberi efek "keycap" fisik: tombol punya alas solid
/// di bawahnya dan akan turun/tenggelam ke alas itu saat ditekan,
/// lalu kembali naik saat dilepas.
class Button3D extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color baseColor;
  final double depth;
  final BorderRadius borderRadius;

  const Button3D({
    super.key,
    required this.child,
    required this.onTap,
    required this.baseColor,
    this.depth = 5,
    this.borderRadius = const BorderRadius.all(Radius.circular(16)),
  });

  @override
  State<Button3D> createState() => _Button3DState();
}

class _Button3DState extends State<Button3D> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (widget.onTap == null) return;
    setState(() => _pressed = value);
  }

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
  }

  void _onThemeChanged() => mounted ? setState(() {}) : null;

  @override
  void dispose() {
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) {
        _setPressed(true);
        HapticFeedback.lightImpact();
      },
      onTapCancel: () => _setPressed(false),
      onTapUp: (_) => _setPressed(false),
      onTap: widget.onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        margin: EdgeInsets.only(top: _pressed ? widget.depth : 0),
        decoration: BoxDecoration(
          borderRadius: widget.borderRadius,
          boxShadow: _pressed
              ? const []
              : [
                  BoxShadow(
                    color: widget.baseColor.withOpacity(0.9),
                    offset: Offset(0, widget.depth),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.35),
                    offset: Offset(0, widget.depth + 2),
                    blurRadius: 8,
                  ),
                ],
        ),
        child: widget.child,
      ),
    );
  }
}

/// SLIME ANIMATED BUTTON — memberi efek kenyal/jelly: saat ditekan,
/// tombol "meregang" secara horizontal lalu memantul kembali seperti
/// slime, dengan kurva elastis yang halus.
class SlimeButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;

  const SlimeButton({super.key, required this.child, required this.onTap});

  @override
  State<SlimeButton> createState() => _SlimeButtonState();
}

class _SlimeButtonState extends State<SlimeButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scaleX;
  late final Animation<double> _scaleY;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 520),
    );
    _scaleX = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 1.16), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 1.16, end: 0.92), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 0.92, end: 1.05), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 1.05, end: 1.0), weight: 25),
    ]).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _scaleY = TweenSequence<double>([
      TweenSequenceItem(tween: Tween(begin: 1.0, end: 0.84), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 0.84, end: 1.10), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 1.10, end: 0.96), weight: 25),
      TweenSequenceItem(tween: Tween(begin: 0.96, end: 1.0), weight: 25),
    ]).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _controller.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _handleTap() {
    if (widget.onTap == null) return;
    HapticFeedback.mediumImpact();
    _controller.forward(from: 0);
    widget.onTap!();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _handleTap,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scaleX: _scaleX.value,
            scaleY: _scaleY.value,
            child: child,
          );
        },
        child: widget.child,
      ),
    );
  }
}

/// GLOW BUTTON — cahaya ungu di sekeliling tombol berdenyut pelan
/// terus-menerus, dan menyala lebih terang + tombol sedikit mengecil
/// saat ditekan.
class GlowButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final Color glowColor;
  final BorderRadius borderRadius;

  const GlowButton({
    super.key,
    required this.child,
    required this.onTap,
    required this.glowColor,
    this.borderRadius = const BorderRadius.all(Radius.circular(14)),
  });

  @override
  State<GlowButton> createState() => _GlowButtonState();
}

class _GlowButtonState extends State<GlowButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;
  bool _pressed = false;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _pulse.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) {
        if (widget.onTap == null) return;
        setState(() => _pressed = true);
        HapticFeedback.selectionClick();
      },
      onTapCancel: () => setState(() => _pressed = false),
      onTapUp: (_) => setState(() => _pressed = false),
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _pulse,
        builder: (context, child) {
          final glow = 0.35 + 0.35 * _pulse.value;
          return AnimatedScale(
            scale: _pressed ? 0.92 : 1.0,
            duration: const Duration(milliseconds: 120),
            curve: Curves.easeOut,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: widget.borderRadius,
                boxShadow: [
                  BoxShadow(
                    color: widget.glowColor
                        .withOpacity(_pressed ? 0.75 : glow),
                    blurRadius: _pressed ? 26 : 18,
                    spreadRadius: _pressed ? 2 : 1,
                  ),
                ],
              ),
              child: child,
            ),
          );
        },
        child: widget.child,
      ),
    );
  }
}

/// LIQUID BUTTON — gradasi ungu di dalam tombol terus "mengalir"
/// perlahan seperti cairan, dan tombol "memampat" seperti tetesan
/// cair saat ditekan.
class LiquidButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final List<Color> liquidColors;
  final BorderRadius borderRadius;

  const LiquidButton({
    super.key,
    required this.child,
    required this.onTap,
    required this.liquidColors,
    this.borderRadius = const BorderRadius.all(Radius.circular(14)),
  });

  @override
  State<LiquidButton> createState() => _LiquidButtonState();
}

class _LiquidButtonState extends State<LiquidButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _flow;
  double _pressT = 0;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _flow = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void _onThemeChanged() => mounted ? setState(() {}) : null;

  void dispose() {
    _flow.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) {
        if (widget.onTap == null) return;
        setState(() => _pressT = 1);
        HapticFeedback.selectionClick();
      },
      onTapCancel: () => setState(() => _pressT = 0),
      onTapUp: (_) => setState(() => _pressT = 0),
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _flow,
        builder: (context, child) {
          final t = _flow.value;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOut,
            clipBehavior: Clip.antiAlias,
            transform: Matrix4.identity()
              ..scale(1.0 - 0.05 * _pressT, 1.0 + 0.05 * _pressT),
            transformAlignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: widget.borderRadius,
              gradient: LinearGradient(
                begin: Alignment(-1 + 2 * t, -1),
                end: Alignment(1, 1 - 2 * t),
                colors: widget.liquidColors,
              ),
            ),
            child: child,
          );
        },
        child: widget.child,
      ),
    );
  }
}
