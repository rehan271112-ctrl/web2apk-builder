import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class PublicChatPage extends StatefulWidget {
  final String username;
  const PublicChatPage({super.key, required this.username});

  @override
  State<PublicChatPage> createState() => _PublicChatPageState();
}

class _PublicChatPageState extends State<PublicChatPage> {
  final TextEditingController _msgController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<dynamic> _messages = [];
  Timer? _refreshTimer;
  bool _isSending = false;

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchMessages();
    _refreshTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _fetchMessages();
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _msgController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // ==================== API FUNCTIONS ====================
  Future<void> _fetchMessages() async {
    try {
      final res = await http.post(Uri.parse("$baseUrl/get-public-chat"));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          List newMsgs = data['messages'];
          bool shouldScroll = newMsgs.length > _messages.length;
          if (mounted) {
            setState(() => _messages = newMsgs);
            if (shouldScroll) _scrollToBottom();
          }
        }
      }
    } catch (e) {}
  }

  Future<void> _sendMessage() async {
    String text = _msgController.text.trim();
    if (text.isEmpty) return;

    _msgController.clear();
    setState(() => _isSending = true);

    try {
      await http.post(
        Uri.parse("$baseUrl/send-public-chat"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "username": widget.username,
          "message": text,
        }),
      );
      await _fetchMessages();
      _scrollToBottom();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            "Gagal mengirim pesan",
            style: TextStyle(
              color: NeoBrutalismColors.white,
              fontFamily: 'Inter',
              fontWeight: FontWeight.w600,
            ),
          ),
          backgroundColor: NeoBrutalismColors.pink,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  // ==================== CHAT BUBBLE ====================
  Widget _buildChatBubble(dynamic msg, bool isMe) {
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.78,
        ),
        child: Column(
          crossAxisAlignment: isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (!isMe)
              Padding(
                padding: const EdgeInsets.only(left: 12, bottom: 4),
                child: Text(
                  msg['username'] ?? 'Unknown',
                  style: TextStyle(
                    color: NeoBrutalismColors.darkGrey,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    fontFamily: 'Inter',
                  ),
                ),
              ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: isMe ? NeoBrutalismColors.purple : NeoBrutalismColors.white,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(16),
                  topRight: const Radius.circular(16),
                  bottomLeft: Radius.circular(isMe ? 16 : 4),
                  bottomRight: Radius.circular(isMe ? 4 : 16),
                ),
                border: Border.all(
                  color: isMe ? NeoBrutalismColors.purple : NeoBrutalismColors.borderColor,
                  width: isMe ? 2 : 3,
                ),
                boxShadow: [
                  BoxShadow(
                    color: NeoBrutalismColors.black.withOpacity(0.06),
                    offset: const Offset(3, 3),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    msg['message'] ?? '',
                    style: TextStyle(
                      color: isMe ? NeoBrutalismColors.white : NeoBrutalismColors.black,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter',
                    ),
                  ),
                  const SizedBox(height: 4),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Text(
                      msg['time'] ?? '',
                      style: TextStyle(
                        color: isMe
                            ? NeoBrutalismColors.white.withOpacity(0.6)
                            : NeoBrutalismColors.darkGrey,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ==================== INPUT AREA ====================
  Widget _buildInputArea() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.white,
        border: Border(
          top: BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.06),
            offset: const Offset(0, -3),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.grey,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: TextField(
                controller: _msgController,
                style: const TextStyle(
                  color: NeoBrutalismColors.black,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Inter',
                ),
                cursorColor: NeoBrutalismColors.black,
                decoration: InputDecoration(
                  hintText: "Type a message...",
                  hintStyle: TextStyle(
                    color: NeoBrutalismColors.darkGrey.withOpacity(0.6),
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                  ),
                  border: InputBorder.none,
                  contentPadding: const EdgeInsets.symmetric(vertical: 12),
                ),
                onSubmitted: (_) => _sendMessage(),
              ),
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: _isSending ? null : _sendMessage,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _isSending ? NeoBrutalismColors.darkGrey : NeoBrutalismColors.yellow,
                shape: BoxShape.circle,
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: NeoBrutalismColors.black.withOpacity(0.08),
                    offset: const Offset(4, 4),
                    blurRadius: 0,
                  ),
                ],
              ),
              child: Icon(
                _isSending ? Icons.hourglass_top_rounded : Icons.send_rounded,
                color: _isSending ? NeoBrutalismColors.white : NeoBrutalismColors.black,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== HEADER ====================
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.white,
        border: Border(
          bottom: BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.06),
            offset: const Offset(0, 4),
            blurRadius: 0,
          ),
        ],
      ),
      child: Row(
        children: [
          // ===== TITLE (TANPA BACK BUTTON) =====
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: NeoBrutalismColors.purple,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
              boxShadow: [
                BoxShadow(
                  color: NeoBrutalismColors.black.withOpacity(0.08),
                  offset: const Offset(4, 4),
                  blurRadius: 0,
                ),
              ],
            ),
            child: const Icon(
              Icons.chat,
              color: NeoBrutalismColors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Public Chat",
                style: TextStyle(
                  color: NeoBrutalismColors.black,
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                  fontFamily: 'Inter',
                  letterSpacing: 1,
                ),
              ),
              Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.green,
                      shape: BoxShape.circle,
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    "Live • ${_messages.length} messages",
                    style: TextStyle(
                      color: NeoBrutalismColors.darkGrey,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            ],
          ),
          const Spacer(),
          // Refresh button
          GestureDetector(
            onTap: _fetchMessages,
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.grey,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: const Icon(
                Icons.refresh,
                color: NeoBrutalismColors.black,
                size: 18,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== BUILD ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: _messages.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.chat_bubble_outline,
                                color: NeoBrutalismColors.darkGrey.withOpacity(0.3),
                                size: 50,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                "Belum ada pesan",
                                style: TextStyle(
                                  color: NeoBrutalismColors.darkGrey.withOpacity(0.5),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Inter',
                                ),
                              ),
                              Text(
                                "Mulai chat sekarang!",
                                style: TextStyle(
                                  color: NeoBrutalismColors.darkGrey.withOpacity(0.3),
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  fontFamily: 'Inter',
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          controller: _scrollController,
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          itemCount: _messages.length,
                          itemBuilder: (context, index) {
                            final msg = _messages[index];
                            final isMe = msg['username'] == widget.username;
                            return _buildChatBubble(msg, isMe);
                          },
                        ),
                ),
                _buildInputArea(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}