//tes Server untuk cek server
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'landing.dart';

enum _CheckState { idle, scanning, success, failed }

class TesServerPage extends StatefulWidget {
  const TesServerPage({super.key});

  @override
  State<TesServerPage> createState() => _TesServerPageState();
}

class _TesServerPageState extends State<TesServerPage>
    with TickerProviderStateMixin {
  _CheckState _state = _CheckState.idle;
  int _progress = 0;
  Timer? _progressTimer;

  late final AnimationController _pulseController;
  late final AnimationController _scanController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1800),
    )..repeat(reverse: true);

    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();
  }

  @override
  void dispose() {
    _progressTimer?.cancel();
    _pulseController.dispose();
    _scanController.dispose();
    super.dispose();
  }

  Future<void> _startServerCheck() async {
    if (_state == _CheckState.scanning) return;

    setState(() {
      _state = _CheckState.scanning;
      _progress = 0;
    });

    // Progress bar palsu buat feedback visual, jalan bareng request asli.
    _progressTimer?.cancel();
    _progressTimer = Timer.periodic(const Duration(milliseconds: 140), (t) {
      if (!mounted) return;
      setState(() {
        if (_progress < 90) _progress += 3;
      });
    });

    bool success = false;
    try {
      final res = await http
          .get(Uri.parse('$apiBaseUrl/ping'))
          .timeout(const Duration(seconds: 8));
      success = res.statusCode == 200;
    } catch (_) {
      success = false;
    }

    _progressTimer?.cancel();
    if (!mounted) return;

    if (success) {
      setState(() {
        _progress = 100;
        _state = _CheckState.success;
      });
      await Future.delayed(const Duration(milliseconds: 1500));
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const LandingPage()),
      );
    } else {
      setState(() {
        _state = _CheckState.failed;
      });
    }
  }

  // ── Warna & teks dinamis sesuai state ──
  Color get _accentColor {
    switch (_state) {
      case _CheckState.idle:
        return const Color(0xFF29B6F6);
      case _CheckState.scanning:
        return const Color(0xFF22E5F0);
      case _CheckState.success:
        return const Color(0xFF2ECC71);
      case _CheckState.failed:
        return const Color(0xFF29B6F6);
    }
  }

  String get _headerText {
    switch (_state) {
      case _CheckState.idle:
        return "VERIFIKASI SERVER";
      case _CheckState.scanning:
        return "MEMINDAI SERVER...";
      case _CheckState.success:
        return "SERVER TERVERIFIKASI";
      case _CheckState.failed:
        return "VERIFIKASI SERVER";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF060B14),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // --- BACKGROUND: gradient radial gelap ---
          AnimatedContainer(
            duration: const Duration(milliseconds: 500),
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.center,
                radius: 0.9,
                colors: [
                  _accentColor.withOpacity(0.22),
                  const Color(0xFF0B1526),
                  const Color(0xFF060B14),
                ],
                stops: const [0.0, 0.55, 1.0],
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                const Spacer(flex: 3),

                // --- HEADER TEXT ---
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: Text(
                    _headerText,
                    key: ValueKey(_headerText),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _state == _CheckState.failed
                          ? Colors.white38
                          : _accentColor,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 3,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),

                const SizedBox(height: 48),

                // --- LINGKARAN UTAMA (fingerprint / check) ---
                GestureDetector(
                  onTap: () {
                    if (_state == _CheckState.idle ||
                        _state == _CheckState.failed) {
                      _startServerCheck();
                    }
                  },
                  child: _buildScanCircle(),
                ),

                const SizedBox(height: 40),

                // --- LOGO "ZERO" ---
                const Text(
                  "ZeroCrash",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 40,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 4,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  "SOLUSI WHATSAPP & SYSTEM DIGITAL",
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.35),
                    fontSize: 11,
                    letterSpacing: 2,
                    fontFamily: 'Orbitron',
                  ),
                ),

                const Spacer(flex: 3),

                // --- BANNER ERROR (kalau server down) ---
                if (_state == _CheckState.failed) _buildFailedBanner(),

                // --- PILL STATUS BAWAH ---
                if (_state != _CheckState.failed) _buildBottomPill(),

                const SizedBox(height: 36),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Lingkaran scanner utama ──
  Widget _buildScanCircle() {
    if (_state == _CheckState.success) {
      return Container(
        width: 190,
        height: 190,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: _accentColor, width: 2.5),
          boxShadow: [
            BoxShadow(
              color: _accentColor.withOpacity(0.55),
              blurRadius: 40,
              spreadRadius: 4,
            ),
          ],
        ),
        child: Container(
          width: 150,
          height: 150,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: _accentColor.withOpacity(0.6), width: 1.5),
          ),
          child: Container(
            width: 100,
            height: 100,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
            ),
            child: Icon(Icons.check, color: _accentColor, size: 52),
          ),
        ),
      );
    }

    return AnimatedBuilder(
      animation: Listenable.merge([_pulseController, _scanController]),
      builder: (context, _) {
        final pulse = _pulseController.value; // 0..1..0
        final isScanning = _state == _CheckState.scanning;

        return Container(
          width: 190,
          height: 190,
          alignment: Alignment.center,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Ring luar transparan tipis (dekorasi statis)
              Container(
                width: 190,
                height: 190,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: Colors.white.withOpacity(0.06),
                    width: 1,
                  ),
                ),
              ),

              // Ring animasi berputar saat scanning
              if (isScanning)
                Transform.rotate(
                  angle: _scanController.value * 2 * math.pi,
                  child: Container(
                    width: 152,
                    height: 152,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: SweepGradient(
                        colors: [
                          _accentColor.withOpacity(0),
                          _accentColor.withOpacity(0.9),
                        ],
                        startAngle: 0,
                        endAngle: math.pi,
                      ),
                    ),
                    child: Center(
                      child: Container(
                        width: 144,
                        height: 144,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xFF060B14),
                        ),
                      ),
                    ),
                  ),
                ),

              // Border lingkaran utama
              Container(
                width: 148,
                height: 148,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _accentColor, width: 2),
                ),
              ),

              // Isi lingkaran (glow radial biru/cyan)
              Container(
                width: 132,
                height: 132,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      _accentColor.withOpacity(0.9 + 0.1 * pulse),
                      _accentColor.withOpacity(0.35),
                    ],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: _accentColor.withOpacity(0.5 + 0.2 * pulse),
                      blurRadius: 35 + 15 * pulse,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),

              // Icon fingerprint + garis scan horizontal
              ClipOval(
                child: SizedBox(
                  width: 132,
                  height: 132,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      const Icon(
                        Icons.fingerprint,
                        color: Colors.white,
                        size: 68,
                      ),
                      if (isScanning)
                        Positioned(
                          top: 132 * (0.5 + 0.42 * math.sin(_scanController.value * 2 * math.pi)),
                          child: Container(
                            width: 132,
                            height: 2,
                            color: Colors.cyanAccent.withOpacity(0.85),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ── Pill status di bawah (idle / scanning / success) ──
  Widget _buildBottomPill() {
    late final String label;
    late final Widget icon;
    late final Color color;

    switch (_state) {
      case _CheckState.idle:
        label = "Tekan & Tahan Sidik Jari";
        icon = const Text("👆", style: TextStyle(fontSize: 14));
        color = Colors.white24;
        break;
      case _CheckState.scanning:
        label = "Mengidentifikasi Biometrik ($_progress%)";
        icon = Icon(Icons.sensors, color: _accentColor, size: 16);
        color = _accentColor;
        break;
      case _CheckState.success:
        label = "✓ Verifikasi Berhasil!";
        icon = Icon(Icons.check_circle, color: _accentColor, size: 16);
        color = _accentColor;
        break;
      case _CheckState.failed:
        label = "";
        icon = const SizedBox.shrink();
        color = Colors.transparent;
        break;
    }

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 300),
      child: Container(
        key: ValueKey(_state),
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.35),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: color.withOpacity(0.6)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            icon,
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                color: Colors.white.withOpacity(0.85),
                fontSize: 13,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Banner merah kalau server mati ──
  Widget _buildFailedBanner() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
            decoration: BoxDecoration(
              color: Colors.red.withOpacity(0.10),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: Colors.redAccent.withOpacity(0.5)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, color: Colors.redAccent, size: 26),
                const SizedBox(height: 10),
                const Text(
                  "MOHON MAAF SERVER SEDANG DOWN/OFF",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                    fontFamily: 'Orbitron',
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  "Tap ikon di atas untuk coba lagi",
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.4),
                    fontSize: 11,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
