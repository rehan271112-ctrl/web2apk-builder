import 'dart:math' as dart_math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'splash.dart';
import 'dashboard_page.dart';
import 'background_widget.dart';
import 'app_theme.dart';

const String baseUrl = "http://alanwinter.alannxd.my.id:3298";

// ─── METALLIC GRAY THEME COLORS ──────────────────────────────
class _C {
  static const bg          = Color(0xFF0A0900);
  static const surface     = Color(0xFF1A1700);
  static const surface2    = Color(0xFF242000);
  static const surface3    = Color(0xFF2D2800);

  // Kuning – accent utama
  static const gray1       = Color(0xFFFFD600); // kuning terang (accent1)
  static const gray2       = Color(0xFFFFBF00); // kuning medium (accent2)
  static const gray3       = Color(0xFF4A3B00); // kuning gelap (accent3)
  static const gray4       = Color(0xFF1F1800); // latar tombol
  static const silver      = Color(0xFFFFD600); // alias accent utama
  static const silverLight = Color(0xFFFFE566); // kuning muda
  static const silverDark  = Color(0xFFBFA000); // kuning redup
  static const chrome      = Color(0xFFFFEA80); // kuning pucat
  static const error       = Color(0xFFFF1744);
  static const warning     = Color(0xFFFFAB40);
  static const textPrimary = Color(0xFFF5F0CC);
  static const textSec     = Color(0xFFD4C060);
  static const textMuted   = Color(0xFF807040);
  static const shadow      = Color(0x40000000);
  static const shadowHeavy = Color(0x80000000);
}

// ─── LOGIN PAGE ────────────────────────────────────────────────
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);

    initLogin();
  }

  @override
  void dispose() {
    _controller.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey  = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse("$baseUrl/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
      try {
        final res  = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          Navigator.pushReplacement(context, _fadeRoute(SplashScreen(
            username: savedUser, password: savedPass,
            role: (data['role'] ?? '').toString(),
            sessionKey: data['key'], expiredDate: data['expiredDate'],
            listBug:  (data['listBug']   as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
            listDoos: (data['listDDoS']  as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
            news:     (data['news']      as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          )));
        }
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  PageRouteBuilder _fadeRoute(Widget page) => PageRouteBuilder(
    transitionDuration: const Duration(milliseconds: 500),
    pageBuilder: (_, __, ___) => page,
    transitionsBuilder: (_, anim, __, child) =>
        FadeTransition(opacity: anim.drive(Tween(begin: 0.0, end: 1.0).chain(CurveTween(curve: Curves.easeOutCubic))), child: child),
  );

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;
    final username = userController.text.trim();
    final password = passController.text.trim();
    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/validate"),
        body: {"username": username, "password": password, "androidId": androidId ?? "unknown_device"},
      );
      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showPopup(
          title: "⛔ Access Expired",
          message: "Your access has expired.\nPlease renew it.",
          color: AppColors.warning,
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        _showPopup(
          title: "Login Failed",
          message: "Invalid username or password.",
          color: AppColors.error,
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);
        Navigator.pushReplacement(context, _fadeRoute(SplashScreen(
          username: username, password: password,
          role: (validData['role'] ?? '').toString(),
          sessionKey: validData['key'], expiredDate: validData['expiredDate'],
          listBug:  (validData['listBug']   as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          listDoos: (validData['listDDoS']  as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
          news:     (validData['news']      as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
        )));
      }
    } catch (_) {
      _showPopup(
        title: "Connection Error",
        message: "Failed to connect to the server.\nPlease check your internet connection.",
        color: AppColors.error,
      );
    }

    setState(() => isLoading = false);
  }

  void _showPopup({
    required String title,
    required String message,
    Color? color,
    bool showContact = false,
  }) {
    final effectiveColor = color ?? AppColors.accent1;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: effectiveColor.withOpacity(0.4), width: 1.5),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: effectiveColor,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        content: Text(
          message,
          style: TextStyle(color: AppColors.textSec, fontSize: 14),
        ),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () async {
                await launchUrl(
                  Uri.parse("https://t.me/ZennTicXD"),
                  mode: LaunchMode.externalApplication,
                );
              },
              child: Text(
                "Contact Admin",
                style: TextStyle(color: AppColors.accent1),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "Close",
              style: TextStyle(color: AppColors.textMuted),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final themeNotifier = ThemeScope.of(context);
    return AnimatedBuilder(
      animation: themeNotifier,
      builder: (context, _) => Scaffold(
      backgroundColor: Colors.transparent,
      extendBodyBehindAppBar: true,
      body: BackgroundWrapper(
        child: Stack(
        children: [
          // ─── DARK OVERLAY ─────────────────────────────────────
          Container(
            color: Colors.black.withOpacity(0.45),
          ),

          // ─── BLUR OVERLAY ─────────────────────────────────────
          Positioned.fill(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 3, sigmaY: 3),
              child: Container(color: Colors.transparent),
            ),
          ),

          // ─── MAIN CONTENT ─────────────────────────────────────
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // ─── LOGO ─────────────────────────────────────
                      TweenAnimationBuilder<double>(
                        duration: const Duration(milliseconds: 600),
                        tween: Tween(begin: 0.5, end: 1.0),
                        curve: Curves.easeOutBack,
                        builder: (_, v, child) => Transform.scale(scale: v, child: child),
                        child: Container(
                          width: 85,
                          height: 85,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(24),
                            gradient: LinearGradient(
                              colors: [AppColors.accent1, AppColors.accent3, AppColors.accent2],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.accent1.withOpacity(0.4),
                                blurRadius: 30,
                                spreadRadius: 4,
                              ),
                              BoxShadow(
                                color: AppColors.accent3.withOpacity(0.3),
                                blurRadius: 20,
                                spreadRadius: 2,
                              ),
                              BoxShadow(
                                color: Colors.black.withOpacity(0.5),
                                blurRadius: 15,
                              ),
                            ],
                            border: Border.all(
                              color: AppColors.accent1.withOpacity(0.3),
                              width: 2,
                            ),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(24),
                            child: Image.asset(
                              'assets/images/logo.jpg',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),

                      // ─── BRAND NAME ──────────────────────────────
                      TweenAnimationBuilder<double>(
                        duration: const Duration(milliseconds: 600),
                        tween: Tween(begin: 0.0, end: 1.0),
                        curve: Curves.easeOutCubic,
                        builder: (_, v, child) => Opacity(
                          opacity: v,
                          child: Transform.translate(
                            offset: Offset(0, 20 * (1 - v)),
                            child: child,
                          ),
                        ),
                        child: Column(
                          children: [
                            ShaderMask(
                              shaderCallback: (bounds) => LinearGradient(
                                colors: [AppColors.accent2, AppColors.accent1, AppColors.accent2],
                                stops: [0.0, 0.5, 1.0],
                              ).createShader(bounds),
                              child: const Text(
                                "ALICIA",
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white,
                                  letterSpacing: 3,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              "POWERED BY RIZQY AND ALICIA",
                              style: TextStyle(
                                color: AppColors.accent1.withOpacity(0.6),
                                fontSize: 10,
                                letterSpacing: 5,
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 20),

                      // ─── BANNER FOTO (loogin.jpg) ──────────────────
                      ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Image.asset(
                          "assets/images/loogin.jpg",
                          width: double.infinity,
                          height: 140,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            height: 140,
                            color: AppColors.surface2,
                            child: Center(
                              child: Text(
                                "BANNER",
                                style: TextStyle(color: AppColors.textMuted),
                              ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 18),

                      // ─── FORM CARD (Lebih Transparan & Blur) ──────
                      TweenAnimationBuilder<double>(
                        duration: const Duration(milliseconds: 700),
                        tween: Tween(begin: 0.9, end: 1.0),
                        curve: Curves.easeOutCubic,
                        builder: (_, v, child) => Transform.scale(scale: v, child: child),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: BackdropFilter(
                            // ✅ BLUR LEBIH TEBAL (sigma 12)
                            filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                            child: Container(
                              padding: const EdgeInsets.all(20),
                              decoration: BoxDecoration(
                                // ✅ LEBIH TRANSPARAN (0.12 → 0.08)
                                color: Colors.white.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                  color: AppColors.accent1.withOpacity(0.12),
                                  width: 1.2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.accent1.withOpacity(0.06),
                                    blurRadius: 30,
                                    spreadRadius: 2,
                                  ),
                                  BoxShadow(
                                    color: AppColors.accent3.withOpacity(0.04),
                                    blurRadius: 20,
                                  ),
                                  const BoxShadow(
                                    color: AppColors.shadowHeavy,
                                    blurRadius: 15,
                                    offset: Offset(0, 8),
                                  ),
                                ],
                              ),
                              child: Form(
                                key: _formKey,
                                child: Column(
                                  children: [
                                    // ─── USERNAME FIELD ──────────────────
                                    _buildTextField(
                                      controller: userController,
                                      label: "USERNAME",
                                      icon: Icons.person_outline_rounded,
                                    ),
                                    const SizedBox(height: 14),

                                    // ─── PASSWORD FIELD ──────────────────
                                    _buildTextField(
                                      controller: passController,
                                      label: "PASSWORD",
                                      icon: Icons.lock_outline_rounded,
                                      obscureText: _obscurePassword,
                                      isPassword: true,
                                    ),
                                    const SizedBox(height: 20),

                                    // ─── LOGIN BUTTON ────────────────────
                                    SizedBox(
                                      width: double.infinity,
                                      height: 50,
                                      child: _AnimatedLoginButton(
                                        isLoading: isLoading,
                                        onPressed: login,
                                        gradient: LinearGradient(
                                          colors: [AppColors.accent1, AppColors.accent2, AppColors.accent3],
                                          begin: Alignment.centerLeft,
                                          end: Alignment.centerRight,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 16),

                      // ─── FOOTER: ID + Contact Admin ──────────────
                      Column(
                        children: [
                          Text(
                            "ID: ${androidId ?? 'Scanning...'}",
                            style: TextStyle(
                              color: AppColors.accent1.withOpacity(0.5),
                              fontSize: 10,
                              fontFamily: 'monospace',
                            ),
                          ),
                          const SizedBox(height: 6),
                          TextButton(
                            onPressed: () async {
                              await launchUrl(
                                Uri.parse("https://t.me/ZennTicXD"),
                                mode: LaunchMode.externalApplication,
                              );
                            },
                            style: TextButton.styleFrom(
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                              minimumSize: Size.zero,
                              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                            ),
                            child: Text(
                              "No account? Contact admin",
                              style: TextStyle(
                                color: AppColors.accent1.withOpacity(0.7),
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                decoration: TextDecoration.underline,
                                decorationColor: AppColors.accent1.withOpacity(0.3),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
        ),
      ),
    ));
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscureText = false,
    bool isPassword = false,
  }) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(milliseconds: 400),
      tween: Tween(begin: 0.85, end: 1.0),
      curve: Curves.easeOutCubic,
      builder: (_, v, child) => Transform.scale(scale: v, child: child),
      child: TextFormField(
        controller: controller,
        obscureText: obscureText,
        style: TextStyle(
          color: AppColors.textPrimary,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: TextStyle(
            color: AppColors.textSec,
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
          prefixIcon: Icon(icon, color: AppColors.accent1, size: 20),
          suffixIcon: isPassword
              ? IconButton(
                  icon: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: Icon(
                      _obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                      key: ValueKey(_obscurePassword),
                      color: AppColors.textMuted,
                      size: 20,
                    ),
                  ),
                  onPressed: () {
                    HapticFeedback.lightImpact();
                    setState(() => _obscurePassword = !_obscurePassword);
                  },
                )
              : null,
          // ✅ INPUT FIELD LEBIH TRANSPARAN
          filled: true,
          fillColor: Colors.white.withOpacity(0.06),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(
              color: AppColors.accent1.withOpacity(0.10),
              width: 1.2,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(
              color: AppColors.accent1,
              width: 1.8,
            ),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppColors.error, width: 1.5),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppColors.error, width: 2),
          ),
          errorStyle: const TextStyle(
            color: AppColors.error,
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
        validator: (v) => (v == null || v.isEmpty) ? "Please enter $label" : null,
      ),
    );
  }
}

// ─── ANIMATED LOGIN BUTTON ──────────────────────────────────────
class _AnimatedLoginButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onPressed;
  final Gradient gradient;

  const _AnimatedLoginButton({
    required this.isLoading,
    required this.onPressed,
    required this.gradient,
  });

  @override
  State<_AnimatedLoginButton> createState() => _AnimatedLoginButtonState();
}

class _AnimatedLoginButtonState extends State<_AnimatedLoginButton>
    with SingleTickerProviderStateMixin {
  bool _isPressed = false;
  late AnimationController _glowCtrl;
  late Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    super.dispose();
  }

  void _handleTap() {
    if (widget.isLoading) return;
    HapticFeedback.lightImpact();
    setState(() => _isPressed = true);
    Future.delayed(const Duration(milliseconds: 150), () {
      if (mounted) setState(() => _isPressed = false);
      widget.onPressed();
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _glow,
      builder: (_, __) => GestureDetector(
        onTap: _handleTap,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 150),
          scale: _isPressed ? 0.97 : 1.0,
          child: Container(
            decoration: BoxDecoration(
              gradient: widget.gradient,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                  color: AppColors.accent1.withOpacity(0.35 * _glow.value),
                  blurRadius: 25,
                  spreadRadius: 2,
                  offset: const Offset(0, 6),
                ),
                BoxShadow(
                  color: AppColors.accent3.withOpacity(0.20 * _glow.value),
                  blurRadius: 15,
                  spreadRadius: 1,
                  offset: const Offset(0, 4),
                ),
                BoxShadow(
                  color: AppColors.accent1.withOpacity(0.05 * _glow.value),
                  blurRadius: 20,
                  spreadRadius: 0,
                  offset: const Offset(0, 0),
                ),
              ],
              border: Border.all(
                color: AppColors.accent1.withOpacity(0.15),
                width: 1,
              ),
            ),
            child: Center(
              child: widget.isLoading
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : const Text(
                      "LOGIN",
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 3,
                        shadows: [
                          Shadow(color: Colors.black45, blurRadius: 2, offset: Offset(0, 1)),
                        ],
                      ),
                    ),
            ),
          ),
        ),
      ),
    );
  }
}