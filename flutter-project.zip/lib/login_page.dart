import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:ui';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== IMPORT SPLASH ====================
import 'splash.dart';

// ==================== IMPORT BUY ACCOUNT ====================
import 'buy_account.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== ROBOT HEAD WIDGET ====================
class RobotHead extends StatelessWidget {
  final double size;

  const RobotHead({super.key, this.size = 140});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: Size(size, size * 0.95),
      painter: _RobotHeadPainter(),
    );
  }
}

class _RobotHeadPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final scale = size.width / 120;

    final Color robotGreen = Colors.green.shade600;
    final Color robotLightGreen = Colors.green.shade300;

    // ===== KEPALA =====
    final headPaint = Paint()
      ..color = robotLightGreen.withOpacity(0.95)
      ..style = PaintingStyle.fill;

    final headBorder = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5;

    final headRect = Rect.fromCenter(
      center: Offset(center.dx, center.dy + 10 * scale),
      width: 90 * scale,
      height: 72 * scale,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(headRect, Radius.circular(16 * scale)),
      headPaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(headRect, Radius.circular(16 * scale)),
      headBorder,
    );

    // ===== GARIS TENGAH =====
    final linePaint = Paint()
      ..color = Colors.black.withOpacity(0.15)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    canvas.drawLine(
      Offset(center.dx, center.dy - 15 * scale),
      Offset(center.dx, center.dy + 35 * scale),
      linePaint,
    );

    // ===== MATA =====
    final eyeWhitePaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    final eyeBorderPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    final eyeBlackPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.fill;

    canvas.drawCircle(
      Offset(center.dx - 24 * scale, center.dy + 2 * scale),
      14 * scale,
      eyeWhitePaint,
    );
    canvas.drawCircle(
      Offset(center.dx - 24 * scale, center.dy + 2 * scale),
      14 * scale,
      eyeBorderPaint,
    );
    canvas.drawCircle(
      Offset(center.dx - 24 * scale, center.dy + 2 * scale),
      7 * scale,
      eyeBlackPaint,
    );
    canvas.drawCircle(
      Offset(center.dx - 27 * scale, center.dy - 1 * scale),
      3 * scale,
      Paint()..color = Colors.white..style = PaintingStyle.fill,
    );

    canvas.drawCircle(
      Offset(center.dx + 24 * scale, center.dy + 2 * scale),
      14 * scale,
      eyeWhitePaint,
    );
    canvas.drawCircle(
      Offset(center.dx + 24 * scale, center.dy + 2 * scale),
      14 * scale,
      eyeBorderPaint,
    );
    canvas.drawCircle(
      Offset(center.dx + 24 * scale, center.dy + 2 * scale),
      7 * scale,
      eyeBlackPaint,
    );
    canvas.drawCircle(
      Offset(center.dx + 21 * scale, center.dy - 1 * scale),
      3 * scale,
      Paint()..color = Colors.white..style = PaintingStyle.fill,
    );

    // ===== ALIS =====
    final alisPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4;

    canvas.drawLine(
      Offset(center.dx - 38 * scale, center.dy - 16 * scale),
      Offset(center.dx - 10 * scale, center.dy - 16 * scale),
      alisPaint,
    );
    canvas.drawLine(
      Offset(center.dx + 10 * scale, center.dy - 16 * scale),
      Offset(center.dx + 38 * scale, center.dy - 16 * scale),
      alisPaint,
    );

    // ===== MULUT SENYUM =====
    final mouthPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    canvas.drawArc(
      Rect.fromCenter(
        center: Offset(center.dx, center.dy + 24 * scale),
        width: 44 * scale,
        height: 28 * scale,
      ),
      3.14,
      3.14,
      false,
      mouthPaint,
    );

    // ===== GARIS MULUT SAMPING =====
    final smileLinePaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;

    canvas.drawLine(
      Offset(center.dx - 22 * scale, center.dy + 18 * scale),
      Offset(center.dx - 28 * scale, center.dy + 24 * scale),
      smileLinePaint,
    );
    canvas.drawLine(
      Offset(center.dx + 22 * scale, center.dy + 18 * scale),
      Offset(center.dx + 28 * scale, center.dy + 24 * scale),
      smileLinePaint,
    );

    // ===== GIGI =====
    final teethPaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;

    for (int i = -3; i <= 3; i++) {
      canvas.drawRect(
        Rect.fromCenter(
          center: Offset(center.dx + i * 5 * scale, center.dy + 28 * scale),
          width: 3 * scale,
          height: 6 * scale,
        ),
        teethPaint,
      );
    }

    // ===== ANTENA =====
    final antenaPaint = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    canvas.drawLine(
      Offset(center.dx, center.dy - 30 * scale),
      Offset(center.dx, center.dy - 52 * scale),
      antenaPaint,
    );

    canvas.drawCircle(
      Offset(center.dx, center.dy - 52 * scale),
      6 * scale,
      Paint()..color = Colors.red..style = PaintingStyle.fill,
    );
    canvas.drawCircle(
      Offset(center.dx, center.dy - 52 * scale),
      6 * scale,
      Paint()..color = Colors.black..style = PaintingStyle.stroke..strokeWidth = 2.5,
    );

    // ===== BINTIK DI PIPI =====
    final dotPaint = Paint()
      ..color = Colors.black.withOpacity(0.2);

    canvas.drawCircle(
      Offset(center.dx - 40 * scale, center.dy + 14 * scale),
      4 * scale,
      dotPaint,
    );
    canvas.drawCircle(
      Offset(center.dx - 40 * scale, center.dy + 22 * scale),
      4 * scale,
      dotPaint,
    );
    canvas.drawCircle(
      Offset(center.dx - 40 * scale, center.dy + 30 * scale),
      4 * scale,
      dotPaint,
    );

    canvas.drawCircle(
      Offset(center.dx + 40 * scale, center.dy + 14 * scale),
      4 * scale,
      dotPaint,
    );
    canvas.drawCircle(
      Offset(center.dx + 40 * scale, center.dy + 22 * scale),
      4 * scale,
      dotPaint,
    );
    canvas.drawCircle(
      Offset(center.dx + 40 * scale, center.dy + 30 * scale),
      4 * scale,
      dotPaint,
    );

    // ===== BINTIK ATAS KEPALA =====
    final smallDotPaint = Paint()
      ..color = Colors.black.withOpacity(0.12);

    for (int i = 0; i < 5; i++) {
      canvas.drawCircle(
        Offset(center.dx - 30 * scale + i * 15 * scale, center.dy - 32 * scale),
        2 * scale,
        smallDotPaint,
      );
    }

    // ===== TELINGA =====
    final earPaint = Paint()
      ..color = robotGreen.withOpacity(0.8)
      ..style = PaintingStyle.fill;

    final earBorder = Paint()
      ..color = Colors.black
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5;

    final earLeftRect = Rect.fromCenter(
      center: Offset(center.dx - 46 * scale, center.dy + 2 * scale),
      width: 10 * scale,
      height: 30 * scale,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(earLeftRect, Radius.circular(5 * scale)),
      earPaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(earLeftRect, Radius.circular(5 * scale)),
      earBorder,
    );

    final earRightRect = Rect.fromCenter(
      center: Offset(center.dx + 46 * scale, center.dy + 2 * scale),
      width: 10 * scale,
      height: 30 * scale,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(earRightRect, Radius.circular(5 * scale)),
      earPaint,
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(earRightRect, Radius.circular(5 * scale)),
      earBorder,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? androidId;
  
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _shakeController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _shakeAnimation;

  @override
  void initState() {
    super.initState();
    initLogin();

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _shakeController = AnimationController(
      duration: const Duration(seconds: 5),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );

    _shakeAnimation = Tween<double>(begin: -15.0, end: 15.0).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticInOut),
    );

    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _shakeController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "$baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true && mounted) {
          Navigator.pushReplacementNamed(
            context,
            '/splash', 
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listPayload': data['listPayload'] ?? [],
              'listDDoS': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _shakeController.forward(from: 0);
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _shakeController.forward(from: 0);
        _showAlert("⛔ Access Expired", "Your access has expired.\nPlease renew it.", showContact: true);
      } else if (validData['valid'] != true) {
        _shakeController.forward(from: 0);
        _showAlert("🚫 Login Failed", "Invalid username or password.", showContact: true);
      } else {
        await Future.delayed(const Duration(seconds: 2));
        
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacementNamed(
            context,
            '/splash',
            arguments: {
              'username': username,
              'password': password,
              'role': validData['role'],
              'key': validData['key'],
              'expiredDate': validData['expiredDate'],
              'listBug': validData['listBug'] ?? [],
              'listPayload': validData['listPayload'] ?? [],
              'listDDoS': validData['listDDoS'] ?? [],
              'news': validData['news'] ?? [],
            },
          );
        }
      }
    } catch (_) {
      _shakeController.forward(from: 0);
      _showAlert("🌐 Connection Error", "Failed to connect to the server.");
    }

    setState(() => isLoading = false);
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: title.contains("Error") || title.contains("Failed")
                    ? NeoBrutalismColors.pink
                    : title.contains("Expired")
                    ? NeoBrutalismColors.yellow
                    : NeoBrutalismColors.blue,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: Icon(
                title.contains("Error") || title.contains("Failed")
                    ? Icons.error_outline
                    : title.contains("Expired")
                    ? Icons.timer_off
                    : Icons.info_outline,
                color: NeoBrutalismColors.white,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: TextStyle(
            color: NeoBrutalismColors.black.withOpacity(0.7),
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Inter',
          ),
        ),
        actions: [
          if (showContact)
            TextButton.icon(
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=RaldzzXyz");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/Rizzisreal01"),
                      mode: LaunchMode.externalApplication);
                }
              },
              icon: const Icon(Icons.message, size: 16, color: NeoBrutalismColors.white),
              label: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: NeoBrutalismColors.white,
                  fontFamily: 'Inter',
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
              style: TextButton.styleFrom(
                backgroundColor: NeoBrutalismColors.purple,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                  side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: NeoBrutalismColors.yellow,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
              ),
            ),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: NeoBrutalismColors.black,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openTelegramBot() async {
    final uri = Uri.parse("tg://resolve?domain=permen_md");
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      await launchUrl(Uri.parse("https://t.me/Rizzisreal01"),
          mode: LaunchMode.externalApplication);
    }
  }

  void _goToBuyAccount() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const BuyAccountPage(),
      ),
    );
  }

  // ==================== NEOBRUTALISM UI HELPERS ====================
  
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(24),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  Widget _neoInput(String hint, TextEditingController controller, IconData icon,
      {bool isPassword = false}) {
    return TextField(
      controller: controller,
      obscureText: isPassword,
      style: const TextStyle(
        color: NeoBrutalismColors.black,
        fontSize: 15,
        fontWeight: FontWeight.w600,
        fontFamily: 'Inter',
      ),
      cursorColor: NeoBrutalismColors.black,
      decoration: InputDecoration(
        prefixIcon: Icon(
          icon,
          color: NeoBrutalismColors.darkGrey,
          size: 20,
        ),
        hintText: hint,
        hintStyle: TextStyle(
          color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
          fontFamily: 'Inter',
          fontWeight: FontWeight.w600,
        ),
        filled: true,
        fillColor: NeoBrutalismColors.grey,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      ),
    );
  }

  Widget _neoButton({
    required String label,
    required VoidCallback onTap,
    Color bg = NeoBrutalismColors.yellow,
    Color textColor = NeoBrutalismColors.black,
    double fontSize = 16,
    bool isLoading = false,
    bool isOutlined = false,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: isOutlined ? Colors.transparent : bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isOutlined ? NeoBrutalismColors.black : NeoBrutalismColors.borderColor,
            width: isOutlined ? 2 : 3,
          ),
          boxShadow: isOutlined ? null : [
            BoxShadow(
              color: NeoBrutalismColors.black.withOpacity(0.1),
              offset: const Offset(4, 4),
              blurRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(
                  width: 24,
                  height: 24,
                  child: CircularProgressIndicator(
                    color: isOutlined ? NeoBrutalismColors.black : textColor,
                    strokeWidth: 2.5,
                  ),
                )
              : Text(
                  label,
                  style: TextStyle(
                    fontSize: fontSize,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                    color: isOutlined ? NeoBrutalismColors.black : textColor,
                    fontFamily: 'Inter',
                  ),
                ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 30),
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: SlideTransition(
              position: _slideAnimation,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // ===== BACK BUTTON =====
                  Align(
                    alignment: Alignment.centerLeft,
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pushReplacementNamed(context, '/');
                      },
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(3, 3),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.arrow_back_ios_new_rounded,
                          color: NeoBrutalismColors.black,
                          size: 18,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ===== LOGO / HERO IMAGE =====
                  Hero(
                    tag: 'logo',
                    child: Container(
                      width: 80,
                      height: 80,
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.purple,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: NeoBrutalismColors.borderColor, width: 4),
                        boxShadow: [
                          BoxShadow(
                            color: NeoBrutalismColors.black.withOpacity(0.12),
                            offset: const Offset(6, 6),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.asset(
                          'assets/images/splash.jpg',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // ===== TITLE =====
                  const Text(
                    "Welcome Back",
                    style: TextStyle(
                      color: NeoBrutalismColors.black,
                      fontSize: 26,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Inter',
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "Login to continue to your account",
                    style: TextStyle(
                      color: NeoBrutalismColors.darkGrey,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter',
                    ),
                  ),

                  const SizedBox(height: 8),

                  // ===== KEPALA ROBOT =====
                  Center(
                    child: RobotHead(size: 140),
                  ),

                  const SizedBox(height: 2),

                  // ===== LOGIN CARD =====
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      // Card utama
                      _neoCard(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            // ===== USERNAME FIELD =====
                            AnimatedBuilder(
                              animation: _shakeController,
                              builder: (context, child) {
                                return Transform.translate(
                                  offset: Offset(_shakeAnimation.value, 0),
                                  child: child,
                                );
                              },
                              child: _neoInput("Username", userController, Icons.person),
                            ),
                            const SizedBox(height: 14),

                            // ===== PASSWORD FIELD =====
                            AnimatedBuilder(
                              animation: _shakeController,
                              builder: (context, child) {
                                return Transform.translate(
                                  offset: Offset(_shakeAnimation.value, 0),
                                  child: child,
                                );
                              },
                              child: _neoInput("Password", passController, Icons.lock, isPassword: true),
                            ),
                            const SizedBox(height: 20),

                            // ===== LOGIN BUTTON =====
                            _neoButton(
                              label: "LOGIN",
                              onTap: login,
                              bg: NeoBrutalismColors.yellow,
                              textColor: NeoBrutalismColors.black,
                              fontSize: 15,
                              isLoading: isLoading,
                            ),

                            const SizedBox(height: 10),

                            // ===== BUY ACCOUNT BUTTON =====
                            _neoButton(
                              label: "BUY ACCOUNT",
                              onTap: _goToBuyAccount,
                              bg: NeoBrutalismColors.purple,
                              textColor: NeoBrutalismColors.white,
                              fontSize: 13,
                              isOutlined: false,
                            ),
                          ],
                        ),
                      ),
                      
                      // ===== TANGAN KIRI (di atas card) =====
                      Positioned(
                        left: 20,
                        top: -20,
                        child: Container(
                          width: 30,
                          height: 20,
                          decoration: BoxDecoration(
                            color: Colors.green.shade600.withOpacity(0.85),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.black, width: 2.5),
                          ),
                        ),
                      ),
                      
                      // ===== TANGAN KANAN (di atas card) =====
                      Positioned(
                        right: 20,
                        top: -20,
                        child: Container(
                          width: 30,
                          height: 20,
                          decoration: BoxDecoration(
                            color: Colors.green.shade600.withOpacity(0.85),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.black, width: 2.5),
                          ),
                        ),
                      ),
                      
                      // ===== KAKI KIRI =====
                      Positioned(
                        left: 20,
                        bottom: -18,
                        child: Container(
                          width: 30,
                          height: 18,
                          decoration: BoxDecoration(
                            color: Colors.green.shade900.withOpacity(0.85),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.black, width: 2.5),
                          ),
                        ),
                      ),
                      
                      // ===== KAKI KANAN =====
                      Positioned(
                        right: 20,
                        bottom: -18,
                        child: Container(
                          width: 30,
                          height: 18,
                          decoration: BoxDecoration(
                            color: Colors.green.shade900.withOpacity(0.85),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(color: Colors.black, width: 2.5),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 40),

                  // ===== COPYRIGHT =====
                  Column(
                    children: [
                      Container(
                        width: 40,
                        height: 3,
                        color: NeoBrutalismColors.borderColor,
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: NeoBrutalismColors.darkGrey,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}