import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ─── DAFTAR WARNA PILIHAN ────────────────────────────────────────────────
class AppThemeColor {
  final String name;
  final String emoji;
  final Color hue;
  const AppThemeColor({required this.name, required this.emoji, required this.hue});
}

const List<AppThemeColor> kAvailableColors = [
  AppThemeColor(name: 'Gold',       emoji: '🟡', hue: Color(0xFFFFB300)),
  AppThemeColor(name: 'Kuning',     emoji: '💛', hue: Color(0xFFFFD600)),
  AppThemeColor(name: 'Amber',      emoji: '🌟', hue: Color(0xFFFF8F00)),
  AppThemeColor(name: 'Oranye',     emoji: '🟠', hue: Color(0xFFF4511E)),
  AppThemeColor(name: 'Oranye Tua', emoji: '🍊', hue: Color(0xFFE64A19)),
  AppThemeColor(name: 'Peach',      emoji: '🍑', hue: Color(0xFFFF7043)),
  AppThemeColor(name: 'Merah',      emoji: '🔴', hue: Color(0xFFE53935)),
  AppThemeColor(name: 'Merah Tua',  emoji: '❤️', hue: Color(0xFFC62828)),
  AppThemeColor(name: 'Scarlet',    emoji: '🌹', hue: Color(0xFFD50000)),
  AppThemeColor(name: 'Koral',      emoji: '🪸', hue: Color(0xFFFF5252)),
  AppThemeColor(name: 'Pink',       emoji: '🩷', hue: Color(0xFFE91E8C)),
  AppThemeColor(name: 'Hot Pink',   emoji: '💗', hue: Color(0xFFFF1493)),
  AppThemeColor(name: 'Magenta',    emoji: '🌸', hue: Color(0xFFD500F9)),
  AppThemeColor(name: 'Rose',       emoji: '🌷', hue: Color(0xFFFF4081)),
  AppThemeColor(name: 'Fuchsia',    emoji: '💜', hue: Color(0xFFE040FB)),
  AppThemeColor(name: 'Ungu',       emoji: '🟣', hue: Color(0xFF8E24AA)),
  AppThemeColor(name: 'Ungu Tua',   emoji: '🍇', hue: Color(0xFF6A1B9A)),
  AppThemeColor(name: 'Violet',     emoji: '💜', hue: Color(0xFF7B1FA2)),
  AppThemeColor(name: 'Lavender',   emoji: '🪻', hue: Color(0xFF9C27B0)),
  AppThemeColor(name: 'Indigo',     emoji: '🔮', hue: Color(0xFF3949AB)),
  AppThemeColor(name: 'Biru',       emoji: '🔵', hue: Color(0xFF1E88E5)),
  AppThemeColor(name: 'Biru Tua',   emoji: '🌊', hue: Color(0xFF1565C0)),
  AppThemeColor(name: 'Biru Muda',  emoji: '🩵', hue: Color(0xFF29B6F6)),
  AppThemeColor(name: 'Royal Blue', emoji: '👑', hue: Color(0xFF1976D2)),
  AppThemeColor(name: 'Cobalt',     emoji: '💎', hue: Color(0xFF0288D1)),
  AppThemeColor(name: 'Sky Blue',   emoji: '☁️', hue: Color(0xFF039BE5)),
  AppThemeColor(name: 'Tosca',      emoji: '🩵', hue: Color(0xFF00ACC1)),
  AppThemeColor(name: 'Cyan',       emoji: '💠', hue: Color(0xFF00BCD4)),
  AppThemeColor(name: 'Aqua',       emoji: '🐚', hue: Color(0xFF00E5FF)),
  AppThemeColor(name: 'Teal',       emoji: '🌊', hue: Color(0xFF00796B)),
  AppThemeColor(name: 'Hijau',      emoji: '🟢', hue: Color(0xFF43A047)),
  AppThemeColor(name: 'Hijau Tua',  emoji: '🌲', hue: Color(0xFF2E7D32)),
  AppThemeColor(name: 'Hijau Muda', emoji: '🌿', hue: Color(0xFF66BB6A)),
  AppThemeColor(name: 'Lime',       emoji: '🍋', hue: Color(0xFFAEEA00)),
  AppThemeColor(name: 'Mint',       emoji: '🌱', hue: Color(0xFF00E676)),
  AppThemeColor(name: 'Emerald',    emoji: '💚', hue: Color(0xFF00C853)),
  AppThemeColor(name: 'Sage',       emoji: '🍃', hue: Color(0xFF558B2F)),
  AppThemeColor(name: 'Silver',     emoji: '⚪', hue: Color(0xFFC0C0C0)),
  AppThemeColor(name: 'Abu',        emoji: '🩶', hue: Color(0xFF78909C)),
  AppThemeColor(name: 'Biru Abu',   emoji: '🌫️', hue: Color(0xFF546E7A)),
  AppThemeColor(name: 'Coklat',     emoji: '🟫', hue: Color(0xFF6D4C41)),
  AppThemeColor(name: 'Tan',        emoji: '🌰', hue: Color(0xFF8D6E63)),
  AppThemeColor(name: 'Sand',       emoji: '🏜️', hue: Color(0xFFA1887F)),
  AppThemeColor(name: 'Neon Hijau', emoji: '⚡', hue: Color(0xFF76FF03)),
  AppThemeColor(name: 'Neon Pink',  emoji: '🌈', hue: Color(0xFFFF1744)),
  AppThemeColor(name: 'Neon Biru',  emoji: '🔷', hue: Color(0xFF00B0FF)),
  AppThemeColor(name: 'Neon Ungu',  emoji: '✨', hue: Color(0xFFD500F9)),
];

// ─── GENERATE PALETTE ─────────────────────────────────────────────────────
class ThemePalette {
  final Color bg, surface, surfaceLight, surface2, cardDark;
  final Color accent1, accent2, accent3;
  final Color textPrimary, textSec, textMuted;
  final Color overlayColor;
  const ThemePalette({
    required this.bg, required this.surface, required this.surfaceLight,
    required this.surface2, required this.cardDark,
    required this.accent1, required this.accent2, required this.accent3,
    required this.textPrimary, required this.textSec, required this.textMuted,
    required this.overlayColor,
  });

  // colorSaturation : 0.0 (pudar) – 1.0 (pekat) → saturasi accent
  // textBrightness  : 0.0 (gelap)  – 1.0 (terang) → lightness teks
  static ThemePalette fromHue(
    Color hue,
    bool dark, {
    double glowIntensity   = 0.5,
    double colorSaturation = 0.5,   // ← BARU: pekat/pudar warna
    double textBrightness  = 0.5,   // ← BARU: pekat/pudar teks
  }) {
    final h = HSLColor.fromColor(hue);

    // Saturation accent: diatur oleh colorSaturation (0.20 pudar → 1.0 pekat)
    final double sat = 0.20 + (colorSaturation * 0.80);

    // Lightness accent dark mode: glowIntensity mengatur kecerahan accent
    final double litAccentDark  = 0.50 + (glowIntensity * 0.35);
    final double litAccentLight = 0.20 + (glowIntensity * 0.25);

    // Teks brightness: textBrightness 0.0→0.5 (gelap) | 0.5→1.0 (terang)
    // Dark mode: teks primary bergerak dari 0.65 (redup) → 0.98 (terang)
    final double txtLitPrimDark  = 0.65 + (textBrightness * 0.33);
    final double txtLitSecDark   = 0.50 + (textBrightness * 0.30);
    final double txtLitMuteDark  = 0.35 + (textBrightness * 0.25);
    // Light mode: teks primary bergerak dari 0.04 (gelap) → 0.30 (agak terang)
    final double txtLitPrimLight = 0.04 + (textBrightness * 0.26);
    final double txtLitSecLight  = 0.12 + (textBrightness * 0.22);
    final double txtLitMuteLight = 0.28 + (textBrightness * 0.20);

    if (dark) {
      return ThemePalette(
        bg:           HSLColor.fromAHSL(1, h.hue, .12, .04).toColor(),
        surface:      HSLColor.fromAHSL(1, h.hue, .12, .08).toColor(),
        surfaceLight: HSLColor.fromAHSL(1, h.hue, .13, .12).toColor(),
        surface2:     HSLColor.fromAHSL(1, h.hue, .14, .16).toColor(),
        cardDark:     HSLColor.fromAHSL(1, h.hue, .10, .05).toColor(),
        accent1:      HSLColor.fromAHSL(1, h.hue, sat.clamp(0.0, 1.0), litAccentDark.clamp(0.0, 1.0)).toColor(),
        accent2:      HSLColor.fromAHSL(1, h.hue, (sat - 0.05).clamp(0.0, 1.0), (litAccentDark - 0.16).clamp(0.0, 1.0)).toColor(),
        accent3:      HSLColor.fromAHSL(1, h.hue, (sat - 0.15).clamp(0.0, 1.0), (litAccentDark - 0.30).clamp(0.0, 1.0)).toColor(),
        textPrimary:  HSLColor.fromAHSL(1, h.hue, 0.35, txtLitPrimDark.clamp(0.0, 1.0)).toColor(),
        textSec:      HSLColor.fromAHSL(1, h.hue, 0.28, txtLitSecDark.clamp(0.0, 1.0)).toColor(),
        textMuted:    HSLColor.fromAHSL(1, h.hue, 0.20, txtLitMuteDark.clamp(0.0, 1.0)).toColor(),
        overlayColor: HSLColor.fromAHSL(0.55, h.hue, .55, .05).toColor(),
      );
    } else {
      return ThemePalette(
        bg:           HSLColor.fromAHSL(1, h.hue, .20, .96).toColor(),
        surface:      HSLColor.fromAHSL(1, h.hue, .20, .91).toColor(),
        surfaceLight: HSLColor.fromAHSL(1, h.hue, .20, .86).toColor(),
        surface2:     HSLColor.fromAHSL(1, h.hue, .18, .80).toColor(),
        cardDark:     HSLColor.fromAHSL(1, h.hue, .20, .93).toColor(),
        accent1:      HSLColor.fromAHSL(1, h.hue, sat.clamp(0.0, 1.0), litAccentLight.clamp(0.0, 1.0)).toColor(),
        accent2:      HSLColor.fromAHSL(1, h.hue, (sat - 0.05).clamp(0.0, 1.0), (litAccentLight + 0.12).clamp(0.0, 1.0)).toColor(),
        accent3:      HSLColor.fromAHSL(1, h.hue, (sat - 0.15).clamp(0.0, 1.0), (litAccentLight + 0.25).clamp(0.0, 1.0)).toColor(),
        textPrimary:  HSLColor.fromAHSL(1, h.hue, 0.60, txtLitPrimLight.clamp(0.0, 1.0)).toColor(),
        textSec:      HSLColor.fromAHSL(1, h.hue, 0.50, txtLitSecLight.clamp(0.0, 1.0)).toColor(),
        textMuted:    HSLColor.fromAHSL(1, h.hue, 0.35, txtLitMuteLight.clamp(0.0, 1.0)).toColor(),
        overlayColor: HSLColor.fromAHSL(0.45, h.hue, .40, .88).toColor(),
      );
    }
  }
}

// ─── DEFAULT WARNA ─────────────────────────────────────────────────────────
const int kDefaultColorIdx = 1; // Kuning 💛

// ─── GLOBAL COLORS ──────────────────────────────────────────────────────────
ThemePalette _P = ThemePalette.fromHue(kAvailableColors[kDefaultColorIdx].hue, true);

class AppColors {
  static Color get bg           => _P.bg;
  static Color get surface      => _P.surface;
  static Color get surfaceLight => _P.surfaceLight;
  static Color get surface2     => _P.surface2;
  static Color get cardDark     => _P.cardDark;
  static Color get silver1      => _P.accent1;
  static Color get silver2      => _P.accent1;
  static Color get gray1        => _P.accent2;
  static Color get gray2        => _P.accent3;
  static Color get accent1      => _P.accent1;
  static Color get accent2      => _P.accent2;
  static Color get accent3      => _P.accent3;
  static Color get textPrimary  => _P.textPrimary;
  static Color get textSec      => _P.textSec;
  static Color get textMuted    => _P.textMuted;
  static Color get overlayColor => _P.overlayColor;
  static const success     = Color(0xFF4CAF50);
  static const warning     = Color(0xFFFFAB40);
  static const error       = Color(0xFFFF1744);
  static const shadow      = Color(0x40000000);
  static const shadowHeavy = Color(0x80000000);
}

class ShadowUtils {
  static List<BoxShadow> get soft  => const [
    BoxShadow(color: AppColors.shadow, blurRadius: 8, offset: Offset(0,2)),
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 2, offset: Offset(0,1)),
  ];
  static List<BoxShadow> get medium => const [
    BoxShadow(color: AppColors.shadow, blurRadius: 16, offset: Offset(0,4)),
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 4, offset: Offset(0,2)),
  ];
  static List<BoxShadow> get heavy => const [
    BoxShadow(color: AppColors.shadow, blurRadius: 24, offset: Offset(0,8)),
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 8, offset: Offset(0,4)),
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 2, offset: Offset(0,1)),
  ];
  static List<BoxShadow> get card => const [
    BoxShadow(color: AppColors.shadowHeavy, blurRadius: 20, offset: Offset(0,10)),
    BoxShadow(color: AppColors.shadow, blurRadius: 6, offset: Offset(0,2)),
  ];
}

// ─── THEME NOTIFIER ───────────────────────────────────────────────────────
class ThemeNotifier extends ChangeNotifier {
  static const _kColorIdx        = 'theme_color_idx';
  static const _kDark            = 'theme_dark_mode';
  static const _kGlowIntensity   = 'theme_glow_intensity';
  static const _kColorSaturation = 'theme_color_saturation'; // ← BARU
  static const _kTextBrightness  = 'theme_text_brightness';  // ← BARU

  int    _colorIdx        = kDefaultColorIdx;
  bool   _isDark          = true;
  double _glowIntensity   = 0.5;
  double _colorSaturation = 0.5; // ← BARU: 0.0 (pudar) – 1.0 (pekat)
  double _textBrightness  = 0.5; // ← BARU: 0.0 (gelap)  – 1.0 (terang)

  int    get colorIdx        => _colorIdx;
  bool   get isDark          => _isDark;
  double get glowIntensity   => _glowIntensity;
  double get colorSaturation => _colorSaturation; // ← BARU
  double get textBrightness  => _textBrightness;  // ← BARU
  AppThemeColor get current  => kAvailableColors[_colorIdx];

  ThemeNotifier() { _load(); }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    _colorIdx        = (prefs.getInt(_kColorIdx)            ?? kDefaultColorIdx).clamp(0, kAvailableColors.length - 1);
    _isDark          =  prefs.getBool(_kDark)               ?? true;
    _glowIntensity   = (prefs.getDouble(_kGlowIntensity)    ?? 0.5).clamp(0.0, 1.0);
    _colorSaturation = (prefs.getDouble(_kColorSaturation)  ?? 0.5).clamp(0.0, 1.0); // ← BARU
    _textBrightness  = (prefs.getDouble(_kTextBrightness)   ?? 0.5).clamp(0.0, 1.0); // ← BARU
    _apply();
    notifyListeners();
  }

  void setColor(int idx) async {
    _colorIdx = idx.clamp(0, kAvailableColors.length - 1);
    _apply(); notifyListeners();
    final p = await SharedPreferences.getInstance();
    p.setInt(_kColorIdx, _colorIdx);
  }

  void setDark(bool v) async {
    _isDark = v;
    _apply(); notifyListeners();
    final p = await SharedPreferences.getInstance();
    p.setBool(_kDark, v);
  }

  void setGlowIntensity(double v) async {
    _glowIntensity = v.clamp(0.0, 1.0);
    _apply(); notifyListeners();
    final p = await SharedPreferences.getInstance();
    p.setDouble(_kGlowIntensity, _glowIntensity);
  }

  // ← BARU: atur kepekatan warna accent (saturation)
  void setColorSaturation(double v) async {
    _colorSaturation = v.clamp(0.0, 1.0);
    _apply(); notifyListeners();
    final p = await SharedPreferences.getInstance();
    p.setDouble(_kColorSaturation, _colorSaturation);
  }

  // ← BARU: atur kepekatan/kepudaran teks
  void setTextBrightness(double v) async {
    _textBrightness = v.clamp(0.0, 1.0);
    _apply(); notifyListeners();
    final p = await SharedPreferences.getInstance();
    p.setDouble(_kTextBrightness, _textBrightness);
  }

  // ── Reset ke default saat logout ─────────────────────────────────────────
  Future<void> reset() async {
    _colorIdx        = kDefaultColorIdx;
    _isDark          = true;
    _glowIntensity   = 0.5;
    _colorSaturation = 0.5; // ← BARU
    _textBrightness  = 0.5; // ← BARU
    _apply();
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    p.remove(_kColorIdx);
    p.remove(_kDark);
    p.remove(_kGlowIntensity);
    p.remove(_kColorSaturation); // ← BARU
    p.remove(_kTextBrightness);  // ← BARU
  }

  void _apply() {
    _P = ThemePalette.fromHue(
      current.hue,
      _isDark,
      glowIntensity:   _glowIntensity,
      colorSaturation: _colorSaturation, // ← BARU
      textBrightness:  _textBrightness,  // ← BARU
    );
  }

  ThemeData get materialTheme => ThemeData(
    brightness: _isDark ? Brightness.dark : Brightness.light,
    fontFamily: 'Made',
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: ColorScheme.fromSeed(
      seedColor:  current.hue,
      brightness: _isDark ? Brightness.dark : Brightness.light,
    ).copyWith(primary: AppColors.accent1, secondary: AppColors.accent2, surface: AppColors.surface),
    pageTransitionsTheme: const PageTransitionsTheme(builders: {}),
  );
}

// ─── INHERITED WIDGET ─────────────────────────────────────────────────────
class ThemeScope extends InheritedNotifier<ThemeNotifier> {
  const ThemeScope({super.key, required ThemeNotifier notifier, required super.child})
      : super(notifier: notifier);

  static ThemeNotifier of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<ThemeScope>()!.notifier!;
  }
}

// ─── HELPER: buka bottom sheet Ganti Warna dari mana saja ─────────────────
void showColorPickerSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (_) => const ColorPickerSheet(),
  );
}

// ─── COLOR PICKER SHEET ───────────────────────────────────────────────────
class ColorPickerSheet extends StatefulWidget {
  const ColorPickerSheet({super.key});
  @override State<ColorPickerSheet> createState() => _ColorPickerSheetState();
}

class _ColorPickerSheetState extends State<ColorPickerSheet> {
  @override
  Widget build(BuildContext context) {
    final themeNotifier = ThemeScope.of(context);
    return AnimatedBuilder(
      animation: themeNotifier,
      builder: (context, _) {
        final hue = themeNotifier.current.hue;
        return DraggableScrollableSheet(
          initialChildSize: 0.92,
          minChildSize: 0.5,
          maxChildSize: 0.96,
          builder: (_, scrollCtrl) => Container(
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border.all(color: AppColors.silver2.withOpacity(0.1), width: 0.5),
            ),
            child: ListView(
              controller: scrollCtrl,
              padding: const EdgeInsets.only(bottom: 32),
              children: [
                // ── Handle ──────────────────────────────────────────────
                Center(
                  child: Container(
                    margin: const EdgeInsets.only(top: 12, bottom: 8),
                    height: 4, width: 40,
                    decoration: BoxDecoration(
                      color: AppColors.silver2.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),

                // ── Header ──────────────────────────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [AppColors.gray1, AppColors.gray2]),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: const Icon(Icons.brush_rounded, color: Colors.white, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'THEME CUSTOMIZER',
                          style: TextStyle(
                            color: AppColors.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(color: AppColors.surface2, shape: BoxShape.circle),
                          child: Icon(Icons.close_rounded, color: AppColors.textMuted, size: 20),
                        ),
                      ),
                    ],
                  ),
                ),

                // ── Preview bar warna aktif ───────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Container(
                    height: 48,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [hue, hue.withOpacity(0.6)],
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                      ),
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [BoxShadow(color: hue.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4))],
                    ),
                    child: Center(
                      child: Text(
                        'ACTIVE THEME PREVIEW',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.95),
                          fontWeight: FontWeight.w800,
                          letterSpacing: 2,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      // ══════════════════════════════════════════════════
                      //  SLIDER 1: KEPEKATAN WARNA (COLOR SATURATION)
                      // ══════════════════════════════════════════════════
                      _buildSliderCard(
                        icon: Icons.palette_rounded,
                        title: 'KEPEKATAN WARNA',
                        leftLabel: 'PUDAR',
                        rightLabel: 'PEKAT',
                        value: themeNotifier.colorSaturation,
                        hue: hue,
                        onChanged: (v) => themeNotifier.setColorSaturation(v),
                        previewBuilder: () => Row(
                          children: List.generate(5, (i) {
                            final sat = 0.20 + (i / 4.0) * 0.80;
                            final c = HSLColor.fromAHSL(1, HSLColor.fromColor(hue).hue, sat, 0.55).toColor();
                            return Expanded(
                              child: Container(
                                height: 8,
                                margin: EdgeInsets.only(left: i == 0 ? 0 : 2),
                                decoration: BoxDecoration(
                                  color: c,
                                  borderRadius: BorderRadius.horizontal(
                                    left: i == 0 ? const Radius.circular(4) : Radius.zero,
                                    right: i == 4 ? const Radius.circular(4) : Radius.zero,
                                  ),
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ══════════════════════════════════════════════════
                      //  SLIDER 2: KEPEKATAN TEKS (TEXT BRIGHTNESS)
                      // ══════════════════════════════════════════════════
                      _buildSliderCard(
                        icon: Icons.text_fields_rounded,
                        title: 'KEPEKATAN TEKS',
                        leftLabel: 'PUDAR',
                        rightLabel: 'TERANG',
                        value: themeNotifier.textBrightness,
                        hue: hue,
                        onChanged: (v) => themeNotifier.setTextBrightness(v),
                        previewBuilder: () => Row(
                          children: List.generate(5, (i) {
                            final lit = themeNotifier.isDark
                                ? 0.65 + (i / 4.0) * 0.33
                                : 0.04 + (i / 4.0) * 0.26;
                            final c = HSLColor.fromAHSL(1, HSLColor.fromColor(hue).hue, 0.35, lit.clamp(0, 1)).toColor();
                            return Expanded(
                              child: Container(
                                height: 8,
                                margin: EdgeInsets.only(left: i == 0 ? 0 : 2),
                                decoration: BoxDecoration(
                                  color: c,
                                  borderRadius: BorderRadius.horizontal(
                                    left: i == 0 ? const Radius.circular(4) : Radius.zero,
                                    right: i == 4 ? const Radius.circular(4) : Radius.zero,
                                  ),
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // ── Section PILIH WARNA ──────────────────────────
                      _sectionLabel('PILIH WARNA', '${kAvailableColors.length} WARNA', hue),
                      const SizedBox(height: 12),

                      GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 5,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                          childAspectRatio: 0.82,
                        ),
                        itemCount: kAvailableColors.length,
                        itemBuilder: (context, i) {
                          final c = kAvailableColors[i];
                          final isSelected = themeNotifier.colorIdx == i;
                          return GestureDetector(
                            onTap: () => themeNotifier.setColor(i),
                            child: Column(
                              children: [
                                AnimatedContainer(
                                  duration: const Duration(milliseconds: 200),
                                  width: 48, height: 48,
                                  decoration: BoxDecoration(
                                    gradient: RadialGradient(
                                      colors: [c.hue, c.hue.withOpacity(0.75)],
                                      center: Alignment.topLeft, radius: 1.5,
                                    ),
                                    shape: BoxShape.circle,
                                    border: isSelected ? Border.all(color: Colors.white, width: 2.5) : null,
                                    boxShadow: isSelected
                                        ? [BoxShadow(color: c.hue.withOpacity(0.60), blurRadius: 14, spreadRadius: 2, offset: const Offset(0, 3))]
                                        : [BoxShadow(color: c.hue.withOpacity(0.25), blurRadius: 6, offset: const Offset(0, 2))],
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  c.name,
                                  style: TextStyle(
                                    fontSize: 7,
                                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                                    color: isSelected ? c.hue : AppColors.textMuted,
                                  ),
                                  textAlign: TextAlign.center,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 20),

                      // ── MODE WARNA (Dark / Light) ─────────────────────
                      _sectionLabel('MODE WARNA', '', hue),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          _modeButton(
                            context: context,
                            themeNotifier: themeNotifier,
                            isDarkMode: false,
                            icon: Icons.wb_sunny_rounded,
                            label: 'WARNA MUDA',
                          ),
                          const SizedBox(width: 12),
                          _modeButton(
                            context: context,
                            themeNotifier: themeNotifier,
                            isDarkMode: true,
                            icon: Icons.nightlight_round,
                            label: 'WARNA TUA',
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ── Helper: kartu slider ──────────────────────────────────────────────────
  Widget _buildSliderCard({
    required IconData icon,
    required String title,
    required String leftLabel,
    required String rightLabel,
    required double value,
    required Color hue,
    required ValueChanged<double> onChanged,
    required Widget Function() previewBuilder,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.silver2.withOpacity(0.1), width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title row
          Row(
            children: [
              Icon(icon, color: hue, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 10, fontWeight: FontWeight.bold,
                    color: AppColors.textMuted, letterSpacing: 1.5,
                  ),
                ),
              ),
              Text(
                '${(value * 100).round()}%',
                style: TextStyle(
                  fontSize: 11, fontWeight: FontWeight.bold,
                  color: hue, letterSpacing: 0.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Color preview gradient bar
          previewBuilder(),
          const SizedBox(height: 4),
          // Slider
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: hue,
              inactiveTrackColor: AppColors.surface.withOpacity(0.6),
              thumbColor: hue,
              overlayColor: hue.withOpacity(0.15),
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 10),
              trackHeight: 4,
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 20),
            ),
            child: Slider(value: value, min: 0.0, max: 1.0, onChanged: onChanged),
          ),
          // Label kiri/kanan
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(leftLabel,  style: TextStyle(fontSize: 9, color: AppColors.textMuted, letterSpacing: 1)),
                Text(rightLabel, style: TextStyle(fontSize: 9, color: AppColors.textMuted, letterSpacing: 1)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Helper: section label ─────────────────────────────────────────────────
  Widget _sectionLabel(String title, String badge, Color hue) {
    return Row(
      children: [
        Container(width: 3, height: 14, decoration: BoxDecoration(color: hue, borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 8),
        Text(title, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.textMuted, letterSpacing: 1.5)),
        const Spacer(),
        if (badge.isNotEmpty)
          Text(badge, style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: hue.withOpacity(0.7), letterSpacing: 0.5)),
      ],
    );
  }

  // ── Helper: mode button ───────────────────────────────────────────────────
  Widget _modeButton({
    required BuildContext context,
    required ThemeNotifier themeNotifier,
    required bool isDarkMode,
    required IconData icon,
    required String label,
  }) {
    final isActive = themeNotifier.isDark == isDarkMode;
    final hue = themeNotifier.current.hue;
    return Expanded(
      child: GestureDetector(
        onTap: () => themeNotifier.setDark(isDarkMode),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: isActive
                  ? [hue.withOpacity(0.25), hue.withOpacity(0.10)]
                  : [AppColors.surface2, AppColors.surface],
            ),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isActive ? hue : AppColors.silver2.withOpacity(0.15),
              width: isActive ? 2 : 0.5,
            ),
            boxShadow: isActive
                ? [BoxShadow(color: hue.withOpacity(0.25), blurRadius: 10, offset: const Offset(0, 3))]
                : null,
          ),
          child: Column(
            children: [
              Icon(icon, color: isActive ? hue : AppColors.textMuted, size: 26),
              const SizedBox(height: 6),
              Text(
                label,
                style: TextStyle(
                  fontSize: 10, fontWeight: FontWeight.bold,
                  color: isActive ? hue : AppColors.textMuted,
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
