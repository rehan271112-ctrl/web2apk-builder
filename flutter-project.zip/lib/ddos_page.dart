import 'package:flutter/material.dart';
import 'tols/chat_ai_page.dart';
import 'tols/nik_check_page.dart';
import 'tols/phone_lookup.dart';
import 'tols/subdomain_finder_page.dart';
import 'tols/anime.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  final List<Map<String, dynamic>> _tools = [
    {'icon': Icons.chat, 'label': 'Chat AI', 'description': 'AI-powered conversation assistant', 'color': NeoBrutalismColors.purple},
    {'icon': Icons.badge, 'label': 'NIK Check', 'description': 'Validate Indonesian identity numbers', 'color': NeoBrutalismColors.blue},
    {'icon': Icons.phone, 'label': 'Phone Lookup', 'description': 'Find information about phone numbers', 'color': NeoBrutalismColors.green},
    {'icon': Icons.language, 'label': 'Subdomain Finder', 'description': 'Discover subdomains of any domain', 'color': NeoBrutalismColors.yellow},
    {'icon': Icons.movie_filter_outlined, 'label': 'Anime', 'description': 'Tempat Nya Para Wibu Marathon Anime', 'color': NeoBrutalismColors.pink},
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  void _navigateToTool(String toolName) {
    Widget page;
    switch (toolName) {
      case 'Chat AI':
        page = ChatAIPage(sessionKey: widget.sessionKey);
        break;
      case 'NIK Check':
        page = NIKCheckPage(sessionKey: widget.sessionKey);
        break;
      case 'Phone Lookup':
        page = PhoneLookupPage(sessionKey: widget.sessionKey);
        break;
      case 'Anime':
        page = const HomeAnimePage();
        break;
      case 'Subdomain Finder':
        page = SubdomainFinderPage(sessionKey: widget.sessionKey);
        break;
      default:
        return;
    }

    Navigator.of(context).push(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => page,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          const begin = Offset(1.0, 0.0);
          const end = Offset.zero;
          const curve = Curves.easeInOut;
          var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          return SlideTransition(position: animation.drive(tween), child: child);
        },
        transitionDuration: const Duration(milliseconds: 300),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ===== HEADER (TANPA BACK BUTTON) =====
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.purple,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoBrutalismColors.black.withOpacity(0.08),
                                  offset: const Offset(4, 4),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.build,
                              color: NeoBrutalismColors.white,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            "Digital Tools",
                            style: TextStyle(
                              color: NeoBrutalismColors.black,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Inter',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Padding(
                        padding: const EdgeInsets.only(left: 4),
                        child: Text(
                          "Select a tool to begin",
                          style: TextStyle(
                            color: NeoBrutalismColors.darkGrey,
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // ===== TOOLS LIST =====
                      ..._tools.asMap().entries.map((entry) {
                        final index = entry.key;
                        final tool = entry.value;
                        final delay = (index + 1) * 0.1;
                        return _buildToolItem(
                          icon: tool['icon'],
                          label: tool['label'],
                          description: tool['description'],
                          color: tool['color'],
                          delay: delay,
                          onTap: () => _navigateToTool(tool['label']),
                        );
                      }).toList(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToolItem({
    required IconData icon,
    required String label,
    required String description,
    required Color color,
    required double delay,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: NeoBrutalismColors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
            boxShadow: [
              BoxShadow(
                color: NeoBrutalismColors.black.withOpacity(0.08),
                offset: const Offset(4, 4),
                blurRadius: 0,
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: color.withOpacity(0.3), width: 2),
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: const TextStyle(
                        color: NeoBrutalismColors.black,
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Inter',
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      description,
                      style: TextStyle(
                        color: NeoBrutalismColors.darkGrey,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: NeoBrutalismColors.darkGrey,
                size: 14,
              ),
            ],
          ),
        ),
      ),
    );
  }
}