// iphone_qc_page.dart
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:gal/gal.dart';

// ─── Palette Cyan Premium SuryaCrash ──────────────────────────────────────────
class _C {
  static const bg         = Color(0xFF050D1A);
  static const surface    = Color(0xFF0A1428);
  static const card       = Color(0xFF0E1E2E);
  static const border     = Color(0xFF1A3A52);
  static const primary    = Color(0xFF00E5FF);
  static const primaryDark = Color(0xFF006064);
  static const cardAccent = Color(0xFF0097A7);
  static const text       = Color(0xFFE0F7FA);
  static const textSub    = Color(0xFF80DEEA);
  static const textDim    = Color(0xFF4DB8C4);
}

class IphoneQcPage extends StatefulWidget {
  const IphoneQcPage({super.key});

  @override
  State<IphoneQcPage> createState() => _IphoneQcPageState();
}

class _IphoneQcPageState extends State<IphoneQcPage> {
  final time = TextEditingController();
  final battery = TextEditingController();
  final sim = TextEditingController();
  final message = TextEditingController();

  Uint8List? image;
  bool loading = false;
  bool downloading = false;

  TextStyle _safeTextStyle({
    required Color color,
    required double fontSize,
    required FontWeight fontWeight,
    double letterSpacing = 0,
  }) {
    return TextStyle(
      color: color,
      fontSize: fontSize,
      fontWeight: fontWeight,
      letterSpacing: letterSpacing,
      fontFamily: 'Orbitron',
      fontFamilyFallback: const ['sans-serif', 'Roboto'],
    );
  }

  Future<void> generate() async {
    if (time.text.isEmpty || battery.text.isEmpty || sim.text.isEmpty || message.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Isi semua data terlebih dahulu"),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() {
      loading = true;
      image = null;
    });

    final url = "https://brat.siputzx.my.id/iphone-quoted"
        "?time=${Uri.encodeComponent(time.text)}"
        "&batteryPercentage=${Uri.encodeComponent(battery.text)}"
        "&carrierName=${Uri.encodeComponent(sim.text)}"
        "&messageText=${Uri.encodeComponent(message.text)}"
        "&emojiStyle=apple";

    try {
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 15));
      if (!mounted) return;

      if (res.statusCode == 200 && res.bodyBytes.isNotEmpty) {
        setState(() {
          image = res.bodyBytes;
        });
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Gagal memuat gambar dari server"),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Terjadi kesalahan koneksi, coba lagi"),
          backgroundColor: Colors.redAccent,
        ),
      );
    }

    if (!mounted) return;
    setState(() => loading = false);
  }

  Future<void> shareImage() async {
    if (image == null) return;

    try {
      final XFile file = XFile.fromData(
        image!,
        mimeType: 'image/png',
        name: 'iphone_quote.png',
      );

      await Share.shareXFiles([file]);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal membagikan: $e"), backgroundColor: Colors.redAccent),
      );
    }
  }

  Future<void> downloadImage() async {
    if (image == null) return;

    setState(() => downloading = true);

    try {
      await Gal.putImageBytes(image!, name: 'iphone_quote_${DateTime.now().millisecondsSinceEpoch}');

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Gambar berhasil disimpan ke Galeri"),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal menyimpan gambar: $e"), backgroundColor: Colors.redAccent),
      );
    }

    if (!mounted) return;
    setState(() => downloading = false);
  }

  Widget inputBox(String label, TextEditingController controller, {int maxLines = 1, String hint = ''}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(width: 3, height: 14, decoration: BoxDecoration(color: _C.primary, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 8),
            Text(label, style: _safeTextStyle(color: _C.text, fontSize: 13, fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(color: _C.card, borderRadius: BorderRadius.circular(16), border: Border.all(color: _C.border)),
          child: TextField(
            controller: controller,
            maxLines: maxLines,
            style: const TextStyle(color: _C.text, fontSize: 14),
            decoration: InputDecoration(
              hintText: hint,
              hintStyle: const TextStyle(color: _C.textDim, fontSize: 13),
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              border: InputBorder.none,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: AppBar(
        backgroundColor: _C.surface,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: _C.textSub, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text("IPHONE QUOTES", style: _safeTextStyle(color: _C.text, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 2)),
        centerTitle: true,
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(color: _C.border, height: 1)),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: _C.surface,
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: _C.border),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 5,
                          child: Column(
                            children: [
                              inputBox("Waktu", time, hint: "09:41"),
                              const SizedBox(height: 12),
                              inputBox("Baterai (%)", battery, hint: "100"),
                              const SizedBox(height: 12),
                              inputBox("Provider SIM", sim, hint: "Telkomsel"),
                            ],
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(flex: 6, child: inputBox("Kata-kata Quotes", message, maxLines: 8, hint: "Tulis kutipan kerenmu di sini...")),
                      ],
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _C.primary,
                          disabledBackgroundColor: _C.primary.withOpacity(0.3),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          elevation: 0,
                        ),
                        onPressed: loading ? null : generate,
                        child: loading
                          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: _C.bg, strokeWidth: 2.5))
                          : Text("BUAT IQC", style: _safeTextStyle(color: _C.bg, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 13)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              if (image != null)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _C.surface,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: _C.border),
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4))],
                  ),
                  child: Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Container(color: _C.card, padding: const EdgeInsets.all(4), child: Image.memory(image!, fit: BoxFit.contain)),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        height: 44,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _C.card,
                            foregroundColor: _C.text,
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            side: const BorderSide(color: _C.border),
                          ),
                          onPressed: shareImage,
                          icon: const Icon(Icons.share_rounded, size: 18, color: _C.textSub),
                          label: Text("BAGIKAN GAMBAR", style: _safeTextStyle(color: _C.text, fontWeight: FontWeight.bold, fontSize: 13)),
                        ),
                      ),
                      const SizedBox(height: 12),
                      // ─── TOMBOL UNDUH GAMBAR (diperbaiki) ──────────────────
                      SizedBox(
                        width: double.infinity,
                        height: 44,
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _C.primary,
                            disabledBackgroundColor: _C.primary.withOpacity(0.3),
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                          onPressed: downloading ? null : downloadImage,
                          icon: downloading
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(color: _C.bg, strokeWidth: 2),
                                )
                              : const Icon(Icons.download_rounded, size: 18, color: _C.bg),
                          label: Text(
                            downloading ? "MENYIMPAN..." : "UNDUH GAMBAR",
                            style: _safeTextStyle(color: _C.bg, fontWeight: FontWeight.bold, fontSize: 13),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}