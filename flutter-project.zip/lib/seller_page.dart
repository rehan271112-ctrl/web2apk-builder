// seller_page.dart
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'config.dart';
import 'color_theme.dart';

enum SellerSection { none, createAccount, extendDuration, listMember }

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> with SingleTickerProviderStateMixin {
  // ── Theme color getters ──
  Color get bgDark => AppThemeController.instance.theme.bgDark;
  Color get primaryPurple => AppThemeController.instance.theme.primaryPurple;
  Color get accentPurple => AppThemeController.instance.theme.accentPurple;
  Color get lightPurple => AppThemeController.instance.theme.lightPurple;
  Color get cardGlass => AppThemeController.instance.theme.cardGlass;
  Color get borderGlass => AppThemeController.instance.theme.borderGlass;

  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  final List<String> roleOptions = ['member'];
  String selectedRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;

  SellerSection _activeSection = SellerSection.none;
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  late Animation<double> _scaleAnim;

  // --- TEMA PURPLE/DARK (sama seperti dashboard) ---
  final Color primaryWhite = Colors.white;
  final Color textGrey = Colors.grey;

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    _animController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeInOut);
    _scaleAnim = Tween<double>(begin: 0.96, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeOutCubic),
    );
    _animController.forward();
  }

  @override

  void _onThemeChanged() => mounted ? setState(() {}) : null;
  void dispose() {
    _animController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _selectSection(SellerSection section) {
    setState(() => _activeSection = section);
    _animController.forward(from: 0);
    if (section == SellerSection.listMember) _fetchUsers();
  }

  void _goBack() {
    setState(() => _activeSection = SellerSection.none);
    _animController.forward(from: 0);
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('$apiBaseUrl/listUsers?key=${widget.keyToken}'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        "$apiBaseUrl/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d",
      ));
      final data = jsonDecode(res.body);
      if (data['created'] == true) {
        _alert("Sukses", "Akun berhasil dibuat!");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
      } else {
        String msg = data['message'] ?? 'Gagal membuat akun.';
        if (data['invalidDay'] == true) msg += " (Max 30 hari untuk Reseller)";
        _alert("Gagal", msg);
      }
    } catch (e) {
      _alert("Error", "Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse(
        "$apiBaseUrl/editUser?key=${widget.keyToken}&username=$u&addDays=$d",
      ));
      final data = jsonDecode(res.body);
      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (e) {
      _alert("Error", "Koneksi error: $e");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: bgDark,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentPurple.withOpacity(0.3)),
        ),
        title: Row(
          children: [
            Icon(Icons.info_outline, color: accentPurple),
            const SizedBox(width: 10),
            Text(title, style: TextStyle(color: primaryWhite)),
          ],
        ),
        content: Text(message, style: TextStyle(color: textGrey)),
        actions: [
          Center(
            child: Container(
              width: 120,
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryPurple, accentPurple]),
                borderRadius: BorderRadius.circular(16),
              ),
              child: TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text("OK", style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold)),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── WIDGETS ──────────────────────────────────────────────

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    bool obscure = false,
    String hint = "",
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        keyboardType: type,
        obscureText: obscure,
        style: TextStyle(color: primaryWhite),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint.isNotEmpty ? hint : null,
          hintStyle: TextStyle(color: textGrey.withOpacity(0.4), fontSize: 12),
          labelStyle: TextStyle(color: accentPurple),
          prefixIcon: Icon(icon, color: accentPurple),
          filled: true,
          fillColor: const Color(0xFF0D0D0D),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: borderGlass),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: borderGlass),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: accentPurple, width: 2),
          ),
        ),
      ),
    );
  }

  Widget _buildPurpleButton({
    required String label,
    required IconData icon,
    required VoidCallback? onPressed,
  }) {
    return AnimatedBuilder(
      animation: _scaleAnim,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnim.value,
          child: Container(
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryPurple, accentPurple],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: primaryPurple.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: onPressed,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: isLoading
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(icon, size: 20, color: Colors.white),
                        const SizedBox(width: 10),
                        Text(
                          label,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            letterSpacing: 1,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        GestureDetector(
          onTap: _goBack,
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.15),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: accentPurple.withOpacity(0.4)),
            ),
            child: Icon(Icons.arrow_back_ios_new, color: accentPurple, size: 16),
          ),
        ),
        const SizedBox(width: 14),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: primaryPurple.withOpacity(0.2),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: accentPurple),
        ),
        const SizedBox(width: 12),
        Text(
          title,
          style: TextStyle(
            color: primaryWhite,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 1,
            shadows: [Shadow(color: accentPurple.withOpacity(0.5), blurRadius: 8)],
          ),
        ),
      ],
    );
  }

  Widget _buildCard(Widget child) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.08),
            blurRadius: 20,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: child,
    );
  }

  // ── SELECTOR PAGE ─────────────────────────────────────────

  Widget _buildSelectorPage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 10),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [accentPurple, lightPurple, accentPurple],
            ).createShader(bounds),
            child: const Icon(Icons.storefront, color: Colors.white, size: 52),
          ),
          const SizedBox(height: 12),
          ShaderMask(
            shaderCallback: (bounds) => LinearGradient(
              colors: [Colors.white, lightPurple],
            ).createShader(bounds),
            child: const Text(
              "SELLER PANEL",
              style: TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                letterSpacing: 3,
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            "Pilih menu untuk memulai",
            style: TextStyle(
              color: textGrey.withOpacity(0.6),
              fontSize: 13,
              fontFamily: 'ShareTechMono',
            ),
          ),
          const SizedBox(height: 40),

          Container(
            height: 1,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, accentPurple, Colors.transparent],
              ),
            ),
          ),
          const SizedBox(height: 32),

          _buildMenuCard(
            icon: FontAwesomeIcons.userPlus,
            title: "Create Account",
            subtitle: "Buat akun member baru (maks. 30 hari)",
            gradientFrom: const Color(0xFF2A0040),
            gradientTo: const Color(0xFF7B2FF7),
            glowColor: primaryPurple,
            onTap: () => _selectSection(SellerSection.createAccount),
          ),
          const SizedBox(height: 16),

          _buildMenuCard(
            icon: FontAwesomeIcons.clock,
            title: "Extend Duration",
            subtitle: "Perpanjang durasi akun member",
            gradientFrom: const Color(0xFF1A0040),
            gradientTo: const Color(0xFF5A1A8A),
            glowColor: lightPurple,
            onTap: () => _selectSection(SellerSection.extendDuration),
          ),
          const SizedBox(height: 16),

          _buildMenuCard(
            icon: FontAwesomeIcons.users,
            title: "Member List",
            subtitle: "Lihat semua daftar member kamu",
            gradientFrom: const Color(0xFF0A0020),
            gradientTo: const Color(0xFF3A0A6A),
            glowColor: accentPurple,
            onTap: () => _selectSection(SellerSection.listMember),
          ),

          const SizedBox(height: 40),
        ],
      ),
    );
  }

  Widget _buildMenuCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color gradientFrom,
    required Color gradientTo,
    required Color glowColor,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: TweenAnimationBuilder(
        tween: Tween<double>(begin: 1.0, end: 1.0),
        duration: const Duration(milliseconds: 150),
        builder: (context, double scale, child) {
          return Transform.scale(
            scale: scale,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0D0D0D), Color(0xFF0A0015)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: glowColor.withOpacity(0.4), width: 1.2),
                boxShadow: [
                  BoxShadow(
                    color: glowColor.withOpacity(0.12),
                    blurRadius: 20,
                    spreadRadius: 1,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [gradientFrom, gradientTo],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: glowColor.withOpacity(0.35),
                          blurRadius: 12,
                          spreadRadius: 1,
                        ),
                      ],
                    ),
                    child: Icon(icon, color: Colors.white, size: 26),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          subtitle,
                          style: TextStyle(
                            color: textGrey.withOpacity(0.6),
                            fontSize: 12,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: glowColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: glowColor.withOpacity(0.3)),
                    ),
                    child: Icon(Icons.arrow_forward_ios, color: glowColor, size: 14),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ── CREATE ACCOUNT SECTION ────────────────────────────────

  Widget _buildCreateSection() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildCard(
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildSectionHeader("CREATE MEMBER", FontAwesomeIcons.userPlus),
                const SizedBox(height: 24),

                Container(
                  padding: const EdgeInsets.all(14),
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: primaryPurple.withOpacity(0.07),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: accentPurple.withOpacity(0.25)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline, color: accentPurple, size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "Durasi maksimal 30 hari untuk reseller.",
                          style: TextStyle(color: lightPurple.withOpacity(0.8), fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),

                _buildInput(
                  label: "Username Baru",
                  controller: createUsernameController,
                  icon: FontAwesomeIcons.user,
                ),
                _buildInput(
                  label: "Password",
                  controller: createPasswordController,
                  icon: FontAwesomeIcons.lock,
                  obscure: true,
                ),
                _buildInput(
                  label: "Durasi (Hari)",
                  controller: createDayController,
                  icon: FontAwesomeIcons.calendarDay,
                  type: TextInputType.number,
                  hint: "Maksimal 30 hari",
                ),
                const SizedBox(height: 12),
                _buildPurpleButton(
                  label: "CREATE ACCOUNT",
                  icon: FontAwesomeIcons.userPlus,
                  onPressed: isLoading ? null : _createAccount,
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // ── EXTEND DURATION SECTION ───────────────────────────────

  Widget _buildExtendSection() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildCard(
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildSectionHeader("EXTEND DURATION", FontAwesomeIcons.clock),
                const SizedBox(height: 24),

                Container(
                  padding: const EdgeInsets.all(14),
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: lightPurple.withOpacity(0.07),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: lightPurple.withOpacity(0.25)),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.info_outline, color: lightPurple, size: 18),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "Tambah hari ke akun member yang sudah ada.",
                          style: TextStyle(color: lightPurple.withOpacity(0.8), fontSize: 13),
                        ),
                      ),
                    ],
                  ),
                ),

                _buildInput(
                  label: "Username Target",
                  controller: editUsernameController,
                  icon: FontAwesomeIcons.userEdit,
                  hint: "Username member yang diperpanjang",
                ),
                _buildInput(
                  label: "Tambah Hari",
                  controller: editDayController,
                  icon: FontAwesomeIcons.calendarPlus,
                  type: TextInputType.number,
                  hint: "Maksimal 30 hari",
                ),
                const SizedBox(height: 12),
                _buildPurpleButton(
                  label: "ADD DAYS",
                  icon: FontAwesomeIcons.calendarPlus,
                  onPressed: isLoading ? null : _editUser,
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }

  // ── MEMBER LIST SECTION ───────────────────────────────────

  Widget _buildListSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
          child: _buildCard(
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildSectionHeader("MEMBER LIST", FontAwesomeIcons.users),
                const SizedBox(height: 20),

                Row(
                  children: [
                    _buildStatChip(
                      label: "Total",
                      value: "${filteredList.length}",
                      icon: Icons.people_alt_outlined,
                    ),
                    const SizedBox(width: 10),
                    _buildStatChip(
                      label: "Halaman",
                      value: "$currentPage / ${totalPages == 0 ? 1 : totalPages}",
                      icon: Icons.menu_book_outlined,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),

        Expanded(
          child: isLoading
              ? Center(child: CircularProgressIndicator(color: accentPurple))
              : filteredList.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.person_off_outlined, color: textGrey, size: 52),
                          const SizedBox(height: 12),
                          Text("Tidak ada member ditemukan", style: TextStyle(color: textGrey)),
                        ],
                      ),
                    )
                  : ListView(
                      padding: const EdgeInsets.only(bottom: 20),
                      children: [
                        ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                        if (totalPages > 1)
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            child: _buildPagination(),
                          ),
                      ],
                    ),
        ),
      ],
    );
  }

  Widget _buildStatChip({
    required String label,
    required String value,
    required IconData icon,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: primaryPurple.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: accentPurple.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            Icon(icon, color: accentPurple, size: 16),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: TextStyle(color: textGrey, fontSize: 10)),
                Text(
                  value,
                  style: TextStyle(
                    color: primaryWhite,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: cardGlass,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: borderGlass),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.15),
              shape: BoxShape.circle,
              border: Border.all(color: accentPurple.withOpacity(0.3)),
            ),
            child: Icon(Icons.person, color: accentPurple),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user['username'],
                  style: TextStyle(
                    color: primaryWhite,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  "ROLE: ${user['role'].toString().toUpperCase()}  •  EXP: ${user['expiredDate']}",
                  style: TextStyle(color: textGrey.withOpacity(0.6), fontSize: 11),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        final isActive = currentPage == page;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isActive ? accentPurple : const Color(0xFF0D0D0D),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: isActive ? accentPurple : borderGlass),
              boxShadow: isActive
                  ? [BoxShadow(color: accentPurple.withOpacity(0.3), blurRadius: 8)]
                  : [],
            ),
            child: Center(
              child: Text(
                "$page",
                style: TextStyle(
                  color: isActive ? Colors.white : textGrey,
                  fontSize: 13,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  // ── BUILD ─────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgDark,
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [bgDark, primaryPurple.withOpacity(0.06), bgDark],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: _activeSection == SellerSection.none
                ? _buildSelectorPage()
                : _activeSection == SellerSection.createAccount
                    ? _buildCreateSection()
                    : _activeSection == SellerSection.extendDuration
                        ? _buildExtendSection()
                        : _buildListSection(),
          ),
        ),
      ),
    );
  }
}