import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // ===== VIDEO LANDING =====
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  // ===== VIDEO SPLASH (INTRO) =====
  VideoPlayerController? _splashController;
  bool _splashInitialized = false;
  bool _showSplash = false;

  String selectedBugId = "";
  bool _isSending = false;
  bool _isSuccess = false;
  int _activeStep = 0;
  bool _isProcessing = false;

  // ===== COOLDOWN =====
  int _cooldownSeconds = 0;
  Timer? _cooldownTimer;
  bool _isCooldown = false;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeVideoController();
    _setDefaultBug();
    _startAnimations();
    _loadCooldown();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _setDefaultBug() {
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  // ===== COOLDOWN =====
  Future<void> _loadCooldown() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedTime = prefs.getInt('cooldown_${widget.username}');
      if (savedTime != null) {
        final elapsed = DateTime.now().millisecondsSinceEpoch - savedTime;
        final remaining = 300 - (elapsed / 1000).round(); // 300 detik = 5 menit
        if (remaining > 0) {
          setState(() {
            _cooldownSeconds = remaining;
            _isCooldown = true;
          });
          _startCooldownTimer();
        } else {
          await prefs.remove('cooldown_${widget.username}');
        }
      }
    } catch (e) {
      // ignore
    }
  }

  void _startCooldownTimer() {
    _cooldownTimer?.cancel();
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_cooldownSeconds > 0) {
          _cooldownSeconds--;
        } else {
          _isCooldown = false;
          timer.cancel();
          _clearCooldown();
        }
      });
    });
  }

  Future<void> _clearCooldown() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('cooldown_${widget.username}');
    } catch (e) {
      // ignore
    }
  }

  Future<void> _setCooldown() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('cooldown_${widget.username}', DateTime.now().millisecondsSinceEpoch);
      setState(() {
        _cooldownSeconds = 300;
        _isCooldown = true;
      });
      _startCooldownTimer();
    } catch (e) {
      // ignore
    }
  }

  // ===== VIDEO LANDING =====
  void _initializeVideoController() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(0);
          }
        }).catchError((error) {
          print('Video initialization error: $error');
          if (mounted) {
            setState(() {
              _videoError = true;
            });
          }
        });
    } catch (e) {
      print('Video controller creation error: $e');
      if (mounted) {
        setState(() {
          _videoError = true;
        });
      }
    }
  }

  // ===== VIDEO SPLASH =====
  void _showSplashVideo() {
    if (_isCooldown) {
      _showAlert("⏳ Cooldown", "Tunggu ${_cooldownSeconds} detik lagi.");
      return;
    }

    try {
      _splashController = VideoPlayerController.asset('assets/videos/splash.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _splashInitialized = true;
              _showSplash = true;
            });
            
            _splashController!.setLooping(false);
            _splashController!.play();
            _splashController!.setVolume(1.0);
            
            _splashController!.addListener(() {
              if (_splashController!.value.position >= _splashController!.value.duration) {
                _splashController!.pause();
                _closeSplashAndSend();
              }
            });
          }
        }).catchError((error) {
          print('Splash video initialization error: $error');
          _closeSplashAndSend();
        });
    } catch (e) {
      print('Splash video creation error: $e');
      _closeSplashAndSend();
    }
  }

  void _closeSplashAndSend() {
    setState(() {
      _showSplash = false;
      _isProcessing = true;
    });
    
    Future.delayed(const Duration(milliseconds: 500), () {
      _executeSendBug();
    });
  }

  void _executeSendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
      setState(() {
        _isSending = false;
        _isProcessing = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/sendBug?key=$key&target=$target&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        // Set cooldown
        await _setCooldown();
        _showAlert("⏳ Cooldown", "Tunggu ${_cooldownSeconds} detik sebelum mengirim lagi.");
      } else if (data["senderOn"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Sender Kosong, Hubungi Seller.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Session key tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Mungkin server sedang maintenance.");
      } else {
        setState(() {
          _activeStep = 2;
          _isSuccess = true;
        });
        _showSuccessPopup(target);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
        _isProcessing = false;
        if (!_isSuccess) _activeStep = 0;
      });
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _showSuccessPopup(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => SuccessDialog(
        target: target,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() {
            _isSuccess = false;
            _activeStep = 0;
          });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    setState(() {
      _isSending = false;
      _isProcessing = false;
      _activeStep = 0;
    });
    
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: title.contains("Invalid") || title.contains("Gagal") || title.contains("Error") 
                    ? NeoBrutalismColors.pink 
                    : title.contains("Cooldown")
                        ? NeoBrutalismColors.yellow
                        : NeoBrutalismColors.purple,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: Icon(
                title.contains("Invalid") || title.contains("Gagal") || title.contains("Error") 
                    ? Icons.error_outline 
                    : title.contains("Cooldown")
                        ? Icons.timer_outlined
                        : Icons.info_outline,
                color: NeoBrutalismColors.white,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: TextStyle(
            color: NeoBrutalismColors.black.withOpacity(0.7),
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Inter',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: NeoBrutalismColors.yellow,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
              ),
            ),
            child: const Text(
              "OK",
              style: TextStyle(
                color: NeoBrutalismColors.black,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  // ==================== SPLASH OVERLAY ====================
  Widget _buildSplashOverlay() {
    if (!_showSplash || !_splashInitialized || _splashController == null) {
      return const SizedBox.shrink();
    }

    return Container(
      color: Colors.black.withOpacity(0.9),
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: Container(
          width: 658,
          height: 480,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white, width: 3),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 20,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: VideoPlayer(_splashController!),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ===== TITLE =====
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.purple,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoBrutalismColors.black.withOpacity(0.08),
                                  offset: const Offset(4, 4),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: const Icon(
                              FontAwesomeIcons.whatsapp,
                              color: NeoBrutalismColors.white,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            "Bug Attack",
                            style: TextStyle(
                              color: NeoBrutalismColors.black,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Inter',
                              letterSpacing: 1,
                            ),
                          ),
                          const Spacer(),
                          if (_isCooldown)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: NeoBrutalismColors.yellow.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(6),
                                border: Border.all(color: NeoBrutalismColors.yellow, width: 2),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.timer,
                                    color: NeoBrutalismColors.yellow,
                                    size: 14,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    "${_cooldownSeconds}s",
                                    style: TextStyle(
                                      color: NeoBrutalismColors.yellow,
                                      fontSize: 10,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // ===== USER CARD =====
                      _neoCard(
                        child: Row(
                          children: [
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: NeoBrutalismColors.purple,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                                boxShadow: [
                                  BoxShadow(
                                    color: NeoBrutalismColors.black.withOpacity(0.1),
                                    offset: const Offset(4, 4),
                                    blurRadius: 0,
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(7),
                                child: Image.asset(
                                  'assets/images/icon.jpg',
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => const Icon(
                                    Icons.person,
                                    color: NeoBrutalismColors.white,
                                    size: 26,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    widget.username,
                                    style: const TextStyle(
                                      color: NeoBrutalismColors.black,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Row(
                                    children: [
                                      Text(
                                        "EXP: ${widget.expiredDate.split(' ').first}",
                                        style: TextStyle(
                                          color: NeoBrutalismColors.darkGrey,
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          fontFamily: 'Inter',
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                        decoration: BoxDecoration(
                                          color: NeoBrutalismColors.purple,
                                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                          borderRadius: BorderRadius.circular(6),
                                          boxShadow: [
                                            BoxShadow(
                                              color: NeoBrutalismColors.black.withOpacity(0.08),
                                              offset: const Offset(3, 3),
                                              blurRadius: 0,
                                            ),
                                          ],
                                        ),
                                        child: Text(
                                          widget.role.toUpperCase(),
                                          style: const TextStyle(
                                            color: NeoBrutalismColors.white,
                                            fontSize: 8,
                                            fontWeight: FontWeight.w800,
                                            fontFamily: 'Inter',
                                            letterSpacing: 1,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== VIDEO LANDING FULL WIDTH =====
                      Container(
                        width: double.infinity,
                        height: 180,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(5, 5),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: _videoInitialized && !_videoError
                              ? Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    FittedBox(
                                      fit: BoxFit.cover,
                                      child: SizedBox(
                                        width: _videoController.value.size.width,
                                        height: _videoController.value.size.height,
                                        child: VideoPlayer(_videoController),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 10,
                                      right: 10,
                                      child: GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            if (_videoController.value.isPlaying) {
                                              _videoController.pause();
                                            } else {
                                              _videoController.play();
                                            }
                                          });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.all(8),
                                          decoration: BoxDecoration(
                                            color: NeoBrutalismColors.white,
                                            shape: BoxShape.circle,
                                            border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                            boxShadow: [
                                              BoxShadow(
                                                color: NeoBrutalismColors.black.withOpacity(0.08),
                                                offset: const Offset(3, 3),
                                                blurRadius: 0,
                                              ),
                                            ],
                                          ),
                                          child: Icon(
                                            _videoController.value.isPlaying ? Icons.pause : Icons.play_arrow,
                                            color: NeoBrutalismColors.black,
                                            size: 20,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              : Container(
                                  height: 180,
                                  color: NeoBrutalismColors.purple,
                                  child: const Center(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        CircularProgressIndicator(
                                          color: NeoBrutalismColors.white,
                                          strokeWidth: 2,
                                        ),
                                        SizedBox(height: 10),
                                        Text(
                                          "Loading Video...",
                                          style: TextStyle(
                                            color: NeoBrutalismColors.white,
                                            fontSize: 12,
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== PROGRESS =====
                      _neoCard(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        child: Row(
                          children: [
                            _buildStep(0, "Input", Icons.edit, _activeStep),
                            _buildLine(_activeStep > 0),
                            _buildStep(1, "Process", Icons.settings, _activeStep),
                            _buildLine(_activeStep > 1),
                            _buildStep(2, "Complete", Icons.check_circle, _activeStep),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== TARGET INPUT =====
                      _neoCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Target Number",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: targetController,
                              style: const TextStyle(
                                color: NeoBrutalismColors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter',
                              ),
                              cursorColor: NeoBrutalismColors.black,
                              decoration: InputDecoration(
                                hintText: "e.g. +62xxxxxxxxx",
                                hintStyle: TextStyle(
                                  color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w600,
                                ),
                                filled: true,
                                fillColor: NeoBrutalismColors.grey,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
                                ),
                                contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                                prefixIcon: Icon(
                                  FontAwesomeIcons.phone,
                                  color: NeoBrutalismColors.darkGrey,
                                  size: 18,
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              "Use international format without 0 or +",
                              style: TextStyle(
                                color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
                                fontSize: 11,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== BUG TYPE SELECTION =====
                      _neoCard(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Select Bug Type",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Container(
                              height: 110,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                physics: const BouncingScrollPhysics(),
                                itemCount: widget.listBug.length,
                                itemBuilder: (context, index) {
                                  final bug = widget.listBug[index];
                                  final isSelected = selectedBugId == bug['bug_id'];
                                  final bugName = bug['bug_name'] ?? '';
                                  final bugId = bug['bug_id'] ?? '';

                                  return GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        selectedBugId = bugId;
                                      });
                                    },
                                    child: Container(
                                      width: 180,
                                      height: 85,
                                      margin: const EdgeInsets.only(right: 14),
                                      padding: const EdgeInsets.all(14),
                                      decoration: BoxDecoration(
                                        color: isSelected ? NeoBrutalismColors.yellow : NeoBrutalismColors.white,
                                        borderRadius: BorderRadius.circular(16),
                                        border: Border.all(
                                          color: isSelected ? NeoBrutalismColors.borderColor : NeoBrutalismColors.black,
                                          width: isSelected ? 4 : 3,
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                            color: NeoBrutalismColors.black.withOpacity(0.2),
                                            offset: isSelected 
                                                ? const Offset(10, 10) 
                                                : const Offset(6, 6),
                                            blurRadius: 0,
                                          ),
                                        ],
                                      ),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            FontAwesomeIcons.virus,
                                            color: isSelected ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
                                            size: 28,
                                          ),
                                          const SizedBox(width: 12),
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                bugName,
                                                style: TextStyle(
                                                  color: isSelected ? NeoBrutalismColors.black : NeoBrutalismColors.black,
                                                  fontSize: 14,
                                                  fontWeight: isSelected ? FontWeight.w800 : FontWeight.w700,
                                                  fontFamily: 'Inter',
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              const SizedBox(height: 2),
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                                decoration: BoxDecoration(
                                                  color: isSelected ? NeoBrutalismColors.borderColor : NeoBrutalismColors.grey,
                                                  borderRadius: BorderRadius.circular(4),
                                                  border: Border.all(
                                                    color: isSelected ? NeoBrutalismColors.white : NeoBrutalismColors.borderColor,
                                                    width: 1,
                                                  ),
                                                ),
                                                child: Text(
                                                  "#$bugId",
                                                  style: TextStyle(
                                                    color: isSelected ? NeoBrutalismColors.white : NeoBrutalismColors.darkGrey,
                                                    fontSize: 10,
                                                    fontWeight: isSelected ? FontWeight.w800 : FontWeight.w600,
                                                    fontFamily: 'Inter',
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== STATUS =====
                      _neoCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "System Status",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _statusItem(FontAwesomeIcons.server, "Server", true),
                                _statusItem(FontAwesomeIcons.shieldAlt, "Security", true),
                                _statusItem(FontAwesomeIcons.database, "Database", true),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ===== SEND BUTTON =====
                      GestureDetector(
                        onTap: (_isSending || _isProcessing || _isCooldown) ? null : _showSplashVideo,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            color: (_isSending || _isProcessing || _isCooldown) 
                                ? NeoBrutalismColors.grey 
                                : NeoBrutalismColors.yellow,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: (_isSending || _isProcessing || _isCooldown) 
                                  ? NeoBrutalismColors.darkGrey 
                                  : NeoBrutalismColors.borderColor, 
                              width: 3,
                            ),
                            boxShadow: (_isSending || _isProcessing || _isCooldown) 
                                ? null 
                                : [
                                    BoxShadow(
                                      color: NeoBrutalismColors.black.withOpacity(0.2),
                                      offset: const Offset(8, 8),
                                      blurRadius: 0,
                                    ),
                                  ],
                          ),
                          child: Center(
                            child: (_isSending || _isProcessing)
                                ? const SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                      color: NeoBrutalismColors.black,
                                      strokeWidth: 2.5,
                                    ),
                                  )
                                : _isCooldown
                                    ? Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          const Icon(
                                            Icons.timer,
                                            color: NeoBrutalismColors.black,
                                            size: 20,
                                          ),
                                          const SizedBox(width: 8),
                                          Text(
                                            "TUNGGU ${_cooldownSeconds}s",
                                            style: const TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w800,
                                              letterSpacing: 1,
                                              color: NeoBrutalismColors.black,
                                              fontFamily: 'Inter',
                                            ),
                                          ),
                                        ],
                                      )
                                    : const Text(
                                        "SEND BUG",
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: 2,
                                          color: NeoBrutalismColors.black,
                                          fontFamily: 'Inter',
                                        ),
                                      ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),

                      // ===== FOOTER =====
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(3, 3),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Icon(
                              FontAwesomeIcons.exclamationTriangle,
                              color: NeoBrutalismColors.pink,
                              size: 14,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                "Use this tool responsibly. We are not responsible for any misuse.",
                                style: TextStyle(
                                  color: NeoBrutalismColors.darkGrey,
                                  fontSize: 11,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== COPYRIGHT =====
                      Column(
                        children: [
                          Container(
                            width: 40,
                            height: 3,
                            color: NeoBrutalismColors.borderColor,
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                            style: TextStyle(
                              fontSize: 9,
                              letterSpacing: 2,
                              color: NeoBrutalismColors.darkGrey,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          // ===== SPLASH OVERLAY =====
          if (_showSplash) _buildSplashOverlay(),
        ],
      ),
    );
  }

  Widget _buildStep(int step, String label, IconData icon, int active) {
    final isActive = active >= step;
    final isCurrent = active == step;
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: isActive ? NeoBrutalismColors.yellow : NeoBrutalismColors.grey,
              shape: BoxShape.circle,
              border: Border.all(
                color: isActive ? NeoBrutalismColors.borderColor : NeoBrutalismColors.darkGrey,
                width: isCurrent ? 3 : 2,
              ),
              boxShadow: isActive ? [
                BoxShadow(
                  color: NeoBrutalismColors.black.withOpacity(0.08),
                  offset: const Offset(3, 3),
                  blurRadius: 0,
                ),
              ] : null,
            ),
            child: Icon(icon, color: isActive ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey, size: 16),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
              fontSize: 9,
              fontFamily: 'Inter',
              fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLine(bool active) {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        color: active ? NeoBrutalismColors.borderColor : NeoBrutalismColors.darkGrey.withOpacity(0.3),
      ),
    );
  }

  Widget _statusItem(IconData icon, String label, bool isOnline) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isOnline ? NeoBrutalismColors.green.withOpacity(0.15) : NeoBrutalismColors.grey,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isOnline ? NeoBrutalismColors.green : NeoBrutalismColors.darkGrey.withOpacity(0.3),
              width: 2,
            ),
          ),
          child: Icon(icon, color: isOnline ? NeoBrutalismColors.green : NeoBrutalismColors.darkGrey, size: 18),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isOnline ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
            fontSize: 9,
            fontFamily: 'Inter',
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 2),
        Container(
          width: 30,
          height: 2,
          color: isOnline ? NeoBrutalismColors.green : NeoBrutalismColors.darkGrey.withOpacity(0.3),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _videoController.dispose();
    _splashController?.dispose();
    _cooldownTimer?.cancel();
    targetController.dispose();
    super.dispose();
  }
}

// ==================== SUCCESS DIALOG ====================
class SuccessDialog extends StatefulWidget {
  final String target;
  final VoidCallback onDismiss;

  const SuccessDialog({
    super.key,
    required this.target,
    required this.onDismiss,
  });

  @override
  State<SuccessDialog> createState() => _SuccessDialogState();
}

class _SuccessDialogState extends State<SuccessDialog> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );
    _fadeController.forward();
    _scaleController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: ScaleTransition(
          scale: _scaleAnimation,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: NeoBrutalismColors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
              boxShadow: [
                BoxShadow(
                  color: NeoBrutalismColors.black.withOpacity(0.12),
                  offset: const Offset(4, 4),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: NeoBrutalismColors.green, width: 2),
                  ),
                  child: const Icon(
                    FontAwesomeIcons.checkDouble,
                    color: NeoBrutalismColors.green,
                    size: 40,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  "ATTACK SUCCESSFUL!",
                  style: TextStyle(
                    color: NeoBrutalismColors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Inter',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Bug successfully sent to ${widget.target}",
                  style: TextStyle(
                    color: NeoBrutalismColors.darkGrey,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Inter',
                  ),
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: widget.onDismiss,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.yellow,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.08),
                          offset: const Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Text(
                        "DONE",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: NeoBrutalismColors.black,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}