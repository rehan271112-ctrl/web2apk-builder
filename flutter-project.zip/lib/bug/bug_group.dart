import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage> with TickerProviderStateMixin {
  final linkGroupController = TextEditingController();

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  bool _isSending = false;
  int _activeStep = 0;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeVideoController();
    _startAnimations();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _initializeVideoController() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(0);
          }
        }).catchError((error) {
          print('Video initialization error: $error');
          if (mounted) {
            setState(() {
              _videoError = true;
            });
          }
        });
    } catch (e) {
      print('Video controller creation error: $e');
      if (mounted) {
        setState(() {
          _videoError = true;
        });
      }
    }
  }

  bool _isValidGroupLink(String input) {
    final regex = RegExp(r'https://chat\.whatsapp\.com/[a-zA-Z0-9]{22}');
    return regex.hasMatch(input);
  }

  Future<void> _sendGroupBug() async {
    if (_isSending) return;

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    final linkGroup = linkGroupController.text.trim();
    final key = widget.sessionKey;

    if (linkGroup.isEmpty || !_isValidGroupLink(linkGroup)) {
      _showAlert("❌ Invalid Link", "Please enter a valid WhatsApp group link.");
      setState(() {
        _isSending = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/groupBug?key=$key&linkGroup=$linkGroup"));
      final data = jsonDecode(res.body);

      if (data["valid"] == false) {
        _showAlert("❌ Failed", data["message"] ?? "Failed to send group bug.");
      } else {
        setState(() {
          _activeStep = 2;
        });
        _showSuccessPopup(linkGroup, data);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
        if (_activeStep != 2) _activeStep = 0;
      });
    }
  }

  void _showSuccessPopup(String linkGroup, Map<String, dynamic> data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => GroupBugSuccessDialog(
        linkGroup: linkGroup,
        data: data,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() {
            _activeStep = 0;
          });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: title.contains("Invalid") ? NeoBrutalismColors.pink : NeoBrutalismColors.purple,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: Icon(
                title.contains("Invalid") ? Icons.error_outline : Icons.info_outline,
                color: NeoBrutalismColors.white,
                size: 18,
              ),
            ),
            const SizedBox(width: 12),
            Text(
              title,
              style: const TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 16,
                fontWeight: FontWeight.w800,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
        content: Text(
          msg,
          style: TextStyle(
            color: NeoBrutalismColors.black.withOpacity(0.7),
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Inter',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: NeoBrutalismColors.yellow,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
              ),
            ),
            child: const Text(
              "OK",
              style: TextStyle(
                color: NeoBrutalismColors.black,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.08),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  @override
  Widget build(BuildContext context) {
    final allowedRoles = ["dev", "high_pt", "pt", "helper", "admin"];
    if (!allowedRoles.contains(widget.role.toLowerCase())) {
      return Scaffold(
        backgroundColor: NeoBrutalismColors.grey,
        body: Stack(
          children: [
            _buildBackground(),
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.pink.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: NeoBrutalismColors.pink, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.08),
                          offset: const Offset(4, 4),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: const Icon(
                      FontAwesomeIcons.lock,
                      color: NeoBrutalismColors.pink,
                      size: 50,
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    "ACCESS DENIED",
                    style: TextStyle(
                      color: NeoBrutalismColors.pink,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      fontFamily: 'Inter',
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 32),
                    child: Text(
                      "This feature is only available for Dev, high_pt, and Admin users",
                      style: TextStyle(
                        color: NeoBrutalismColors.darkGrey,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Inter',
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: SlideTransition(
                  position: _slideAnimation,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ===== TITLE =====
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.purple,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoBrutalismColors.black.withOpacity(0.08),
                                  offset: const Offset(4, 4),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: const Icon(
                              FontAwesomeIcons.users,
                              color: NeoBrutalismColors.white,
                              size: 20,
                            ),
                          ),
                          const SizedBox(width: 12),
                          const Text(
                            "Group Bug",
                            style: TextStyle(
                              color: NeoBrutalismColors.black,
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              fontFamily: 'Inter',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),

                      // ===== USER CARD =====
                      _neoCard(
                        child: Row(
                          children: [
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: NeoBrutalismColors.purple,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                                boxShadow: [
                                  BoxShadow(
                                    color: NeoBrutalismColors.black.withOpacity(0.1),
                                    offset: const Offset(4, 4),
                                    blurRadius: 0,
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(7),
                                child: Image.asset(
                                  'assets/images/icon.jpg',
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, __, ___) => const Icon(
                                    Icons.person,
                                    color: NeoBrutalismColors.white,
                                    size: 26,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    widget.username,
                                    style: const TextStyle(
                                      color: NeoBrutalismColors.black,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Row(
                                    children: [
                                      Text(
                                        "EXP: ${widget.expiredDate.split(' ').first}",
                                        style: TextStyle(
                                          color: NeoBrutalismColors.darkGrey,
                                          fontSize: 10,
                                          fontWeight: FontWeight.w700,
                                          fontFamily: 'Inter',
                                        ),
                                      ),
                                      const SizedBox(width: 10),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                        decoration: BoxDecoration(
                                          color: NeoBrutalismColors.purple,
                                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                          borderRadius: BorderRadius.circular(6),
                                          boxShadow: [
                                            BoxShadow(
                                              color: NeoBrutalismColors.black.withOpacity(0.08),
                                              offset: const Offset(3, 3),
                                              blurRadius: 0,
                                            ),
                                          ],
                                        ),
                                        child: Text(
                                          widget.role.toUpperCase(),
                                          style: const TextStyle(
                                            color: NeoBrutalismColors.white,
                                            fontSize: 8,
                                            fontWeight: FontWeight.w800,
                                            fontFamily: 'Inter',
                                            letterSpacing: 1,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== VIDEO FULL WIDTH =====
                      Container(
                        width: double.infinity,
                        height: 180,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.08),
                              offset: const Offset(5, 5),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: _videoInitialized && !_videoError
                              ? Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    FittedBox(
                                      fit: BoxFit.cover,
                                      child: SizedBox(
                                        width: _videoController.value.size.width,
                                        height: _videoController.value.size.height,
                                        child: VideoPlayer(_videoController),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 10,
                                      right: 10,
                                      child: GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            if (_videoController.value.isPlaying) {
                                              _videoController.pause();
                                            } else {
                                              _videoController.play();
                                            }
                                          });
                                        },
                                        child: Container(
                                          padding: const EdgeInsets.all(8),
                                          decoration: BoxDecoration(
                                            color: NeoBrutalismColors.white,
                                            shape: BoxShape.circle,
                                            border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                            boxShadow: [
                                              BoxShadow(
                                                color: NeoBrutalismColors.black.withOpacity(0.08),
                                                offset: const Offset(3, 3),
                                                blurRadius: 0,
                                              ),
                                            ],
                                          ),
                                          child: Icon(
                                            _videoController.value.isPlaying ? Icons.pause : Icons.play_arrow,
                                            color: NeoBrutalismColors.black,
                                            size: 20,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                )
                              : Container(
                                  height: 180,
                                  color: NeoBrutalismColors.purple,
                                  child: const Center(
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        CircularProgressIndicator(
                                          color: NeoBrutalismColors.white,
                                          strokeWidth: 2,
                                        ),
                                        SizedBox(height: 10),
                                        Text(
                                          "Loading Video...",
                                          style: TextStyle(
                                            color: NeoBrutalismColors.white,
                                            fontSize: 12,
                                            fontFamily: 'Inter',
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== PROGRESS =====
                      _neoCard(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        child: Row(
                          children: [
                            _buildStep(0, "Input", Icons.edit, _activeStep),
                            _buildLine(_activeStep > 0),
                            _buildStep(1, "Process", Icons.settings, _activeStep),
                            _buildLine(_activeStep > 1),
                            _buildStep(2, "Complete", Icons.check_circle, _activeStep),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== INPUT LINK =====
                      _neoCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Group Link",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: linkGroupController,
                              style: const TextStyle(
                                color: NeoBrutalismColors.black,
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter',
                              ),
                              cursorColor: NeoBrutalismColors.black,
                              decoration: InputDecoration(
                                hintText: "https://chat.whatsapp.com/...",
                                hintStyle: TextStyle(
                                  color: NeoBrutalismColors.darkGrey.withOpacity(0.7),
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w600,
                                ),
                                filled: true,
                                fillColor: NeoBrutalismColors.grey,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
                                ),
                                contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                                prefixIcon: Icon(
                                  FontAwesomeIcons.link,
                                  color: NeoBrutalismColors.darkGrey,
                                  size: 18,
                                ),
                              ),
                            ),
                            const SizedBox(height: 10),
                            Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: NeoBrutalismColors.grey,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    FontAwesomeIcons.infoCircle,
                                    color: NeoBrutalismColors.purple,
                                    size: 14,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      "This tool will join the group, send a bug, and leave without any trace.",
                                      style: TextStyle(
                                        color: NeoBrutalismColors.darkGrey,
                                        fontSize: 11,
                                        fontFamily: 'Inter',
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== STATUS =====
                      _neoCard(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "System Status",
                              style: TextStyle(
                                color: NeoBrutalismColors.black,
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w800,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _statusItem(FontAwesomeIcons.server, "Server", true),
                                _statusItem(FontAwesomeIcons.shieldAlt, "Security", true),
                                _statusItem(FontAwesomeIcons.database, "Database", true),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),

                      // ===== SEND BUTTON =====
                      GestureDetector(
                        onTap: _isSending ? null : _sendGroupBug,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          decoration: BoxDecoration(
                            color: NeoBrutalismColors.yellow,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: NeoBrutalismColors.black.withOpacity(0.1),
                                offset: const Offset(4, 4),
                                blurRadius: 0,
                              ),
                            ],
                          ),
                          child: Center(
                            child: _isSending
                                ? const SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                      color: NeoBrutalismColors.black,
                                      strokeWidth: 2.5,
                                    ),
                                  )
                                : const Text(
                                    "ATTACK GROUP",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 2,
                                      color: NeoBrutalismColors.black,
                                      fontFamily: 'Inter',
                                    ),
                                  ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),

                      // ===== FOOTER =====
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.white,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              FontAwesomeIcons.exclamationTriangle,
                              color: NeoBrutalismColors.pink,
                              size: 14,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                "Use this tool responsibly.",
                                style: TextStyle(
                                  color: NeoBrutalismColors.darkGrey,
                                  fontSize: 11,
                                  fontFamily: 'Inter',
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),

                      // ===== COPYRIGHT =====
                      Column(
                        children: [
                          Container(
                            width: 40,
                            height: 3,
                            color: NeoBrutalismColors.borderColor,
                          ),
                          const SizedBox(height: 8),
                          const Text(
                            "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                            style: TextStyle(
                              fontSize: 9,
                              letterSpacing: 2,
                              color: NeoBrutalismColors.darkGrey,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Inter',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStep(int step, String label, IconData icon, int active) {
    final isActive = active >= step;
    final isCurrent = active == step;
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: isActive ? NeoBrutalismColors.yellow : NeoBrutalismColors.grey,
              shape: BoxShape.circle,
              border: Border.all(
                color: isActive ? NeoBrutalismColors.borderColor : NeoBrutalismColors.darkGrey,
                width: isCurrent ? 3 : 2,
              ),
              boxShadow: isActive ? [
                BoxShadow(
                  color: NeoBrutalismColors.black.withOpacity(0.08),
                  offset: const Offset(3, 3),
                  blurRadius: 0,
                ),
              ] : null,
            ),
            child: Icon(icon, color: isActive ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey, size: 16),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
              fontSize: 9,
              fontFamily: 'Inter',
              fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLine(bool active) {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        color: active ? NeoBrutalismColors.borderColor : NeoBrutalismColors.darkGrey.withOpacity(0.3),
      ),
    );
  }

  Widget _statusItem(IconData icon, String label, bool isOnline) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isOnline ? NeoBrutalismColors.green.withOpacity(0.15) : NeoBrutalismColors.grey,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isOnline ? NeoBrutalismColors.green : NeoBrutalismColors.darkGrey.withOpacity(0.3),
              width: 2,
            ),
          ),
          child: Icon(icon, color: isOnline ? NeoBrutalismColors.green : NeoBrutalismColors.darkGrey, size: 18),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            color: isOnline ? NeoBrutalismColors.black : NeoBrutalismColors.darkGrey,
            fontSize: 9,
            fontFamily: 'Inter',
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 2),
        Container(
          width: 30,
          height: 2,
          color: isOnline ? NeoBrutalismColors.green : NeoBrutalismColors.darkGrey.withOpacity(0.3),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _videoController.dispose();
    linkGroupController.dispose();
    super.dispose();
  }
}

// ==================== SUCCESS DIALOG ====================
class GroupBugSuccessDialog extends StatefulWidget {
  final String linkGroup;
  final Map<String, dynamic> data;
  final VoidCallback onDismiss;

  const GroupBugSuccessDialog({
    super.key,
    required this.linkGroup,
    required this.data,
    required this.onDismiss,
  });

  @override
  State<GroupBugSuccessDialog> createState() => _GroupBugSuccessDialogState();
}

class _GroupBugSuccessDialogState extends State<GroupBugSuccessDialog> with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );
    _fadeController.forward();
    _scaleController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _scaleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: FadeTransition(
        opacity: _fadeAnimation,
        child: ScaleTransition(
          scale: _scaleAnimation,
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: NeoBrutalismColors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
              boxShadow: [
                BoxShadow(
                  color: NeoBrutalismColors.black.withOpacity(0.12),
                  offset: const Offset(4, 4),
                  blurRadius: 0,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.green.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: NeoBrutalismColors.green, width: 2),
                  ),
                  child: const Icon(
                    FontAwesomeIcons.checkDouble,
                    color: NeoBrutalismColors.green,
                    size: 40,
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  "GROUP BUG SENT!",
                  style: TextStyle(
                    color: NeoBrutalismColors.black,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'Inter',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: NeoBrutalismColors.grey,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
                  ),
                  child: Column(
                    children: [
                      _detailRow("Group Link", widget.linkGroup),
                      _detailRow("Success", widget.data["success"] ? "Yes" : "No"),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                GestureDetector(
                  onTap: widget.onDismiss,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    decoration: BoxDecoration(
                      color: NeoBrutalismColors.yellow,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                      boxShadow: [
                        BoxShadow(
                          color: NeoBrutalismColors.black.withOpacity(0.08),
                          offset: const Offset(3, 3),
                          blurRadius: 0,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Text(
                        "DONE",
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w800,
                          color: NeoBrutalismColors.black,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
            width: 100,
            child: Text(
              "$label:",
              style: TextStyle(
                color: NeoBrutalismColors.darkGrey,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                fontFamily: 'Inter',
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}