// ============================================================================
//  DOUYIN FEED PAGE — Pure InAppWebView (No Overlay Buttons)
//
//  Hanya InAppWebView yang memuat https://www.douyin.com/ + 1 tombol panah
//  back di pojok kiri atas untuk kembali ke dashboard.
//
//  Tidak ada: top tabs, search, bottom nav, pull-to-refresh, loading branding,
//  error state dengan tombol — semua dihilangkan agar video Douyin full-screen
//  tanpa penghalang.
//
//  Dependensi: flutter_inappwebview: ^6.1.5
// ============================================================================

import 'package:flutter/material.dart';
import 'color_theme.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class DouyinFeedPage extends StatefulWidget {
  const DouyinFeedPage({super.key});

  @override
  State<DouyinFeedPage> createState() => _DouyinFeedPageState();
}

class _DouyinFeedPageState extends State<DouyinFeedPage>
    with WidgetsBindingObserver, TickerProviderStateMixin {
  InAppWebViewController? _webController;
  bool _hasError = false;
  bool _isLoading = true; // true sampai onLoadStop pertama

  // === Animation controllers untuk loading screen ===
  late AnimationController _pulseController; // logo scale + glow
  late AnimationController _dotsController; // 3 dots bounce
  late AnimationController _fadeController; // text fade in/out

  // Mobile UA — Douyin versi mobile lebih ringan & cepat
  static const String _mobileUA =
      'Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

  // CSS minimal — hanya disable text selection & hide download banner Douyin.
  // Sisanya biarkan apa adanya agar tidak mengganggu UI asli Douyin.
  static const String _cleanupCss = r'''
    (function() {
      if (window.__douyinCleaned) return;
      window.__douyinCleaned = true;
      const style = document.createElement('style');
      style.innerHTML = `
        * {
          -webkit-touch-callout: none;
          -webkit-user-select: none;
          user-select: none;
          -webkit-tap-highlight-color: transparent;
        }
        [data-e2e="download-btn"], .download-bar, .dy-tip {
          display: none !important;
        }
        video {
          object-fit: cover !important;
        }
      `;
      (document.head || document.documentElement).appendChild(style);
    })();
  ''';

  // JS autoplay — pastikan video langsung play saat load & saat swipe
  static const String _enableAutoplay = r'''
    (function() {
      const play = function() {
        const v = document.querySelector('video');
        if (v) {
          v.setAttribute('playsinline', 'true');
          v.setAttribute('webkit-playsinline', 'true');
          v.muted = false;
          v.volume = 1.0;
          v.play().catch(function(){});
        }
      };
      play();
      if (!window.__douyinAutoPlayObserver) {
        window.__douyinAutoPlayObserver = new MutationObserver(function(mutations) {
          mutations.forEach(function(m) {
            m.addedNodes.forEach(function(node) {
              if (node.nodeName === 'VIDEO' ||
                  (node.querySelector && node.querySelector('video'))) {
                const v = node.nodeName === 'VIDEO'
                    ? node
                    : node.querySelector('video');
                if (v) {
                  v.setAttribute('playsinline', 'true');
                  v.muted = false;
                  v.volume = 1.0;
                  v.play().catch(function(){});
                }
              }
            });
          });
        });
        window.__douyinAutoPlayObserver.observe(document.body, {
          childList: true, subtree: true
        });
      }
    })();
  ''';

  @override
  void initState() {
    super.initState();
    AppThemeController.instance.addListener(_onThemeChanged);
    WidgetsBinding.instance.addObserver(this);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

    // === Init animasi loading ===
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1100),
    )..repeat(reverse: true); // 0.85 ↔ 1.15

    _dotsController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(); // 0 → 1 loop

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true); // 0.4 ↔ 1.0
  }

  @override

  void _onThemeChanged() => mounted ? setState(() {}) : null;
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pulseController.dispose();
    _dotsController.dispose();
    _fadeController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    AppThemeController.instance.removeListener(_onThemeChanged);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_webController == null) return;
    if (state == AppLifecycleState.resumed) {
      _webController!.evaluateJavascript(source: r'''
        (function(){const v=document.querySelector('video');if(v)v.play().catch(function(){});})();
      ''');
    } else if (state == AppLifecycleState.paused) {
      _webController!.evaluateJavascript(source: r'''
        (function(){const v=document.querySelector('video');if(v)v.pause();})();
      ''');
    }
  }

  void _goBack() {
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    } else {
      SystemNavigator.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // === INAPPWEBVIEW — full screen, no obstruction ===
          Positioned.fill(
            child: InAppWebView(
              key: const ValueKey('douyin_webview'),
              initialUrlRequest: URLRequest(
                url: WebUri('https://www.douyin.com/?recommend=1'),
              ),
              initialSettings: InAppWebViewSettings(
                useHybridComposition: true,
                hardwareAcceleration: true,
                mediaPlaybackRequiresUserGesture: false,
                allowsInlineMediaPlayback: true,
                allowsAirPlayForMediaPlayback: true,
                cacheEnabled: true,
                clearCache: false,
                domStorageEnabled: true,
                databaseEnabled: true,
                sharedCookiesEnabled: true,
                loadWithOverviewMode: true,
                useWideViewPort: false,
                supportZoom: false,
                textZoom: 100,
                javaScriptEnabled: true,
                userAgent: _mobileUA,
                transparentBackground: false,
                disableDefaultErrorPage: true,
                allowFileAccess: true,
                allowContentAccess: true,
                verticalScrollBarEnabled: false,
                horizontalScrollBarEnabled: false,
                useShouldInterceptRequest: false,
                useShouldOverrideUrlLoading: false,
              ),
              onWebViewCreated: (controller) {
                _webController = controller;
              },
              onLoadStart: (controller, url) {
                if (mounted) setState(() => _isLoading = true);
              },
              onLoadStop: (controller, url) async {
                await controller.evaluateJavascript(source: _cleanupCss);
                await controller.evaluateJavascript(source: _enableAutoplay);
                if (mounted) {
                  setState(() {
                    _hasError = false;
                    _isLoading = false; // hide loading overlay
                  });
                }
              },
              onLoadError: (controller, url, code, message) {
                if (mounted) {
                  setState(() {
                    _hasError = true;
                    _isLoading = false; // hide loading biar error badge kelihatan
                  });
                }
              },
              onReceivedError: (controller, request, error) {
                if (mounted &&
                    request.isForMainFrame == true) {
                  setState(() => _hasError = true);
                }
              },
              onPermissionRequest: (controller, request) async {
                return PermissionResponse(
                  resources: request.resources,
                  action: PermissionResponseAction.GRANT,
                );
              },
              onCreateWindow: (controller, createWindowAction) async {
                final url = createWindowAction.request.url;
                if (url != null) {
                  await controller.loadUrl(urlRequest: URLRequest(url: url));
                }
                return true;
              },
            ),
          ),

          // === ANIMATED LOADING OVERLAY ===
          // Muncul sebelum WebView selesai load. Bisa di-tap untuk skip
          // (langsung hide, biar user lihat progress webview apa adanya).
          if (_isLoading)
            Positioned.fill(
              child: _buildAnimatedLoading(),
            ),

          // === BACK ARROW BUTTON (top-left, semi-transparan) ===
          // Hanya tombol ini yang overlay di atas WebView
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            left: 8,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: _goBack,
                borderRadius: BorderRadius.circular(24),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.35),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                    size: 22,
                  ),
                ),
              ),
            ),
          ),

          // === MINIMAL ERROR BADGE (jika load gagal) ===
          // Hanya indikator kecil, tidak ada tombol — user bisa tap back arrow
          // untuk kembali ke dashboard & coba lagi.
          if (_hasError)
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              right: 8,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.wifi_off, color: Colors.white, size: 14),
                    SizedBox(width: 4),
                    Text(
                      'Koneksi bermasalah',
                      style: TextStyle(color: Colors.white, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ===========================================================================
  //  ANIMATED LOADING OVERLAY
  //  - Logo Douyin-style (musik note) dengan pulse scale + glow shadow
  //  - Text "抖音" putih bold dengan letter spacing
  //  - 3 dots bounce (staggered) sebagai progress indicator
  //  - Subtitle fade in/out "Memuat Douyin..."
  //  - Tap untuk skip (langsung hide overlay)
  // ===========================================================================
  Widget _buildAnimatedLoading() {
    return GestureDetector(
      onTap: () {
        // Tap untuk skip loading overlay ( WebView tetap load di background)
        if (mounted) setState(() => _isLoading = false);
      },
      behavior: HitTestBehavior.opaque,
      child: Container(
        color: Colors.black,
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // === Logo dengan pulse animation + glow ===
              AnimatedBuilder(
                animation: _pulseController,
                builder: (context, child) {
                  // Pulse curve: easeInOut supaya halus
                  final t = Curves.easeInOut.transform(_pulseController.value);
                  final scale = 0.85 + (0.30 * t); // 0.85 → 1.15
                  final glowOpacity = 0.30 + (0.40 * t); // 0.30 → 0.70
                  return Transform.scale(
                    scale: scale,
                    child: Container(
                      width: 84,
                      height: 84,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFE2C55),
                        borderRadius: BorderRadius.circular(22),
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFFFE2C55)
                                .withOpacity(glowOpacity),
                            blurRadius: 28 + (20 * t),
                            spreadRadius: 2 + (4 * t),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.music_note,
                        color: Colors.white,
                        size: 52,
                      ),
                    ),
                  );
                },
              ),

              const SizedBox(height: 26),

              // === Text "抖音" ===
              const Text(
                '抖音',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 6,
                  fontFamily: 'sans-serif',
                ),
              ),

              const SizedBox(height: 10),

              // === Subtitle fade in/out ===
              AnimatedBuilder(
                animation: _fadeController,
                builder: (context, child) {
                  // 0.4 → 1.0
                  final opacity = 0.4 + (0.6 * _fadeController.value);
                  return Opacity(
                    opacity: opacity,
                    child: child,
                  );
                },
                child: const Text(
                  'Memuat Douyin...',
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 14,
                    letterSpacing: 0.5,
                  ),
                ),
              ),

              const SizedBox(height: 36),

              // === 3 dots bounce (staggered) ===
              AnimatedBuilder(
                animation: _dotsController,
                builder: (context, _) {
                  return Row(
                    mainAxisSize: MainAxisSize.min,
                    children: List.generate(3, (i) {
                      // Stagger setiap dot 0.2 phase shift
                      final phase =
                          (_dotsController.value + (i * 0.2)) % 1.0;
                      // Curve bounce: dot scale naik-turun
                      final bounce = Curves.easeInOut.transform(
                        phase < 0.5 ? phase * 2 : (1 - phase) * 2,
                      );
                      final scale = 0.6 + (0.6 * bounce);
                      final opacity = 0.4 + (0.6 * bounce);

                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 5),
                        child: Transform.scale(
                          scale: scale,
                          child: Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: const Color(0xFFFE2C55)
                                  .withOpacity(opacity),
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                      );
                    }),
                  );
                },
              ),

              const SizedBox(height: 28),

              // === Hint text "Tap untuk lewati" ===
              Text(
                'Tap untuk lewati',
                style: TextStyle(
                  color: Colors.white.withOpacity(0.25),
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
