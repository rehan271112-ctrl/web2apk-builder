import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';

// ==================== IMPORT BASEURL ====================
import '../server/domain_server.dart' show baseUrl;

// ==================== IMPORT CHANGE PASSWORD ====================
import 'admin/change_password_page.dart';

// ==================== IMPORT LOGIN PAGE ====================
import 'login_page.dart';

// ==================== NEOBRUTALISM COLOR PALETTE ====================
class NeoBrutalismColors {
  static const Color yellow = Color(0xFFFFD700);
  static const Color pink = Color(0xFFFF6B8A);
  static const Color blue = Color(0xFF4A7CF7);
  static const Color purple = Color(0xFF8B5CF6);
  static const Color green = Color(0xFF22C55E);
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF1A1A1A);
  static const Color grey = Color(0xFFF5F0EB);
  static const Color darkGrey = Color(0xFF8888AA);
  static const Color borderColor = Color(0xFF1A1A1A);
}

// ==================== GRID PAINTER ====================
class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = NeoBrutalismColors.borderColor.withOpacity(0.05)
      ..strokeWidth = 1;
    
    const spacing = 30.0;
    
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class ProfilePage extends StatefulWidget {
  final String username;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const ProfilePage({
    super.key,
    required this.username,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  bool _isLoading = true;
  bool _showPassword = false;
  String _password = "";
  String _key = "";
  
  // ===== PROFILE IMAGE =====
  File? _profileImage;
  final ImagePicker _picker = ImagePicker();

  // ==================== BACKGROUND ====================
  Widget _buildBackground() {
    return Container(
      color: NeoBrutalismColors.grey,
      child: CustomPaint(
        painter: GridPainter(),
        size: Size.infinite,
      ),
    );
  }

  // ==================== NEOBRUTALISM HELPERS ====================
  Widget _neoCard({
    required Widget child,
    Color bg = NeoBrutalismColors.white,
    double radius = 12,
    double shadowOffset = 5,
    EdgeInsets padding = const EdgeInsets.all(16),
  }) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
        boxShadow: [
          BoxShadow(
            color: NeoBrutalismColors.black.withOpacity(0.15),
            offset: Offset(shadowOffset, shadowOffset),
            blurRadius: 0,
          ),
        ],
      ),
      child: child,
    );
  }

  @override
  void initState() {
    super.initState();
    _fetchUserData();
    _loadProfileImage();
  }

  // ==================== LOAD PROFILE IMAGE ====================
  Future<void> _loadProfileImage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final imagePath = prefs.getString('profile_image_${widget.username}');
      if (imagePath != null && imagePath.isNotEmpty) {
        final file = File(imagePath);
        if (await file.exists()) {
          setState(() {
            _profileImage = file;
          });
        }
      }
    } catch (e) {
      print('Error loading profile image: $e');
    }
  }

  // ==================== SAVE PROFILE IMAGE ====================
  Future<void> _saveProfileImage(File image) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('profile_image_${widget.username}', image.path);
      
      // Trigger refresh di loader_page.dart
      // SharedPreferences akan otomatis terbaca oleh loader_page
    } catch (e) {
      print('Error saving profile image: $e');
    }
  }

  // ==================== PICK IMAGE FROM GALLERY ====================
  Future<void> _pickImage() async {
    try {
      final XFile? image = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 85,
      );
      
      if (image != null) {
        final File file = File(image.path);
        setState(() {
          _profileImage = file;
        });
        
        // Simpan path ke SharedPreferences
        await _saveProfileImage(file);
      }
    } catch (e) {
      print('Error picking image: $e');
    }
  }

  // ==================== FETCH USER DATA ====================
  Future<void> _fetchUserData() async {
    setState(() => _isLoading = true);
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/api/user/myInfo?key=${widget.sessionKey}'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _password = data['password'] ?? "••••••••";
            _key = data['key'] ?? widget.sessionKey;
            _isLoading = false;
          });
        } else {
          setState(() => _isLoading = false);
        }
      } else {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      print('Error fetching user data: $e');
      setState(() => _isLoading = false);
    }
  }

  // ==================== NAVIGATION ====================
  void _navigateToChangePassword() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChangePasswordPage(
          username: widget.username,
          sessionKey: widget.sessionKey,
        ),
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: NeoBrutalismColors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 3),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: NeoBrutalismColors.pink,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
              ),
              child: const Icon(Icons.logout, color: NeoBrutalismColors.white, size: 20),
            ),
            const SizedBox(width: 12),
            const Text(
              "Logout",
              style: TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 18,
                fontWeight: FontWeight.w900,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
        content: Text(
          "Are you sure you want to logout?",
          style: TextStyle(
            color: NeoBrutalismColors.black.withOpacity(0.7),
            fontSize: 14,
            fontWeight: FontWeight.w600,
            fontFamily: 'Inter',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            style: TextButton.styleFrom(
              backgroundColor: NeoBrutalismColors.grey,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
              ),
            ),
            child: const Text(
              "Cancel",
              style: TextStyle(
                color: NeoBrutalismColors.black,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            style: TextButton.styleFrom(
              backgroundColor: NeoBrutalismColors.pink,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(color: NeoBrutalismColors.borderColor, width: 2),
              ),
            ),
            child: const Text(
              "Yes, Logout",
              style: TextStyle(
                color: NeoBrutalismColors.white,
                fontFamily: 'Inter',
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== UI BUILD ====================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: NeoBrutalismColors.grey,
      body: Stack(
        children: [
          _buildBackground(),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ===== HEADER =====
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: NeoBrutalismColors.purple,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: NeoBrutalismColors.black.withOpacity(0.15),
                              offset: const Offset(6, 6),
                              blurRadius: 0,
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.person,
                          color: NeoBrutalismColors.white,
                          size: 22,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Text(
                        "My Profile",
                        style: TextStyle(
                          color: NeoBrutalismColors.black,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                          fontFamily: 'Inter',
                          letterSpacing: 1,
                        ),
                      ),
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: _getRoleColor().withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: _getRoleColor().withOpacity(0.3), width: 2),
                        ),
                        child: Text(
                          widget.role.toUpperCase(),
                          style: TextStyle(
                            color: _getRoleColor(),
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            fontFamily: 'Inter',
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // ===== PROFILE CARD =====
                  _neoCard(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      children: [
                        // ===== FOTO PROFIL =====
                        GestureDetector(
                          onTap: _pickImage,
                          child: Stack(
                            children: [
                              Container(
                                width: 120,
                                height: 120,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: NeoBrutalismColors.purple, width: 4),
                                  boxShadow: [
                                    BoxShadow(
                                      color: NeoBrutalismColors.black.withOpacity(0.2),
                                      offset: const Offset(8, 8),
                                      blurRadius: 0,
                                    ),
                                  ],
                                ),
                                child: ClipOval(
                                  child: _profileImage != null
                                      ? Image.file(
                                          _profileImage!,
                                          width: 120,
                                          height: 120,
                                          fit: BoxFit.cover,
                                        )
                                      : Image.asset(
                                          'assets/images/icon.jpg',
                                          width: 120,
                                          height: 120,
                                          fit: BoxFit.cover,
                                          errorBuilder: (_, __, ___) => Container(
                                            color: NeoBrutalismColors.purple,
                                            child: const Icon(
                                              Icons.person,
                                              color: NeoBrutalismColors.white,
                                              size: 60,
                                            ),
                                          ),
                                        ),
                                ),
                              ),
                              // ===== ICON KAMERA =====
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: NeoBrutalismColors.yellow,
                                    shape: BoxShape.circle,
                                    border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                                    boxShadow: [
                                      BoxShadow(
                                        color: NeoBrutalismColors.black.withOpacity(0.15),
                                        offset: const Offset(4, 4),
                                        blurRadius: 0,
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.camera_alt,
                                    color: NeoBrutalismColors.black,
                                    size: 20,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 12),
                        GestureDetector(
                          onTap: _pickImage,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.grey,
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                            ),
                            child: const Text(
                              "Tap to change photo",
                              style: TextStyle(
                                color: NeoBrutalismColors.darkGrey,
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter',
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        
                        // ===== NAMA =====
                        Text(
                          widget.username,
                          style: const TextStyle(
                            color: NeoBrutalismColors.black,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            fontFamily: 'Inter',
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 6),
                        
                        // ===== ROLE BADGE =====
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                          decoration: BoxDecoration(
                            color: _getRoleColor().withOpacity(0.15),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: _getRoleColor().withOpacity(0.3), width: 2),
                          ),
                          child: Text(
                            widget.role.toUpperCase(),
                            style: TextStyle(
                              color: _getRoleColor(),
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              fontFamily: 'Inter',
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                        
                        const SizedBox(height: 20),
                        
                        // ===== DIVIDER =====
                        Container(
                          height: 2,
                          color: NeoBrutalismColors.borderColor.withOpacity(0.3),
                        ),
                        const SizedBox(height: 20),
                        
                        // ===== INFO DETAILS =====
                        if (_isLoading)
                          const Center(
                            child: SizedBox(
                              height: 80,
                              child: Center(
                                child: CircularProgressIndicator(
                                  color: NeoBrutalismColors.purple,
                                ),
                              ),
                            ),
                          )
                        else ...[
                          _buildInfoRow(Icons.person, "Username", widget.username),
                          _buildInfoRow(Icons.admin_panel_settings, "Role", widget.role.toUpperCase()),
                          _buildInfoRow(Icons.calendar_today, "Expired", widget.expiredDate),
                          _buildPasswordRow(),
                          _buildInfoRow(Icons.vpn_key, "Session Key", _key.length > 20 ? "${_key.substring(0, 15)}..." : _key),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),

                  // ===== CHANGE PASSWORD =====
                  GestureDetector(
                    onTap: _navigateToChangePassword,
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: NeoBrutalismColors.borderColor, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: NeoBrutalismColors.black.withOpacity(0.15),
                            offset: const Offset(6, 6),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.yellow,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: NeoBrutalismColors.borderColor, width: 2),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoBrutalismColors.black.withOpacity(0.1),
                                  offset: const Offset(3, 3),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.lock_reset,
                              color: NeoBrutalismColors.black,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Change Password",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.black,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                                Text(
                                  "Update your account password",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.darkGrey,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios,
                            color: NeoBrutalismColors.darkGrey,
                            size: 14,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  
                  // ===== LOGOUT =====
                  GestureDetector(
                    onTap: _showLogoutDialog,
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: NeoBrutalismColors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: NeoBrutalismColors.pink, width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: NeoBrutalismColors.black.withOpacity(0.15),
                            offset: const Offset(6, 6),
                            blurRadius: 0,
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: NeoBrutalismColors.pink.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: NeoBrutalismColors.pink, width: 2),
                              boxShadow: [
                                BoxShadow(
                                  color: NeoBrutalismColors.black.withOpacity(0.1),
                                  offset: const Offset(3, 3),
                                  blurRadius: 0,
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.logout,
                              color: NeoBrutalismColors.pink,
                              size: 22,
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  "Logout",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.pink,
                                    fontSize: 15,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                                Text(
                                  "Sign out from your account",
                                  style: TextStyle(
                                    color: NeoBrutalismColors.darkGrey,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Inter',
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(
                            Icons.arrow_forward_ios,
                            color: NeoBrutalismColors.pink,
                            size: 14,
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 20),

                  // ===== COPYRIGHT =====
                  Column(
                    children: [
                      Container(
                        width: 40,
                        height: 3,
                        color: NeoBrutalismColors.borderColor,
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "© 2026 X•RZYN V1 PROJECT • ALL RIGHTS RESERVED",
                        style: TextStyle(
                          fontSize: 9,
                          letterSpacing: 2,
                          color: NeoBrutalismColors.darkGrey,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.grey,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
      ),
      child: Row(
        children: [
          Icon(icon, color: NeoBrutalismColors.purple, size: 18),
          const SizedBox(width: 10),
          Text(
            "$label:",
            style: const TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              fontFamily: 'Inter',
            ),
          ),
          const Spacer(),
          Expanded(
            flex: 2,
            child: Text(
              value,
              style: const TextStyle(
                color: NeoBrutalismColors.black,
                fontSize: 12,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
              textAlign: TextAlign.right,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPasswordRow() {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: NeoBrutalismColors.grey,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: NeoBrutalismColors.borderColor, width: 1),
      ),
      child: Row(
        children: [
          const Icon(Icons.lock, color: NeoBrutalismColors.purple, size: 18),
          const SizedBox(width: 10),
          const Text(
            "Password:",
            style: TextStyle(
              color: NeoBrutalismColors.darkGrey,
              fontSize: 12,
              fontWeight: FontWeight.w700,
              fontFamily: 'Inter',
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () {
              setState(() {
                _showPassword = !_showPassword;
              });
            },
            child: Row(
              children: [
                Text(
                  _showPassword ? _password : "••••••••",
                  style: TextStyle(
                    color: _showPassword ? NeoBrutalismColors.purple : NeoBrutalismColors.black,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Inter',
                  ),
                ),
                const SizedBox(width: 6),
                Icon(
                  _showPassword ? Icons.visibility_off : Icons.visibility,
                  color: NeoBrutalismColors.purple,
                  size: 16,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor() {
    switch (widget.role.toLowerCase()) {
      case 'dev': return NeoBrutalismColors.pink;
      case 'pendiri': return NeoBrutalismColors.pink;
      case 'admin': return NeoBrutalismColors.pink;
      case 'reseller': return NeoBrutalismColors.blue;
      case 'vip': return NeoBrutalismColors.yellow;
      default: return NeoBrutalismColors.purple;
    }
  }
}